# Provider Integrations

This directory contains built-in integrations for local API providers. Each integration is a single `.js` file that exports a CommonJS object through `module.exports`. Files are discovered by `GET /providers/integrations`, copied to `dist/local/integrations` during the API build, and can be selected in the provider form.

An integration describes how a provider connects to an external system, receives data, converts it into NQ devices, and sends commands from the application back to those devices.

## Quick Template

```js
module.exports = {
  name: "My Integration",
  type: "mqtt",
  requiresMqtt: true,
  mqtt: {
    topic: "my-integration",
    server: "mqtt://localhost:1883",
  },

  icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 12h16"/></svg>',

  configFields: [
    {
      key: "sampleOption",
      type: "string",
      label: "Sample option",
      default: "value",
      required: false,
    },
  ],

  init: async function (ctx) {
    const baseTopic = this.getBaseTopic(ctx);
    await ctx.mqtt?.subscribe(`${baseTopic}/#`, () => {});
  },

  destroy: function (ctx) {},

  onMessage: async function (topic, payload, ctx) {
    const baseTopic = this.getBaseTopic(ctx);
    const relativeTopic = this.getRelativeTopic(baseTopic, topic);
    if (!relativeTopic || relativeTopic.endsWith("/set")) return;

    ctx.events.stateChange({
      externalId: relativeTopic,
      friendlyName: relativeTopic,
      model: "example",
      vendor: "my-integration",
      definitionId: "my-integration-device",
      available: true,
      state: payload && typeof payload === "object" ? payload : { value: payload },
      metadata: { sourceTopic: topic },
    });
  },

  sendCommand: async function (ctx, deviceId, command) {
    const baseTopic = this.getBaseTopic(ctx);
    await ctx.mqtt?.publish(`${baseTopic}/${deviceId}/set`, command || {});
  },

  getDevices: async function (cachedDevices, ctx) {
    return cachedDevices.map((device) => ({
      ...device,
      provider: device.provider || ctx?.providerId || ctx?.provider?._id,
      definitionId: device.definitionId || "my-integration-device",
    }));
  },

  getDefinitions: async function (devices, ctx) {
    const provider = ctx?.providerId || ctx?.provider?._id;
    return [
      {
        id: "my-integration-device",
        name: "My Integration Device",
        provider,
        metadata: { type: "example" },
        fields: [
          { key: "value", name: "Value", type: "string", control: false },
          { key: "power", name: "Power", type: "boolean", control: true },
        ],
      },
    ];
  },

  getBaseTopic: function (ctx) {
    return (ctx.mqtt?.config?.topic || "my-integration").replace(/\/[#+]$/, "");
  },

  getRelativeTopic: function (baseTopic, topic) {
    if (topic === baseTopic) return "";
    const prefix = `${baseTopic}/`;
    if (!topic.startsWith(prefix)) return null;
    return topic.slice(prefix.length);
  },
};
```

## Where To Add Files

Add a new integration as a JavaScript file in this directory, for example `my-integration.js`. The file name is stored in `provider.integration`, so keep it stable. Renaming an existing integration file will break providers that still reference the old file name.

A provider can use an integration in a few ways:

- through the UI: the form fetches the list from `GET /providers/integrations` and stores the selected `filename` in `integration`,
- through the API: send `integration: "my-integration.js"` when creating a provider,
- as a relative or absolute path: the loader checks locations such as `integrations`, `apps/local/api/integrations`, and `dist/local/integrations`.

When `integration` is set, the provider logic is read from the file and is not stored in the database `logic` field. The `logic` field is used for custom providers entered inline.

## Export Structure

An integration must export an object:

```js
module.exports = {
  name: "Display Name",
  type: "mqtt",
  requiresMqtt: true,
  mqtt: { topic: "base-topic", server: "mqtt://localhost:1883" },
  configFields: [],
  init: async function (ctx) {},
  onMessage: async function (topic, payload, ctx) {},
  sendCommand: async function (ctx, deviceId, command) {},
  getDevices: async function (cachedDevices, ctx) { return cachedDevices; },
  getDefinitions: async function (devices, ctx) { return []; },
};
```

### Metadata Fields

- `name` - display name shown in the integrations UI.
- `type` - descriptive integration type, for example `mqtt` or `local`. The code does not enforce specific values, but existing conventions should be reused.
- `requiresMqtt` - when `true`, the provider always requires MQTT; when `false`, the provider works locally without MQTT; when omitted, the decision comes from the provider `mqttConnection` field.
- `mqtt` - default MQTT configuration. It is merged with existing provider configuration and form data.
- `icon` - optional inline SVG shown in the UI.
- `configFields` - configuration fields rendered in the provider form.

### MQTT Configuration

`mqtt` can contain:

```js
mqtt: {
  server: "mqtt://localhost:1883",
  topic: "zigbee2mqtt",
  username: "optional",
  password: "optional",
}
```

For MQTT integrations, set `requiresMqtt: true` and provide at least default `server` and `topic`, or make sure the user enters them in the form. When MQTT is enabled, the API requires `mqtt.server` and `mqtt.topic`.

Integration code should usually work with a base topic without wildcards:

```js
const baseTopic = (ctx.mqtt?.config?.topic || "my-topic").replace(/\/[#+]$/, "");
```

This keeps configurations such as `zigbee2mqtt`, `zigbee2mqtt/#`, and similar variants predictable when publishing commands.

### UI Configuration Fields

`configFields` is consumed by the UI and saved into `provider.config`. The provider form currently supports these field types:

- `string` - text input,
- `number` - number input,
- `boolean` - toggle,
- `password` - password input.

Example:

```js
configFields: [
  { key: "latitude", type: "number", label: "Latitude", required: true },
  { key: "apiKey", type: "password", label: "API Key", required: false },
  { key: "requestSnapshotOnInit", type: "boolean", label: "Request snapshot on init", default: true },
]
```

Read these values from `ctx.provider.config`:

```js
const config = ctx.provider?.config || {};
const enabled = config.requestSnapshotOnInit !== false;
```

## Context `ctx`

Every runtime method receives the provider context:

```js
{
  providerId,
  provider,
  mqtt: {
    config,
    subscribe,
    publish,
  },
  events: {
    stateChange,
  },
  logger,
}
```

- `ctx.providerId` - provider ID from the database.
- `ctx.provider` - full provider object, including `name`, `mqtt`, `config`, `heartbeat`, and `disabled`.
- `ctx.mqtt.config` - effective MQTT configuration for this provider.
- `ctx.mqtt.subscribe(topic, handler)` - subscribes to a topic for this provider. The handler is optional because every matching message is also routed to `onMessage`.
- `ctx.mqtt.publish(topic, payload)` - publishes a message through this provider's MQTT connection.
- `ctx.events.stateChange(message)` - reports or updates a device in the provider cache.
- `ctx.logger` - currently `console`; use `log`, `warn`, and `error`.

Integration methods are called with `this` set to the exported object. Helpers defined next to the methods can therefore be called as `this.getBaseTopic(ctx)`.

## Integration Lifecycle

### `init(ctx)`

Called when the API starts, when a provider is enabled, during reconnect, and after creating or updating a provider. Typical tasks:

- subscribe to topics, for example `${baseTopic}/#`,
- request a snapshot or device list,
- create placeholder devices through `ctx.events.stateChange`,
- start timers for local integrations.

MQTT example with an initial snapshot request:

```js
init: async function (ctx) {
  const baseTopic = (ctx.mqtt?.config?.topic || "example").replace(/\/[#+]$/, "");

  await ctx.mqtt?.subscribe(`${baseTopic}/#`, () => {});
  await ctx.mqtt?.publish(`${baseTopic}/devices/get`, {});

  ctx.events.stateChange({
    externalId: "status",
    friendlyName: "Provider Status",
    definitionId: "example-status",
    available: true,
    state: { requested_at: new Date().toISOString() },
  });
}
```

Local example with a timer:

```js
const timers = new Map();

module.exports = {
  name: "Example Local Integration",
  type: "local",
  requiresMqtt: false,

  init: async function (ctx) {
    this.destroy(ctx);

    const emit = () => {
      ctx.events.stateChange({
        externalId: "clock",
        friendlyName: "Clock",
        definitionId: "example-clock",
        available: true,
        state: { now: new Date().toISOString() },
      });
    };

    emit();

    const timer = setInterval(emit, 60 * 1000);
    if (typeof timer.unref === "function") timer.unref();
    timers.set(ctx.providerId, timer);
  },

  destroy: function (ctx) {
    const timer = timers.get(ctx.providerId);
    if (timer) clearInterval(timer);
    timers.delete(ctx.providerId);
  },
};
```

### `destroy(ctx)`

Optional. Called when a provider is disabled or deleted, or before provider logic is registered again. Use it to clean up timers and runtime memory. If an integration uses `setInterval` or `setTimeout`, it should implement `destroy`.

### `onMessage(topic, payload, ctx)`

Called for MQTT messages matching the provider. Parse topics and payloads here, ignore command topics (`/set`, `/get`, `command/...`), and emit device changes through `ctx.events.stateChange`.

The minimal device message must include `externalId`:

```js
ctx.events.stateChange({
  externalId: "device-1",
  state: { power: true },
});
```

You can also use the shorthand form:

```js
ctx.events.stateChange("device-1", { state: { power: true } });
```

### `sendCommand(ctx, deviceId, command)`

Called by `POST /providers/:id/commands`. The integration should translate the UI/API `command` into the external protocol. For MQTT, this usually means publishing to `${baseTopic}/${deviceId}/set`.

If `sendCommand` is not defined, the manager publishes commands by default to `${baseTopic}/${externalId}/set`.

### `getDevices(cachedDevices, ctx)`

Called by `GET /providers/:id/devices`. It receives the device cache built from `stateChange`. Use this method to:

- filter devices that belong to the integration,
- fill `provider`, `definitionId`, `friendlyName`, and `metadata`,
- add virtual devices that have not emitted state yet.

The returned list is sorted by `lastSeenAt` descending.

### `getDefinitions(devices, ctx)`

Called by `GET /providers/:id/definitions`. It returns device type definitions and fields that the UI can display or control. In most cases, return definitions only for device types present in `devices`.

## Device Message Format

`ctx.events.stateChange` accepts this object:

```js
{
  externalId: "device-id",
  friendlyName: "Device name",
  model: "model",
  vendor: "vendor",
  definitionId: "definition-id",
  state: {
    power: true,
    temperature: 21.5,
  },
  available: true,
  metadata: {
    sourcePayload: {},
  },
}
```

Field meanings:

- `externalId` - required, stable device ID within the provider.
- `friendlyName` - display name for the UI.
- `model` and `vendor` - descriptive information.
- `definitionId` - ID of a definition returned by `getDefinitions`.
- `state` - current device state; subsequent messages are merged with previous state.
- `available` - device availability.
- `metadata` - additional helper data, such as the original payload or model details.

When `state` is set and the device is already mapped in the system, the API updates the target application device state.

## Definition Format

A definition describes a device type and its fields:

```js
{
  id: "gpio-control",
  name: "GPIO Control",
  provider: ctx.providerId,
  metadata: {
    type: "gpio",
    description: "GPIO output control",
  },
  fields: [
    { key: "power", name: "Power", type: "boolean", control: false },
    { key: "duration", name: "Duration", type: "number", control: true, optional: true },
  ],
}
```

Common definition fields:

- `id` - stable definition ID, matching `device.definitionId`.
- `name` - device type name.
- `provider` - provider ID.
- `metadata` - descriptive data for the UI and diagnostics.
- `fields` - list of state fields and controls.

Common entries in `fields`:

- `key` - key in `state` or command payload,
- `name` - label,
- `type` - field type, for example `boolean`, `number`, `string`, `enum`, `color`, `button`, `datetime`, `date`, `time`, `image`, `array-object`, `form`,
- `control` - `true` when the field sends commands,
- `optional` - optional field marker,
- `values` - values for `enum` or binary mappings,
- `extra` - additional options, for example `min`, `max`, `step`, `suffix`, `valueTrue`, `valueFalse`,
- `fields` - nested fields for `array-object` or `form`.

For multi-field controls, use `form`:

```js
{
  type: "form",
  control: true,
  fields: [
    { key: "power", name: "Power", type: "boolean", control: true, optional: true },
    { key: "duration", name: "Duration", type: "number", control: true, optional: true },
  ],
}
```

## MQTT Integrations

Recommended flow for MQTT integrations:

1. Set `type: "mqtt"`, `requiresMqtt: true`, and a default `mqtt.topic`.
2. In `init`, subscribe to `${baseTopic}/#` and optionally request a snapshot or device list.
3. In `onMessage`, calculate `relativeTopic`, filter out command messages, and parse state messages.
4. Emit every discovered device through `ctx.events.stateChange` with a stable `externalId`.
5. In `sendCommand`, publish commands to the topic expected by the external system.
6. In `getDevices` and `getDefinitions`, fill `definitionId` and return field definitions.

Use the sections above as examples for the common shapes: MQTT devices discovered from topics, virtual local devices, form controls, and timers cleaned up in `destroy`.

## Local Integrations Without MQTT

An integration can run without MQTT by setting `requiresMqtt: false` and emitting virtual devices directly:

```js
module.exports = {
  name: "Local Status",
  type: "local",
  requiresMqtt: false,
  init: async function (ctx) {
    ctx.events.stateChange({
      externalId: "status",
      friendlyName: "Local Status",
      definitionId: "local-status",
      available: true,
      state: { updated_at: new Date().toISOString() },
    });
  },
};
```

For local integrations, cleaning up timers in `destroy(ctx)` is especially important because `init` can run again after provider edits or reconnects.

## Runtime State And Timers

Integration code runs inside the API process and may keep in-memory state. For per-provider state, use a key based on `ctx.providerId`, preferably under a single map on `globalThis`:

```js
const runtime = globalThis.__exampleIntegrationRuntime || new Map();
globalThis.__exampleIntegrationRuntime = runtime;

function getProviderRuntime(ctx) {
  const key = ctx.providerId || ctx.provider?._id || "default";
  if (!runtime.has(key)) runtime.set(key, {});
  return runtime.get(key);
}
```

Recommendations:

- do not keep secrets in global state longer than necessary,
- always add `destroy(ctx)` and clear `setTimeout` / `setInterval` when timers are used,
- if a timer should not keep the process alive, check `if (typeof timer.unref === "function") timer.unref()`.

## Registering A Provider Through The API

MQTT example:

```json
{
  "name": "Example MQTT Provider",
  "integration": "example-mqtt.js",
  "mqttConnection": true,
  "mqtt": {
    "server": "mqtt://localhost:1883",
    "topic": "example"
  },
  "config": {}
}
```

Local example without MQTT:

```json
{
  "name": "Example Local Provider",
  "integration": "example-local.js",
  "mqttConnection": false,
  "config": {
    "refreshIntervalMinutes": 15
  }
}
```

## New Integration Checklist

- The file has a `.js` extension and exports an object through `module.exports`.
- `name` is readable and the file name is stable.
- `requiresMqtt` matches the integration's real requirements.
- MQTT integrations define a default `mqtt.topic` and optionally `mqtt.server`.
- `configFields` includes all user-facing settings required by the integration.
- `init` subscribes to a topic or initializes local refresh logic.
- `destroy` cleans up timers and runtime state if the integration uses them.
- `onMessage` ignores command topics and emits only valid devices.
- Every `stateChange` has a stable `externalId`.
- Every device has a `definitionId`, and `getDefinitions` returns the matching definition.
- Fields from `state` have matching definition fields, especially when they should be visible or controllable in the UI.
- `sendCommand` validates `deviceId` and `command` when the integration supports control.
- After adding the file, check `GET /providers/integrations`, provider creation, `GET /providers/:id/devices`, `GET /providers/:id/definitions`, and command sending if applicable.

## Common Pitfalls

- Missing `externalId` in `stateChange` - the message is ignored.
- Unstable `externalId` - the application treats subsequent states as different devices.
- Missing `definitionId`, or no definition with the same `id` - the UI cannot describe the device fields.
- Subscribing with a wildcard topic and publishing commands to the same string without removing `/#` - commands go to the wrong topic.
- Missing `destroy` when timers are used - provider edits can leave duplicated refresh loops running.
- Using `require`, ES imports, or unavailable Node APIs in provider logic - integrations are compiled with `new Function('module', 'exports', source)`, so keep the file self-contained.
- Assuming `payload` is always an object - validate with `payload && typeof payload === "object"` where needed.
