/**
 * Local sun provider.
 * Calculates sunrise, sunset, solar noon and the current sun phase.
 */

const TIMER_KEY = "__nqLitSunProviderTimers";
const DAY_MS = 24 * 60 * 60 * 1000;
const SUN_STATES = ["DARK", "SUNRISE", "DAYLIGHT", "EVENING", "SUNSET"];
const SUNRISE_SUNSET_ZENITH = 90.833;
const EVENING_ZENITH = 84;
const CIVIL_TWILIGHT_ZENITH = 96;

module.exports = {
  name: "Sun",
  type: "local",
  requiresMqtt: false,

  icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M4.93 19.07l1.41-1.41M17.66 6.34l1.41-1.41"/></svg>',

  configFields: [
    {
      key: "latitude",
      type: "number",
      label: "Latitude",
      required: true,
    },
    {
      key: "longitude",
      type: "number",
      label: "Longitude",
      required: true,
    },
  ],

  init: async function (ctx) {
    const config = ctx.provider?.config || {};
    const latitude = this.toNumber(config.latitude);
    const longitude = this.toNumber(config.longitude);

    if (!this.isValidLatitude(latitude) || !this.isValidLongitude(longitude)) {
      ctx.logger.warn("[Sun] Missing or invalid latitude/longitude config");
      return;
    }

    this.clearProviderTimers(ctx.providerId);

    const emitSun = () => {
      ctx.events.stateChange(this.createSunMessage(latitude, longitude));
    };

    emitSun();
    this.scheduleNextStateEmit(ctx.providerId, latitude, longitude, emitSun);
  },

  destroy: function (ctx) {
    this.clearProviderTimers(ctx.providerId);
  },

  onMessage: async function () {},

  sendCommand: async function () {},

  getDevices: async function (cachedDevices, ctx) {
    return cachedDevices
      .filter((device) => device.externalId === "sun-position")
      .map((device) => ({
        ...device,
        provider: device.provider || ctx?.providerId || ctx?.provider?._id,
        friendlyName: "Sun position",
        model: "sun",
        vendor: "sun",
        definitionId: "sun-position",
      }));
  },

  getDefinitions: async function (devices, ctx) {
    if (!devices.some((device) => device.externalId === "sun-position")) return [];

    return [{
      id: "sun-position",
      name: "Sun position",
      provider: ctx?.providerId || ctx?.provider?._id,
      metadata: {
        type: "sun",
        description: "Local sunrise and sunset information",
      },
      fields: [
        { key: "sunrise", name: "Sunrise", type: "datetime", control: false },
        { key: "sunset", name: "Sunset", type: "datetime", control: false },
        { key: "solar_noon", name: "Solar noon", type: "datetime", control: false },
        { key: "day_length_minutes", name: "Day length", type: "number", control: false, extra: { suffix: "min" } },
        { key: "state", name: "State", type: "enum", values: SUN_STATES, control: false },
        { key: "is_daylight", name: "Daylight", type: "boolean", control: false },
        { key: "updated_at", name: "Updated at", type: "datetime", control: false },
      ],
    }];
  },

  createSunMessage: function (latitude, longitude) {
    const now = new Date();
    const today = this.getSunTimes(now, latitude, longitude);
    const tomorrow = this.getSunTimes(new Date(now.getTime() + DAY_MS), latitude, longitude);
    const isDaylight = today.sunrise && today.sunset
      ? now >= today.sunrise && now < today.sunset
      : false;

    return {
      externalId: "sun-position",
      friendlyName: "Sun position",
      model: "sun",
      vendor: "sun",
      definitionId: "sun-position",
      available: true,
      state: {
        sunrise: this.toIsoOrNull(today.sunrise),
        sunset: this.toIsoOrNull(today.sunset),
        solar_noon: this.toIsoOrNull(today.solarNoon),
        day_length_minutes: today.dayLengthMinutes,
        state: this.getSunState(now, today),
        is_daylight: isDaylight,
        updated_at: now.toISOString(),
      },
      metadata: {
        latitude,
        longitude,
        date: this.formatDateKey(now),
      },
    };
  },

  scheduleNextStateEmit: function (providerId, latitude, longitude, emit) {
    const now = new Date();
    const nextChange = this.getNextStateChange(now, latitude, longitude);
    const timer = setTimeout(() => {
      emit();
      this.scheduleNextStateEmit(providerId, latitude, longitude, emit);
    }, Math.max(1000, nextChange.getTime() - now.getTime()));
    this.registerProviderTimer(providerId, timer);
  },

  getSunState: function (now, sunTimes) {
    const dawn = sunTimes?.civilDawn;
    const sunrise = sunTimes?.sunrise;
    const evening = sunTimes?.evening;
    const sunset = sunTimes?.sunset;
    const dusk = sunTimes?.civilDusk;
    if (!dawn || !sunrise || !evening || !sunset || !dusk) return "DARK";

    if (now < dawn) return "DARK";
    if (now < sunrise) return "SUNRISE";
    if (now < evening) return "DAYLIGHT";
    if (now < sunset) return "EVENING";
    if (now < dusk) return "SUNSET";
    return "DARK";
  },

  getNextStateChange: function (now, latitude, longitude) {
    const today = this.getSunTimes(now, latitude, longitude);
    const tomorrowDate = new Date(now.getTime() + DAY_MS);
    const tomorrow = this.getSunTimes(tomorrowDate, latitude, longitude);
    const nextDayRefresh = new Date(now);
    nextDayRefresh.setHours(0, 1, 0, 0);
    if (nextDayRefresh <= now) nextDayRefresh.setDate(nextDayRefresh.getDate() + 1);
    const boundaries = [
      today.civilDawn,
      today.sunrise,
      today.evening,
      today.sunset,
      today.civilDusk,
      tomorrow.civilDawn,
      tomorrow.sunrise,
      nextDayRefresh,
    ].filter((date) => date && date > now);

    boundaries.sort((a, b) => a.getTime() - b.getTime());
    if (boundaries[0]) return boundaries[0];

    return boundaries[0] || nextDayRefresh;
  },

  getSunTimes: function (date, latitude, longitude) {
    const dayOfYear = this.getDayOfYear(date);
    const dateKey = this.formatDateKey(date);
    const civilDawn = this.minutesToUtcDate(
      dateKey,
      this.calculateSunTimeUtc(dayOfYear, latitude, longitude, true, CIVIL_TWILIGHT_ZENITH),
    );
    const sunrise = this.minutesToUtcDate(
      dateKey,
      this.calculateSunTimeUtc(dayOfYear, latitude, longitude, true, SUNRISE_SUNSET_ZENITH),
    );
    const sunset = this.minutesToUtcDate(
      dateKey,
      this.calculateSunTimeUtc(dayOfYear, latitude, longitude, false, SUNRISE_SUNSET_ZENITH),
    );
    const evening = this.minutesToUtcDate(
      dateKey,
      this.calculateSunTimeUtc(dayOfYear, latitude, longitude, false, EVENING_ZENITH),
    );
    const civilDusk = this.minutesToUtcDate(
      dateKey,
      this.calculateSunTimeUtc(dayOfYear, latitude, longitude, false, CIVIL_TWILIGHT_ZENITH),
    );

    return {
      civilDawn,
      sunrise,
      evening,
      sunset,
      civilDusk,
      solarNoon: sunrise && sunset
        ? new Date((sunrise.getTime() + sunset.getTime()) / 2)
        : null,
      dayLengthMinutes: sunrise && sunset
        ? Math.round((sunset.getTime() - sunrise.getTime()) / 60000)
        : null,
    };
  },

  calculateSunTimeUtc: function (dayOfYear, latitude, longitude, isSunrise, zenith = SUNRISE_SUNSET_ZENITH) {
    const lngHour = longitude / 15;
    const approxTime = dayOfYear + ((isSunrise ? 6 : 18) - lngHour) / 24;
    const meanAnomaly = (0.9856 * approxTime) - 3.289;
    const trueLongitude = this.normalizeDegrees(
      meanAnomaly
        + (1.916 * Math.sin(this.degToRad(meanAnomaly)))
        + (0.020 * Math.sin(this.degToRad(2 * meanAnomaly)))
        + 282.634,
    );

    let rightAscension = this.radToDeg(Math.atan(0.91764 * Math.tan(this.degToRad(trueLongitude))));
    rightAscension = this.normalizeDegrees(rightAscension);
    rightAscension += Math.floor(trueLongitude / 90) * 90 - Math.floor(rightAscension / 90) * 90;
    rightAscension /= 15;

    const sinDeclination = 0.39782 * Math.sin(this.degToRad(trueLongitude));
    const cosDeclination = Math.cos(Math.asin(sinDeclination));
    const cosHourAngle = (
      Math.cos(this.degToRad(zenith)) - (sinDeclination * Math.sin(this.degToRad(latitude)))
    ) / (cosDeclination * Math.cos(this.degToRad(latitude)));

    if (cosHourAngle > 1 || cosHourAngle < -1) return null;

    const hourAngle = isSunrise
      ? 360 - this.radToDeg(Math.acos(cosHourAngle))
      : this.radToDeg(Math.acos(cosHourAngle));
    const localMeanTime = (hourAngle / 15) + rightAscension - (0.06571 * approxTime) - 6.622;
    return this.normalizeHours(localMeanTime - lngHour) * 60;
  },

  minutesToUtcDate: function (dateKey, minutes) {
    if (minutes === null || minutes === undefined) return null;
    return new Date(new Date(`${dateKey}T00:00:00.000Z`).getTime() + Math.round(minutes * 60000));
  },

  getDayOfYear: function (date) {
    const start = Date.UTC(date.getUTCFullYear(), 0, 0);
    const current = Date.UTC(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate());
    return Math.floor((current - start) / DAY_MS);
  },

  formatDateKey: function (date) {
    return date.toISOString().slice(0, 10);
  },

  normalizeDegrees: function (value) {
    return ((value % 360) + 360) % 360;
  },

  normalizeHours: function (value) {
    return ((value % 24) + 24) % 24;
  },

  degToRad: function (degrees) {
    return degrees * Math.PI / 180;
  },

  radToDeg: function (radians) {
    return radians * 180 / Math.PI;
  },

  toNumber: function (value) {
    if (value === null || value === undefined || value === "") return NaN;
    return Number(value);
  },

  isValidLatitude: function (value) {
    return Number.isFinite(value) && value >= -90 && value <= 90;
  },

  isValidLongitude: function (value) {
    return Number.isFinite(value) && value >= -180 && value <= 180;
  },

  toIsoOrNull: function (date) {
    return date ? date.toISOString() : null;
  },

  getTimerStore: function () {
    globalThis[TIMER_KEY] = globalThis[TIMER_KEY] || new Map();
    return globalThis[TIMER_KEY];
  },

  registerProviderTimer: function (providerId, timer) {
    const timers = this.getTimerStore();
    const providerTimers = timers.get(providerId) || [];
    providerTimers.push(timer);
    timers.set(providerId, providerTimers);
    if (typeof timer.unref === "function") timer.unref();
  },

  clearProviderTimers: function (providerId) {
    const timers = this.getTimerStore();
    const providerTimers = timers.get(providerId) || [];
    providerTimers.forEach((timer) => clearTimeout(timer));
    timers.delete(providerId);
  },
};
