/**
 * Built-in provider logic for Zigbee2MQTT.
 * This file can be referenced via integration when registering a provider.
 */

module.exports = {
  name: "Zigbee2MQTT",
  type: "mqtt",
  requiresMqtt: true,
  mqtt: {
    topic: "zigbee2mqtt",
    server: "mqtt://localhost:1883",
  },

  icon: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M11.988 0a11.85 11.85 0 00-8.617 3.696c7.02-.875 11.401-.583 13.289-.34 3.752.583 3.558 3.404 3.558 3.404L8.237 19.112c2.299.22 6.897.366 13.796-.631a11.86 11.86 0 001.912-6.469C23.945 5.374 18.595 0 11.988 0zm.232 4.31c-2.451-.014-5.772.146-9.963.723C.854 7.003.055 9.41.055 12.012.055 18.626 5.38 24 11.988 24c3.63 0 6.85-1.63 9.053-4.182-7.286.948-11.813.631-13.75.388-3.775-.56-3.557-3.404-3.557-3.404L15.691 4.474a38.635 38.635 0 00-3.471-.163Z"/></svg>',

  configFields: [
    {
      key: "sample",
      type: "string",
      label: "Sample field",
      default: "default value",
      required: false,
    },
  ],

  init: async function (ctx) {
    const baseTopic = (ctx.mqtt?.config?.topic || "zigbee2mqtt").replace(/\/[#+]$/, "");
    console.log('[Zigbee2MQTT] init with config', ctx.mqtt?.config);

    await ctx.mqtt?.subscribe(`${baseTopic}/#`, () => {});
    await ctx.mqtt?.publish(`${baseTopic}/bridge/request/devices`, {});
  },

  onMessage: async function (topic, payload, ctx) {
    const baseTopic = (ctx.mqtt?.config?.topic || "zigbee2mqtt").replace(/\/[#+]$/, "");

    if (topic === `${baseTopic}/bridge/devices` && Array.isArray(payload)) {
      payload.forEach((device) => {
        const msg = this.parseDiscoveredDevice(device);
        if (msg) ctx.events.stateChange(msg);
      });
      return;
    }

    if (topic.includes('/bridge/') || topic.endsWith('/set') || topic.endsWith('/get')) {
      return;
    }

    const msg = this.parseStateMessage(topic, payload);
    if (msg) ctx.events.stateChange(msg);
  },

  sendCommand: async function (ctx, deviceId, command) {
    const baseTopic = (ctx.mqtt?.config?.topic || "zigbee2mqtt").replace(/\/[#+]$/, "");
    await ctx.mqtt?.publish(`${baseTopic}/${deviceId}/set`, command);
  },

  getDevices: async function (cachedDevices, ctx) {
    return cachedDevices.map((d) => {
      const def = d.definition || d.metadata?.definition;
      const vendor = d.vendor || def?.vendor || def?.manufacturer;
      const model = d.model || def?.model || def?.model_id;
      const definitionId = this.buildDefinitionId(vendor, model);
      return {
        ...d,
        provider: d.provider || ctx?.providerId || ctx?.provider?._id,
        definitionId,
      };
    });
  },

  getDefinitions: async function (devices, ctx) {
    const defs = [];
    devices.forEach((device) => {
      if (!device.definition || !device.definitionId) return;
      defs.push({
        id: device.definitionId,
        name: `${device.vendor || ""} ${device.model || ""}`.trim(),
        provider: device.providerId || device.provider || ctx?.providerId || ctx?.provider?._id,
        metadata: {
          model: device.model,
          vendor: device.vendor,
          description: device.definition?.description,
          type: device.definition?.type,
          supported: device.definition?.supported,
          power_source: device.definition?.power_source,
        },
        fields: this.transformExposes(device.definition?.exposes || []),
      });
    });
    return defs;
  },

  parseStateMessage: function (topic, payload) {
    if (!payload || typeof payload !== "object") return null;
    const parts = topic.split("/");
    const friendlyName = parts[1];
    if (!friendlyName) return null;

    const externalId = payload.ieee_address || friendlyName;
    const state = this.extractState(payload);
    const msg = {
      externalId,
      friendlyName,
      model: payload.model,
      vendor: payload.vendor,
      definitionId: this.buildDefinitionId(payload.vendor, payload.model),
      state,
      available: payload.linkquality !== undefined ? payload.linkquality > 0 : undefined,
      metadata: {
        linkquality: payload.linkquality,
        battery: payload.battery,
        voltage: payload.voltage,
      },
    };
    return msg;
  },

  parseDiscoveredDevice: function (device) {
    if (!device) return null;
    // console.log('[Zigbee2MQTT] Discovered device', device);
    const vendor = device?.definition?.vendor || device.manufacturer;
    const model = device?.definition?.model || device.model_id;
    const definitionId = this.buildDefinitionId(vendor, model);
    return {
      externalId: device.ieee_address || device.friendly_name,
      friendlyName: device.friendly_name,
      model,
      vendor,
      definitionId,
      available: device.supported !== false,
      metadata: {
        type: device.type,
        supported: device.supported,
        power_source: device.power_source,
        definition: device.definition,
      },
      definition: device.definition,
    };
  },

  extractState: function (payload) {
    const metaKeys = [
      "ieee_address",
      "friendly_name",
      "model",
      "vendor",
      "linkquality",
      "battery",
      "voltage",
      "last_seen",
      "elapsed",
    ];
    const state = {};
    Object.entries(payload).forEach(([k, v]) => {
      if (!metaKeys.includes(k)) state[k] = v;
    });
    return state;
  },

  buildDefinitionId: function (vendor, model) {
    if (!vendor || !model) return undefined;
    const normalize = (value) => String(value || "")
      .trim()
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-+|-+$/g, "");

    const vendorPart = normalize(vendor);
    const modelPart = normalize(model);
    if (!vendorPart || !modelPart) return undefined;
    return `z2m-${vendorPart}-${modelPart}`;
  },

  transformExposes: function (exposes) {
    const fields = [];
    const process = (expose) => {
      if (!expose) return;
      const isColorComposite =
        expose.type === "composite" &&
        ((expose.property && expose.property.toLowerCase().includes("color")) ||
          (expose.name && expose.name.toLowerCase().includes("color")));
      if (isColorComposite) {
        fields.push({
          key: "color",
          name: expose.label || expose.name || "Color",
          type: "color",
          control: this.hasWriteAccess(expose),
        });
        return;
      }

      if (expose.features && Array.isArray(expose.features)) {
        expose.features.forEach(process);
        return;
      }
      const key = expose.property || expose.name;
      if (!key) return;
      const field = {
        key,
        name: expose.label || expose.name || key,
        type: this.mapType(expose.type, key),
        control: this.hasWriteAccess(expose),
      };
      if (expose.type === "binary") {
        field.values = [
          { name: "On", value: expose.value_on },
          { name: "Off", value: expose.value_off },
        ];
        field.extra = { valueTrue: expose.value_on, valueFalse: expose.value_off };
      }
      if (expose.type === "enum" && expose.values) {
        field.values = expose.values;
      }
      if (expose.type === "numeric") {
        field.extra = field.extra || {};
        if (expose.value_min !== undefined) field.extra.min = expose.value_min;
        if (expose.value_max !== undefined) field.extra.max = expose.value_max;
        if (expose.value_step !== undefined) field.extra.step = expose.value_step;
        if (expose.unit) field.extra.suffix = expose.unit;
      }
      if (field.extra && Object.keys(field.extra).length === 0) delete field.extra;
      fields.push(field);
    };
    exposes.forEach(process);
    this.disambiguateDuplicateFieldNames(fields);
    return fields;
  },

  disambiguateDuplicateFieldNames: function (fields) {
    const groups = new Map();
    fields.forEach((field) => {
      if (!field?.name || !field?.key) return;
      const name = String(field.name);
      if (!groups.has(name)) groups.set(name, []);
      groups.get(name).push(field);
    });

    groups.forEach((group) => {
      if (group.length < 2) return;

      const qualifiers = group.map((field) => this.getDuplicateNameQualifier(field, group));
      const uniqueQualifiers = new Set(qualifiers.filter(Boolean));
      if (uniqueQualifiers.size !== group.length) return;

      group.forEach((field, index) => {
        field.name = `${field.name} (${qualifiers[index]})`;
      });
    });
  },

  getDuplicateNameQualifier: function (field, group) {
    const keyParts = String(field.key).split("_").filter(Boolean);
    const nameParts = String(field.name)
      .toLowerCase()
      .split(/[^a-z0-9]+/i)
      .filter(Boolean);
    const namePartSet = new Set(nameParts);
    const suffixParts = keyParts.filter((part) => !namePartSet.has(part.toLowerCase()));

    if (suffixParts.length > 0) return suffixParts.join(" ");

    const groupKeyParts = group.map((item) => String(item.key).split("_").filter(Boolean));
    const differentParts = keyParts.filter((part, index) =>
      groupKeyParts.some((parts) => parts[index] !== part)
    );
    return differentParts.join(" ");
  },

  mapType: function (type, key) {
    if (key && key.toLowerCase() === "color") return "color";
    switch (type) {
      case "binary":
        return "boolean";
      case "numeric":
        return "number";
      case "enum":
        return "enum";
      case "text":
        return "string";
      case "color":
        return "color";
      case "list":
        return "string";
      case "composite":
        return key && key.toLowerCase().includes("color") ? "color" : "string";
      default:
        return "string";
    }
  },

  hasWriteAccess: function (expose) {
    if (!expose) return false;
    if (Array.isArray(expose.access)) return expose.access.includes("WRITE");
    if (typeof expose.access === "number") return (expose.access & 2) !== 0;
    return false;
  },
};
