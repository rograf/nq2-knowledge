# Scripts

This directory contains built-in local API scripts. Each script is a single `.js` file that exports a CommonJS object through `module.exports`. Scripts are stored as file-backed database records, exposed by the `/scripts` API, copied to `dist/local/scripts` during the API build, and can be selected in cards, devices, schedules, providers, and manual execution forms.

A script is a small async function that receives validated `params` and helper functions under `fn`. Scripts do not receive hidden device/card context. If a script needs a device or card, define it as a parameter and pass a static ID or a dynamic value such as `@device._id` or `@card._id`.

## Quick Template

```js
module.exports = {
  _id: "my-script",
  name: "My Script",
  description: "Example script",
  waitForCompletion: false,
  tags: ["example"],

  params: [
    {
      key: "device",
      label: "Device",
      type: "id",
      subtype: "device",
      required: true,
    },
    {
      key: "key",
      label: "State key",
      type: "string",
      default: "power",
    },
    {
      key: "value",
      label: "Value",
      type: "any",
      default: true,
    },
  ],

  function: async (params, fn) => {
    fn.log("Running script", params);

    await fn.devices.sendCommand(params.device, {
      [params.key]: params.value,
    });

    return { ok: true };
  },
};
```

## Where To Add Files

Add a new script as a JavaScript file in this directory, for example `my-script.js`. The file name is used as the default `_id` when `_id` is not provided.

Keep script IDs stable. Cards, devices, schedules, providers, and other scripts can reference scripts by ID. Renaming an existing file or changing `_id` can break saved actions.

Scripts can also be created and edited through the UI or `/scripts` API. The file parser supports both:

```js
function: async (params, fn) => {
  // body
}
```

and a string body stored in the database.

## Export Structure

A script must export an object:

```js
module.exports = {
  _id: "stable-id",
  name: "Display Name",
  description: "Optional description",
  waitForCompletion: false,
  params: [],
  tags: [],
  function: async (params, fn) => {},
};
```

### Metadata Fields

- `_id` - optional stable script ID. If omitted, the file name without `.js` is used.
- `name` - display name shown in script selectors.
- `description` - optional help text.
- `waitForCompletion` - when `true`, action forms select this script with waiting enabled by default and hide the action-level wait toggle.
- `params` - parameter definitions rendered by the UI and validated by the API.
- `tags` - optional tags used for filtering and grouping.
- `function` - async script function body.

Script IDs may contain only lowercase letters, numbers, underscores, and hyphens when created through the API.

## Function Arguments

Every script runs as:

```js
async (params, fn) => {}
```

- `params` - validated parameter values.
- `fn` - helper API for logging, sleeping, devices, cards, schedules, scripts, and messages.

There is no third argument. Current device/card data must be passed explicitly through params.

## Parameters

Parameter definitions describe what the UI renders and what the API validates.

```js
params: [
  {
    key: "mode",
    label: "Mode",
    type: "enum",
    options: ["on", "off", "toggle"],
    default: "toggle",
    required: true,
    description: "What should happen",
  },
]
```

Supported `type` values:

- `string`
- `number`
- `enum`
- `boolean`
- `object`
- `array`
- `id`
- `ids`
- `any`

Common fields:

- `key` - required parameter key.
- `label` - UI label. Falls back to `key`.
- `type` - required value type.
- `required` - when `true`, the value must be present.
- `description` - UI help text.
- `default` - default value applied when the value is missing.
- `options` - enum options.
- `subtype` - extra UI meaning.
- `relation` - connects related parameters.
- `fields` - nested definitions, used mainly by repeat/action-style parameters.

Validation happens before the script runs. If a required parameter is missing or a value has the wrong type, the script is not executed.

## Parameter Subtypes

Subtypes let the UI render better pickers and connected fields.

Supported `subtype` values:

- `device` - single device picker.
- `devices` - multiple devices picker.
- `device-field` - field picker from the selected device definition. Use it for fields intentionally exposed by the definition.
- `device-field-value` - value input for a selected device definition field.
- `device-state` - state key picker from the selected device's current provider state. It can include keys that are not exposed in the definition.
- `device-state-value` - value input for a selected device state key.
- `card` - single card picker.
- `cards` - multiple cards picker.
- `card-field` - field picker from selected card definitions/configuration.
- `card-field-value` - value input for a selected card field.
- `script` - script picker.
- `milliseconds` - number stored in milliseconds; UI renders it as a time unit input.

For repeatable nested action fields, use `type: "array"` with `fields`. The UI renders array parameters as repeatable groups.

Example with a related device key and value:

```js
params: [
  { key: "device", label: "Device", type: "id", subtype: "device", required: true },
  { key: "key", label: "Key", type: "string", subtype: "device-state", relation: "device", required: true },
  { key: "value", label: "Value", type: "any", subtype: "device-state-value", relation: "key" },
]
```

Example with a nested script:

```js
params: [
  { key: "script", label: "Script", type: "id", subtype: "script" },
  { key: "scriptParams", label: "Script params", type: "object", relation: "script" },
]
```

## Dynamic Values In Actions

When a script is used from card/device triggers or card field actions, parameter values can contain dynamic values such as:

- `@value` - value sent by UI or action source.
- `@state` - current state.
- `@previousState` - previous state, where available.
- `@changed` - changed state keys, where available.
- `@card` - current card metadata, where available.
- `@device` - current device metadata, where available.

Nested paths are supported, for example:

```txt
@card._id
@device._id
@value.checked
@state.power
```

The available dynamic values depend on where the script is executed. Schedules and provider heartbeat actions usually receive only the configured static params.

## Helper API `fn`

The `fn` object currently contains:

```js
{
  log,
  stop,
  sleep,
  devices,
  cards,
  crons,
  scripts,
  messages,
}
```

### `fn.log(...args)`

Writes to the API console with a `[Script]` prefix.

```js
fn.log("Command sent", params);
```

### `fn.sleep(seconds)`

Waits for the given number of seconds.

```js
await fn.sleep(2.5);
```

### `fn.stop(reason?)`

Returns a stop signal for action runners.

```js
return fn.stop("No more actions needed");
```

This stops following scripts only when the current action has `waitForCompletion: true`. Without waiting, the runner does not wait for the result and cannot use the stop signal.

You can also return the raw shape:

```js
return { stop: true };
```

### Services

Most helpers are live API services:

- `fn.devices` - device service.
- `fn.cards` - card service.
- `fn.crons` - schedule/cron service.
- `fn.scripts` - script service.
- `fn.messages` - message service.

Use existing service methods carefully. These are internal service objects, not a small public SDK, so prefer simple calls already used by existing scripts:

```js
const device = await fn.devices.getById(params.device);
await fn.devices.sendCommand(params.device, { power: true });

const card = await fn.cards.getById(params.card);
await fn.cards.setState(params.card, { armed: true });

await fn.scripts.execute(params.script, params.scriptParams || {});
```

## Execution Places

Scripts can be used from several places:

- manual execution from the Scripts view or `POST /scripts/:id/execute`,
- card field commands,
- card triggers,
- device triggers,
- schedules/cron actions,
- provider heartbeat actions,
- other scripts through `fn.scripts.execute`.

### Card And Device Triggers

Triggers resolve dynamic parameter values before the script runs. Use params such as `device: "@device._id"` or `card: "@card._id"` when the script needs the current device or card.

If an action has `waitForCompletion: true`, the next action waits for the current script to finish.

### Schedules And Provider Heartbeat

Schedules and heartbeat actions use the same action runner and use configured `params`.

## Action Runner Rules

Card triggers, device triggers, schedules, and provider heartbeat actions use the same script action runner.

Each action has:

```js
{
  script: "script-id",
  params: {},
  waitForCompletion: true,
}
```

Rules:

- If `waitForCompletion` is missing or `false`, the script starts and the runner continues to the next action immediately.
- If `waitForCompletion` is `true`, the runner waits for the script to finish.
- Script errors are logged and do not stop following actions.
- Returning `{ stop: true }` or `fn.stop()` stops following actions only when `waitForCompletion` is `true`.

Example:

```js
function: async (params, fn) => {
  const card = await fn.cards.getById(params.card);
  if (card.state?.enabled === false) {
    return fn.stop("Card is disabled");
  }

  await fn.cards.sendCommand(params.card, {
    key: params.key,
    value: params.value,
  });
}
```

## Calling Another Script

Scripts can execute other scripts:

```js
const result = await fn.scripts.execute(params.script, params.scriptParams || {});
fn.log("Child script result", result);
```

Pass all required data through `params.scriptParams`.

Errors from child scripts throw, so catch them if the parent should continue:

```js
try {
  await fn.scripts.execute(params.script, params.scriptParams || {});
} catch (error) {
  fn.log("Child script failed", error.message);
}
```

## Creating Messages

The message service is available as `fn.messages`. Messages created from scripts are system messages when `author` is not set on the payload.

```js
await fn.messages.create({
  title: "Low battery",
  message: "<strong>Sensor battery is below 20%.</strong>",
  recipients: [], // empty means everyone
  priority: "high",
  tags: ["system", "battery"],
});
```

Messages are stored per recipient. When `recipients` contains multiple users, or is empty and targets everyone, the service creates one message record for each recipient. Read and delete state is therefore independent for each user.

Common message service methods:

- `fn.messages.getAll(query?)` - returns paginated messages.
- `fn.messages.getById(id, options?)` - returns one full message. Use `{ markAsRead: false }` if you pass a `userId` and do not want to mark it as read.
- `fn.messages.create(data)` - creates a message.
- `fn.messages.delete(id, actor?)` - removes one message.
- `fn.messages.deleteMany(ids, actor?)` - removes many messages.

Example:

```js
const messages = await fn.messages.getAll({ page: 1, limit: 10, tag: "battery" });
fn.log("Battery messages", messages.total);

if (messages.items.length > 10) {
  await fn.messages.deleteMany(messages.items.slice(10).map((message) => message._id));
}
```

## Good Practices

- Keep `_id` and file names stable.
- Validate business rules inside the script, even if params are type-validated.
- Prefer `fn.log` over `console.log`.
- Use `await` for commands that must finish before the script returns.
- Use `fn.stop()` for controlled cancellation, not `throw`.
- Use `throw` only for real errors.
- Keep long-running loops bounded and add sleeps.
- Be careful when calling internal services because they can change application state immediately.
- Avoid storing secrets in script source or logs.
- Prefer small focused scripts over one large script with many unrelated modes.

## New Script Checklist

- The file has a `.js` extension and exports an object through `module.exports`.
- `_id` is stable and uses lowercase letters, numbers, underscores, or hyphens.
- `name` is readable in selectors.
- `description` explains what the script does.
- `params` define every required value.
- `default` values are present where they make the script easier to use.
- Script selectors show useful parameter labels.
- The function uses `async (params, fn) => {}`.
- Commands that must finish are awaited.
- Controlled cancellation uses `return fn.stop()`.
- The script was tested manually or from the place where it will run.

## Common Pitfalls

- Returning `fn.stop()` without enabling `waitForCompletion` on the action - the next actions may already be running.
- Using `throw` to stop normal flow - it logs an error and action runners continue.
- Expecting `device` to always be present - schedules and provider heartbeat usually do not pass it.
- Forgetting `await` before `fn.devices.sendCommand`, `fn.cards.setState`, or `fn.scripts.execute`.
- Using a parameter type that does not match the actual value, for example `string` for an object.
- Renaming a script file or `_id` that is already referenced by cards, devices, schedules, or providers.
- Creating long sleeps or loops in actions that are expected to run often.
