module.exports = {
  name: 'Card: Conditional Repeat Actions',
  description: 'Runs independent delayed and repeated script commands with an optional card stop condition.',
  params: [
    {
      key: 'name',
      label: 'Sequence name',
      required: true,
      type: 'string',
      description: 'Only one sequence with this name can run at the same time.',
    },
    {
      key: 'commands',
      label: 'Commands',
      required: true,
      type: 'array',
      description: 'Independent scripts with delay, repeat count, and interval.',
      default: [],
      fields: [
        {
          key: 'script',
          label: 'Script',
          required: true,
          type: 'id',
          subtype: 'script',
        },
        {
          key: 'params',
          label: 'Parameters',
          required: false,
          type: 'object',
          relation: 'script',
          default: {},
        },
        {
          key: 'delay',
          label: 'Initial delay',
          required: false,
          type: 'number',
          subtype: 'milliseconds',
          default: 0,
        },
        {
          key: 'repeat',
          label: 'Repeat',
          required: false,
          type: 'number',
          default: 1,
        },
        {
          key: 'intervalMs',
          label: 'Interval',
          required: false,
          type: 'number',
          subtype: 'milliseconds',
          default: 0,
        },
      ],
    },
    {
      key: 'cardId',
      label: 'Stop condition card',
      required: false,
      type: 'id',
      subtype: 'card',
      description: 'Optional card used to stop the whole sequence.',
    },
    {
      key: 'cardKey',
      label: 'Stop condition field',
      required: false,
      type: 'string',
      subtype: 'card-field',
      relation: 'cardId',
      description: 'Optional card state key used by the stop condition.',
    },
    {
      key: 'cardValue',
      label: 'Stop condition value',
      required: false,
      type: 'any',
      subtype: 'card-field-value',
      relation: 'cardKey',
      description: 'Optional value that stops the whole sequence.',
    },
  ],
  tags: ['card', 'advanced'],
  function: async (params, fn) => {
    const sequenceName = String(params.name || '').trim();
    if (!sequenceName) {
      throw new Error('name is required');
    }

    if (!globalThis.__nqActiveScriptRepeats2) {
      globalThis.__nqActiveScriptRepeats2 = new Map();
    }

    const activeSequences = globalThis.__nqActiveScriptRepeats2;
    if (activeSequences.has(sequenceName)) {
      fn.log('Script Repeats 2: already active', sequenceName);
      return {
        status: 'already-active',
        name: sequenceName,
      };
    }

    const executionToken = Symbol(sequenceName);
    activeSequences.set(sequenceName, executionToken);
    let stopped = false;

    const valuesEqual = (currentValue, expectedValue) => {
      if (Object.is(currentValue, expectedValue)) return true;

      if (
        currentValue &&
        expectedValue &&
        typeof currentValue === 'object' &&
        typeof expectedValue === 'object'
      ) {
        try {
          return JSON.stringify(currentValue) === JSON.stringify(expectedValue);
        } catch (error) {
          return false;
        }
      }

      return false;
    };

    const hasStopCondition = () =>
      Boolean(params.cardId && params.cardKey) &&
      params.cardValue !== undefined;

    const shouldStop = async () => {
      if (stopped) return true;
      if (!hasStopCondition()) return false;

      const card = await fn.cards.getById(params.cardId);
      const matched = valuesEqual(card.state?.[params.cardKey], params.cardValue);
      if (matched) stopped = true;
      return matched;
    };

    const wait = async (milliseconds) => {
      let remainingMs = Math.max(0, Number(milliseconds) || 0);

      while (remainingMs > 0 && !stopped) {
        const sleepMs = Math.min(1000, remainingMs);
        await fn.sleep(sleepMs / 1000);
        remainingMs -= sleepMs;
        if (await shouldStop()) return false;
      }

      return !stopped;
    };

    const normalizeRepeat = (value) => {
      const repeat = Math.floor(Number(value) || 0);
      return repeat > 1 ? repeat : 1;
    };

    const runCommand = async (command, index) => {
      if (!command?.script || stopped) return;
      if (!await wait(command.delay)) return;

      const repeat = normalizeRepeat(command.repeat);
      const intervalMs = Math.max(0, Number(command.intervalMs) || 0);

      for (let iteration = 0; iteration < repeat && !stopped; iteration += 1) {
        if (iteration > 0 && !await wait(intervalMs)) return;
        if (await shouldStop()) return;

        try {
          await fn.scripts.execute(command.script, command.params || {});
        } catch (error) {
          fn.log('Script Repeats 2: child script failed', {
            name: sequenceName,
            command: index + 1,
            iteration: iteration + 1,
            scriptId: command.script,
            error: error?.message || String(error),
          });
        }
      }
    };

    try {
      const commands = Array.isArray(params.commands) ? params.commands : [];
      await Promise.all(commands.map((command, index) => runCommand(command, index)));

      return {
        status: stopped ? 'stopped' : 'completed',
        name: sequenceName,
      };
    } finally {
      if (activeSequences.get(sequenceName) === executionToken) {
        activeSequences.delete(sequenceName);
      }
    }
  },
};
