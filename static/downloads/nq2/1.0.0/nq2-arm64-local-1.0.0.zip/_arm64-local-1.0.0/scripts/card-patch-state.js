module.exports = {
  name: 'Card: Patch State',
  description: 'Patch selected keys in card state. Undefined values remove keys.',
  params: [
    {
      key: 'card',
      required: true,
      type: 'id',
      subtype: 'card',
      description: 'Card ID',
      default: '',
    },
    {
      key: 'state',
      required: true,
      type: 'object',
      description: 'State patch. Keys with undefined values are removed.',
      default: {},
    },
  ],
  tags: ['card', 'core'],
  function: async (params, fn) => {
    const cardId = params.card || params.cardId || params.id;
    const patch = params.state || params.patch || {};

    if (!cardId) {
      throw new Error('card is required');
    }
    if (!patch || typeof patch !== 'object' || Array.isArray(patch)) {
      throw new Error('state must be an object');
    }

    const card = await fn.cards.getById(cardId);
    const nextState = { ...(card.state || {}) };

    const resolveValue = (value) => {
      if (value === 'new Date()') {
        return new Date();
      }
      return value;
    };

    for (const [key, value] of Object.entries(patch)) {
      if (value === undefined) {
        delete nextState[key];
      } else {
        nextState[key] = resolveValue(value);
      }
    }

    await fn.cards.setState(cardId, nextState);
    return nextState;
  },
};
