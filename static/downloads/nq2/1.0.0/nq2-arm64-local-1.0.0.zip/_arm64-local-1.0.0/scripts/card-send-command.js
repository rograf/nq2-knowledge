module.exports = {
  name: 'Card: Send Command',
  description: 'Sends a command to one selected card field.',
  params: [
    {
      key: 'card',
      required: true,
      type: 'id',
      subtype: 'card',
      description: 'Card ID. You can use @card._id from card triggers.',
      default: '',
    },
    {
      key: 'key',
      required: false,
      type: 'string',
      subtype: 'card-field',
      relation: 'card',
      description: 'Card field key.',
      default: '',
    },
    {
      key: 'value',
      required: false,
      type: 'any',
      subtype: 'card-field-value',
      relation: 'key',
      description: 'Value sent to card field.',
    },
  ],
  tags: ['card', 'core'],
  function: async (params, fn) => {
    const cardId = params.card || params.cardId || params.id;
    let value = params.value;

    if (!cardId) {
      throw new Error('card is required');
    }

    if (typeof value === 'string') {
      try {
        value = JSON.parse(value);
      } catch (error) {
        value = params.value;
      }
    }

    const payload = {};
    if (params.key) {
      payload.key = params.key;
    }
    if (value !== undefined) {
      payload.value = value;
    }

    return await fn.cards.sendCommand(cardId, payload);
  },
};
