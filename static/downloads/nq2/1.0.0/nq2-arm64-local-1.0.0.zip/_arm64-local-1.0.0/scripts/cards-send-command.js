module.exports = {
  name: 'Cards: Send Command',
  description: 'Sends a command to selected card fields.',
  params: [
    {
      key: 'cards',
      required: true,
      type: 'ids',
      subtype: 'cards',
      description: 'Sends a command to selected card fields.',
      default: false,
    },
    {
      key: 'key',
      required: false,
      type: 'string',
      subtype: 'card-field',
      description: 'Card field key',
      default: '',
    },
    {
      key: 'value',
      required: false,
      type: 'any',
      subtype: 'card-field-value',
      description: 'Value sent to card field',
    },
    {
      key: 'parallel',
      required: false,
      type: 'boolean',
      description: 'Run commands in parallel. Disabled means cards are processed one by one.',
      default: false,
    },
  ],
  tags: ['card', 'core'],
  function: async (params, fn) => {
    const cards = Array.isArray(params.cards) ? params.cards : [params.cards];
    let value = params.value;

    if (typeof value === 'string') {
      try {
        value = JSON.parse(value);
      } catch (e) {
        value = params.value;
      }
    }

    const payload = {};
    if (params.key) {
      payload.key = params.key;
    }
    if (value !== undefined) {
      payload.value = value;
    }

    const send = (cardId) => fn.cards.sendCommand(cardId, payload);

    if (params.parallel) {
      return await Promise.all(cards.map(send));
    }

    const results = [];
    for (const cardId of cards) {
      results.push(await send(cardId));
    }

    return results;
  },
};

