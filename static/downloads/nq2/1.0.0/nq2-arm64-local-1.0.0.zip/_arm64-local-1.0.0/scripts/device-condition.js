module.exports = {
  name: 'Device: Condition',
  description: 'Checks a device provider state value and can stop following scripts when the condition does not match.',
  waitForCompletion: true,
  params: [
    {
      key: 'device',
      label: 'Device',
      required: true,
      type: 'id',
      subtype: 'device',
      description: 'Device to check. You can pass a static device ID or a dynamic value such as @device._id.',
    },
    {
      key: 'key',
      label: 'State',
      required: true,
      type: 'string',
      subtype: 'device-state',
      relation: 'device',
      description: 'Provider state key to read from the selected device.',
    },
    {
      key: 'operator',
      label: 'Operator',
      required: true,
      type: 'enum',
      options: [
        '$eq',
        '$ne',
        '$gt',
        '$gte',
        '$lt',
        '$lte',
        '$in',
        '$nin',
        '$exists',
        '$notExists',
        '$truthy',
        '$falsy',
      ],
      default: '$eq',
      description: 'Comparison operator.',
    },
    {
      key: 'value',
      label: 'Value',
      required: false,
      type: 'any',
      subtype: 'device-state-value',
      relation: 'key',
      description: 'Expected value. Ignored by exists, not-exists, truthy, and falsy.',
    },
  ],
  tags: ['device', 'core'],
  function: async (params, fn) => {
    const deviceId = params.device;
    const key = String(params.key || '').trim();
    const operator = params.operator || '$eq';

    if (!deviceId) {
      throw new Error('device is required');
    }
    if (!key) {
      throw new Error('key is required');
    }

    const device = await fn.devices.getById(deviceId);
    const state = device?.state || {};
    const currentValue = state[key];
    const expectedValue = params.value;
    const hasValue = Object.prototype.hasOwnProperty.call(state, key);

    const normalizeString = (value) => String(value ?? '').toLowerCase();
    const toNumber = (value) => {
      const number = Number(value);
      return Number.isFinite(number) ? number : NaN;
    };
    const valuesEqual = (left, right) => {
      if (Object.is(left, right)) return true;

      if (
        left &&
        right &&
        typeof left === 'object' &&
        typeof right === 'object'
      ) {
        try {
          return JSON.stringify(left) === JSON.stringify(right);
        } catch (error) {
          return false;
        }
      }

      return normalizeString(left) === normalizeString(right);
    };
    const contains = (left, right) => {
      if (Array.isArray(left)) {
        return left.some((item) => valuesEqual(item, right));
      }
      if (left && typeof left === 'object') {
        return Object.prototype.hasOwnProperty.call(left, String(right));
      }
      return normalizeString(left).includes(normalizeString(right));
    };

    const matched = (() => {
      switch (operator) {
        case '$eq':
          return valuesEqual(currentValue, expectedValue);
        case '$ne':
          return !valuesEqual(currentValue, expectedValue);
        case '$gt':
          return toNumber(currentValue) > toNumber(expectedValue);
        case '$gte':
          return toNumber(currentValue) >= toNumber(expectedValue);
        case '$lt':
          return toNumber(currentValue) < toNumber(expectedValue);
        case '$lte':
          return toNumber(currentValue) <= toNumber(expectedValue);
        case '$in':
          return contains(currentValue, expectedValue);
        case '$nin':
          return !contains(currentValue, expectedValue);
        case '$exists':
          return hasValue && currentValue !== undefined && currentValue !== null;
        case '$notExists':
          return !hasValue || currentValue === undefined || currentValue === null;
        case '$truthy':
          return Boolean(currentValue);
        case '$falsy':
          return !currentValue;
        default:
          throw new Error(`Unsupported operator: ${operator}`);
      }
    })();

    const result = {
      matched,
      device: deviceId,
      key,
      operator,
      currentValue,
      expectedValue,
    };

    fn.log('Device Condition:', result);

    if (!matched) {
      return fn.stop('Device condition did not match');
    }

    return result;
  },
};
