module.exports = {
  name: 'Device: Send Command',
  description: 'Send a value to a selected control field of a device.',
  params: [
    {
      key: 'device',
      label: 'Device',
      required: true,
      type: 'id',
      subtype: 'device',
      description: 'Target device.',
    },
    {
      key: 'key',
      label: 'Field',
      required: true,
      type: 'string',
      subtype: 'device-field',
      relation: 'device',
      description: 'Device control field.',
    },
    {
      key: 'value',
      label: 'Value',
      required: true,
      type: 'any',
      subtype: 'device-field-value',
      relation: 'key',
      description: 'Value sent to the selected field.',
    },
  ],
  tags: ['device', 'core'],
  function: async (params, fn) => {
    const deviceId = params.device;
    const key = String(params.key || '').trim();

    if (!deviceId) {
      throw new Error('device is required');
    }
    if (!key) {
      throw new Error('key is required');
    }

    await fn.devices.sendCommand(deviceId, { [key]: params.value });
  },
};
