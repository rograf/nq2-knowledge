module.exports = {
  name: 'Utility: Wait',
  description: 'Waits for the configured amount of time before the next script continues.',
  waitForCompletion: true,
  params: [
    {
      key: 'durationMs',
      label: 'Duration',
      required: true,
      type: 'number',
      subtype: 'milliseconds',
      description: 'How long to wait. Stored and executed in milliseconds.',
      default: 1000,
    },
  ],
  tags: ['utility'],
  function: async (params, fn) => {
    const durationMs = Number(params.durationMs);

    if (!Number.isFinite(durationMs) || durationMs < 0) {
      throw new Error('durationMs must be a non-negative number');
    }

    await fn.sleep(durationMs / 1000);
    return { waitedMs: durationMs };
  },
};
