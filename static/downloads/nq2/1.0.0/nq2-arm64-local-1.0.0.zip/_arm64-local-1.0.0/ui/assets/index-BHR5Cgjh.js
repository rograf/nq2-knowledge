var e=Object.defineProperty,t=(t,n)=>{let r={};for(var i in t)e(r,i,{get:t[i],enumerable:!0});return n||e(r,Symbol.toStringTag,{value:`Module`}),r};(function(){let e=document.createElement(`link`).relList;if(e&&e.supports&&e.supports(`modulepreload`))return;for(let e of document.querySelectorAll(`link[rel="modulepreload"]`))n(e);new MutationObserver(e=>{for(let t of e)if(t.type===`childList`)for(let e of t.addedNodes)e.tagName===`LINK`&&e.rel===`modulepreload`&&n(e)}).observe(document,{childList:!0,subtree:!0});function t(e){let t={};return e.integrity&&(t.integrity=e.integrity),e.referrerPolicy&&(t.referrerPolicy=e.referrerPolicy),e.crossOrigin===`use-credentials`?t.credentials=`include`:e.crossOrigin===`anonymous`?t.credentials=`omit`:t.credentials=`same-origin`,t}function n(e){if(e.ep)return;e.ep=!0;let n=t(e);fetch(e.href,n)}})();var n=globalThis,r=n.ShadowRoot&&(n.ShadyCSS===void 0||n.ShadyCSS.nativeShadow)&&`adoptedStyleSheets`in Document.prototype&&`replace`in CSSStyleSheet.prototype,i=Symbol(),a=new WeakMap,o=class{constructor(e,t,n){if(this._$cssResult$=!0,n!==i)throw Error("CSSResult is not constructable. Use `unsafeCSS` or `css` instead.");this.cssText=e,this.t=t}get styleSheet(){let e=this.o,t=this.t;if(r&&e===void 0){let n=t!==void 0&&t.length===1;n&&(e=a.get(t)),e===void 0&&((this.o=e=new CSSStyleSheet).replaceSync(this.cssText),n&&a.set(t,e))}return e}toString(){return this.cssText}},s=e=>new o(typeof e==`string`?e:e+``,void 0,i),c=(e,...t)=>new o(e.length===1?e[0]:t.reduce(((t,n,r)=>t+(e=>{if(!0===e._$cssResult$)return e.cssText;if(typeof e==`number`)return e;throw Error(`Value passed to 'css' function must be a 'css' function result: `+e+`. Use 'unsafeCSS' to pass non-literal values, but take care to ensure page security.`)})(n)+e[r+1]),e[0]),e,i),l=(e,t)=>{if(r)e.adoptedStyleSheets=t.map((e=>e instanceof CSSStyleSheet?e:e.styleSheet));else for(let r of t){let t=document.createElement(`style`),i=n.litNonce;i!==void 0&&t.setAttribute(`nonce`,i),t.textContent=r.cssText,e.appendChild(t)}},u=r?e=>e:e=>e instanceof CSSStyleSheet?(e=>{let t=``;for(let n of e.cssRules)t+=n.cssText;return s(t)})(e):e,{is:d,defineProperty:f,getOwnPropertyDescriptor:p,getOwnPropertyNames:m,getOwnPropertySymbols:h,getPrototypeOf:g}=Object,_=globalThis,ee=_.trustedTypes,te=ee?ee.emptyScript:``,ne=_.reactiveElementPolyfillSupport,re=(e,t)=>e,ie={toAttribute(e,t){switch(t){case Boolean:e=e?te:null;break;case Object:case Array:e=e==null?e:JSON.stringify(e)}return e},fromAttribute(e,t){let n=e;switch(t){case Boolean:n=e!==null;break;case Number:n=e===null?null:Number(e);break;case Object:case Array:try{n=JSON.parse(e)}catch{n=null}}return n}},ae=(e,t)=>!d(e,t),oe={attribute:!0,type:String,converter:ie,reflect:!1,useDefault:!1,hasChanged:ae};Symbol.metadata??=Symbol(`metadata`),_.litPropertyMetadata??=new WeakMap;var se=class extends HTMLElement{static addInitializer(e){this._$Ei(),(this.l??=[]).push(e)}static get observedAttributes(){return this.finalize(),this._$Eh&&[...this._$Eh.keys()]}static createProperty(e,t=oe){if(t.state&&(t.attribute=!1),this._$Ei(),this.prototype.hasOwnProperty(e)&&((t=Object.create(t)).wrapped=!0),this.elementProperties.set(e,t),!t.noAccessor){let n=Symbol(),r=this.getPropertyDescriptor(e,n,t);r!==void 0&&f(this.prototype,e,r)}}static getPropertyDescriptor(e,t,n){let{get:r,set:i}=p(this.prototype,e)??{get(){return this[t]},set(e){this[t]=e}};return{get:r,set(t){let a=r?.call(this);i?.call(this,t),this.requestUpdate(e,a,n)},configurable:!0,enumerable:!0}}static getPropertyOptions(e){return this.elementProperties.get(e)??oe}static _$Ei(){if(this.hasOwnProperty(re(`elementProperties`)))return;let e=g(this);e.finalize(),e.l!==void 0&&(this.l=[...e.l]),this.elementProperties=new Map(e.elementProperties)}static finalize(){if(this.hasOwnProperty(re(`finalized`)))return;if(this.finalized=!0,this._$Ei(),this.hasOwnProperty(re(`properties`))){let e=this.properties,t=[...m(e),...h(e)];for(let n of t)this.createProperty(n,e[n])}let e=this[Symbol.metadata];if(e!==null){let t=litPropertyMetadata.get(e);if(t!==void 0)for(let[e,n]of t)this.elementProperties.set(e,n)}this._$Eh=new Map;for(let[e,t]of this.elementProperties){let n=this._$Eu(e,t);n!==void 0&&this._$Eh.set(n,e)}this.elementStyles=this.finalizeStyles(this.styles)}static finalizeStyles(e){let t=[];if(Array.isArray(e)){let n=new Set(e.flat(1/0).reverse());for(let e of n)t.unshift(u(e))}else e!==void 0&&t.push(u(e));return t}static _$Eu(e,t){let n=t.attribute;return!1===n?void 0:typeof n==`string`?n:typeof e==`string`?e.toLowerCase():void 0}constructor(){super(),this._$Ep=void 0,this.isUpdatePending=!1,this.hasUpdated=!1,this._$Em=null,this._$Ev()}_$Ev(){this._$ES=new Promise((e=>this.enableUpdating=e)),this._$AL=new Map,this._$E_(),this.requestUpdate(),this.constructor.l?.forEach((e=>e(this)))}addController(e){(this._$EO??=new Set).add(e),this.renderRoot!==void 0&&this.isConnected&&e.hostConnected?.()}removeController(e){this._$EO?.delete(e)}_$E_(){let e=new Map,t=this.constructor.elementProperties;for(let n of t.keys())this.hasOwnProperty(n)&&(e.set(n,this[n]),delete this[n]);e.size>0&&(this._$Ep=e)}createRenderRoot(){let e=this.shadowRoot??this.attachShadow(this.constructor.shadowRootOptions);return l(e,this.constructor.elementStyles),e}connectedCallback(){this.renderRoot??=this.createRenderRoot(),this.enableUpdating(!0),this._$EO?.forEach((e=>e.hostConnected?.()))}enableUpdating(e){}disconnectedCallback(){this._$EO?.forEach((e=>e.hostDisconnected?.()))}attributeChangedCallback(e,t,n){this._$AK(e,n)}_$ET(e,t){let n=this.constructor.elementProperties.get(e),r=this.constructor._$Eu(e,n);if(r!==void 0&&!0===n.reflect){let i=(n.converter?.toAttribute===void 0?ie:n.converter).toAttribute(t,n.type);this._$Em=e,i==null?this.removeAttribute(r):this.setAttribute(r,i),this._$Em=null}}_$AK(e,t){let n=this.constructor,r=n._$Eh.get(e);if(r!==void 0&&this._$Em!==r){let e=n.getPropertyOptions(r),i=typeof e.converter==`function`?{fromAttribute:e.converter}:e.converter?.fromAttribute===void 0?ie:e.converter;this._$Em=r;let a=i.fromAttribute(t,e.type);this[r]=a??this._$Ej?.get(r)??a,this._$Em=null}}requestUpdate(e,t,n){if(e!==void 0){let r=this.constructor,i=this[e];if(n??=r.getPropertyOptions(e),!((n.hasChanged??ae)(i,t)||n.useDefault&&n.reflect&&i===this._$Ej?.get(e)&&!this.hasAttribute(r._$Eu(e,n))))return;this.C(e,t,n)}!1===this.isUpdatePending&&(this._$ES=this._$EP())}C(e,t,{useDefault:n,reflect:r,wrapped:i},a){n&&!(this._$Ej??=new Map).has(e)&&(this._$Ej.set(e,a??t??this[e]),!0!==i||a!==void 0)||(this._$AL.has(e)||(this.hasUpdated||n||(t=void 0),this._$AL.set(e,t)),!0===r&&this._$Em!==e&&(this._$Eq??=new Set).add(e))}async _$EP(){this.isUpdatePending=!0;try{await this._$ES}catch(e){Promise.reject(e)}let e=this.scheduleUpdate();return e!=null&&await e,!this.isUpdatePending}scheduleUpdate(){return this.performUpdate()}performUpdate(){if(!this.isUpdatePending)return;if(!this.hasUpdated){if(this.renderRoot??=this.createRenderRoot(),this._$Ep){for(let[e,t]of this._$Ep)this[e]=t;this._$Ep=void 0}let e=this.constructor.elementProperties;if(e.size>0)for(let[t,n]of e){let{wrapped:e}=n,r=this[t];!0!==e||this._$AL.has(t)||r===void 0||this.C(t,void 0,n,r)}}let e=!1,t=this._$AL;try{e=this.shouldUpdate(t),e?(this.willUpdate(t),this._$EO?.forEach((e=>e.hostUpdate?.())),this.update(t)):this._$EM()}catch(t){throw e=!1,this._$EM(),t}e&&this._$AE(t)}willUpdate(e){}_$AE(e){this._$EO?.forEach((e=>e.hostUpdated?.())),this.hasUpdated||(this.hasUpdated=!0,this.firstUpdated(e)),this.updated(e)}_$EM(){this._$AL=new Map,this.isUpdatePending=!1}get updateComplete(){return this.getUpdateComplete()}getUpdateComplete(){return this._$ES}shouldUpdate(e){return!0}update(e){this._$Eq&&=this._$Eq.forEach((e=>this._$ET(e,this[e]))),this._$EM()}updated(e){}firstUpdated(e){}};se.elementStyles=[],se.shadowRootOptions={mode:`open`},se[re(`elementProperties`)]=new Map,se[re(`finalized`)]=new Map,ne?.({ReactiveElement:se}),(_.reactiveElementVersions??=[]).push(`2.1.1`);var ce=globalThis,le=ce.trustedTypes,ue=le?le.createPolicy(`lit-html`,{createHTML:e=>e}):void 0,de=`$lit$`,fe=`lit$${Math.random().toFixed(9).slice(2)}$`,pe=`?`+fe,me=`<${pe}>`,he=document,ge=()=>he.createComment(``),_e=e=>e===null||typeof e!=`object`&&typeof e!=`function`,ve=Array.isArray,ye=e=>ve(e)||typeof e?.[Symbol.iterator]==`function`,be=`[ 	
\f\r]`,xe=/<(?:(!--|\/[^a-zA-Z])|(\/?[a-zA-Z][^>\s]*)|(\/?$))/g,Se=/-->/g,Ce=/>/g,we=RegExp(`>|${be}(?:([^\\s"'>=/]+)(${be}*=${be}*(?:[^ \t\n\f\r"'\`<>=]|("|')|))|$)`,`g`),Te=/'/g,Ee=/"/g,De=/^(?:script|style|textarea|title)$/i,Oe=e=>(t,...n)=>({_$litType$:e,strings:t,values:n}),v=Oe(1),ke=Oe(2),Ae=Symbol.for(`lit-noChange`),y=Symbol.for(`lit-nothing`),je=new WeakMap,Me=he.createTreeWalker(he,129);function Ne(e,t){if(!ve(e)||!e.hasOwnProperty(`raw`))throw Error(`invalid template strings array`);return ue===void 0?t:ue.createHTML(t)}var Pe=(e,t)=>{let n=e.length-1,r=[],i,a=t===2?`<svg>`:t===3?`<math>`:``,o=xe;for(let t=0;t<n;t++){let n=e[t],s,c,l=-1,u=0;for(;u<n.length&&(o.lastIndex=u,c=o.exec(n),c!==null);)u=o.lastIndex,o===xe?c[1]===`!--`?o=Se:c[1]===void 0?c[2]===void 0?c[3]!==void 0&&(o=we):(De.test(c[2])&&(i=RegExp(`</`+c[2],`g`)),o=we):o=Ce:o===we?c[0]===`>`?(o=i??xe,l=-1):c[1]===void 0?l=-2:(l=o.lastIndex-c[2].length,s=c[1],o=c[3]===void 0?we:c[3]===`"`?Ee:Te):o===Ee||o===Te?o=we:o===Se||o===Ce?o=xe:(o=we,i=void 0);let d=o===we&&e[t+1].startsWith(`/>`)?` `:``;a+=o===xe?n+me:l>=0?(r.push(s),n.slice(0,l)+de+n.slice(l)+fe+d):n+fe+(l===-2?t:d)}return[Ne(e,a+(e[n]||`<?>`)+(t===2?`</svg>`:t===3?`</math>`:``)),r]},Fe=class e{constructor({strings:t,_$litType$:n},r){let i;this.parts=[];let a=0,o=0,s=t.length-1,c=this.parts,[l,u]=Pe(t,n);if(this.el=e.createElement(l,r),Me.currentNode=this.el.content,n===2||n===3){let e=this.el.content.firstChild;e.replaceWith(...e.childNodes)}for(;(i=Me.nextNode())!==null&&c.length<s;){if(i.nodeType===1){if(i.hasAttributes())for(let e of i.getAttributeNames())if(e.endsWith(de)){let t=u[o++],n=i.getAttribute(e).split(fe),r=/([.?@])?(.*)/.exec(t);c.push({type:1,index:a,name:r[2],strings:n,ctor:r[1]===`.`?Be:r[1]===`?`?Ve:r[1]===`@`?He:ze}),i.removeAttribute(e)}else e.startsWith(fe)&&(c.push({type:6,index:a}),i.removeAttribute(e));if(De.test(i.tagName)){let e=i.textContent.split(fe),t=e.length-1;if(t>0){i.textContent=le?le.emptyScript:``;for(let n=0;n<t;n++)i.append(e[n],ge()),Me.nextNode(),c.push({type:2,index:++a});i.append(e[t],ge())}}}else if(i.nodeType===8)if(i.data===pe)c.push({type:2,index:a});else{let e=-1;for(;(e=i.data.indexOf(fe,e+1))!==-1;)c.push({type:7,index:a}),e+=fe.length-1}a++}}static createElement(e,t){let n=he.createElement(`template`);return n.innerHTML=e,n}};function Ie(e,t,n=e,r){if(t===Ae)return t;let i=r===void 0?n._$Cl:n._$Co?.[r],a=_e(t)?void 0:t._$litDirective$;return i?.constructor!==a&&(i?._$AO?.(!1),a===void 0?i=void 0:(i=new a(e),i._$AT(e,n,r)),r===void 0?n._$Cl=i:(n._$Co??=[])[r]=i),i!==void 0&&(t=Ie(e,i._$AS(e,t.values),i,r)),t}var Le=class{constructor(e,t){this._$AV=[],this._$AN=void 0,this._$AD=e,this._$AM=t}get parentNode(){return this._$AM.parentNode}get _$AU(){return this._$AM._$AU}u(e){let{el:{content:t},parts:n}=this._$AD,r=(e?.creationScope??he).importNode(t,!0);Me.currentNode=r;let i=Me.nextNode(),a=0,o=0,s=n[0];for(;s!==void 0;){if(a===s.index){let t;s.type===2?t=new Re(i,i.nextSibling,this,e):s.type===1?t=new s.ctor(i,s.name,s.strings,this,e):s.type===6&&(t=new Ue(i,this,e)),this._$AV.push(t),s=n[++o]}a!==s?.index&&(i=Me.nextNode(),a++)}return Me.currentNode=he,r}p(e){let t=0;for(let n of this._$AV)n!==void 0&&(n.strings===void 0?n._$AI(e[t]):(n._$AI(e,n,t),t+=n.strings.length-2)),t++}},Re=class e{get _$AU(){return this._$AM?._$AU??this._$Cv}constructor(e,t,n,r){this.type=2,this._$AH=y,this._$AN=void 0,this._$AA=e,this._$AB=t,this._$AM=n,this.options=r,this._$Cv=r?.isConnected??!0}get parentNode(){let e=this._$AA.parentNode,t=this._$AM;return t!==void 0&&e?.nodeType===11&&(e=t.parentNode),e}get startNode(){return this._$AA}get endNode(){return this._$AB}_$AI(e,t=this){e=Ie(this,e,t),_e(e)?e===y||e==null||e===``?(this._$AH!==y&&this._$AR(),this._$AH=y):e!==this._$AH&&e!==Ae&&this._(e):e._$litType$===void 0?e.nodeType===void 0?ye(e)?this.k(e):this._(e):this.T(e):this.$(e)}O(e){return this._$AA.parentNode.insertBefore(e,this._$AB)}T(e){this._$AH!==e&&(this._$AR(),this._$AH=this.O(e))}_(e){this._$AH!==y&&_e(this._$AH)?this._$AA.nextSibling.data=e:this.T(he.createTextNode(e)),this._$AH=e}$(e){let{values:t,_$litType$:n}=e,r=typeof n==`number`?this._$AC(e):(n.el===void 0&&(n.el=Fe.createElement(Ne(n.h,n.h[0]),this.options)),n);if(this._$AH?._$AD===r)this._$AH.p(t);else{let e=new Le(r,this),n=e.u(this.options);e.p(t),this.T(n),this._$AH=e}}_$AC(e){let t=je.get(e.strings);return t===void 0&&je.set(e.strings,t=new Fe(e)),t}k(t){ve(this._$AH)||(this._$AH=[],this._$AR());let n=this._$AH,r,i=0;for(let a of t)i===n.length?n.push(r=new e(this.O(ge()),this.O(ge()),this,this.options)):r=n[i],r._$AI(a),i++;i<n.length&&(this._$AR(r&&r._$AB.nextSibling,i),n.length=i)}_$AR(e=this._$AA.nextSibling,t){for(this._$AP?.(!1,!0,t);e!==this._$AB;){let t=e.nextSibling;e.remove(),e=t}}setConnected(e){this._$AM===void 0&&(this._$Cv=e,this._$AP?.(e))}},ze=class{get tagName(){return this.element.tagName}get _$AU(){return this._$AM._$AU}constructor(e,t,n,r,i){this.type=1,this._$AH=y,this._$AN=void 0,this.element=e,this.name=t,this._$AM=r,this.options=i,n.length>2||n[0]!==``||n[1]!==``?(this._$AH=Array(n.length-1).fill(new String),this.strings=n):this._$AH=y}_$AI(e,t=this,n,r){let i=this.strings,a=!1;if(i===void 0)e=Ie(this,e,t,0),a=!_e(e)||e!==this._$AH&&e!==Ae,a&&(this._$AH=e);else{let r=e,o,s;for(e=i[0],o=0;o<i.length-1;o++)s=Ie(this,r[n+o],t,o),s===Ae&&(s=this._$AH[o]),a||=!_e(s)||s!==this._$AH[o],s===y?e=y:e!==y&&(e+=(s??``)+i[o+1]),this._$AH[o]=s}a&&!r&&this.j(e)}j(e){e===y?this.element.removeAttribute(this.name):this.element.setAttribute(this.name,e??``)}},Be=class extends ze{constructor(){super(...arguments),this.type=3}j(e){this.element[this.name]=e===y?void 0:e}},Ve=class extends ze{constructor(){super(...arguments),this.type=4}j(e){this.element.toggleAttribute(this.name,!!e&&e!==y)}},He=class extends ze{constructor(e,t,n,r,i){super(e,t,n,r,i),this.type=5}_$AI(e,t=this){if((e=Ie(this,e,t,0)??y)===Ae)return;let n=this._$AH,r=e===y&&n!==y||e.capture!==n.capture||e.once!==n.once||e.passive!==n.passive,i=e!==y&&(n===y||r);r&&this.element.removeEventListener(this.name,this,n),i&&this.element.addEventListener(this.name,this,e),this._$AH=e}handleEvent(e){typeof this._$AH==`function`?this._$AH.call(this.options?.host??this.element,e):this._$AH.handleEvent(e)}},Ue=class{constructor(e,t,n){this.element=e,this.type=6,this._$AN=void 0,this._$AM=t,this.options=n}get _$AU(){return this._$AM._$AU}_$AI(e){Ie(this,e)}},We={M:de,P:fe,A:pe,C:1,L:Pe,R:Le,D:ye,V:Ie,I:Re,H:ze,N:Ve,U:He,B:Be,F:Ue},Ge=ce.litHtmlPolyfillSupport;Ge?.(Fe,Re),(ce.litHtmlVersions??=[]).push(`3.3.1`);var Ke=(e,t,n)=>{let r=n?.renderBefore??t,i=r._$litPart$;if(i===void 0){let e=n?.renderBefore??null;r._$litPart$=i=new Re(t.insertBefore(ge(),e),e,void 0,n??{})}return i._$AI(e),i},qe=globalThis,b=class extends se{constructor(){super(...arguments),this.renderOptions={host:this},this._$Do=void 0}createRenderRoot(){let e=super.createRenderRoot();return this.renderOptions.renderBefore??=e.firstChild,e}update(e){let t=this.render();this.hasUpdated||(this.renderOptions.isConnected=this.isConnected),super.update(e),this._$Do=Ke(t,this.renderRoot,this.renderOptions)}connectedCallback(){super.connectedCallback(),this._$Do?.setConnected(!0)}disconnectedCallback(){super.disconnectedCallback(),this._$Do?.setConnected(!1)}render(){return Ae}};b._$litElement$=!0,b.finalized=!0,qe.litElementHydrateSupport?.({LitElement:b});var Je=qe.litElementPolyfillSupport;Je?.({LitElement:b}),(qe.litElementVersions??=[]).push(`4.2.1`);var x=e=>(t,n)=>{n===void 0?customElements.define(e,t):n.addInitializer((()=>{customElements.define(e,t)}))},Ye={attribute:!0,type:String,converter:ie,reflect:!1,hasChanged:ae},Xe=(e=Ye,t,n)=>{let{kind:r,metadata:i}=n,a=globalThis.litPropertyMetadata.get(i);if(a===void 0&&globalThis.litPropertyMetadata.set(i,a=new Map),r===`setter`&&((e=Object.create(e)).wrapped=!0),a.set(n.name,e),r===`accessor`){let{name:r}=n;return{set(n){let i=t.get.call(this);t.set.call(this,n),this.requestUpdate(r,i,e)},init(t){return t!==void 0&&this.C(r,void 0,e,t),t}}}if(r===`setter`){let{name:r}=n;return function(n){let i=this[r];t.call(this,n),this.requestUpdate(r,i,e)}}throw Error(`Unsupported decorator location: `+r)};function S(e){return(t,n)=>typeof n==`object`?Xe(e,t,n):((e,t,n)=>{let r=t.hasOwnProperty(n);return t.constructor.createProperty(n,e),r?Object.getOwnPropertyDescriptor(t,n):void 0})(e,t,n)}function C(e){return S({...e,state:!0,attribute:!1})}var Ze=(e,t,n)=>(n.configurable=!0,n.enumerable=!0,Reflect.decorate&&typeof t!=`object`&&Object.defineProperty(e,t,n),n);function Qe(e,t){return(n,r,i)=>{let a=t=>t.renderRoot?.querySelector(e)??null;if(t){let{get:e,set:t}=typeof r==`object`?n:i??(()=>{let e=Symbol();return{get(){return this[e]},set(t){this[e]=t}}})();return Ze(n,r,{get(){let n=e.call(this);return n===void 0&&(n=a(this),(n!==null||this.hasUpdated)&&t.call(this,n)),n}})}return Ze(n,r,{get(){return a(this)}})}}var w=class extends b{createRenderRoot(){return this}},$e=e=>(e.startsWith(`#`)?e.slice(1):e).split(`?`)[0].split(`#`)[0].trim().replace(/\/{2,}/g,`/`).replace(/^\/+/,``).replace(/\/+$/g,``),et=e=>e?e.split(`/`).map(e=>e.trim()).filter(Boolean):[],tt=e=>{let t=e??(typeof window<`u`?window.location.hash:``),n=t.indexOf(`?`);if(n===-1)return{};let r=t.slice(n+1).split(`#`)[0],i={};return r.split(`&`).forEach(e=>{let[t,n]=e.split(`=`);t&&(i[decodeURIComponent(t)]=n?decodeURIComponent(n):``)}),i},nt=new class{constructor(){this.listeners=new Set,this.handleHashChange=()=>{this.notify(this.currentPath)},typeof window<`u`&&(window.addEventListener(`hashchange`,this.handleHashChange),window.addEventListener(`load`,this.handleHashChange))}get currentPath(){return typeof window>`u`?``:$e(window.location.hash)}subscribe(e){return this.listeners.add(e),e(this.currentPath),()=>this.listeners.delete(e)}navigate(e,t){if(typeof window>`u`)return;let n=e.indexOf(`?`),r=n===-1?``:e.slice(n),i=$e(n===-1?e:e.slice(0,n)),a=i||r?`#${i}${r}`:`#`;if(i===this.currentPath&&!r){this.notify(i);return}if(t?.replace){let e=`${window.location.pathname}${window.location.search}${a}`;window.history.replaceState(null,``,e),this.notify(i)}else window.location.hash=a}notify(e){this.listeners.forEach(t=>t(e))}},T=(e,t)=>{nt.navigate(e,t)},rt=()=>nt.currentPath,it=(e,t)=>{let n=$e(t?.currentPath??nt.currentPath),r=$e(e);return r?t?.exact?n===r:n===r||n.startsWith(`${r}/`):t?.exact?n===``:n===``||n.startsWith(`/`)},at=()=>et(nt.currentPath),{I:ot}=We,st=e=>e.strings===void 0,ct=()=>document.createComment(``),lt=(e,t,n)=>{let r=e._$AA.parentNode,i=t===void 0?e._$AB:t._$AA;if(n===void 0)n=new ot(r.insertBefore(ct(),i),r.insertBefore(ct(),i),e,e.options);else{let t=n._$AB.nextSibling,a=n._$AM,o=a!==e;if(o){let t;n._$AQ?.(e),n._$AM=e,n._$AP!==void 0&&(t=e._$AU)!==a._$AU&&n._$AP(t)}if(t!==i||o){let e=n._$AA;for(;e!==t;){let t=e.nextSibling;r.insertBefore(e,i),e=t}}}return n},ut=(e,t,n=e)=>(e._$AI(t,n),e),dt={},ft=(e,t=dt)=>e._$AH=t,pt=e=>e._$AH,mt=e=>{e._$AR(),e._$AA.remove()},ht={ATTRIBUTE:1,CHILD:2,PROPERTY:3,BOOLEAN_ATTRIBUTE:4,EVENT:5,ELEMENT:6},gt=e=>(...t)=>({_$litDirective$:e,values:t}),_t=class{constructor(e){}get _$AU(){return this._$AM._$AU}_$AT(e,t,n){this._$Ct=e,this._$AM=t,this._$Ci=n}_$AS(e,t){return this.update(e,t)}update(e,t){return this.render(...t)}},vt=(e,t)=>{let n=e._$AN;if(n===void 0)return!1;for(let e of n)e._$AO?.(t,!1),vt(e,t);return!0},yt=e=>{let t,n;do{if((t=e._$AM)===void 0)break;n=t._$AN,n.delete(e),e=t}while(n?.size===0)},bt=e=>{for(let t;t=e._$AM;e=t){let n=t._$AN;if(n===void 0)t._$AN=n=new Set;else if(n.has(e))break;n.add(e),Ct(t)}};function xt(e){this._$AN===void 0?this._$AM=e:(yt(this),this._$AM=e,bt(this))}function St(e,t=!1,n=0){let r=this._$AH,i=this._$AN;if(i!==void 0&&i.size!==0)if(t)if(Array.isArray(r))for(let e=n;e<r.length;e++)vt(r[e],!1),yt(r[e]);else r!=null&&(vt(r,!1),yt(r));else vt(this,e)}var Ct=e=>{e.type==ht.CHILD&&(e._$AP??=St,e._$AQ??=xt)},wt=class extends _t{constructor(){super(...arguments),this._$AN=void 0}_$AT(e,t,n){super._$AT(e,t,n),bt(this),this.isConnected=e._$AU}_$AO(e,t=!0){e!==this.isConnected&&(this.isConnected=e,e?this.reconnected?.():this.disconnected?.()),t&&(vt(this,e),yt(this))}setValue(e){if(st(this._$Ct))this._$Ct._$AI(e,this);else{let t=[...this._$Ct._$AH];t[this._$Ci]=e,this._$Ct._$AI(t,this,0)}}disconnected(){}reconnected(){}},Tt=gt(class extends wt{constructor(e){if(super(e),e.type!==ht.BOOLEAN_ATTRIBUTE&&e.type!==ht.PROPERTY)throw Error(`routeActive() can only be used in boolean attribute or property bindings`)}render(){return!1}update(e,t){return this.element||(this.element=e.element,this.unsubscribe=nt.subscribe(()=>{this.setValue(this.checkActive())})),this.checkActive()}checkActive(){if(!this.element)return!1;let e=this.element.getAttribute(`routerlink`);return e?it(e):!1}disconnected(){this.unsubscribe?.(),this.unsubscribe=void 0}reconnected(){!this.unsubscribe&&this.element&&(this.unsubscribe=nt.subscribe(()=>{this.setValue(this.checkActive())}))}}),Et=gt(class extends wt{render(e=``,t=``,n){return this.activeClass=e,this.inactiveClass=t,this.targetPath=n,this.getClass()}update(e,[t,n,r]){return this.element||=e.element,this.activeClass=t??``,this.inactiveClass=n??``,this.targetPath=r,this.unsubscribe||=nt.subscribe(()=>{this.setValue(this.getClass())}),this.getClass()}getClass(){let e=this.targetPath;return!e&&this.element&&(e=this.element.getAttribute(`routerlink`)||``),e&&it(e)?this.activeClass??``:this.inactiveClass??``}disconnected(){this.unsubscribe?.(),this.unsubscribe=void 0}reconnected(){this.unsubscribe||=nt.subscribe(()=>{this.setValue(this.getClass())})}}),Dt=`router-link:navigate`,Ot=[`routerLink`,`routerlink`],kt=new WeakMap,At=e=>e.defaultPrevented||e.button!==0||e.metaKey||e.ctrlKey||e.shiftKey||e.altKey,jt=e=>`disabled`in e?!!e.disabled:e.getAttribute(`aria-disabled`)===`true`,Mt=(e,t)=>{if(t==null){e.dataset.routerLinkPath!==void 0&&delete e.dataset.routerLinkPath,e instanceof HTMLAnchorElement&&e.removeAttribute(`href`);return}let n=$e(t);if(e.dataset.routerLinkPath!==n&&(e.dataset.routerLinkPath=n),e instanceof HTMLAnchorElement){let t=n?`#${n}`:`#`;e.getAttribute(`href`)!==t&&e.setAttribute(`href`,t)}},Nt=e=>{if(e.dataset.routerLinkPath!==void 0)return e.dataset.routerLinkPath;for(let t of Ot)if(e.hasAttribute(t)){let n=e.getAttribute(t);return n==null?null:$e(n)}return null},Pt=e=>{let t=typeof e.composedPath==`function`?e.composedPath():[];for(let e of t)if(e instanceof HTMLElement&&(Ot.some(t=>e.hasAttribute(t))||e.dataset.routerLinkPath!==void 0))return e;return null},Ft=(e,t,n)=>e.dispatchEvent(new CustomEvent(Dt,{detail:{path:t,options:n},bubbles:!0,cancelable:!0,composed:!0})),It=e=>{if(At(e))return;let t=Pt(e);if(!t||jt(t))return;let n=Nt(t);if(n==null)return;let r=kt.get(t)??{};Ft(t,n,r)&&(e.preventDefault(),T(n,r))},Lt=()=>{typeof MutationObserver>`u`||new MutationObserver(e=>{e.forEach(e=>{if(e.type===`attributes`&&e.target instanceof HTMLElement&&e.attributeName&&Ot.includes(e.attributeName)){let t=e.target;Mt(t,t.getAttribute(e.attributeName)),kt.delete(t)}})}).observe(document.documentElement,{attributes:!0,attributeFilter:[...Ot],subtree:!0})};(()=>{if(typeof window>`u`||typeof document>`u`)return;document.addEventListener(`click`,e=>{e instanceof MouseEvent&&It(e)}),Lt();let e=Ot.map(e=>`[${e}]`).join(`,`);document.querySelectorAll(e).forEach(e=>{for(let t of Ot)if(e.hasAttribute(t)){Mt(e,e.getAttribute(t));break}})})();var Rt=class{constructor(e,t){this.host=e,this.propertyKey=t,this.host.addController(this)}hostConnected(){this.unsubscribe=nt.subscribe(e=>{this.host[this.propertyKey]=e})}hostDisconnected(){this.unsubscribe?.(),this.unsubscribe=void 0}};function zt(){return function(e,t){let n=`connectedCallback`,r=`disconnectedCallback`,i=e[n],a=e[r],o=new WeakMap;e[n]=function(){if(i&&i.call(this),!o.has(this)){let e=new Rt(this,t);o.set(this,e)}},e[r]=function(){a&&a.call(this),o.get(this)&&o.delete(this)}}}var Bt=class{constructor(e,t){this.host=e,this.propertyKey=t,this.host.addController(this)}hostConnected(){let e=this.host,t=Object.getOwnPropertyDescriptor(e,`routeParams`);if(t&&t.set){this.updateFromRouteParams();return}let n=e.routeParams||{};this.host[this.propertyKey]={...n};let r=this;Object.defineProperty(e,"routeParams",{get(){return n},set:e=>{let t=JSON.stringify(n)!==JSON.stringify(e);if(n=e,t){let t=r.host[r.propertyKey];r.host[r.propertyKey]={...e},r.host.requestUpdate&&r.host.requestUpdate(r.propertyKey,t)}},configurable:!0,enumerable:!0})}hostDisconnected(){this.observer?.disconnect(),this.observer=void 0}updateFromRouteParams(){let e=this.host;e.routeParams&&(this.host[this.propertyKey]={...e.routeParams})}};function Vt(){return function(e,t){let n=`connectedCallback`,r=`disconnectedCallback`,i=e[n],a=e[r],o=new WeakMap;e[n]=function(){if(i&&i.call(this),!o.has(this)){let e=new Bt(this,t);o.set(this,e)}},e[r]=function(){a&&a.call(this),o.get(this)&&o.delete(this)}}}var Ht=Symbol.for(``),Ut=e=>{if(e?.r===Ht)return e?._$litStatic$},Wt=e=>({_$litStatic$:e,r:Ht}),Gt=new Map,Kt=(e=>(t,...n)=>{let r=n.length,i,a,o=[],s=[],c,l=0,u=!1;for(;l<r;){for(c=t[l];l<r&&(a=n[l],i=Ut(a))!==void 0;)c+=i+t[++l],u=!0;l!==r&&s.push(a),o.push(c),l++}if(l===r&&o.push(t[r]),u){let e=o.join(`$$lit$$`);(t=Gt.get(e))===void 0&&(o.raw=o,Gt.set(e,t=o)),n=s}return e(t,...n)})(v);function E(e,t){if(typeof Reflect==`object`&&typeof Reflect.metadata==`function`)return Reflect.metadata(e,t)}function D(e,t,n,r){var i=arguments.length,a=i<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,o;if(typeof Reflect==`object`&&typeof Reflect.decorate==`function`)a=Reflect.decorate(e,t,n,r);else for(var s=e.length-1;s>=0;s--)(o=e[s])&&(a=(i<3?o(a):i>3?o(t,n,a):o(t,n))||a);return i>3&&a&&Object.defineProperty(t,n,a),a}var qt=class extends w{constructor(){super(),this.activeMatch=null,this.activeParams={},this.parentContext=null,this.activeChildContext=null,this.childOutlets=new Set,this.lastSignature=``,this.activeElement=null,this.navigationToken=0,this.handleNavigation=this.handleNavigation.bind(this),this.handleContextRequest=this.handleContextRequest.bind(this)}connectedCallback(){super.connectedCallback(),this.addEventListener(`router-request-context`,this.handleContextRequest),this.requestParentContext(),this.parentOutlet||this.startRouterSubscription()}disconnectedCallback(){super.disconnectedCallback(),this.removeEventListener(`router-request-context`,this.handleContextRequest),this.stopRouterSubscription(),this.parentOutlet?.unregisterChildOutlet(this),this.childOutlets.forEach(e=>{e.parentOutlet===this&&e.detachFromParent(this)}),this.childOutlets.clear()}updated(e){e.has(`routes`)&&this.handleNavigation(nt.currentPath)}requestParentContext(){let e=!Array.isArray(this.routes)||this.routes.length===0,t=new CustomEvent(`router-request-context`,{detail:{requestor:this,requiresContext:e},bubbles:!0,composed:!0});this.dispatchEvent(t)}handleContextRequest(e){let{requestor:t,requiresContext:n}=e.detail;t!==this&&(!this.activeChildContext&&n||(this.registerChildOutlet(t),e.stopPropagation()))}registerChildOutlet(e){this.childOutlets.has(e)||this.childOutlets.add(e),e.attachToParent(this,this.activeChildContext)}unregisterChildOutlet(e){this.childOutlets.delete(e)&&e.detachFromParent(this)}attachToParent(e,t){this.parentOutlet=e,this.parentContext=t,this.stopRouterSubscription(),this.handleNavigation(nt.currentPath)}detachFromParent(e){this.parentOutlet===e&&(this.parentOutlet=void 0,this.parentContext=null,this.startRouterSubscription(),this.isConnected&&this.handleNavigation(nt.currentPath))}startRouterSubscription(){this.unsubscribe||=nt.subscribe(this.handleNavigation)}stopRouterSubscription(){this.unsubscribe&&=(this.unsubscribe(),void 0)}async handleNavigation(e){if(!this.isConnected)return;let t=++this.navigationToken,n=et(e),r=this.parentContext?.depth??0,i={...this.parentContext?.params??{}},a=this.routes??this.parentContext?.routes??[];if(!a.length){this.setMatch(null,{}),this.updateChildContexts(null);return}let o=this.matchRoutes(a,n,r,i);if(!o){this.setMatch(null,{}),this.updateChildContexts(null);return}if(`redirectTo`in o){t===this.navigationToken&&T(o.redirectTo,{replace:!0});return}let s=o,c=await this.evaluateGuards(s,n);if(t!==this.navigationToken)return;if(!c){this.setMatch(null,{}),this.updateChildContexts(null);return}this.setMatch(s,s.params);let l=s.route.children?{depth:s.startIndex+s.consumed,params:s.params,routes:s.route.children}:null;this.updateChildContexts(l)}setMatch(e,t){this.activeMatch=e,this.activeParams=t,(!e||typeof e.route.component==`string`)&&this.clearActiveElement();let n=e?`${e.route.path}|${JSON.stringify(t)}`:`::no-match::`;n!==this.lastSignature&&(this.lastSignature=n,this.dispatchEvent(new CustomEvent(`route-changed`,{detail:{route:e?.route??null,params:t},bubbles:!0,composed:!0})))}clearActiveElement(){this.activeElement?.parentNode&&this.activeElement.remove(),this.activeElement=null,this.activeElementCtor=void 0}updateChildContexts(e){this.activeChildContext=e,this.childOutlets.forEach(t=>{if(!t.isConnected){this.childOutlets.delete(t),t.detachFromParent(this);return}t.attachToParent(this,e)})}matchRoutes(e,t,n,r){for(let i of e){let e=this.tryMatchRoute(i,t,n,r);if(e)return e}return null}collectGuards(e){return e.canActivate?Array.isArray(e.canActivate)?e.canActivate:[e.canActivate]:[]}async evaluateGuards(e,t){let n=this.collectGuards(e.route);if(!n.length)return!0;let r=e.startIndex+e.consumed,i=t.slice(0,r).join(`/`),a={params:e.params,queryParams:tt(),path:i,route:e.route,navigate:T};for(let e of n){let t=await e(a);if(typeof t==`string`&&t.trim().length>0)return T(t,{replace:!0}),!1;if(t===!1)return!1}return!0}tryMatchRoute(e,t,n,r){let i={...r};if(t[n],e.path===``||e.path==null){if(e.children){let r=this.matchRoutes(e.children,t,n,i);if(r&&!(`redirectTo`in r))return{route:e,params:r.params,startIndex:n,consumed:0}}return t.length===n?e.redirectTo?{redirectTo:this.resolveRedirectPath(e.redirectTo,t.slice(0,n))}:{route:e,params:i,startIndex:n,consumed:0}:null}if(e.path===`**`)return i.wildcard=t.slice(n).join(`/`),e.redirectTo?{redirectTo:this.resolveRedirectPath(e.redirectTo,t.slice(0,n))}:{route:e,params:i,startIndex:n,consumed:t.length-n};let a=e.path.split(`/`).filter(Boolean);if(!a.length||t.length<n+a.length)return null;let o=0;for(let e=0;e<a.length;e++){let r=a[e],s=t[n+e];if(!s)return null;if(r.startsWith(`:`)){let e=r.slice(1);if(!e)return null;i[e]=decodeURIComponent(s),o+=1;continue}if(r!==s)return null;o+=1}if(e.redirectTo)return{redirectTo:this.resolveRedirectPath(e.redirectTo,t.slice(0,n+o))};if(e.children){let r=this.matchRoutes(e.children,t,n+o,i);if(r&&!(`redirectTo`in r))return{route:e,params:r.params,startIndex:n,consumed:o}}return t.length>n+o?null:{route:e,params:i,startIndex:n,consumed:o}}resolveRedirectPath(e,t){let n=e.trim();if(!n)return``;if(n.startsWith(`/`))return n;let[r,i]=n.split(`?`),a=et(r||``),o=[...t,...a].join(`/`);return i?`${o}?${i}`:o}render(){if(!this.activeMatch)return this.fallback??y;let{route:e}=this.activeMatch,t=this.activeParams;if(!e.component)return this.clearActiveElement(),this.fallback??y;if(typeof e.component==`string`){let n=Wt(e.component);return Kt`<${n} .routeParams=${t}></${n}>`}if((!this.activeElement||this.activeElementCtor!==e.component)&&(this.clearActiveElement(),this.activeElement=new e.component,this.activeElementCtor=e.component),this.activeElement){let n=this.activeElement;n.routeParams=t,e.children?n.routes=e.children:`routes`in n&&(n.routes=void 0)}return this.activeElement}};D([S({attribute:!1}),E(`design:type`,Array)],qt.prototype,`routes`,void 0),D([S({attribute:!1}),E(`design:type`,Object)],qt.prototype,`fallback`,void 0),D([C(),E(`design:type`,Object)],qt.prototype,`activeMatch`,void 0),D([C(),E(`design:type`,Object)],qt.prototype,`activeParams`,void 0),qt=D([x(`router-outlet`),E(`design:paramtypes`,[])],qt);var Jt=new Map;function Yt(e){Object.entries(e).forEach(([e,t])=>{Jt.set(e,t)})}function Xt(e){return Jt.get(e)}function Zt(){return Array.from(Jt.entries()).map(([e,t])=>({name:e,icon:t}))}var Qt=[[`path`,{d:`M6 3C3.58901 4.93486 2 8.24345 2 12C2 15.7565 3.58901 19.0651 6 21`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M18 3C20.411 4.93486 22 8.24345 22 12C22 15.7565 20.411 19.0651 18 21`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}]],$t=[[`path`,{d:`M12 11.5C12.4955 11.5 12.9562 11.3015 13.8775 10.9045L14.5423 10.618C16.1808 9.91202 17 9.55902 17 9C17 8.44098 16.1808 8.08798 14.5423 7.38197L13.8775 7.09549C12.9562 6.6985 12.4955 6.5 12 6.5C11.5045 6.5 11.0438 6.6985 10.1225 7.09549L9.45768 7.38197C7.81923 8.08798 7 8.44098 7 9C7 9.55902 7.81923 9.91202 9.45768 10.618L10.1225 10.9045C11.0438 11.3015 11.5045 11.5 12 11.5ZM12 11.5V17.5`,stroke:`currentColor`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M17 9V15C17 15.559 16.1808 15.912 14.5423 16.618L13.8775 16.9045C12.9562 17.3015 12.4955 17.5 12 17.5C11.5045 17.5 11.0438 17.3015 10.1225 16.9045L9.45768 16.618C7.81923 15.912 7 15.559 7 15V9`,stroke:`currentColor`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M9.14426 2.5C6.48724 2.56075 4.93529 2.81456 3.87493 3.87493C2.81456 4.93529 2.56075 6.48724 2.5 9.14426M14.8557 2.5C17.5128 2.56075 19.0647 2.81456 20.1251 3.87493C21.1854 4.93529 21.4392 6.48724 21.5 9.14426M14.8557 21.5C17.5128 21.4392 19.0647 21.1854 20.1251 20.1251C21.1854 19.0647 21.4392 17.5128 21.5 14.8557M9.14426 21.5C6.48724 21.4392 4.93529 21.1854 3.87493 20.1251C2.81456 19.0647 2.56075 17.5128 2.5 14.8557`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}]],O=[[`path`,{d:`M12.001 5.00003V19.002`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M19.002 12.002L4.99998 12.002`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}]],en=[[`path`,{d:`M7 4.5C5.34315 4.5 4 5.84315 4 7.5C4 8.06866 4.15822 8.60037 4.43304 9.0535C3.04727 9.31855 2 10.537 2 12C2 13.463 3.04727 14.6814 4.43304 14.9465M7 4.5C7 3.11929 8.11929 2 9.5 2C10.8807 2 12 3.11929 12 4.5V19.5C12 20.8807 10.8807 22 9.5 22C8.11929 22 7 20.8807 7 19.5C5.34315 19.5 4 18.1569 4 16.5C4 15.9313 4.15822 15.3996 4.43304 14.9465M7 4.5C7 5.31791 7.39278 6.04408 8 6.50018M4.43304 14.9465C4.78948 14.3588 5.34207 13.9032 6 13.6707`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M17 19.4999C18.6569 19.4999 20 18.1567 20 16.4999C20 15.9312 19.8418 15.3995 19.567 14.9464C20.9527 14.6813 22 13.4629 22 11.9999C22 10.5369 20.9527 9.31843 19.567 9.05338M17 19.4999C17 20.8806 15.8807 21.9999 14.5 21.9999C13.1193 21.9999 12 20.8806 12 19.4999L12 4.49988C12 3.11917 13.1193 1.99988 14.5 1.99988C15.8807 1.99988 17 3.11917 17 4.49988C18.6569 4.49988 20 5.84302 20 7.49988C20 8.06854 19.8418 8.60024 19.567 9.05338M17 19.4999C17 18.682 16.6072 17.9558 16 17.4997M19.567 9.05338C19.2105 9.64109 18.6579 10.0966 18 10.3292`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}]],tn=[[`path`,{d:`M13.9248 21H10.0752C5.44476 21 3.12955 21 2.27636 19.4939C1.42317 17.9879 2.60736 15.9914 4.97574 11.9985L6.90057 8.75333C9.17559 4.91778 10.3131 3 12 3C13.6869 3 14.8244 4.91777 17.0994 8.75332L19.0243 11.9985C21.3926 15.9914 22.5768 17.9879 21.7236 19.4939C20.8704 21 18.5552 21 13.9248 21Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M12 9V13`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M12.125 16.75H12M12.25 16.75C12.25 16.8881 12.1381 17 12 17C11.8619 17 11.75 16.8881 11.75 16.75C11.75 16.6119 11.8619 16.5 12 16.5C12.1381 16.5 12.25 16.6119 12.25 16.75Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}]],nn=[[`circle`,{cx:`12`,cy:`12`,r:`10`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M12 8V12`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M12.125 15.75H12M12.25 15.75C12.25 15.8881 12.1381 16 12 16C11.8619 16 11.75 15.8881 11.75 15.75C11.75 15.6119 11.8619 15.5 12 15.5C12.1381 15.5 12.25 15.6119 12.25 15.75Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}]],rn=[[`path`,{d:`M11 18H15M13.5 8H14.4429C15.7533 8 16.4086 8 16.9641 8.31452C17.5196 8.62904 17.89 9.20972 18.6308 10.3711C19.1502 11.1854 19.6955 11.7765 20.4622 12.3024C21.2341 12.8318 21.6012 13.0906 21.8049 13.506C22 13.9038 22 14.375 22 15.3173C22 16.5596 22 17.1808 21.651 17.5755C21.636 17.5925 21.6207 17.609 21.6049 17.625C21.2375 18 20.6594 18 19.503 18H19`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M5 18C3.58579 18 2.87868 18 2.43934 17.5607C2 17.1213 2 16.4142 2 15V8C2 6.58579 2 5.87868 2.43934 5.43934C2.87868 5 3.58579 5 5 5H10.5C11.9142 5 12.6213 5 13.0607 5.43934C13.5 5.87868 13.5 6.58579 13.5 8V18H9`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M22 15H21`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}],[`path`,{d:`M8 9V13M10 11L6 11`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`3`}],[`circle`,{cx:`17`,cy:`18`,r:`2`,stroke:`currentColor`,strokeWidth:`1.5`,key:`4`}],[`circle`,{cx:`7`,cy:`18`,r:`2`,stroke:`currentColor`,strokeWidth:`1.5`,key:`5`}]],an=[[`path`,{d:`M18 17L18 7L6 7L6 17L18 17Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M22 17.9296L22 6.07037C22 5.5464 22 5.28442 21.8817 5.06333C21.7633 4.84223 21.5454 4.69691 21.1094 4.40627L19.1934 3.12892C19.0673 3.04486 18.9191 3 18.7676 3C18.3437 3 18 3.34366 18 3.76759L18 20.2324C18 20.6563 18.3437 21 18.7676 21C18.9191 21 19.0673 20.9551 19.1934 20.8711L21.1094 19.5937C21.5454 19.3031 21.7633 19.1578 21.8817 18.9367C22 18.7156 22 18.4536 22 17.9296Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M2.8906 19.5937C2.45463 19.3031 2.23665 19.1578 2.11833 18.9367C2 18.7156 2 18.4536 2 17.9296L2 6.07037C2 5.5464 2 5.28442 2.11833 5.06333C2.23665 4.84223 2.45463 4.69691 2.8906 4.40627L4.80662 3.12892C4.93271 3.04486 5.08087 3 5.23241 3C5.65634 3 6 3.34366 6 3.76759L6 20.2324C6 20.6563 5.65634 21 5.23241 21C5.08087 21 4.93272 20.9551 4.80663 20.8711L2.8906 19.5937Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}],[`path`,{d:`M13.5001 10.0004L14.7267 11.0576C15.2423 11.502 15.5001 11.7242 15.5001 12.0004C15.5001 12.2765 15.2423 12.4987 14.7267 12.9432L13.5001 14.0004`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`3`}],[`path`,{d:`M10.5 10L9.27346 11.0572C8.75782 11.5016 8.5 11.7239 8.5 12C8.5 12.2761 8.75782 12.4984 9.27346 12.9428L10.5 14`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`4`}]],on=[[`path`,{d:`M11.9902 8.98595V3.31543`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M11.9902 20.6705V15`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M20.6702 12.0001L14.9999 11.9482`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}],[`path`,{d:`M9.00031 12.0001L3.33002 11.9482`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`3`}],[`path`,{d:`M14.9999 5.99998C14.9999 5.99998 12.7904 3.00001 11.9999 3C11.2093 2.99999 8.99995 6 8.99995 6`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`4`}],[`path`,{d:`M5.99993 15C5.99993 15 2.99996 12.7905 2.99995 12C2.99994 11.2094 5.99995 9 5.99995 9`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`5`}],[`path`,{d:`M17.9999 9C17.9999 9 20.9999 11.2095 20.9999 12C20.9999 12.7906 17.9999 15 17.9999 15`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`6`}],[`path`,{d:`M8.99995 18C8.99995 18 11.2094 21 11.9999 21C12.7905 21 14.9999 18 14.9999 18`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`7`}]],sn=[[`path`,{d:`M19 9H6.65856C5.65277 9 5.14987 9 5.02472 8.69134C4.89957 8.38268 5.25517 8.01942 5.96637 7.29289L8.21091 5`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M5 15H17.3414C18.3472 15 18.8501 15 18.9753 15.3087C19.1004 15.6173 18.7448 15.9806 18.0336 16.7071L15.7891 19`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}]],cn=[[`path`,{d:`M18 9.00005C18 9.00005 13.5811 15 12 15C10.4188 15 6 9 6 9`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}]],ln=[[`path`,{d:`M8.00001 3.09779C8.00001 3.09779 4.03375 2.74194 3.38784 3.38785C2.74192 4.03375 3.09784 8 3.09784 8`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M8.00001 20.9022C8.00001 20.9022 4.03375 21.2581 3.38784 20.6122C2.74192 19.9662 3.09784 16 3.09784 16`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M16 3.09779C16 3.09779 19.9663 2.74194 20.6122 3.38785C21.2581 4.03375 20.9022 8 20.9022 8`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}],[`path`,{d:`M16 20.9022C16 20.9022 19.9663 21.2581 20.6122 20.6122C21.2581 19.9662 20.9022 16 20.9022 16`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`3`}],[`path`,{d:`M14.0107 9.99847L20.0625 3.94678`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`4`}],[`path`,{d:`M9.99696 14.0024L3.63966 20.3807`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`5`}],[`path`,{d:`M9.99732 10.0024L3.84571 3.85889`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`6`}],[`path`,{d:`M13.9795 14.0024L20.5279 20.4983`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`7`}]],un=[[`path`,{d:`M15 6C15 6 9.00001 10.4189 9 12C8.99999 13.5812 15 18 15 18`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}]],dn=[[`path`,{d:`M9.00005 6C9.00005 6 15 10.4189 15 12C15 13.5812 9 18 9 18`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}]],fn=[[`path`,{d:`M17.9998 15C17.9998 15 13.5809 9.00001 11.9998 9C10.4187 8.99999 5.99985 15 5.99985 15`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}]],pn=[[`path`,{d:`M12 5.5V19`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M18 11C18 11 13.5811 5.00001 12 5C10.4188 4.99999 6 11 6 11`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}]],mn=[[`path`,{d:`M16 5.5H8C5.17157 5.5 3.75736 5.5 2.87868 6.37868C2 7.25736 2 8.67157 2 11.5V15C2 17.8284 2 19.2426 2.87868 20.1213C3.75736 21 5.17157 21 8 21H16C18.8284 21 20.2426 21 21.1213 20.1213C22 19.2426 22 17.8284 22 15V11.5C22 8.67157 22 7.25736 21.1213 6.37868C20.2426 5.5 18.8284 5.5 16 5.5Z`,stroke:`currentColor`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M17 8.5V12.5M19 10.5H15`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M9 10.5H5`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}],[`path`,{d:`M9 5.5V4.75C9 4.04777 9 3.69665 8.83147 3.44443C8.75851 3.33524 8.66476 3.24149 8.55557 3.16853C8.30335 3 7.95223 3 7.25 3C6.54777 3 6.19665 3 5.94443 3.16853C5.83524 3.24149 5.74149 3.33524 5.66853 3.44443C5.5 3.69665 5.5 4.04777 5.5 4.75V5.5`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`3`}],[`path`,{d:`M18.5 5.5V4.75C18.5 4.04777 18.5 3.69665 18.3315 3.44443C18.2585 3.33524 18.1648 3.24149 18.0556 3.16853C17.8033 3 17.4522 3 16.75 3C16.0478 3 15.6967 3 15.4444 3.16853C15.3352 3.24149 15.2415 3.33524 15.1685 3.44443C15 3.69665 15 4.04777 15 4.75V5.5`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`4`}]],hn=[[`path`,{d:`M16 5.5H8C5.17157 5.5 3.75736 5.5 2.87868 6.37868C2 7.25736 2 8.67157 2 11.5V15C2 17.8284 2 19.2426 2.87868 20.1213C3.75736 21 5.17157 21 8 21H16C18.8284 21 20.2426 21 21.1213 20.1213C22 19.2426 22 17.8284 22 15V11.5C22 8.67157 22 7.25736 21.1213 6.37868C20.2426 5.5 18.8284 5.5 16 5.5Z`,stroke:`currentColor`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M12.5 9L10 13H14L11.5 17`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M9 5.5V4.75C9 4.04777 9 3.69665 8.83147 3.44443C8.75851 3.33524 8.66476 3.24149 8.55557 3.16853C8.30335 3 7.95223 3 7.25 3C6.54777 3 6.19665 3 5.94443 3.16853C5.83524 3.24149 5.74149 3.33524 5.66853 3.44443C5.5 3.69665 5.5 4.04777 5.5 4.75V5.5`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}],[`path`,{d:`M18.5 5.5V4.75C18.5 4.04777 18.5 3.69665 18.3315 3.44443C18.2585 3.33524 18.1648 3.24149 18.0556 3.16853C17.8033 3 17.4522 3 16.75 3C16.0478 3 15.6967 3 15.4444 3.16853C15.3352 3.24149 15.2415 3.33524 15.1685 3.44443C15 3.69665 15 4.04777 15 4.75V5.5`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`3`}]],gn=[[`path`,{d:`M4.06492 12.6258C4.31931 13.8374 5.67295 14.7077 8.38024 16.4481C11.3247 18.3411 12.797 19.2876 13.9895 18.9229C14.3934 18.7994 14.7654 18.5823 15.0777 18.2876C16 17.4178 16 15.6118 16 12C16 8.38816 16 6.58224 15.0777 5.71235C14.7654 5.41773 14.3934 5.20057 13.9895 5.07707C12.797 4.71243 11.3247 5.6589 8.38024 7.55186C5.67295 9.29233 4.31931 10.1626 4.06492 11.3742C3.97836 11.7865 3.97836 12.2135 4.06492 12.6258Z`,stroke:`currentColor`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M20 5V19`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.5`,key:`1`}]],_n=[[`path`,{d:`M2.16293 12.9178C2.4453 13.6884 3.29859 14.3047 5.00518 15.5372C7.33231 17.218 8.49587 18.0583 9.4688 17.9969C10.2118 17.9499 10.9024 17.6007 11.3777 17.0315C12 16.2863 12 14.8575 12 12C12 9.14246 12 7.71369 11.3777 6.96846C10.9024 6.39933 10.2118 6.0501 9.4688 6.00315C8.49587 5.94167 7.33231 6.78203 5.00518 8.46275C3.29859 9.6953 2.4453 10.3116 2.16293 11.0822C1.94569 11.675 1.94569 12.325 2.16293 12.9178Z`,stroke:`currentColor`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M12.1629 12.9178C12.4453 13.6884 13.2986 14.3047 15.0052 15.5372C17.3323 17.218 18.4959 18.0583 19.4688 17.9969C20.2118 17.9499 20.9024 17.6007 21.3777 17.0315C22 16.2863 22 14.8575 22 12C22 9.14246 22 7.71369 21.3777 6.96846C20.9024 6.39933 20.2118 6.0501 19.4688 6.00315C18.4959 5.94167 17.3323 6.78203 15.0052 8.46275C13.2986 9.6953 12.4453 10.3116 12.1629 11.0822C11.9457 11.675 11.9457 12.325 12.1629 12.9178Z`,stroke:`currentColor`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}]],vn=[[`path`,{d:`M12 21C16.9706 21 21 16.9706 21 12C21 7.02944 16.9706 3 12 3C7.02944 3 3 7.02944 3 12C3 16.9706 7.02944 21 12 21Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M6 6L18 18`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}]],yn=[[`path`,{d:`M19.4 11H4.6C4.50715 11 4.46072 11 4.4215 11.0021C3.65482 11.0422 3.04224 11.6548 3.00206 12.4215C3 12.4607 3 12.5071 3 12.6C3 12.9714 3 13.1571 3.00822 13.314C3.16894 16.3807 5.61928 18.8311 8.68598 18.9918C8.84288 19 9.02859 19 9.4 19H14.6C14.9714 19 15.1571 19 15.314 18.9918C18.3807 18.8311 20.8311 16.3807 20.9918 13.314C21 13.1571 21 12.9714 21 12.6C21 12.5071 21 12.4607 20.9979 12.4215C20.9578 11.6548 20.3452 11.0422 19.5785 11.0021C19.5393 11 19.4929 11 19.4 11Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M5 11V5.12132C5 5.00867 5 4.95235 5.00227 4.90475C5.05136 3.87506 5.87506 3.05136 6.90475 3.00227C6.95235 3 7.00867 3 7.12132 3C7.1707 3 7.1954 3 7.21921 3.00057C7.71656 3.01242 8.19164 3.2092 8.5517 3.5525C8.56894 3.56894 8.5864 3.5864 8.62132 3.62132L10 5`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M9 6L11 4`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}],[`path`,{d:`M7 19L6 21M17 19L18 21`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`3`}]],bn=[[`path`,{d:`M6 20L5 21M18 20L19 21`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M3 12V13C3 16.2998 3 17.9497 4.02513 18.9749C5.05025 20 6.70017 20 10 20H14C17.2998 20 18.9497 20 19.9749 18.9749C21 17.9497 21 16.2998 21 13V12`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M2 12H22`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.5`,key:`2`}],[`path`,{d:`M4 12V5.5234C4 4.12977 5.12977 3 6.5234 3C7.64166 3 8.62654 3.73598 8.94339 4.80841L9 5`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.5`,key:`3`}],[`path`,{d:`M8 6L10.5 4`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.5`,key:`4`}]],xn=[[`path`,{d:`M22 12H15C14.3509 12 13.7193 11.7895 13.2 11.4L10.8 9.6C10.2807 9.21053 9.64911 9 9 9H2`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M3 9V11C3 14.7712 3 16.6569 4.17157 17.8284C5.34315 19 7.22876 19 11 19H14C16.8089 19 18.2134 19 19.2223 18.3259C19.659 18.034 20.034 17.659 20.3259 17.2223C21 16.2134 21 14.8089 21 12`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M18 19V21M6 19V21`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}],[`path`,{d:`M5 9V4.5C5 3.67157 5.67157 3 6.5 3C7.32843 3 8 3.67157 8 4.5V5`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`3`}]],Sn=[[`path`,{d:`M21 21C18.8012 19.7735 15.5841 19 12 19C8.41592 19 5.19883 19.7735 3 21`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M9.5 6.45068C7.83333 6.11465 5 6.45068 3.5 9.48348M9.5 6.45068C10.5 6.95471 11.5 8.47764 11.5 12M9.5 6.45068C12 5.94657 15 7.47125 15 11.4968M9.5 6.45068C8.5 4.43502 6.5 2.94235 3 4.95391`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M9.5 6.5C8.5 8.33333 6.5 13.5 6.5 19.5`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}],[`circle`,{cx:`19`,cy:`5`,r:`2`,stroke:`currentColor`,strokeWidth:`1.5`,key:`3`}]],Cn=[[`path`,{d:`M22 17.5H2`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M22 21V16C22 14.1144 22 13.1716 21.4142 12.5858C20.8284 12 19.8856 12 18 12H6C4.11438 12 3.17157 12 2.58579 12.5858C2 13.1716 2 14.1144 2 16V21`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M11 12V10.2134C11 9.83272 10.9428 9.70541 10.6497 9.55538C10.0395 9.24292 9.29865 9 8.5 9C7.70135 9 6.96055 9.24292 6.35025 9.55538C6.05721 9.70541 6 9.83272 6 10.2134L6 12`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.5`,key:`2`}],[`path`,{d:`M18 12V10.2134C18 9.83272 17.9428 9.70541 17.6497 9.55538C17.0395 9.24292 16.2987 9 15.5 9C14.7013 9 13.9605 9.24292 13.3503 9.55538C13.0572 9.70541 13 9.83272 13 10.2134L13 12`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.5`,key:`3`}],[`path`,{d:`M21 12V7.36057C21 6.66893 21 6.32311 20.8079 5.99653C20.6157 5.66995 20.342 5.50091 19.7944 5.16283C17.5869 3.79978 14.8993 3 12 3C9.10067 3 6.41314 3.79978 4.20558 5.16283C3.65804 5.50091 3.38427 5.66995 3.19213 5.99653C3 6.32311 3 6.66893 3 7.36057V12`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.5`,key:`4`}]],wn=[[`path`,{d:`M22 17.5H2`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M22 21V16C22 14.1144 22 13.1716 21.4142 12.5858C20.8284 12 19.8856 12 18 12H6C4.11438 12 3.17157 12 2.58579 12.5858C2 13.1716 2 14.1144 2 16V21`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M16 12V10.6178C16 10.1103 15.9085 9.94054 15.4396 9.7405C14.4631 9.32389 13.2778 9 12 9C10.7222 9 9.53688 9.32389 8.5604 9.7405C8.09154 9.94054 8 10.1103 8 10.6178L8 12`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.5`,key:`2`}],[`path`,{d:`M20 12V7.36057C20 6.66893 20 6.32311 19.8292 5.99653C19.6584 5.66995 19.4151 5.50091 18.9284 5.16283C16.9661 3.79978 14.5772 3 12 3C9.42282 3 7.03391 3.79978 5.07163 5.16283C4.58492 5.50091 4.34157 5.66995 4.17079 5.99653C4 6.32311 4 6.66893 4 7.36057V12`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.5`,key:`3`}]],Tn=[[`path`,{d:`M2 3.5V20.5`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M22 8.5L22 20.5`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M2 8.5L6 10.5H22`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}],[`path`,{d:`M2 15.5H6M22 15.5H19`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`3`}],[`path`,{d:`M6 10.5V16.5C6 18.1547 6.34533 18.5 8 18.5H17C18.6547 18.5 19 18.1547 19 16.5V10.5`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`4`}],[`path`,{d:`M6.81362 10.5C6.89385 10.076 7.0202 9.63248 6.99567 9.19713C6.95941 8.5536 6.63697 7.96625 6.1264 7.61368C5.92478 7.47446 5.48 7.33239 5.01268 7.21093C4.3308 7.0337 3.98986 6.94508 3.59142 7.03644C3.30841 7.10133 3.06258 7.25187 2.71115 7.52079C2.67243 7.55042 2.65307 7.56523 2.62289 7.59026C2.3843 7.78812 2.17276 8.07424 2.05352 8.36034C2.03844 8.39653 2.02562 8.43102 2 8.5`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`5`}]],En=[[`path`,{d:`M16 18C16 20.2091 14.2091 22 12 22C9.79086 22 8 20.2091 8 18`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M8 3.12589C8.88491 2.48978 9.95074 2.08864 11.1071 2.01285C11.3031 2 11.5353 2 11.9995 2C12.4638 2 12.696 2 12.892 2.01285C15.8965 2.20977 18.2898 4.60304 18.4867 7.60758C18.4995 7.80358 18.4995 8.03572 18.4995 8.5V9.8056C18.4995 10.5353 18.4995 10.9002 18.5356 11.254C18.6477 12.354 19.0187 13.4119 19.6184 14.3409C19.8113 14.6397 20.0392 14.9246 20.4951 15.4944L20.6648 15.7066C20.7508 15.814 20.8286 15.9113 20.8986 16`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M18 18H4.43654C3.70878 18 3.3449 18 3.13431 17.8951C2.72509 17.6913 2.50621 17.2359 2.60268 16.789C2.65233 16.559 2.87964 16.2749 3.33427 15.7066L3.50401 15.4944C3.95985 14.9246 4.18779 14.6397 4.38067 14.3409C4.98035 13.4119 5.35143 12.354 5.46349 11.254C5.49954 10.9002 5.49954 10.5353 5.49954 9.8056V8.5C5.49954 8.03572 5.49954 7.80358 5.51239 7.60758C5.54913 7.04701 5.66232 6.50772 5.84168 6`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.5`,key:`2`}],[`path`,{d:`M2 2L22 22`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`3`}]],Dn=[[`path`,{d:`M22 8C22 5.7 21.2 3.7 20 2`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M4 2C2.8 3.7 2 5.7 2 8`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M16 18C16 20.2091 14.2091 22 12 22C9.79086 22 8 20.2091 8 18`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}],[`path`,{d:`M4.43654 18H19.5625C20.2903 18 20.6542 18 20.8648 17.8951C21.274 17.6913 21.4929 17.2359 21.3964 16.789C21.3468 16.559 21.1194 16.2749 20.6648 15.7066L20.4951 15.4944C20.0392 14.9246 19.8113 14.6397 19.6184 14.3409C19.0187 13.4119 18.6477 12.354 18.5356 11.254C18.4995 10.9002 18.4995 10.5353 18.4995 9.8056V8.5C18.4995 8.03572 18.4995 7.80358 18.4867 7.60758C18.2898 4.60304 15.8965 2.20977 12.892 2.01285C12.696 2 12.4638 2 11.9995 2C11.5353 2 11.3031 2 11.1071 2.01285C8.10258 2.20977 5.70931 4.60304 5.51239 7.60758C5.49954 7.80358 5.49954 8.03572 5.49954 8.5V9.8056C5.49954 10.5353 5.49954 10.9002 5.46349 11.254C5.35143 12.354 4.98035 13.4119 4.38067 14.3409C4.18779 14.6397 3.95985 14.9246 3.50401 15.4944L3.33427 15.7066C2.87964 16.2749 2.65233 16.559 2.60268 16.789C2.50621 17.2359 2.72509 17.6913 3.13431 17.8951C3.3449 18 3.70878 18 4.43654 18Z`,stroke:`currentColor`,strokeWidth:`1.5`,key:`3`}]],On=[[`path`,{d:`M5.5 20.5C7.433 20.5 9 18.933 9 17C9 15.067 7.433 13.5 5.5 13.5C3.567 13.5 2 15.067 2 17C2 18.933 3.567 20.5 5.5 20.5Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M18.5 20.5C20.433 20.5 22 18.933 22 17C22 15.067 20.433 13.5 18.5 13.5C16.567 13.5 15 15.067 15 17C15 18.933 16.567 20.5 18.5 20.5Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M15 4V4.5M16 4.5C16 5.05228 15.5523 5.5 15 5.5C14.4477 5.5 14 5.05228 14 4.5C14 3.94772 14.4477 3.5 15 3.5C15.5523 3.5 16 3.94772 16 4.5Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}],[`path`,{d:`M12 18.4998V16.1567C12 15.3392 12 14.9305 11.8478 14.5629C11.6955 14.1954 11.4065 13.9063 10.8284 13.3283L9.91421 12.4141C9.24755 11.7474 8.91422 11.4141 8.91422 10.9998C8.91422 10.5856 9.24755 10.2523 9.91422 9.58564L11.0858 8.41406C11.7525 7.7474 12.0858 7.41406 12.5 7.41406C12.9142 7.41406 13.2475 7.7474 13.9142 8.41406L14.8284 9.32828C15.4065 9.90634 15.6955 10.1954 16.0631 10.3476C16.4306 10.4998 16.8394 10.4998 17.6569 10.4998H19M13.5 8.49985L10 11.9998M12.5 8.49985L10 10.9998`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`3`}]],kn=[[`circle`,{cx:`17`,cy:`17`,r:`5`,stroke:`currentColor`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M7.5 13H6.4C4.32582 13 3.28873 13 2.64437 12.3556C2 11.7113 2 10.6742 2 8.6V6.4C2 4.32582 2 3.28873 2.64437 2.64437C3.28873 2 4.32582 2 6.4 2H8.6C10.6742 2 11.7113 2 12.3556 2.64437C13 3.28873 13 4.32582 13 6.4V7.5`,stroke:`currentColor`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M12.0348 19C9.17734 18.5206 7 16.0355 7 13.0418C7 9.70499 9.70499 7 13.0418 7C16.0355 7 18.5206 9.17734 19 12.0348`,stroke:`currentColor`,strokeWidth:`1.5`,key:`2`}]],An=[[`path`,{d:`M8.06505 11.0322L2.8836 12.8234C0.435955 13.7381 3.73502 17.9574 4.82985 19.0466C5.92467 20.1359 10.3317 23.5832 11.2511 21.1481L12.9942 15.9361M3.23407 16.49L5.93576 15.1122M7.63912 20.4976L8.89322 18.0545`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M12.6264 8.24924L13.6286 7.25217C14.0229 6.85992 14.7109 6.93348 15.1052 7.32572L16.6694 8.8819C17.0636 9.27415 17.0636 9.9101 16.6694 10.3023L15.6671 11.2994C15.3716 11.5934 15.1751 11.9714 15.1046 12.3812L14.6101 15.2579C14.472 16.0612 13.4804 16.3751 12.9011 15.7988L8.36308 11.0114C7.78382 10.4351 7.88891 9.51181 8.69639 9.37441L11.5878 8.88241C11.9998 8.81232 12.3309 8.54324 12.6264 8.24924Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M16.9446 9.00217L21.5271 4.26023C22.8841 2.91024 21.0186 1.16009 19.7192 2.45293L14.9254 6.99335`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}]],jn=[[`path`,{d:`M2.01792 20.3051C3.14656 21.9196 8.05942 23.1871 10.3797 20.1645C12.8894 21.3649 17.0289 20.9928 20.3991 19.1134C20.8678 18.8521 21.3112 18.5222 21.5827 18.0593C22.1957 17.0143 22.2102 15.5644 21.0919 13.4251C19.2274 8.77072 15.874 4.68513 14.5201 3.04212C14.2421 2.78865 12.4687 2.42868 11.3872 2.08279C10.9095 1.93477 10.02 1.83664 8.95612 3.23862C8.45176 3.90329 6.16059 5.5357 9.06767 6.63346C9.51805 6.74806 9.84912 6.95939 11.9038 6.58404C12.1714 6.53761 12.8395 6.58404 13.3103 7.41041L14.2936 8.81662C14.3851 8.94752 14.4445 9.09813 14.4627 9.25682C14.635 10.7557 14.6294 12.6323 15.4651 13.5826C14.1743 12.6492 10.8011 11.5406 8.2595 14.6951M2.00189 12.94C3.21009 11.791 6.71197 9.97592 10.4179 12.5216`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}]],Mn=[[`path`,{d:`M20 22H6C4.89543 22 4 21.1046 4 20M4 20C4 18.8954 4.89543 18 6 18H18C19.1046 18 20 17.1046 20 16V2C20 3.10457 19.1046 4 18 4L10 4C7.17157 4 5.75736 4 4.87868 4.87868C4 5.75736 4 7.17157 4 10V20Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M18.5 18C18.5 18 17.5 18.7628 17.5 20C17.5 21.2372 18.5 22 18.5 22`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M9 4V8`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}]],Nn=[[`path`,{d:`M21 13.6376V10.3624C21 8.71559 21 7.89217 20.6166 7.20744C20.2332 6.52271 19.5317 6.09334 18.1287 5.2346L15.1287 3.39836C13.6056 2.46612 12.8441 2 12 2C11.1559 2 10.3944 2.46612 8.8713 3.39836L5.8713 5.2346C4.46832 6.09334 3.76683 6.52271 3.38341 7.20744C3 7.89217 3 8.71559 3 10.3624V13.6376C3 15.2844 3 16.1078 3.38341 16.7926C3.76683 17.4773 4.46832 17.9067 5.8713 18.7654L8.8713 20.6016C10.3944 21.5339 11.1559 22 12 22C12.8441 22 13.6056 21.5339 15.1287 20.6016L18.1287 18.7654C19.5317 17.9067 20.2332 17.4773 20.6166 16.7926C21 16.1078 21 15.2844 21 13.6376Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M3.5 7L12 12L20.5 7`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M12 12V22`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}]],Pn=[[`path`,{d:`M10.5 21.5981C9.80385 22 8.86923 22 7 22C5.13077 22 4.19615 22 3.5 21.5981C3.04394 21.3348 2.66523 20.9561 2.40192 20.5C2 19.8038 2 18.8692 2 17C2 15.1308 2 14.1962 2.40192 13.5C2.66523 13.0439 3.04394 12.6652 3.5 12.4019C4.19615 12 5.13077 12 7 12C8.86923 12 9.80385 12 10.5 12.4019C10.9561 12.6652 11.3348 13.0439 11.5981 13.5C12 14.1962 12 15.1308 12 17C12 18.8692 12 19.8038 11.5981 20.5C11.3348 20.9561 10.9561 21.3348 10.5 21.5981Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M20.5 21.5981C19.8038 22 18.8692 22 17 22C15.1308 22 14.1962 22 13.5 21.5981C13.0439 21.3348 12.6652 20.9561 12.4019 20.5C12 19.8038 12 18.8692 12 17C12 15.1308 12 14.1962 12.4019 13.5C12.6652 13.0439 13.0439 12.6652 13.5 12.4019C14.1962 12 15.1308 12 17 12C18.8692 12 19.8038 12 20.5 12.4019C20.9561 12.6652 21.3348 13.0439 21.5981 13.5C22 14.1962 22 15.1308 22 17C22 18.8692 22 19.8038 21.5981 20.5C21.3348 20.9561 20.9561 21.3348 20.5 21.5981Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M15.5 11.5981C14.8038 12 13.8692 12 12 12C10.1308 12 9.19615 12 8.5 11.5981C8.04394 11.3348 7.66523 10.9561 7.40192 10.5C7 9.80385 7 8.86923 7 7C7 5.13077 7 4.19615 7.40192 3.5C7.66523 3.04394 8.04394 2.66523 8.5 2.40192C9.19615 2 10.1308 2 12 2C13.8692 2 14.8038 2 15.5 2.40192C15.9561 2.66523 16.3348 3.04394 16.5981 3.5C17 4.19615 17 5.13077 17 7C17 8.86923 17 9.80385 16.5981 10.5C16.3348 10.9561 15.9561 11.3348 15.5 11.5981Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}],[`path`,{d:`M12 2V5`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`3`}],[`path`,{d:`M7 12V15`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`4`}],[`path`,{d:`M17 12V15`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`5`}]],Fn=[[`circle`,{cx:`19`,cy:`13`,r:`2`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`circle`,{cx:`13`,cy:`19`,r:`3`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`circle`,{cx:`8.5`,cy:`7.5`,r:`5.5`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}],[`path`,{d:`M6 7.5C6 6.11929 7.11929 5 8.5 5`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`3`}]],In=[[`path`,{d:`M5.14286 14C4.41735 12.8082 4 11.4118 4 9.91886C4 5.54539 7.58172 2 12 2C16.4183 2 20 5.54539 20 9.91886C20 11.4118 19.5827 12.8082 18.8571 14`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M14 10C13.3875 10.6432 12.7111 11 12 11C11.2889 11 10.6125 10.6432 10 10`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M7.38287 17.0982C7.291 16.8216 7.24507 16.6833 7.25042 16.5713C7.26174 16.3343 7.41114 16.1262 7.63157 16.0405C7.73579 16 7.88105 16 8.17157 16H15.8284C16.119 16 16.2642 16 16.3684 16.0405C16.5889 16.1262 16.7383 16.3343 16.7496 16.5713C16.7549 16.6833 16.709 16.8216 16.6171 17.0982C16.4473 17.6094 16.3624 17.8651 16.2315 18.072C15.9572 18.5056 15.5272 18.8167 15.0306 18.9408C14.7935 19 14.525 19 13.9881 19H10.0119C9.47495 19 9.2065 19 8.96944 18.9408C8.47283 18.8167 8.04281 18.5056 7.7685 18.072C7.63755 17.8651 7.55266 17.6094 7.38287 17.0982Z`,stroke:`currentColor`,strokeWidth:`1.5`,key:`2`}],[`path`,{d:`M15 19L14.8707 19.6466C14.7293 20.3537 14.6586 20.7072 14.5001 20.9866C14.2552 21.4185 13.8582 21.7439 13.3866 21.8994C13.0816 22 12.7211 22 12 22C11.2789 22 10.9184 22 10.6134 21.8994C10.1418 21.7439 9.74484 21.4185 9.49987 20.9866C9.34144 20.7072 9.27073 20.3537 9.12932 19.6466L9 19`,stroke:`currentColor`,strokeWidth:`1.5`,key:`3`}],[`path`,{d:`M12 15.5V11`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`4`}]],Ln=[[`path`,{d:`M21.5 12.95V11.05C21.5 7.01949 21.5 5.00424 20.1088 3.75212C18.7175 2.5 16.4783 2.5 12 2.5C7.52166 2.5 5.28249 2.5 3.89124 3.75212C2.5 5.00424 2.5 7.01949 2.5 11.05V12.95C2.5 16.9805 2.5 18.9958 3.89124 20.2479C5.28249 21.5 7.52166 21.5 12 21.5C16.4783 21.5 18.7175 21.5 20.1088 20.2479C21.5 18.9958 21.5 16.9805 21.5 12.95Z`,stroke:`currentColor`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M18 8H14M16 6L16 10`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M18 17.5H14`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}],[`path`,{d:`M18 14.5H14`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`3`}],[`path`,{d:`M10 17.5L8.25 15.75M8.25 15.75L6.5 14M8.25 15.75L10 14M8.25 15.75L6.5 17.5`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`4`}],[`path`,{d:`M10 8H6`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`5`}]],Rn=[[`path`,{d:`M16 2V6M8 2V6`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M13 4H11C7.22876 4 5.34315 4 4.17157 5.17157C3 6.34315 3 8.22876 3 12V14C3 17.7712 3 19.6569 4.17157 20.8284C5.34315 22 7.22876 22 11 22H13C16.7712 22 18.6569 22 19.8284 20.8284C21 19.6569 21 17.7712 21 14V12C21 8.22876 21 6.34315 19.8284 5.17157C18.6569 4 16.7712 4 13 4Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M3 10H21`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}],[`path`,{d:`M10 18.5002L9.99999 13.8474C9.99999 13.6557 9.86325 13.5002 9.69458 13.5002H9M14 18.4983L15.4855 13.8923C15.4951 13.8626 15.5 13.8315 15.5 13.8002C15.5 13.6346 15.3657 13.5002 15.2 13.5002L13 13.5`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`3`}]],zn=[[`path`,{d:`M16 2V6M8 2V6`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M13 4H11C7.22876 4 5.34315 4 4.17157 5.17157C3 6.34315 3 8.22876 3 12V14C3 17.7712 3 19.6569 4.17157 20.8284C5.34315 22 7.22876 22 11 22H13C16.7712 22 18.6569 22 19.8284 20.8284C21 19.6569 21 17.7712 21 14V12C21 8.22876 21 6.34315 19.8284 5.17157C18.6569 4 16.7712 4 13 4Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M3 10H21`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}],[`path`,{d:`M11 14H16M8 14H8.00898M13 18H8M16 18H15.991`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`3`}]],Bn=[[`path`,{d:`M16 2V6M8 2V6`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M13 4H11C7.22876 4 5.34315 4 4.17157 5.17157C3 6.34315 3 8.22876 3 12V14C3 17.7712 3 19.6569 4.17157 20.8284C5.34315 22 7.22876 22 11 22H13C16.7712 22 18.6569 22 19.8284 20.8284C21 19.6569 21 17.7712 21 14V12C21 8.22876 21 6.34315 19.8284 5.17157C18.6569 4 16.7712 4 13 4Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M3 10H21`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}],[`path`,{d:`M12.1258 14H12.0008M12.1258 18H12.0008M7.625 14H7.5M7.625 18H7.5M16.625 14H16.5M12.2508 14C12.2508 14.1381 12.1389 14.25 12.0008 14.25C11.8628 14.25 11.7508 14.1381 11.7508 14C11.7508 13.8619 11.8628 13.75 12.0008 13.75C12.1389 13.75 12.2508 13.8619 12.2508 14ZM12.2508 18C12.2508 18.1381 12.1389 18.25 12.0008 18.25C11.8628 18.25 11.7508 18.1381 11.7508 18C11.7508 17.8619 11.8628 17.75 12.0008 17.75C12.1389 17.75 12.2508 17.8619 12.2508 18ZM7.75 14C7.75 14.1381 7.63807 14.25 7.5 14.25C7.36193 14.25 7.25 14.1381 7.25 14C7.25 13.8619 7.36193 13.75 7.5 13.75C7.63807 13.75 7.75 13.8619 7.75 14ZM7.75 18C7.75 18.1381 7.63807 18.25 7.5 18.25C7.36193 18.25 7.25 18.1381 7.25 18C7.25 17.8619 7.36193 17.75 7.5 17.75C7.63807 17.75 7.75 17.8619 7.75 18ZM16.75 14C16.75 14.1381 16.6381 14.25 16.5 14.25C16.3619 14.25 16.25 14.1381 16.25 14C16.25 13.8619 16.3619 13.75 16.5 13.75C16.6381 13.75 16.75 13.8619 16.75 14Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`3`}]],Vn=[[`path`,{d:`M16 2V6M8 2V6`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M21 12C21 8.22876 21 6.34315 19.8284 5.17157C18.6569 4 16.7712 4 13 4H11C7.22876 4 5.34315 4 4.17157 5.17157C3 6.34315 3 8.22876 3 12V14C3 17.7712 3 19.6569 4.17157 20.8284C5.34315 22 7.22876 22 11 22H11.5`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M3 10H21`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}],[`path`,{d:`M15.7355 16.1747L15.7354 14.7843C15.7354 14.5789 15.744 14.371 15.8176 14.1792C16.0136 13.6688 16.5326 13 17.4776 13C18.4225 13 18.962 13.6688 19.1579 14.1792C19.2315 14.371 19.2401 14.5789 19.2401 14.7843L19.2401 16.1747M15.805 21.9976H19.191C20.1878 21.9976 20.9959 21.191 20.9959 20.196V18.1947C20.9959 17.1997 20.1878 16.3931 19.191 16.3931H15.805C14.8081 16.3931 14 17.1997 14 18.1947V20.196C14 21.191 14.8081 21.9976 15.805 21.9976Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`3`}]],Hn=[[`path`,{d:`M12.6974 3.5H11.303C10.5884 3.5 10.2311 3.5 9.91067 3.612C9.71499 3.68039 9.53113 3.77879 9.36568 3.90367C9.09474 4.10816 8.89655 4.40544 8.50018 5L8.50017 5.00001C8.29717 5.30453 7.99794 5.75337 7.87867 5.87871C7.58314 6.18927 7.19563 6.39666 6.77329 6.47029C6.60284 6.5 6.41985 6.5 6.05387 6.5C5.07379 6.5 4.58376 6.5 4.18307 6.61342C3.18074 6.89716 2.39734 7.68055 2.1136 8.68289C2.00018 9.08357 2.00018 9.57361 2.00018 10.5537V14.5C2.00018 17.3284 2.00018 18.7426 2.87886 19.6213C3.75754 20.5 5.17176 20.5 8.00018 20.5H16.0002C18.8286 20.5 20.2428 20.5 21.1215 19.6213C22.0002 18.7426 22.0002 17.3284 22.0002 14.5V10.5537C22.0002 9.57361 22.0002 9.08357 21.8868 8.68289C21.603 7.68055 20.8196 6.89716 19.8173 6.61342C19.4166 6.5 18.9266 6.5 17.9465 6.5C17.5805 6.5 17.3975 6.5 17.2271 6.47029C16.8047 6.39666 16.4172 6.18927 16.1217 5.87871C16.0024 5.75336 15.7032 5.30451 15.5002 5C15.1038 4.40544 14.9056 4.10816 14.6347 3.90367C14.4692 3.77879 14.2854 3.68039 14.0897 3.612C13.7693 3.5 13.412 3.5 12.6974 3.5Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M16.0002 13C16.0002 15.2091 14.2093 17 12.0002 17C9.79104 17 8.00018 15.2091 8.00018 13C8.00018 10.7909 9.79104 9 12.0002 9C14.2093 9 16.0002 10.7909 16.0002 13Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M19.1252 9.5H19.0002M19.2502 9.5C19.2502 9.63807 19.1383 9.75 19.0002 9.75C18.8621 9.75 18.7502 9.63807 18.7502 9.5C18.7502 9.36193 18.8621 9.25 19.0002 9.25C19.1383 9.25 19.2502 9.36193 19.2502 9.5Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.5`,key:`2`}]],Un=[[`path`,{d:`M12.6975 3.49998H11.303C10.5885 3.49998 10.2312 3.49998 9.91073 3.61198C9.71505 3.68038 9.53119 3.77877 9.36574 3.90365C9.0948 4.10815 8.89662 4.40543 8.50024 4.99998L8.50023 5C8.29723 5.30451 7.998 5.75335 7.87873 5.87869C7.5832 6.18926 7.19569 6.39665 6.77335 6.47027C6.6029 6.49998 6.41991 6.49998 6.05393 6.49998C5.07386 6.49998 4.58382 6.49998 4.18314 6.61341C3.1808 6.89714 2.3974 7.68054 2.11367 8.68288C2.00024 9.08356 2.00024 9.5736 2.00024 10.5537V14.5C2.00024 17.3284 2.00024 18.7426 2.87892 19.6213C3.7576 20.5 5.17182 20.5 8.00024 20.5H16.0002C18.8287 20.5 20.2429 20.5 21.1216 19.6213C22.0002 18.7426 22.0002 17.3284 22.0002 14.5V10.5537C22.0002 9.5736 22.0002 9.08356 21.8868 8.68288C21.6031 7.68054 20.8197 6.89714 19.8174 6.61341C19.4167 6.49998 18.9266 6.49998 17.9466 6.49998C17.5806 6.49998 17.3976 6.49998 17.2271 6.47027C16.8048 6.39665 16.4173 6.18926 16.1218 5.87869C16.0025 5.75335 15.7033 5.3045 15.5002 4.99998C15.1039 4.40543 14.9057 4.10815 14.6348 3.90365C14.4693 3.77877 14.2854 3.68038 14.0898 3.61198C13.7693 3.49998 13.412 3.49998 12.6975 3.49998Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M19.0002 9.49998V9.50998`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`2`,key:`1`}],[`path`,{d:`M15.0002 16.5L12.6684 9.97086C12.5676 9.68848 12.3001 9.49998 12.0002 9.49998C11.7004 9.49998 11.4329 9.68848 11.3321 9.97086L9.00024 16.5M10.5002 14H13.5002`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}]],Wn=[[`circle`,{cx:`17`,cy:`19`,r:`2`,stroke:`currentColor`,strokeWidth:`1.5`,key:`0`}],[`circle`,{cx:`7`,cy:`19`,r:`2`,stroke:`currentColor`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M16 7H20.9383C21.4324 7 21.6794 7 21.8203 6.88531C21.9062 6.81539 21.9664 6.71959 21.9915 6.61269C22.0327 6.43736 21.9222 6.21984 21.7013 5.78486C21.1469 4.6935 20.8697 4.14783 20.438 3.76671C20.1688 3.529 19.8587 3.34036 19.5223 3.20962C18.9829 3 18.3631 3 17.1235 3H8.09555C5.22208 3 3.78535 3 2.89267 3.87868C2 4.75736 2 6.17157 2 9V14`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}],[`path`,{d:`M9 19H15M19 19C20.6569 19 22 17.6569 22 16V13H4C3.05719 13 2.58579 13 2.29289 13.2929C2 13.5858 2 14.0572 2 15V16C2 17.4142 2 18.1213 2.43934 18.5607C2.87868 19 3.58579 19 5 19`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`3`}],[`path`,{d:`M6 7L8 7`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`4`}],[`path`,{d:`M14 13V8.9657C14 8.25047 14 7.89285 14.123 7.62348C14.2146 7.42269 14.3522 7.25756 14.5196 7.14756C14.744 7 15.0421 7 15.6381 7C16.5393 7 16.9899 7 17.4041 7.14611C17.7159 7.25609 18.0108 7.42615 18.2772 7.64963C18.631 7.94652 18.9125 8.36875 19.4755 9.21321L22 13`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`5`}]],Gn=[[`path`,{d:`M18 6L6.00081 17.9992M17.9992 18L6 6.00085`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}]],Kn=[[`path`,{d:`M4 8C4 5.17157 4 3.75736 5.00421 2.87868C6.00841 2 7.62465 2 10.8571 2H13.1429C16.3753 2 17.9916 2 18.9958 2.87868C20 3.75736 20 5.17157 20 8V17H4V8Z`,stroke:`currentColor`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M3 17H21`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M10.6987 5.56588C11.9289 5.38957 13.9674 5.4601 12.2803 7.15266C10.1715 9.26836 7.00837 14.0289 10.6987 12.4421C14.3891 10.8554 15.9709 11.9132 14.3893 13.5`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}],[`path`,{d:`M12 17V21`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.5`,key:`3`}],[`path`,{d:`M5 22L8 17`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.5`,key:`4`}],[`path`,{d:`M19 22L16 17`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.5`,key:`5`}]],qn=[[`path`,{d:`M2.5 12L4.5 13`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M21.5 12.5L19.5 13`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M8 17.5L8.24567 16.8858C8.61101 15.9725 8.79368 15.5158 9.17461 15.2579C9.55553 15 10.0474 15 11.0311 15H12.9689C13.9526 15 14.4445 15 14.8254 15.2579C15.2063 15.5158 15.389 15.9725 15.7543 16.8858L16 17.5`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}],[`path`,{d:`M2 17V19.882C2 20.2607 2.24075 20.607 2.62188 20.7764C2.86918 20.8863 3.10538 21 3.39058 21H5.10942C5.39462 21 5.63082 20.8863 5.87812 20.7764C6.25925 20.607 6.5 20.2607 6.5 19.882V18`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`3`}],[`path`,{d:`M17.5 18V19.882C17.5 20.2607 17.7408 20.607 18.1219 20.7764C18.3692 20.8863 18.6054 21 18.8906 21H20.6094C20.8946 21 21.1308 20.8863 21.3781 20.7764C21.7592 20.607 22 20.2607 22 19.882V17`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`4`}],[`path`,{d:`M20 8.5L21 8`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`5`}],[`path`,{d:`M4 8.5L3 8`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`6`}],[`path`,{d:`M4.5 9L5.5883 5.73509C6.02832 4.41505 6.24832 3.75503 6.7721 3.37752C7.29587 3 7.99159 3 9.38304 3H14.617C16.0084 3 16.7041 3 17.2279 3.37752C17.7517 3.75503 17.9717 4.41505 18.4117 5.73509L19.5 9`,stroke:`currentColor`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`7`}],[`path`,{d:`M4.5 9H19.5C20.4572 10.0135 22 11.4249 22 12.9996V16.4702C22 17.0407 21.6205 17.5208 21.1168 17.5875L18 18H6L2.88316 17.5875C2.37955 17.5208 2 17.0407 2 16.4702V12.9996C2 11.4249 3.54279 10.0135 4.5 9Z`,stroke:`currentColor`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`8`}]],Jn=[[`path`,{d:`M9.0072 17C9.0072 18.1046 8.11177 19 7.0072 19C5.90263 19 5.0072 18.1046 5.0072 17C5.0072 15.8954 5.90263 15 7.0072 15C8.11177 15 9.0072 15.8954 9.0072 17Z`,stroke:`currentColor`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M19.0072 17C19.0072 18.1046 18.1118 19 17.0072 19C15.9026 19 15.0072 18.1046 15.0072 17C15.0072 15.8954 15.9026 15 17.0072 15C18.1118 15 19.0072 15.8954 19.0072 17Z`,stroke:`currentColor`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M2.00722 10H18.0072M3.64197 5.42C3.16234 6.2 2.22306 8.26 2.00722 10C2.00722 10.78 1.98723 13.04 2.01122 15.26C2.04719 15.98 2.1671 16.58 5.00893 17M9.00722 10V5M14.9973 17H9.00189M2.02321 5H12.2394C12.2394 5 12.779 5 13.2586 5.048C14.158 5.132 14.9134 5.54 15.6688 6.56C16.4687 7.64 17.0837 9.008 17.8991 9.74C19.2541 10.9564 21.8321 10.58 21.976 13.16C22.012 14.48 22.012 15.92 21.952 16.16C21.8557 16.8667 21.3108 16.9821 20.633 17C20.0448 17.0156 19.3357 16.9721 18.9903 17`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.5`,key:`2`}]],Yn=[[`path`,{d:`M22 15.4222V18.5C22 18.9659 22 19.1989 21.9239 19.3827C21.8224 19.6277 21.6277 19.8224 21.3827 19.9239C21.1989 20 20.9659 20 20.5 20C20.0341 20 19.8011 20 19.6173 19.9239C19.3723 19.8224 19.1776 19.6277 19.0761 19.3827C19 19.1989 19 18.9659 19 18.5C19 18.0341 19 17.8011 18.9239 17.6173C18.8224 17.3723 18.6277 17.1776 18.3827 17.0761C18.1989 17 17.9659 17 17.5 17H6.5C6.03406 17 5.80109 17 5.61732 17.0761C5.37229 17.1776 5.17761 17.3723 5.07612 17.6173C5 17.8011 5 18.0341 5 18.5C5 18.9659 5 19.1989 4.92388 19.3827C4.82239 19.6277 4.62771 19.8224 4.38268 19.9239C4.19891 20 3.96594 20 3.5 20C3.03406 20 2.80109 20 2.61732 19.9239C2.37229 19.8224 2.17761 19.6277 2.07612 19.3827C2 19.1989 2 18.9659 2 18.5V15.4222C2 14.22 2 13.6188 2.17163 13.052C2.34326 12.4851 2.67671 11.9849 3.3436 10.9846L4 10L4.96154 7.69231C5.70726 5.90257 6.08013 5.0077 6.8359 4.50385C7.59167 4 8.56112 4 10.5 4H13.5C15.4389 4 16.4083 4 17.1641 4.50385C17.9199 5.0077 18.2927 5.90257 19.0385 7.69231L20 10L20.6564 10.9846C21.3233 11.9849 21.6567 12.4851 21.8284 13.052C22 13.6188 22 14.22 22 15.4222Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M6.125 14H6M6.25 14C6.25 14.1381 6.13807 14.25 6 14.25C5.86193 14.25 5.75 14.1381 5.75 14C5.75 13.8619 5.86193 13.75 6 13.75C6.13807 13.75 6.25 13.8619 6.25 14Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M18.125 14H18M18.25 14C18.25 14.1381 18.1381 14.25 18 14.25C17.8619 14.25 17.75 14.1381 17.75 14C17.75 13.8619 17.8619 13.75 18 13.75C18.1381 13.75 18.25 13.8619 18.25 14Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}],[`path`,{d:`M2 8.5L4 10L6 10.5H18L20 10L22 8.5`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`3`}]],Xn=[[`path`,{d:`M4 12L3.3436 12.9846C2.67671 13.9849 2.34326 14.4851 2.17163 15.052C2 15.6188 2 16.22 2 17.4222V20.5C2 20.9659 2 21.1989 2.07612 21.3827C2.17761 21.6277 2.37229 21.8224 2.61732 21.9239C2.80109 22 3.03406 22 3.5 22C3.96594 22 4.19891 22 4.38268 21.9239C4.62771 21.8224 4.82239 21.6277 4.92388 21.3827C5 21.1989 5 20.9659 5 20.5C5 20.0341 5 19.8011 5.07612 19.6173C5.17761 19.3723 5.37229 19.1776 5.61732 19.0761C5.80109 19 6.03406 19 6.5 19H17.5C17.9659 19 18.1989 19 18.3827 19.0761C18.6277 19.1776 18.8224 19.3723 18.9239 19.6173C19 19.8011 19 20.0341 19 20.5C19 20.9659 19 21.1989 19.0761 21.3827C19.1776 21.6277 19.3723 21.8224 19.6173 21.9239C19.8011 22 20.0341 22 20.5 22C20.9659 22 21.1989 22 21.3827 21.9239C21.6277 21.8224 21.8224 21.6277 21.9239 21.3827C22 21.1989 22 20.9659 22 20.5V17.4222C22 16.22 22 15.6188 21.8284 15.052C21.6567 14.4851 21.3233 13.9849 20.6564 12.9846L20 12L18.4777 12.3806C18.2392 12.4402 18.1199 12.47 17.9982 12.485C17.8764 12.5 17.7535 12.5 17.5076 12.5H6.49242C6.24652 12.5 6.12357 12.5 6.00184 12.485C5.88012 12.47 5.76084 12.4402 5.52228 12.3806L4 12ZM4 12L4.96154 9.69231C5.70726 7.90257 6.08013 7.0077 6.8359 6.50385C7.59167 6 8.56112 6 10.5 6M4 12L2 10.5`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`circle`,{cx:`17`,cy:`6`,r:`4`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M17 4V6`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}],[`path`,{d:`M6.125 16H6M6.25 16C6.25 16.1381 6.13807 16.25 6 16.25C5.86193 16.25 5.75 16.1381 5.75 16C5.75 15.8619 5.86193 15.75 6 15.75C6.13807 15.75 6.25 15.8619 6.25 16Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`3`}],[`path`,{d:`M18.125 16H18M18.25 16C18.25 16.1381 18.1381 16.25 18 16.25C17.8619 16.25 17.75 16.1381 17.75 16C17.75 15.8619 17.8619 15.75 18 15.75C18.1381 15.75 18.25 15.8619 18.25 16Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`4`}],[`path`,{d:`M17.0508 7.90249H17.0008M17.1008 7.90249C17.1008 7.95772 17.056 8.00249 17.0008 8.00249C16.9455 8.00249 16.9008 7.95772 16.9008 7.90249C16.9008 7.84726 16.9455 7.80249 17.0008 7.80249C17.056 7.80249 17.1008 7.84726 17.1008 7.90249Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`5`}]],Zn=[[`path`,{d:`M22 21V9.61065C22 8.28771 22 7.62624 21.6561 7.11395C21.3123 6.60167 20.7034 6.35601 19.4856 5.86468L13.4856 3.44396C12.752 3.14799 12.3852 3 12 3C11.6148 3 11.248 3.14799 10.5144 3.44396L4.51444 5.86468C3.29663 6.35601 2.68773 6.60167 2.34387 7.11395C2 7.62624 2 8.28771 2 9.61065V21`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M16 19V21M8 19V21`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M7.5 14L7.74254 13.0299C8.10632 11.5747 8.28821 10.8472 8.83073 10.4236C9.37325 10 10.1232 10 11.6231 10H12.3769C13.8768 10 14.6267 10 15.1693 10.4236C15.7118 10.8472 15.8937 11.5747 16.2575 13.0299L16.5 14`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}],[`path`,{d:`M17 14H7C6.44772 14 6 14.4477 6 15V18C6 18.5523 6.44772 19 7 19H17C17.5523 19 18 18.5523 18 18V15C18 14.4477 17.5523 14 17 14Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`3`}],[`path`,{d:`M8.5 16.49V16.5`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`4`}],[`path`,{d:`M15.5 16.49V16.5`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`5`}]],Qn=[[`path`,{d:`M3 11C3 8.17157 3 6.75736 3.87868 5.87868C4.75736 5 6.17157 5 9 5H11C13.8284 5 15.2426 5 16.1213 5.87868C17 6.75736 17 8.17157 17 11V16C17 18.8284 17 20.2426 16.1213 21.1213C15.2426 22 13.8284 22 11 22H9C6.17157 22 4.75736 22 3.87868 21.1213C3 20.2426 3 18.8284 3 16V11Z`,stroke:`currentColor`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M8.04435 11.762L8.42742 11.3048C9.15621 10.4349 9.52061 10 10 10C10.4794 10 10.8438 10.4349 11.5726 11.3048L11.9556 11.762C12.6519 12.593 13 13.0086 13 13.5C13 13.9914 12.6519 14.407 11.9556 15.238L11.5726 15.6952C10.8438 16.5651 10.4794 17 10 17C9.52061 17 9.15621 16.5651 8.42742 15.6952L8.04435 15.238C7.34812 14.407 7 13.9914 7 13.5C7 13.0086 7.34812 12.593 8.04435 11.762Z`,stroke:`currentColor`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M16.9244 19C18.0202 18.3874 18.3929 17.0406 19.1383 14.3469L20.1925 10.5375C20.938 7.84378 21.3107 6.49694 20.678 5.4359C20.0453 4.37485 18.6543 4.01397 15.8724 3.2922L13.9052 2.78183C11.1232 2.06006 9.73225 1.69918 8.63642 2.31177C7.85623 2.74792 7.44258 3.55626 7 4.95786`,stroke:`currentColor`,strokeWidth:`1.5`,key:`2`}]],$n=[[`path`,{d:`M14.5 17.5V7.5H7.5001C5.1431 7.5 3.9646 7.5 3.23237 8.23222C2.50013 8.96445 2.50012 10.1429 2.5001 12.5L2.50006 16.5C2.50004 18.857 2.50003 20.0355 3.23226 20.7678C3.9645 21.5 5.14302 21.5 7.50006 21.5H10.5C12.3856 21.5 13.3284 21.5 13.9142 20.9142C14.5 20.3284 14.5 19.3856 14.5 17.5Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M14.4999 16.5H16.4999C18.8569 16.5 20.0355 16.5 20.7677 15.7678C21.4999 15.0355 21.4999 13.857 21.4999 11.5V7.5C21.4999 5.14298 21.4999 3.96447 20.7677 3.23223C20.0355 2.5 18.8569 2.5 16.4999 2.5H9.50006L9.5002 7.5`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M5.50006 12.5H9.00006M5.50006 16.5H11.5001`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}],[`path`,{d:`M9.50006 2.5L14.5001 7.5`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`3`}]],er=[[`path`,{d:`M8 14L7.64311 15.7845C7.33525 17.3237 7.18133 18.0934 6.62837 18.5467C6.07541 19 5.29054 19 3.72078 19H2`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M2 17V21`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M16.951 11.5083L21.2025 11.5411C21.3272 11.542 21.45 11.5724 21.5611 11.6298C21.9565 11.8341 22.1137 12.3247 21.9123 12.7257L19.4857 17.555C19.2843 17.9559 18.8005 18.1153 18.4051 17.911C18.294 17.8536 18.1975 17.7707 18.1235 17.669L15.5984 14.2003M13.017 10.4647L12.9606 10.5768M15.1475 15.0976L17.4018 10.611C17.8998 9.61987 17.5112 8.40699 16.5338 7.90198L7.68514 3.32994C6.21904 2.57242 4.42496 3.16355 3.67795 4.65027L2.32536 7.34221C1.57835 8.82892 2.16128 10.6482 3.62738 11.4058L12.476 15.9778C13.4534 16.4828 14.6495 16.0887 15.1475 15.0976ZM13.0733 10.3525C13.1955 10.4156 13.2441 10.5672 13.1818 10.6911C13.1196 10.815 12.9701 10.8643 12.8479 10.8012C12.7257 10.738 12.6772 10.5864 12.7394 10.4625C12.8017 10.3386 12.9512 10.2894 13.0733 10.3525Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}]],tr=[[`path`,{d:`M8.08665 13.5V15C8.08665 16.8856 8.08665 17.8284 7.49072 18.4142C6.89478 19 5.93563 19 4.01733 19H3`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M3 17V21`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M8 3C8.27336 3.09886 8.57042 3.21 8.89516 3.33149L17.6375 6.60223C19.1243 7.15852 19.8678 7.43666 19.9852 8.04464C20.1026 8.65262 19.5187 9.20029 18.3507 10.2956L16.5335 12`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}],[`path`,{d:`M4.61554 5C4.48179 5.35097 4.33952 5.75274 4.17734 6.21075L3.77687 7.34171C3.1182 9.20182 2.78887 10.1319 3.14701 10.9202C3.50515 11.7085 4.41112 12.0476 6.22308 12.726L10.8152 14.4451C11.9522 14.8708 12.5208 15.0836 13.0826 14.9695C13.3921 14.9066 13.6666 14.7512 14 14.4842`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`3`}],[`path`,{d:`M20.5859 12.25C20.972 12.7236 21.1138 13.4084 20.9016 14.0466L20.6321 14.8572C20.5817 15.0085 20.5387 15.1378 20.5002 15.25`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`4`}],[`path`,{d:`M3 3L21 21`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`5`}]],nr=[[`path`,{d:`M12 12L12 20`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M11.5 7.06301C11.6598 7.02188 11.8274 7 12 7C13.1046 7 14 7.89543 14 9C14 9.17265 13.9781 9.34019 13.937 9.5`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M2 2L22 22`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.5`,key:`2`}],[`path`,{d:`M16.9588 6C17.6186 6.86961 18 7.89801 18 9C18 10.102 17.6186 11.1304 16.9588 12M7.04117 12C6.38143 11.1304 6 10.102 6 9C6 8.29588 6.15572 7.62181 6.44027 7`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`3`}],[`path`,{d:`M20.3159 4C21.3796 5.43008 22 7.14984 22 9C22 10.8502 21.3796 12.5699 20.3159 14M3.68409 4C2.62036 5.43008 2 7.14984 2 9C2 10.8502 2.62036 12.5699 3.68409 14`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`4`}]],rr=[[`path`,{d:`M12 11L12 20`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M14 9C14 10.1046 13.1046 11 12 11C10.8954 11 10 10.1046 10 9C10 7.89543 10.8954 7 12 7C13.1046 7 14 7.89543 14 9Z`,stroke:`currentColor`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M16.9588 6C17.6186 6.86961 18 7.89801 18 9C18 10.102 17.6186 11.1304 16.9588 12M7.04117 6C6.38143 6.86961 6 7.89801 6 9C6 10.102 6.38143 11.1304 7.04117 12`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}],[`path`,{d:`M20.3159 4C21.3796 5.43008 22 7.14984 22 9C22 10.8502 21.3796 12.5699 20.3159 14M3.68409 4C2.62036 5.43008 2 7.14984 2 9C2 10.8502 2.62036 12.5699 3.68409 14`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`3`}]],ir=[[`path`,{d:`M7 15V22M17 15V22`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M12 11C10.4783 11 8.86931 11.2925 7.60803 11.6838C6.6583 11.9784 5.89434 13.322 6.01199 14.4128C6.05558 14.8169 6.36877 15 6.69807 15H17.3019C17.6312 15 17.9444 14.8169 17.988 14.4128C18.1057 13.322 17.3417 11.9784 16.392 11.6838C15.1307 11.2925 13.5217 11 12 11Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M7.08364 12L6.71797 8.2874C6.46316 5.70038 6.33575 4.40687 6.88692 3.47939C7.92424 1.73383 10.2405 2.01699 12 2.01699C13.7595 2.01699 16.0758 1.73383 17.1131 3.47939C17.6642 4.40687 17.5368 5.70038 17.282 8.28741L16.9164 12`,stroke:`currentColor`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}],[`path`,{d:`M7 18L17 18`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`3`}]],ar=[[`path`,{d:`M22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22C17.5228 22 22 17.5228 22 12Z`,stroke:`currentColor`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M8 12.75C8 12.75 9.6 13.6625 10.4 15C10.4 15 12.8 9.75 16 8`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}]],or=[[`path`,{d:`M15.3979 4.40951C15.9703 4.02542 16.659 3.80138 17.4 3.80138C19.3882 3.80138 21 5.4144 21 7.40415C21 9.31828 19.5084 10.8838 17.625 11H17M15.3979 4.40951C14.9058 3.0062 13.5703 2 12 2C10.4297 2 9.09418 3.0062 8.60215 4.40951M15.3979 4.40951C15.5288 4.78297 15.6 5.18455 15.6 5.60277C15.6 5.91378 15.5606 6.21558 15.4866 6.50346M9.71838 5.60277C9.44207 5.12473 9.05914 4.71612 8.60215 4.40951M8.60215 4.40951C8.02968 4.02543 7.34099 3.80138 6.6 3.80138C4.61177 3.80138 3 5.4144 3 7.40415C3 9.31828 4.49159 10.8838 6.375 11H7`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M17 14V10M7 14V10`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M18 14.5C16.401 13.8776 14.3005 13.5 12 13.5C9.69952 13.5 7.59905 13.8776 6 14.5`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.5`,key:`2`}],[`path`,{d:`M17 17C17 19.7614 14.7614 22 12 22C9.23858 22 7 19.7614 7 17`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.5`,key:`3`}]],sr=[[`path`,{d:`M21 3L13 11.5`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M9.44573 11.0854C6.96539 12.0368 4.98269 11.8736 3 11.0885C3.50059 17.531 6.50414 20.0089 10.5089 21C10.5089 21 13.5261 18.8664 13.961 13.8074C14.0081 13.2595 14.0317 12.9856 13.9178 12.6769C13.8038 12.3682 13.5802 12.1468 13.1329 11.704C12.3973 10.9757 12.0295 10.6116 11.5929 10.5204C11.1564 10.4293 10.5862 10.648 9.44573 11.0854Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M4.5 16.4464C4.5 16.4464 7 16.9286 9.5 15`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}],[`path`,{d:`M8.5 7.25C8.5 7.94036 7.94036 8.5 7.25 8.5C6.55964 8.5 6 7.94036 6 7.25C6 6.55964 6.55964 6 7.25 6C7.94036 6 8.5 6.55964 8.5 7.25Z`,stroke:`currentColor`,strokeWidth:`1.5`,key:`3`}],[`path`,{d:`M11.125 4H11M11.25 4C11.25 4.13807 11.1381 4.25 11 4.25C10.8619 4.25 10.75 4.13807 10.75 4C10.75 3.86193 10.8619 3.75 11 3.75C11.1381 3.75 11.25 3.86193 11.25 4Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`4`}]],cr=[[`circle`,{cx:`12`,cy:`12`,r:`10`,stroke:`currentColor`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M12 8V12L14 14`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}]],lr=[[`path`,{d:`M17.4776 8.7803L17.5 8.78025C19.9853 8.78025 22 10.7212 22 13.1154C22 14.8176 20.9817 16.2906 19.5 17M17.4776 8.7803C17.4924 8.62164 17.5 8.46095 17.5 8.29856C17.5 5.37225 15.0376 3 12 3C9.12324 3 6.76233 5.12773 6.52042 7.83875M17.4776 8.7803C17.3753 9.8732 16.9286 10.8704 16.2428 11.6704M6.52042 7.83875C3.98398 8.07128 2 10.1293 2 12.6338C2 14.566 3.18102 16.2326 4.88559 17M6.52042 7.83875C6.67826 7.82428 6.83823 7.81688 7 7.81688C8.12582 7.81688 9.16474 8.17534 10.0005 8.78025`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M12.0434 12L10.907 13.036C10.3596 13.596 10.3596 14.492 10.9358 15.052C11.224 15.332 11.6401 15.5 12.0434 15.5C12.4468 15.5 12.7797 15.36 13.0678 15.108C13.6441 14.548 13.6441 13.624 13.0678 13.064L12.0434 12Z`,stroke:`currentColor`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M8.54345 17.5L7.40701 18.536C6.8596 19.096 6.85963 19.992 7.43585 20.552C7.72396 20.832 8.14009 21 8.54345 21C8.9468 21 9.27972 20.86 9.56783 20.608C10.1441 20.048 10.1441 19.124 9.56783 18.564L8.54345 17.5Z`,stroke:`currentColor`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}],[`path`,{d:`M15.5434 17.5L14.407 18.536C13.8596 19.096 13.8596 19.992 14.4358 20.552C14.724 20.832 15.1401 21 15.5434 21C15.9468 21 16.2797 20.86 16.5678 20.608C17.1441 20.048 17.1441 19.124 16.5678 18.564L15.5434 17.5Z`,stroke:`currentColor`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`3`}]],ur=[[`path`,{d:`M17.4776 8.50005C17.485 8.50002 17.4925 8.5 17.5 8.5C19.9853 8.5 22 10.5147 22 13C22 14.5602 21.206 15.935 20 16.7422M16.9003 10.5C17.2119 9.89038 17.4131 9.21494 17.4776 8.50005C17.4924 8.33536 17.5 8.16856 17.5 8C17.5 4.96243 15.0376 2.5 12 2.5C9.12324 2.5 6.76233 4.70862 6.52042 7.5227M6.52042 7.5227C3.98398 7.76407 2 9.90034 2 12.5C2 14.1358 2.78555 15.5882 4 16.5004M6.52042 7.5227C6.67826 7.50768 6.83823 7.5 7 7.5C7.78232 7.5 8.52268 7.67967 9.18206 8`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M10.1992 21.5L12.1992 16.5`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M9 14.5L7 19.5`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}],[`path`,{d:`M17 14.5L15 19.5`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`3`}]],dr=[[`path`,{d:`M17.4776 10.0001C17.485 10 17.4925 10 17.5 10C19.9853 10 22 12.0147 22 14.5C22 16.9853 19.9853 19 17.5 19H7C4.23858 19 2 16.7614 2 14C2 11.4003 3.98398 9.26407 6.52042 9.0227M17.4776 10.0001C17.4924 9.83536 17.5 9.66856 17.5 9.5C17.5 6.46243 15.0376 4 12 4C9.12324 4 6.76233 6.20862 6.52042 9.0227M17.4776 10.0001C17.3753 11.1345 16.9286 12.1696 16.2428 13M6.52042 9.0227C6.67826 9.00768 6.83823 9 7 9C8.12582 9 9.16474 9.37209 10.0005 10`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}]],fr=[[`path`,{d:`M16 6.99998L19.0664 9.64296C20.3554 10.7541 21 11.3096 21 12C21 12.6903 20.3555 13.2459 19.0664 14.357L16 17`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M8 6.99998L4.93365 9.64296C3.64455 10.7541 3 11.3096 3 12C3 12.6903 3.64455 13.2459 4.93365 14.357L8 17`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}]],pr=[[`path`,{d:`M22 12H2`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M20 17H16C14.1144 17 13.1716 17 12.5858 16.4142C12 15.8284 12 14.8856 12 13V12`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M4 12V22M20 12V22`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}],[`path`,{d:`M7 6V5C7 3.58579 7 2.87868 7.43934 2.43934C7.87868 2 8.58579 2 10 2H14C15.4142 2 16.1213 2 16.5607 2.43934C17 2.87868 17 3.58579 17 5V6C17 7.41421 17 8.12132 16.5607 8.56066C16.1213 9 15.4142 9 14 9H10C8.58579 9 7.87868 9 7.43934 8.56066C7 8.12132 7 7.41421 7 6Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`3`}],[`path`,{d:`M13.5 9L14 12M10.5 9L10 12`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`4`}]],mr=[[`path`,{d:`M4 12C4 8.22876 4 6.34315 5.17157 5.17157C6.34315 4 8.22876 4 12 4C15.7712 4 17.6569 4 18.8284 5.17157C20 6.34315 20 8.22876 20 12C20 15.7712 20 17.6569 18.8284 18.8284C17.6569 20 15.7712 20 12 20C8.22876 20 6.34315 20 5.17157 18.8284C4 17.6569 4 15.7712 4 12Z`,stroke:`currentColor`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M9.5 2V4`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M14.5 2V4`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}],[`path`,{d:`M9.5 20V22`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`3`}],[`path`,{d:`M14.5 20V22`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`4`}],[`path`,{d:`M13 9L9 13`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`5`}],[`path`,{d:`M15 13L13 15`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`6`}],[`path`,{d:`M22 14.5L20 14.5`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`7`}],[`path`,{d:`M4 9.5L2 9.5`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`8`}],[`path`,{d:`M4 14.5L2 14.5`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`9`}],[`path`,{d:`M22 9.5L20 9.5`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`10`}]],hr=[[`path`,{d:`M22 3L2 3`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M5 14C5.5985 13.2925 6.76719 11.3937 7 9`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M19 14C18.4015 13.2925 17.2328 11.3937 17 9`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}],[`path`,{d:`M3 3V14.625M3 14.625V16.75C3 18.7535 3 19.7552 3.58579 20.3776C4.17157 21 5.11438 21 7 21H8C8 19.5311 7.6 16.0778 6 14.0154M3 14.625C4.14794 14.5482 5.14101 14.3343 6 14.0154M6 14.0154C9.88075 12.5749 12.0001 7.21447 12 3`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`3`}],[`path`,{d:`M21 3V14.625M21 14.625V16.75C21 18.7535 21 19.7552 20.4142 20.3776C19.8284 21 18.8856 21 17 21H16C16 19.5311 16.4 16.0778 18 14.0154M21 14.625C19.8521 14.5482 18.859 14.3343 18 14.0154M18 14.0154C14.1192 12.5749 11.9999 7.21447 12 3`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`4`}]],gr=[[`ellipse`,{cx:`11`,cy:`5`,rx:`8`,ry:`3`,stroke:`currentColor`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M6 10.8418C6.60158 11.0226 7.27434 11.1716 8 11.2817`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M3 12C3 13.5299 6.05369 14.7923 10 14.9768`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.5`,key:`2`}],[`path`,{d:`M6 17.8418C6.60158 18.0226 7.27434 18.1716 8 18.2817`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.5`,key:`3`}],[`path`,{d:`M11 22C6.58172 22 3 20.6569 3 19V5M19 5V11`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`4`}],[`path`,{d:`M17 20.7143V22M17 20.7143C15.8432 20.7143 14.8241 20.1461 14.2263 19.2833M19.7738 15.7169C20.1273 16.2271 20.3333 16.8403 20.3333 17.5C20.3333 18.1597 20.1272 18.773 19.7737 19.2833C19.1759 20.1461 18.1568 20.7143 17 20.7143M17 14.2857C18.1569 14.2857 19.1761 14.854 19.7738 15.7169M17 14.2857C15.8431 14.2857 14.8239 14.854 14.2262 15.7169M17 14.2857V13M21 14.9286L19.7738 15.7169M13.0004 20.0714L14.2263 19.2833M13 14.9286L14.2262 15.7169M20.9996 20.0714L19.7737 19.2833M14.2262 15.7169C13.8727 16.2271 13.6667 16.8403 13.6667 17.5C13.6667 18.1597 13.8728 18.773 14.2263 19.2833`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.5`,key:`5`}]],_r=[[`path`,{d:`M19.5 5.5L18.8803 15.5251C18.7219 18.0864 18.6428 19.3671 18.0008 20.2879C17.6833 20.7431 17.2747 21.1273 16.8007 21.416C15.8421 22 14.559 22 11.9927 22C9.42312 22 8.1383 22 7.17905 21.4149C6.7048 21.1257 6.296 20.7408 5.97868 20.2848C5.33688 19.3626 5.25945 18.0801 5.10461 15.5152L4.5 5.5`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M3 5.5H21M16.0557 5.5L15.3731 4.09173C14.9196 3.15626 14.6928 2.68852 14.3017 2.39681C14.215 2.3321 14.1231 2.27454 14.027 2.2247C13.5939 2 13.0741 2 12.0345 2C10.9688 2 10.436 2 9.99568 2.23412C9.8981 2.28601 9.80498 2.3459 9.71729 2.41317C9.32164 2.7167 9.10063 3.20155 8.65861 4.17126L8.05292 5.5`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.5`,key:`1`}]],k=[[`path`,{d:`M19.5 5.5L18.8803 15.5251C18.7219 18.0864 18.6428 19.3671 18.0008 20.2879C17.6833 20.7431 17.2747 21.1273 16.8007 21.416C15.8421 22 14.559 22 11.9927 22C9.42312 22 8.1383 22 7.17905 21.4149C6.7048 21.1257 6.296 20.7408 5.97868 20.2848C5.33688 19.3626 5.25945 18.0801 5.10461 15.5152L4.5 5.5`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M9 11.7349H15`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M10.5 15.6543H13.5`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.5`,key:`2`}],[`path`,{d:`M3 5.5H21M16.0555 5.5L15.3729 4.09173C14.9194 3.15626 14.6926 2.68852 14.3015 2.39681C14.2148 2.3321 14.1229 2.27454 14.0268 2.2247C13.5937 2 13.0739 2 12.0343 2C10.9686 2 10.4358 2 9.99549 2.23412C9.89791 2.28601 9.80479 2.3459 9.7171 2.41317C9.32145 2.7167 9.10044 3.20155 8.65842 4.17126L8.05273 5.5`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.5`,key:`3`}]],vr=[[`path`,{d:`M8 7L8 21`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M12 18L12 21`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M3 21H15`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}],[`path`,{d:`M4 13V13.9596C4 14.8052 4 15.228 4.20108 15.5762C4.40216 15.9243 4.76839 16.1356 5.50083 16.5582L8 18`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`3`}],[`path`,{d:`M12 9V11.9596C12 12.8052 12 13.228 11.7989 13.5762C11.5978 13.9243 11.2316 14.1356 10.4992 14.5582L8 16`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`4`}],[`circle`,{cx:`18`,cy:`6`,r:`3`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`5`}]],yr=[[`path`,{d:`M14.5 2.5H9.5C6.20017 2.5 4.55025 2.5 3.52513 3.52513C2.5 4.55025 2.5 6.20017 2.5 9.5V14.5C2.5 17.7998 2.5 19.4497 3.52513 20.4749C4.55025 21.5 6.20017 21.5 9.5 21.5H14.5C17.7998 21.5 19.4497 21.5 20.4749 20.4749C21.5 19.4497 21.5 17.7998 21.5 14.5V9.5C21.5 6.20017 21.5 4.55025 20.4749 3.52513C19.4497 2.5 17.7998 2.5 14.5 2.5Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M2.5 8.5H21.5`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M6 5.5H10`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}],[`path`,{d:`M14.5 18.5C16.433 18.5 18 16.933 18 15C18 13.067 16.433 11.5 14.5 11.5C12.567 11.5 11 13.067 11 15C11 16.933 12.567 18.5 14.5 18.5Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`3`}],[`path`,{d:`M12 12.5505C11.3647 11.9022 10.4793 11.5 9.5 11.5C7.567 11.5 6 13.067 6 15C6 16.933 7.567 18.5 9.5 18.5C10.4793 18.5 11.3647 18.0978 12 17.4495`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`4`}],[`path`,{d:`M18.125 5.5H18M18.25 5.5C18.25 5.63807 18.1381 5.75 18 5.75C17.8619 5.75 17.75 5.63807 17.75 5.5C17.75 5.36193 17.8619 5.25 18 5.25C18.1381 5.25 18.25 5.36193 18.25 5.5Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`5`}]],br=[[`path`,{d:`M18 20C19.1046 20 20 19.1046 20 18V6C20 4.89543 19.1046 4 18 4`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M4 6.84771V17.1523C4 18.7454 4 19.542 4.4645 20.0976C4.92899 20.6531 5.71415 20.7956 7.28446 21.0806L10.2845 21.6251C12.4701 22.0217 13.563 22.2201 14.2815 21.6215C15 21.023 15 19.9142 15 17.6968V6.30325C15 4.08578 15 2.97704 14.2815 2.37849C13.563 1.77994 12.4701 1.97827 10.2845 2.37495L7.28446 2.91941C5.71415 3.2044 4.92899 3.34689 4.4645 3.90244C4 4.45799 4 5.25457 4 6.84771Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M11.625 12H11.5M11.75 12C11.75 12.1381 11.6381 12.25 11.5 12.25C11.3619 12.25 11.25 12.1381 11.25 12C11.25 11.8619 11.3619 11.75 11.5 11.75C11.6381 11.75 11.75 11.8619 11.75 12Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.5`,key:`2`}]],xr=[[`path`,{d:`M5 22V8C5 5.17157 5 3.75736 5.87868 2.87868C6.75736 2 8.17157 2 11 2H13C15.8284 2 17.2426 2 18.1213 2.87868C19 3.75736 19 5.17157 19 8V22`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M3 22H21`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M15.125 12H15M15.25 12C15.25 12.1381 15.1381 12.25 15 12.25C14.8619 12.25 14.75 12.1381 14.75 12C14.75 11.8619 14.8619 11.75 15 11.75C15.1381 11.75 15.25 11.8619 15.25 12Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.5`,key:`2`}]],Sr=[[`path`,{d:`M2.5 20.502L10.5 20.502`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M16 17.002V15.502C16 14.3974 16.8954 13.502 18 13.502C19.1046 13.502 20 14.3974 20 15.502V17.002M16 17.002H20M16 17.002C15.5341 17.002 15.3011 17.002 15.1173 17.0781C14.8723 17.1796 14.6776 17.3742 14.5761 17.6193C14.5 17.803 14.5 18.036 14.5 18.502V19.502C14.5 20.4448 14.5 20.9162 14.7929 21.2091C15.0858 21.502 15.5572 21.502 16.5 21.502H19.5C20.4428 21.502 20.9142 21.502 21.2071 21.2091C21.5 20.9162 21.5 20.4448 21.5 19.502V18.502C21.5 18.036 21.5 17.803 21.4239 17.6193C21.3224 17.3742 21.1277 17.1796 20.8827 17.0781C20.6989 17.002 20.4659 17.002 20 17.002`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M7.5 11.502H9`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}],[`path`,{d:`M18.5 9.50195V8.50195C18.5 5.67353 18.5 4.25931 17.6213 3.38063C16.7426 2.50195 15.3284 2.50195 12.5 2.50195H10.5C7.67157 2.50195 6.25736 2.50195 5.37868 3.38063C4.5 4.25931 4.5 5.67353 4.5 8.50195V20.502`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`3`}]],Cr=[[`path`,{d:`M3 21.002H21`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M5 21.002V9.00195C5 6.17353 5 4.75931 5.87868 3.88063C6.75736 3.00195 8.17157 3.00195 11 3.00195H13C15.8284 3.00195 17.2426 3.00195 18.1213 3.88063C19 4.75931 19 6.17353 19 9.00195V21.002`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M8 12.002H9.5`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}]],wr=[[`path`,{d:`M12 11.502V12.002M13 12.002C13 12.5542 12.5523 13.002 12 13.002C11.4477 13.002 11 12.5542 11 12.002C11 11.4497 11.4477 11.002 12 11.002C12.5523 11.002 13 11.4497 13 12.002Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}]],Tr=[[`path`,{d:`M16.9504 12.1817C17.1981 12.814 16.5076 13.5726 15.1267 15.0899C13.6702 16.6902 12.9201 17.4904 12 17.5C11.0799 17.4904 10.3298 16.6902 8.87331 15.0899C7.49239 13.5726 6.80193 12.814 7.04964 12.1817C7.05868 12.1586 7.06851 12.1359 7.0791 12.1135C7.34928 11.542 8.24477 11.5029 10 11.5002V4.99998C10 4.53501 10 4.30253 10.0511 4.11179C10.1898 3.59414 10.5941 3.1898 11.1118 3.05111C11.3025 3 11.535 3 12 3C12.4649 3 12.6974 3 12.8882 3.05111C13.4058 3.1898 13.8102 3.59414 13.9489 4.11179C14 4.30253 14 4.53501 14 4.99998V11.5002C15.7552 11.5029 16.6507 11.542 16.9209 12.1135C16.9315 12.1359 16.9413 12.1586 16.9504 12.1817Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M5.00006 21H19.0001`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}]],Er=[[`path`,{d:`M16 6C16 6.55228 15.5523 7 15 7C14.4477 7 14 6.55228 14 6C14 5.44772 14.4477 5 15 5C15.5523 5 16 5.44772 16 6Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M10 6C10 6.55228 9.55228 7 9 7C8.44772 7 8 6.55228 8 6C8 5.44772 8.44772 5 9 5C9.55228 5 10 5.44772 10 6Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M16 18C16 18.5523 15.5523 19 15 19C14.4477 19 14 18.5523 14 18C14 17.4477 14.4477 17 15 17C15.5523 17 16 17.4477 16 18Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}],[`path`,{d:`M16 12C16 12.5523 15.5523 13 15 13C14.4477 13 14 12.5523 14 12C14 11.4477 14.4477 11 15 11C15.5523 11 16 11.4477 16 12Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`3`}],[`path`,{d:`M10 18C10 18.5523 9.55228 19 9 19C8.44772 19 8 18.5523 8 18C8 17.4477 8.44772 17 9 17C9.55228 17 10 17.4477 10 18Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`4`}],[`path`,{d:`M10 12C10 12.5523 9.55228 13 9 13C8.44772 13 8 12.5523 8 12C8 11.4477 8.44772 11 9 11C9.55228 11 10 11.4477 10 12Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`5`}]],Dr=[[`path`,{d:`M6.26869 7.96595C5.55098 8.65784 5.19212 9.00379 4.75494 8.99997C3.73206 8.99102 1.92649 7.00413 2.00231 5.986C2.033 5.57393 2.39927 5.26497 3.13182 4.64705L5.32917 2.79353C5.979 2.24539 6.87323 2.22352 7.68526 2.06696C8.00922 2.0045 8.1712 1.97327 8.31518 2.02893C8.77941 2.20837 9.16219 3.05277 9.4391 3.43412C10.604 5.03836 11.1864 5.84049 12.0003 5.84049C12.8141 5.84049 13.3966 5.03836 14.5615 3.43412C14.8384 3.05277 15.2211 2.20837 15.6854 2.02893C15.8294 1.97327 15.9913 2.0045 16.3153 2.06696C17.1591 2.22965 17.9924 2.22083 18.6714 2.79353L20.8687 4.64705C21.6013 5.26497 21.9676 5.57393 21.9982 5.986C22.0741 7.00413 20.2685 8.99102 19.2456 8.99997C18.8084 9.00379 18.4496 8.65784 17.7319 7.96595`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M6 7C7.5 9 6.95594 11.1815 6.59802 13.2178C6.22004 15.3682 5.58295 16.6762 5.21963 18.4412C4.97017 19.6531 4.84545 20.2591 5.33363 20.7716C6.71183 22.2184 16.9342 22.5901 18.6664 20.7716C19.1546 20.2591 19.0298 19.6531 18.7804 18.4412C18.4171 16.6762 17.78 15.3682 17.402 13.2178C17.0441 11.1815 16.5 9 18 7`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}]],Or=[[`path`,{d:`M12.0009 17.9994C13.6228 17.9994 15.0193 17.034 15.6471 15.6465`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M2 2L22 22`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M8.77661 3.77661C9.05754 3.49066 9.3321 3.22188 9.59499 2.97222C10.96 1.67593 13.0417 1.67593 14.4067 2.97222C16.9201 5.35907 20.5009 9.49387 20.5009 13.678C20.5009 14.2298 20.4426 14.7836 20.329 15.329M6.45106 6.45106C4.8377 8.58331 3.50085 11.1215 3.50085 13.678C3.50085 17.7804 6.71963 22 12.0009 22C14.9766 22 17.2975 20.6603 18.7569 18.7569`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}]],kr=[[`path`,{d:`M3.5 13.678C3.5 9.49387 7.08079 5.35907 9.59413 2.97222C10.9591 1.67593 13.0409 1.67593 14.4059 2.97222C16.9192 5.35907 20.5 9.49387 20.5 13.678C20.5 17.7804 17.2812 22 12 22C6.71878 22 3.5 17.7804 3.5 13.678Z`,stroke:`currentColor`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M16 14C16 16.2091 14.2091 18 12 18`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}]],Ar=[[`path`,{d:`M7.73438 13.7323C7.73438 13.7323 8.63984 12.5102 9.23438 12.2319C11.0292 11.3915 11.3943 11.0263 12.2344 9.23091C12.5127 8.63618 13.7344 7.73044 13.7344 7.73044M10.2344 16.2331C10.2344 16.2331 11.4561 15.3273 11.7344 14.7326C12.5745 12.9373 12.9396 12.5721 14.7344 11.7317C15.3289 11.4533 16.2344 10.2312 16.2344 10.2312`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M14.4311 2.89207C14.938 2.38343 15.7611 2.38212 16.2696 2.88916L21.0814 7.68726C21.5899 8.1943 21.5912 9.01767 21.0843 9.52632L19.5557 11.0603C19.0488 11.5689 18.2257 11.5702 17.7172 11.0632L12.9054 6.26507C12.397 5.75803 12.3957 4.93466 12.9025 4.42601L14.4311 2.89207Z`,stroke:`currentColor`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M4.41377 12.9022C4.92065 12.3936 5.74376 12.3923 6.25225 12.8993L11.0641 17.6974C11.5725 18.2045 11.5738 19.0278 11.067 19.5365L9.53836 21.0704C9.03148 21.5791 8.20837 21.5804 7.69988 21.0733L2.88808 16.2752C2.37959 15.7682 2.37829 14.9448 2.88517 14.4362L4.41377 12.9022Z`,stroke:`currentColor`,strokeWidth:`1.5`,key:`2`}],[`path`,{d:`M17.9377 3.45254C19.8201 0.985467 23.14 3.8401 20.5431 6.02872M3.37811 17.9773C0.998473 19.9687 3.99782 23.1586 6.06742 20.4657`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`3`}]],jr=[[`path`,{d:`M12 22C6.47715 22 2 17.5228 2 12C2 9.20746 3.14465 6.68227 4.99037 4.86802M12 22C11.037 21.2864 11.1907 20.4555 11.6738 19.6247C12.4166 18.3474 12.4166 18.3474 12.4166 16.6444C12.4166 14.9414 13.4286 14.1429 17 14.8571C18.6047 15.1781 19.7741 12.9609 21.8573 13.693M12 22C16.9458 22 21.053 18.4096 21.8573 13.693M21.8573 13.693C21.9511 13.1427 22 12.5771 22 12C22 7.11857 18.5024 3.05405 13.8766 2.17579M13.8766 2.17579C14.3872 3.11599 14.1816 4.23551 13.1027 4.66298C11.3429 5.3603 12.6029 6.64343 11.1035 7.4356C10.1038 7.96372 8.6044 7.83152 7.10496 6.24716C6.31517 5.41264 5.83966 4.95765 4.99037 4.86802M13.8766 2.17579C13.2687 2.06039 12.6414 2 12 2C9.26969 2 6.79495 3.09421 4.99037 4.86802`,stroke:`currentColor`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}]],Mr=[[`path`,{d:`M16.9459 3.17305C17.5332 2.58578 17.8268 2.29215 18.1521 2.15173C18.6208 1.94942 19.1521 1.94942 19.6208 2.15173C19.946 2.29215 20.2397 2.58578 20.8269 3.17305C21.4142 3.76032 21.7079 4.05395 21.8483 4.37925C22.0506 4.8479 22.0506 5.37924 21.8483 5.84789C21.7079 6.17319 21.4142 6.46682 20.8269 7.05409L15.8054 12.0757C14.5682 13.3129 13.9496 13.9315 13.1748 14.298C12.4 14.6645 11.5294 14.7504 9.78823 14.9222L9 15L9.07778 14.2118C9.24958 12.4706 9.33549 11.6 9.70201 10.8252C10.0685 10.0504 10.6871 9.43183 11.9243 8.19464L16.9459 3.17305Z`,stroke:`currentColor`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M6 15H3.75C2.7835 15 2 15.7835 2 16.75C2 17.7165 2.7835 18.5 3.75 18.5H13.25C14.2165 18.5 15 19.2835 15 20.25C15 21.2165 14.2165 22 13.25 22H11`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}]],A=[[`path`,{d:`M14.0737 3.88545C14.8189 3.07808 15.1915 2.6744 15.5874 2.43893C16.5427 1.87076 17.7191 1.85309 18.6904 2.39232C19.0929 2.6158 19.4769 3.00812 20.245 3.79276C21.0131 4.5774 21.3972 4.96972 21.6159 5.38093C22.1438 6.37312 22.1265 7.57479 21.5703 8.5507C21.3398 8.95516 20.9446 9.33578 20.1543 10.097L10.7506 19.1543C9.25288 20.5969 8.504 21.3182 7.56806 21.6837C6.63212 22.0493 5.6032 22.0224 3.54536 21.9686L3.26538 21.9613C2.63891 21.9449 2.32567 21.9367 2.14359 21.73C1.9615 21.5234 1.98636 21.2043 2.03608 20.5662L2.06308 20.2197C2.20301 18.4235 2.27297 17.5255 2.62371 16.7182C2.97444 15.9109 3.57944 15.2555 4.78943 13.9445L14.0737 3.88545Z`,stroke:`currentColor`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M13 4L20 11`,stroke:`currentColor`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M14 22L22 22`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}]],Nr=[[`path`,{d:`M15 15L10.7506 19.068C9.25288 20.5543 8.504 21.2975 7.56806 21.6741C6.63212 22.0508 5.6032 22.0231 3.54536 21.9676L3.26538 21.9601C2.63891 21.9432 2.32567 21.9348 2.14359 21.7219C1.9615 21.509 1.98636 21.1802 2.03608 20.5227L2.06308 20.1657C2.20301 18.3151 2.27297 17.3898 2.62371 16.5581C2.97444 15.7263 3.57944 15.051 4.78943 13.7003L9 9`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M11.5 6.67393L14.0737 3.88545C14.8189 3.07808 15.1915 2.6744 15.5874 2.43893C16.5427 1.87076 17.7191 1.85309 18.6904 2.39232C19.0929 2.6158 19.4769 3.00812 20.245 3.79276C21.0131 4.5774 21.3972 4.96972 21.6159 5.38093C22.1438 6.37312 22.1265 7.57479 21.5703 8.5507C21.3398 8.95516 20.9446 9.33578 20.1543 10.097L17.5 12.5`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M13 4L20 11`,stroke:`currentColor`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}],[`path`,{d:`M2 2L22 22`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`3`}]],Pr=[[`path`,{d:`M9.26281 12.2458C7.19268 12.0545 4.64013 12.1232 3.2361 12.9338L3.08751 13.0196C2.62814 13.2848 2.28791 13.723 2.25891 14.2527C2.21535 15.0482 2.30808 16.3264 3.07103 17.6479C4.42486 19.9928 6.77519 21.0713 7.76997 21.4394C8.06576 21.5489 8.38955 21.5054 8.66269 21.3477C9.16614 21.0571 9.37976 20.4464 9.24709 19.8804C8.87657 18.2997 8.79308 16.0301 9.9787 14.2647C9.52837 13.8126 9.25 13.189 9.25 12.5005C9.25 12.4145 9.25434 12.3296 9.26281 12.2458Z`,stroke:`currentColor`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M14.1611 13.1637C13.9722 13.8519 13.4966 14.4215 12.8706 14.7359C13.7391 16.6397 15.09 18.8587 16.5108 19.679L16.6594 19.7648C17.1188 20.03 17.6685 20.1055 18.1416 19.8658C18.8523 19.5058 19.913 18.7864 20.6759 17.4649C22.0297 15.12 21.7886 12.5453 21.61 11.4998C21.5569 11.1889 21.3574 10.9302 21.0842 10.7725C20.5808 10.4818 19.9451 10.6021 19.5213 11C18.3133 12.1341 16.3345 13.368 14.1611 13.1637Z`,stroke:`currentColor`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M11.1722 10.0676C11.3577 10.0237 11.5511 10.0005 11.75 10.0005C12.3502 10.0005 12.901 10.212 13.3319 10.5645C14.5328 8.86728 15.75 6.62197 15.75 5.00049V4.82892C15.75 4.29848 15.5406 3.78471 15.0964 3.49477C14.4293 3.0593 13.2759 2.50049 11.75 2.50049C9.04235 2.50049 6.93318 3.99669 6.11697 4.67412C5.87428 4.87556 5.75 5.17768 5.75 5.49308C5.75 6.07441 6.17204 6.56474 6.72854 6.73284C8.25356 7.19351 10.2147 8.2251 11.1722 10.0676Z`,stroke:`currentColor`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}],[`path`,{d:`M14.2499 12.5002C14.2499 13.881 13.1307 15.0002 11.7499 15.0002C10.3692 15.0002 9.24994 13.881 9.24994 12.5002C9.24994 11.1195 10.3692 10.0002 11.7499 10.0002C13.1307 10.0002 14.2499 11.1195 14.2499 12.5002Z`,stroke:`currentColor`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`3`}]],Fr=[[`path`,{d:`M8 17H16`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M8 13H12`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M13 2.5V3C13 5.82843 13 7.24264 13.8787 8.12132C14.7574 9 16.1716 9 19 9H19.5M20 10.6569V14C20 17.7712 20 19.6569 18.8284 20.8284C17.6569 22 15.7712 22 12 22C8.22876 22 6.34315 22 5.17157 20.8284C4 19.6569 4 17.7712 4 14V9.45584C4 6.21082 4 4.58831 4.88607 3.48933C5.06508 3.26731 5.26731 3.06508 5.48933 2.88607C6.58831 2 8.21082 2 11.4558 2C12.1614 2 12.5141 2 12.8372 2.11401C12.9044 2.13772 12.9702 2.165 13.0345 2.19575C13.3436 2.34355 13.593 2.593 14.0919 3.09188L18.8284 7.82843C19.4065 8.40649 19.6955 8.69552 19.8478 9.06306C20 9.4306 20 9.83935 20 10.6569Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}]],Ir=[[`path`,{d:`M14.4998 19H12.4998C9.67139 19 8.25718 19 7.3785 18.1213C6.49982 17.2426 6.49982 15.8284 6.49982 13V8C6.49982 5.17157 6.49982 3.75736 7.3785 2.87868C8.25718 2 9.67139 2 12.4998 2H13.843C14.6605 2 15.0692 2 15.4368 2.15224C15.8043 2.30448 16.0933 2.59351 16.6714 3.17157L19.3282 5.82843C19.9063 6.40648 20.1953 6.69552 20.3476 7.06306C20.4998 7.4306 20.4998 7.83935 20.4998 8.65685V13C20.4998 15.8284 20.4998 17.2426 19.6211 18.1213C18.7425 19 17.3282 19 14.4998 19Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M14.9998 2.5V3.5C14.9998 5.38562 14.9998 6.32843 15.5856 6.91421C16.1714 7.5 17.1142 7.5 18.9998 7.5H19.9998`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M6.49945 5C4.8426 5 3.49945 6.34315 3.49945 8V16C3.49945 18.8285 3.49945 20.2427 4.37813 21.1213C5.25681 22 6.67102 22 9.49945 22H14.4998C16.1566 22 17.4998 20.6568 17.4998 19`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}],[`path`,{d:`M10 11H14M10 15H17`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`3`}]],Lr=[[`path`,{d:`M20.6693 7C20.7527 6.8184 20.7971 6.62572 20.8297 6.37281C21.0319 4.8008 21.133 4.0148 20.672 3.5074C20.2111 3 19.396 3 17.7657 3H6.23433C4.60404 3 3.7889 3 3.32795 3.5074C2.86701 4.0148 2.96811 4.8008 3.17033 6.3728C3.22938 6.8319 3.3276 7.09253 3.62734 7.44867C4.59564 8.59915 6.36901 10.6456 8.85746 12.5061C9.08486 12.6761 9.23409 12.9539 9.25927 13.2614C9.53961 16.6864 9.79643 19.0261 9.93278 20.1778C10.0043 20.782 10.6741 21.2466 11.226 20.8563C12.1532 20.2006 13.8853 19.4657 14.1141 18.2442C14.2223 17.6668 14.3806 16.6588 14.5593 15`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M17.5 8V15M21 11.5L14 11.5`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}]],Rr=[[`path`,{d:`M13.8561 22C26.0783 19 19.2338 7 10.9227 2C9.9453 5.5 8.47838 6.5 5.54497 10C1.66121 14.6339 3.5895 20 8.96719 22C8.1524 21 6.04958 18.9008 7.5 16C8 15 9 14 8.5 12C9.47778 12.5 11.5 13 12 15.5C12.8148 14.5 13.6604 12.4 12.8783 10C19 14.5 16.5 19 13.8561 22Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}]],zr=[[`path`,{d:`M15.8785 3L10.2827 3C7.32099 3 5.84015 3 4.92007 3.87868C4 4.75736 4 6.17157 4 9L4.10619 15L15.8785 15C18.1016 15 19.2131 15 19.6847 14.4255C19.8152 14.2666 19.9108 14.0841 19.9656 13.889C20.1639 13.184 19.497 12.3348 18.1631 10.6364L18.1631 10.6364C17.6083 9.92985 17.3309 9.57659 17.2814 9.1751C17.2671 9.05877 17.2671 8.94123 17.2814 8.8249C17.3309 8.42341 17.6083 8.07015 18.1631 7.36364L18.1631 7.36364C19.497 5.66521 20.1639 4.816 19.9656 4.11098C19.9108 3.91591 19.8152 3.73342 19.6847 3.57447C19.2131 3 18.1016 3 15.8785 3L15.8785 3Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M4 21L4 8`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.5`,key:`1`}]],Br=[[`path`,{d:`M5.22576 11.3294L12.224 2.34651C12.7713 1.64397 13.7972 2.08124 13.7972 3.01707V9.96994C13.7972 10.5305 14.1995 10.985 14.6958 10.985H18.0996C18.8729 10.985 19.2851 12.0149 18.7742 12.6706L11.776 21.6535C11.2287 22.356 10.2028 21.9188 10.2028 20.9829V14.0301C10.2028 13.4695 9.80048 13.015 9.3042 13.015H5.90035C5.12711 13.015 4.71494 11.9851 5.22576 11.3294Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}]],Vr=[[`path`,{d:`M6 6C6 7.04416 6.27249 8.07025 6.79054 8.97683L7.71665 10.526C7.85746 10.7616 7.92786 10.8793 7.96393 11.01C8 11.1406 8 11.2778 8 11.5522V18C8 19.4001 8 20.1002 8.27248 20.635C8.51217 21.1054 8.89462 21.4878 9.36502 21.7275C9.8998 22 10.5999 22 12 22C13.4001 22 14.1002 22 14.635 21.7275C15.1054 21.4878 15.4878 21.1054 15.7275 20.635C16 20.1002 16 19.4001 16 18V16`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M7 2.29243C7.60164 2 8.50417 2 10 2H14C15.8856 2 16.8284 2 17.4142 2.58579C18 3.17157 18 4.11438 18 6C18 7.04416 17.7275 8.07025 17.2095 8.97683L16.2834 10.526C16.1425 10.7616 16.0721 10.8793 16.0361 11.01`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M2 2L22 22`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}],[`path`,{d:`M11 6L18 6`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`3`}],[`path`,{d:`M12 12V15`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`4`}]],Hr=[[`path`,{d:`M15 3H9C8.05719 3 7.58579 3 7.29289 3.29289C7 3.58579 7 4.05719 7 5V6C7 7.04416 7.27249 8.07025 7.79054 8.97683L9 11V18C9 18.9319 9 19.3978 9.15224 19.7654C9.35523 20.2554 9.74458 20.6448 10.2346 20.8478C10.6022 21 11.0681 21 12 21C12.9319 21 13.3978 21 13.7654 20.8478C14.2554 20.6448 14.6448 20.2554 14.8478 19.7654C15 19.3978 15 18.9319 15 18V11L16.2095 8.97683C16.7275 8.07025 17 7.04416 17 6V5C17 4.05719 17 3.58579 16.7071 3.29289C16.4142 3 15.9428 3 15 3Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M7 6H17`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M12 13V15`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}]],Ur=[[`path`,{d:`M8 22V19C8 17.1144 8 16.1716 8.58579 15.5858C9.17157 15 10.1144 15 12 15C13.8856 15 14.8284 15 15.4142 15.5858C16 16.1716 16 17.1144 16 19V22`,stroke:`currentColor`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M10 7H14`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M3 11.8584C3 7.28199 3 4.99376 4.38674 3.54394C4.43797 3.49038 4.49038 3.43797 4.54394 3.38674C5.99376 2 8.28199 2 12.8584 2C13.943 2 14.4655 2.00376 14.9628 2.18936C15.4417 2.3681 15.8429 2.70239 16.6452 3.37099L18.8411 5.20092C19.9027 6.08561 20.4335 6.52795 20.7168 7.13266C21 7.73737 21 8.42833 21 9.81025V13C21 16.7497 21 18.6246 20.0451 19.9389C19.7367 20.3634 19.3634 20.7367 18.9389 21.0451C17.6246 22 15.7497 22 12 22C8.25027 22 6.3754 22 5.06107 21.0451C4.6366 20.7367 4.26331 20.3634 3.95491 19.9389C3 18.6246 3 16.7497 3 13V11.8584Z`,stroke:`currentColor`,strokeWidth:`1.5`,key:`2`}]],Wr=[[`path`,{d:`M19.9351 12.6258C19.6807 13.8374 18.327 14.7077 15.6198 16.4481C12.6753 18.3411 11.203 19.2876 10.0105 18.9229C9.60662 18.7994 9.23463 18.5823 8.92227 18.2876C8 17.4178 8 15.6118 8 12C8 8.38816 8 6.58224 8.92227 5.71235C9.23463 5.41773 9.60662 5.20057 10.0105 5.07707C11.203 4.71243 12.6753 5.6589 15.6198 7.55186C18.327 9.29233 19.6807 10.1626 19.9351 11.3742C20.0216 11.7865 20.0216 12.2135 19.9351 12.6258Z`,stroke:`currentColor`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M4 5L4 19`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.5`,key:`1`}]],Gr=[[`path`,{d:`M21.8371 12.9178C21.5547 13.6884 20.7014 14.3047 18.9948 15.5372C16.6677 17.218 15.5041 18.0583 14.5312 17.9969C13.7882 17.9499 13.0976 17.6007 12.6223 17.0315C12 16.2863 12 14.8575 12 12C12 9.14246 12 7.71369 12.6223 6.96846C13.0976 6.39933 13.7882 6.0501 14.5312 6.00315C15.5041 5.94167 16.6677 6.78203 18.9948 8.46275C20.7014 9.6953 21.5547 10.3116 21.8371 11.0822C22.0543 11.675 22.0543 12.325 21.8371 12.9178Z`,stroke:`currentColor`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M11.8371 12.9178C11.5547 13.6884 10.7014 14.3047 8.99482 15.5372C6.66769 17.218 5.50413 18.0583 4.5312 17.9969C3.78818 17.9499 3.09758 17.6007 2.62232 17.0315C2 16.2863 2 14.8575 2 12C2 9.14246 2 7.71369 2.62232 6.96846C3.09758 6.39933 3.78818 6.0501 4.5312 6.00315C5.50413 5.94167 6.66769 6.78203 8.99482 8.46275C10.7014 9.6953 11.5547 10.3116 11.8371 11.0822C12.0543 11.675 12.0543 12.325 11.8371 12.9178Z`,stroke:`currentColor`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}]],Kr=[[`path`,{d:`M11 13H13`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M12 9V3`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M20.1526 20.9174C22.0143 20.3289 22.5597 16.7547 21.3708 12.9344C20.1819 9.11398 17.709 6.49405 15.8474 7.08259C14.6972 7.44619 14.6438 8.86174 13.6968 9.378C13.473 9.5 13.1595 9.5 12.5324 9.5H11.4676C10.8405 9.5 10.527 9.5 10.3032 9.378C9.35625 8.86174 9.30278 7.44619 8.15264 7.08259C6.29102 6.49405 3.8181 9.11398 2.62922 12.9344C1.44035 16.7547 1.98573 20.3289 3.84736 20.9174C5.20631 21.347 6.891 20.067 8.16417 17.8583C9.01333 16.3851 9.39787 16 11.1039 16H12.8961C14.6021 16 14.9867 16.3851 15.8358 17.8583C17.109 20.067 18.7937 21.347 20.1526 20.9174Z`,stroke:`currentColor`,strokeWidth:`1.5`,key:`2`}]],qr=[[`path`,{d:`M9.7812 3.09766L5.6718 5.89369C4.3639 6.78359 3.70995 7.22854 3.35498 7.90548C3 8.58242 3 9.38456 3 10.9888V17.9176C3 19.8421 3 20.8043 3.58579 21.4021C4.17157 22 5.11438 22 7 22H17C18.8856 22 19.8284 22 20.4142 21.4021C21 20.8043 21 19.8421 21 17.9176V10.9888C21 9.38456 21 8.58242 20.645 7.90548C20.29 7.22854 19.6361 6.78359 18.3282 5.89369L14.2188 3.09766C13.1433 2.36589 12.6056 2 12 2C11.3944 2 10.8567 2.36589 9.7812 3.09766Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M7 22V17C7 15.1144 7 14.1716 7.58579 13.5858C8.17157 13 9.11438 13 11 13H13C14.8856 13 15.8284 13 16.4142 13.5858C17 14.1716 17 15.1144 17 17V22`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M7 16H17`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}],[`path`,{d:`M7 19H17`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`3`}],[`path`,{d:`M12.125 7H12M12.25 7C12.25 7.13807 12.1381 7.25 12 7.25C11.8619 7.25 11.75 7.13807 11.75 7C11.75 6.86193 11.8619 6.75 12 6.75C12.1381 6.75 12.25 6.86193 12.25 7Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.5`,key:`4`}]],Jr=[[`path`,{d:`M19 17L19 11C19 8.17157 19 6.75736 18.1213 5.87868C17.2426 5 15.8284 5 13 5H10M10 5C10 4.29977 11.9943 2.99153 12.5 2.5M10 5C10 5.70023 11.9943 7.00847 12.5 7.5`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M5 7.5L5 13.5C5 16.3284 5 17.7426 5.87868 18.6213C6.75736 19.5 8.17157 19.5 11 19.5H14M14 19.5C14 20.2002 12.0057 21.5085 11.5 22M14 19.5C14 18.7998 12.0057 17.4915 11.5 17`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`circle`,{cx:`19`,cy:`19`,r:`2`,stroke:`currentColor`,strokeWidth:`1.5`,key:`2`}],[`circle`,{cx:`5`,cy:`5`,r:`2`,stroke:`currentColor`,strokeWidth:`1.5`,key:`3`}]],Yr=[[`path`,{d:`M12.5 19L12.5 22`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M10.5 22H14.5`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`circle`,{cx:`7`,cy:`7`,r:`7`,transform:`matrix(-1 0 0 1 20.5 2)`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.5`,key:`2`}],[`path`,{d:`M8.5 4C9.15431 4.0385 9.49236 4.35899 10.0735 4.97301C11.1231 6.08206 12.1727 6.1746 12.8724 5.80492C13.922 5.2504 13.04 4.35221 14.2719 3.86409C15.0748 3.54595 15.1868 2.68026 14.7399 2`,stroke:`currentColor`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`3`}],[`path`,{d:`M20 10C18.5 10 18.2338 11.2468 17 11C14.5 10.5 13.7916 11.0589 13.7916 12.2511C13.7916 13.4432 13.7916 13.4432 13.2717 14.3373C12.9335 14.9189 12.8153 15.5004 13.4894 16`,stroke:`currentColor`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`4`}],[`path`,{d:`M6.5 2C4.64864 3.79995 3.5 6.3082 3.5 9.08251C3.5 14.5598 7.97715 19 13.5 19C16.2255 19 18.6962 17.9187 20.5 16.165`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.5`,key:`5`}]],Xr=[[`path`,{d:`M17.0794 6.53297L15.4953 4.94738C14.2496 3.70049 12.5601 3 10.7985 3C9.95308 3 9.52971 4.02309 10.1275 4.62145L10.5245 5.01883C11.9169 6.41256 11.9169 8.67222 10.5245 10.0659L13.0456 12.5895L14.5583 11.0754L16.0709 12.5895C15.514 13.147 15.514 14.0508 16.0709 14.6083L16.5752 15.113C16.9876 15.5258 17.1938 15.7322 17.4162 15.8426C17.8394 16.0525 18.3363 16.0525 18.7595 15.8426C18.9819 15.7322 19.1881 15.5258 19.6005 15.113L21.1132 13.5989C21.5256 13.1861 21.7318 12.9797 21.842 12.7571C22.0517 12.3335 22.0517 11.8361 21.842 11.4125C21.7318 11.1898 21.5256 10.9834 21.1132 10.5706L20.6089 10.0659C20.052 9.50845 19.149 9.50845 18.592 10.0659L17.0794 8.55181C17.6363 7.99432 17.6363 7.09046 17.0794 6.53297Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M10.6074 10L2.52431 17.9822C2.1886 18.3138 2 18.7634 2 19.2322C2 20.2085 2.80146 21 3.7901 21C4.26487 21 4.72019 20.8138 5.0559 20.4822L13.6453 12`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}]],Zr=[[`path`,{d:`M4.12572 15.3668L10.1284 11.9903C10.7234 11.6556 11.3252 11.5 12 11.5C12.6748 11.5 13.2766 11.6556 13.8716 11.9903L19.8743 15.3668C20.5697 15.7579 21 16.4937 21 17.2916C21 18.5113 20.0113 19.5 18.7916 19.5H5.20841C3.98874 19.5 3 18.5113 3 17.2916C3 16.4937 3.43034 15.7579 4.12572 15.3668Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M10 6.40476C10 5.35279 10.8954 4.5 12 4.5C13.1046 4.5 14 5.35279 14 6.40476C14 7.12453 13.5808 7.75106 12.9623 8.07498C12.473 8.33119 12 8.75724 12 9.30952V11.5`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.5`,key:`1`}]],Qr=[[`path`,{d:`M4 5V19`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M14 5V19`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M17 19H18.5M20 19H18.5M18.5 19V11L17 12`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}],[`path`,{d:`M4 12L14 12`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`3`}]],$r=[[`path`,{d:`M3.5 5V19`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M13.5 5V19`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M20.5 19H16.5V18.6907C16.5 18.2521 16.5 18.0327 16.5865 17.8385C16.673 17.6443 16.836 17.4976 17.1621 17.2041L19.7671 14.8596C20.2336 14.4397 20.5 13.8416 20.5 13.214V13C20.5 11.8954 19.6046 11 18.5 11C17.3954 11 16.5 11.8954 16.5 13V13.4`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}],[`path`,{d:`M3.5 12L13.5 12`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`3`}]],ei=[[`path`,{d:`M3.5 5V19`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M13.5 5V19`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M16.5 17C16.5 18.1046 17.3954 19 18.5 19C19.6046 19 20.5 18.1046 20.5 17C20.5 15.8954 19.6046 15 18.5 15C19.6046 15 20.5 14.1046 20.5 13C20.5 11.8954 19.6046 11 18.5 11C17.3954 11 16.5 11.8954 16.5 13`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}],[`path`,{d:`M3.5 12L13.5 12`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`3`}]],ti=[[`path`,{d:`M18 8C18.9751 8.09652 19.6314 8.31467 20.1213 8.80768C21 9.69197 21 11.1152 21 13.9617C21 16.8082 21 18.2314 20.1213 19.1157C19.2426 20 17.8284 20 15 20H9C6.17157 20 4.75736 20 3.87868 19.1157C3 18.2314 3 16.8082 3 13.9617C3 11.1152 3 9.69197 3.87868 8.80768C4.36857 8.31467 5.02492 8.09652 6 8`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M18 20V22M6 20V22`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M12 12V16`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}],[`path`,{d:`M16 12V16`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`3`}],[`path`,{d:`M8 12V16`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`4`}],[`path`,{d:`M14.5 8C16.2321 5 12.7679 5 14.5 2`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`5`}],[`path`,{d:`M9.5 8C11.2321 5 7.76795 5 9.5 2`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`6`}]],ni=[[`circle`,{cx:`12`,cy:`12`,r:`10`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M9.5 9.5C9.5 8.11929 10.6193 7 12 7C13.3807 7 14.5 8.11929 14.5 9.5C14.5 10.3569 14.0689 11.1131 13.4117 11.5636C12.7283 12.0319 12 12.6716 12 13.5`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M12.125 16.75H12M12.25 16.75C12.25 16.8881 12.1381 17 12 17C11.8619 17 11.75 16.8881 11.75 16.75C11.75 16.6119 11.8619 16.5 12 16.5C12.1381 16.5 12.25 16.6119 12.25 16.75Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}]],ri=[[`path`,{d:`M3 11.9896V14.5C3 17.7998 3 19.4497 4.02513 20.4749C5.05025 21.5 6.70017 21.5 10 21.5H14C17.2998 21.5 18.9497 21.5 19.9749 20.4749C21 19.4497 21 17.7998 21 14.5V11.9896C21 10.3083 21 9.46773 20.6441 8.74005C20.2882 8.01237 19.6247 7.49628 18.2976 6.46411L16.2976 4.90855C14.2331 3.30285 13.2009 2.5 12 2.5C10.7991 2.5 9.76689 3.30285 7.70242 4.90855L5.70241 6.46411C4.37533 7.49628 3.71179 8.01237 3.3559 8.74005C3 9.46773 3 10.3083 3 11.9896Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M15.0002 17C14.2007 17.6224 13.1504 18 12.0002 18C10.8499 18 9.79971 17.6224 9.00018 17`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}]],ii=[[`path`,{d:`M9.99915 10.3495V12.3495`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M13.9991 10.3495V12.3495`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M13.8325 12.3495H10.1658C10.011 12.3495 9.93365 12.3495 9.86841 12.3552C9.14324 12.4186 8.5683 12.9936 8.50485 13.7188C8.49915 13.784 8.49915 13.8614 8.49915 14.0162C8.49915 14.3257 8.49915 14.4805 8.51056 14.611C8.63745 16.0613 9.78734 17.2112 11.2377 17.3381C11.3682 17.3495 11.5229 17.3495 11.8325 17.3495H12.1658C12.4754 17.3495 12.6301 17.3495 12.7606 17.3381C14.211 17.2112 15.3608 16.0613 15.4877 14.611C15.4991 14.4805 15.4991 14.3257 15.4991 14.0162C15.4991 13.8614 15.4991 13.784 15.4934 13.7188C15.43 12.9936 14.855 12.4186 14.1299 12.3552C14.0646 12.3495 13.9873 12.3495 13.8325 12.3495Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}],[`path`,{d:`M11.9991 17.3495V21.3495`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`3`}],[`path`,{d:`M15.9991 21.3495C17.8684 21.3495 18.803 21.3495 19.4991 20.9476C19.9552 20.6843 20.3339 20.3056 20.5972 19.8495C20.9991 19.1533 20.9991 18.2187 20.9991 16.3495V11.784C20.9991 10.3429 20.9991 9.62242 20.6941 8.9987C20.389 8.37497 19.8203 7.93261 18.6828 7.04789L15.6828 4.71456C13.9132 3.33824 13.0285 2.65009 11.9991 2.65009C10.9698 2.65009 10.085 3.33824 8.3155 4.71456L5.3155 7.04789C4.178 7.93261 3.60925 8.37497 3.3042 8.9987C2.99915 9.62242 2.99915 10.3429 2.99915 11.784V16.3495C2.99915 18.2187 2.99915 19.1533 3.40107 19.8495C3.66437 20.3056 4.04309 20.6843 4.49915 20.9476C5.1953 21.3495 6.12991 21.3495 7.99915 21.3495`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`4`}]],ai=[[`circle`,{cx:`7.5`,cy:`7.5`,r:`1.5`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M2.5 12C2.5 7.52166 2.5 5.28249 3.89124 3.89124C5.28249 2.5 7.52166 2.5 12 2.5C16.4783 2.5 18.7175 2.5 20.1088 3.89124C21.5 5.28249 21.5 7.52166 21.5 12C21.5 16.4783 21.5 18.7175 20.1088 20.1088C18.7175 21.5 16.4783 21.5 12 21.5C7.52166 21.5 5.28249 21.5 3.89124 20.1088C2.5 18.7175 2.5 16.4783 2.5 12Z`,stroke:`currentColor`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M5 21C9.37246 15.775 14.2741 8.88406 21.4975 13.5424`,stroke:`currentColor`,strokeWidth:`1.5`,key:`2`}]],oi=[[`path`,{d:`M2 21.9684C2.94975 21.9684 3.88858 22.0553 4.67843 21.4396C5.45232 20.8365 6.68304 20.8564 7.42654 21.4842C8.2373 22.1688 9.76776 22.1494 10.5969 21.5032C11.4013 20.8763 12.6209 20.804 13.4265 21.4842C14.3106 22.2306 15.8003 22.1241 16.6784 21.4396C17.4523 20.8365 18.683 20.8564 19.4265 21.4842C20.1427 22.0889 21.1197 21.9684 22 21.9684`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M8 19C9.19765 16.6088 11.4362 15 14 15C16.5638 15 18.8023 16.6088 20 19`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M11 15.1016C8 14.5448 5.39726 16.3366 4 19`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}],[`path`,{d:`M12 15C12 12 12.8 7.16 16 5`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`3`}],[`path`,{d:`M15.5004 2C16.3755 2 17.3024 3.0972 16 5M16 5C16.7861 5.23357 19.208 6.31952 18.9828 9M16 5C15.4148 4.29569 13.3126 3.40012 12 4.80011M16 5C16.58 5.70922 17 8 16 9`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`4`}]],si=[[`path`,{d:`M11.9831 14.0001V3.00006M11.9831 14.0001C10.3247 14.0001 8.98038 15.4355 8.98038 16.6251C8.98038 18.3751 10.3247 21.0001 11.9831 21.0001C13.6414 21.0001 14.9857 18.3751 14.9857 16.6251C14.9857 15.4355 13.6414 14.0001 11.9831 14.0001Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M4.97841 10.0283L4.97841 21M3.68615 3.12945L2.90347 3.20753C2.33225 3.26452 1.92596 3.78885 2.01382 4.35564L2.6828 8.67118C2.79612 9.40225 3.426 10.0106 4.16644 10.0106H5.7904C6.53083 10.0106 7.16071 9.40225 7.27404 8.67118L7.94301 4.35564C8.03087 3.78885 7.62458 3.26452 7.05336 3.20753L6.27337 3.12962C5.41311 3.04368 4.54642 3.04363 3.68615 3.12945Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M17.996 13.8182L17.996 3.02594C19.1545 3.34592 21.0815 4.55268 21.4006 7.52842L21.9737 12.0424C22.0743 12.8351 21.8727 13.6261 21.0846 13.7616C20.4244 13.8751 19.4229 13.9122 17.996 13.8182ZM17.996 13.8182L17.996 21.0001`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}]],ci=[[`path`,{d:`M13.6468 17.7161C14.0276 17.6191 14.3277 17.2686 14.9279 16.5674L20.1144 10.5083C22.0236 8.27791 22.7538 5.16032 21.0179 2.53909C20.4426 1.67029 19.4814 1.97862 18.8802 2.57285L2.57422 18.6916C1.80859 19.4484 1.80859 20.6755 2.57422 21.4323C3.44222 22.2903 4.88535 22.1577 5.57852 21.1563C6.52528 19.7884 8.00705 16.2711 9.65825 15.6456C11.371 14.9968 11.9676 18.1437 13.6468 17.7161Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}]],li=[[`path`,{d:`M12 7C8.68629 7 6 9.68629 6 13L18 13C18 9.68629 15.3137 7 12 7Z`,stroke:`currentColor`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M9 13C9 14.6569 10.3431 16 12 16C13.6569 16 15 14.6569 15 13`,stroke:`currentColor`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M5 13H19`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}],[`path`,{d:`M12 7V2`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`3`}],[`path`,{d:`M12.0002 20V22M15 19L17 20.4999M9 19L7 20.5`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`4`}]],ui=[[`path`,{d:`M19.9244 12.102C20.3882 11.4385 18.588 9.20647 18.0742 8.81246C17.6051 8.45281 17 8.27446 15.7896 7.91776C14.5811 7.56161 13.2866 7 12 7C10.7134 7 9.41894 7.56161 8.21043 7.91776C7.00005 8.27446 6.39486 8.45281 5.92582 8.81246C5.41197 9.20647 3.61181 11.4385 4.07564 12.102C4.96428 13.3732 19.1407 13.2231 19.9244 12.102Z`,stroke:`currentColor`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M8.99989 13C8.99989 14.6569 10.343 16 11.9999 16C13.6567 16 14.9999 14.6569 14.9999 13`,stroke:`currentColor`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M12.0001 20V22M14.9999 19L16.9999 20.4999M8.99991 19L6.99991 20.5`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}],[`path`,{d:`M11.9999 7V2`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`3`}]],di=[[`path`,{d:`M14.5936 10H9.40637C7.51043 10 6.56247 10 6.16052 9.45157C5.75858 8.90313 6.14759 8.14046 6.92562 6.61512L8.31723 3.88683C8.78446 2.97081 9.01808 2.5128 9.46755 2.2564C9.91703 2 10.4863 2 11.6249 2H12.3751C13.5137 2 14.083 2 14.5324 2.2564C14.9819 2.5128 15.2155 2.97081 15.6828 3.88683L17.0744 6.61512C17.8524 8.14046 18.2414 8.90313 17.8395 9.45157C17.4375 10 16.4896 10 14.5936 10Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M12 10V19`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M8 22H16`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}],[`path`,{d:`M9 22L9.36754 20.8974C9.64721 20.0584 9.78704 19.6389 10.094 19.3706C10.1647 19.3088 10.2409 19.2539 10.3218 19.2064C10.6734 19 11.1156 19 12 19C12.8844 19 13.3266 19 13.6782 19.2064C13.7591 19.2539 13.8353 19.3088 13.906 19.3706C14.213 19.6389 14.3528 20.0584 14.6325 20.8974L15 22`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`3`}],[`path`,{d:`M15.5 10V13`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`4`}]],fi=[[`path`,{d:`M12 2C13.6348 2 14.4522 2 15.1648 2.28954C15.5483 2.44535 15.9052 2.66072 16.2227 2.92783C16.8128 3.42423 17.1996 4.15077 17.9732 5.60384L18.7735 7.10708C20.174 9.73759 20.8743 11.0528 20.2973 12.0264C19.7203 13 18.2406 13 15.2811 13H8.71885C5.75941 13 4.27968 13 3.7027 12.0264C3.12572 11.0528 3.82597 9.73758 5.22647 7.10708L6.02681 5.60384C6.80043 4.15076 7.18725 3.42423 7.77728 2.92783C8.09479 2.66072 8.45174 2.44535 8.83521 2.28954C9.54784 2 10.3652 2 12 2Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M12 13V19`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M9.45585 20.2991C9.72509 19.8443 9.85972 19.6168 10.0568 19.4477C10.2568 19.276 10.5028 19.1476 10.7739 19.0733C11.0411 19 11.3421 19 11.944 19H12.0562C12.6582 19 12.9592 19 13.2263 19.0733C13.4976 19.1476 13.7436 19.2761 13.9437 19.4479C14.1407 19.617 14.2753 19.8445 14.5444 20.2994C14.8656 20.8422 15.0262 21.1136 14.9965 21.3346C14.9666 21.5571 14.8206 21.7567 14.5984 21.8787C14.3777 22 14.0186 22 13.3003 22H10.6999C9.98144 22 9.6222 22 9.40146 21.8787C9.17933 21.7566 9.03337 21.557 9.00349 21.3346C8.97379 21.1135 9.13448 20.8421 9.45585 20.2991Z`,stroke:`currentColor`,strokeWidth:`1.5`,key:`2`}]],pi=[[`path`,{d:`M8.65938 21H19.3406C20.257 21 21 20.2571 21 19.3406C21 19.1159 20.9543 18.8935 20.8658 18.6869L19.039 14.4243C18.5351 13.2485 18.2831 12.6606 17.7822 12.3303C17.2812 12 16.6416 12 15.3624 12H12.6376C11.3583 12 10.7187 12 10.2178 12.3303C9.71686 12.6606 9.4649 13.2485 8.96099 14.4243L7.13416 18.6869C7.04563 18.8935 6.99998 19.1159 6.99998 19.3406C6.99998 20.2571 7.74292 21 8.65938 21Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M8.99998 16H19`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M2.99995 7.66667V4.33333C2.99995 4.02334 2.99995 3.86835 3.03403 3.74118C3.1265 3.39609 3.39604 3.12654 3.74114 3.03407C3.8683 3 4.0233 3 4.33329 3C4.95327 3 5.26326 3 5.51759 3.06815C6.20778 3.25308 6.74687 3.79218 6.93181 4.48236C6.99995 4.73669 6.99995 5.04669 6.99995 5.66667V6.33333C6.99995 6.95331 6.99995 7.26331 6.93181 7.51764C6.74687 8.20782 6.20778 8.74692 5.51759 8.93185C5.26326 9 4.95327 9 4.33329 9C4.0233 9 3.8683 9 3.74114 8.96593C3.39604 8.87346 3.1265 8.60391 3.03403 8.25882C2.99995 8.13165 2.99995 7.97666 2.99995 7.66667Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}],[`path`,{d:`M6.99998 6H7.99998C10.8284 6 12.2426 6 13.1213 6.87868C14 7.75736 14 9.17157 14 12`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`3`}]],mi=[[`path`,{d:`M9 7H19`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M8.65943 12H19.3406C20.2571 12 21 11.2571 21 10.3406C21 10.1159 20.9544 9.89349 20.8659 9.68694L19.039 5.42433C18.5351 4.24853 18.2832 3.66064 17.7822 3.33032C17.2813 3 16.6417 3 15.3624 3H12.6376C11.3584 3 10.7188 3 10.2178 3.33032C9.7169 3.66064 9.46495 4.24853 8.96104 5.42432L7.1342 9.68694C7.04568 9.89349 7.00003 10.1159 7.00003 10.3406C7.00003 11.2571 7.74297 12 8.65943 12Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M3.00003 19.6667V16.3333C3.00003 16.0233 3.00003 15.8683 3.0341 15.7412C3.12657 15.3961 3.39612 15.1265 3.74121 15.0341C3.86838 15 4.02337 15 4.33336 15C4.95334 15 5.26334 15 5.51767 15.0681C6.20785 15.2531 6.74695 15.7922 6.93188 16.4824C7.00003 16.7367 7.00003 17.0467 7.00003 17.6667V18.3333C7.00003 18.9533 7.00003 19.2633 6.93188 19.5176C6.74695 20.2078 6.20785 20.7469 5.51767 20.9319C5.26334 21 4.95334 21 4.33336 21C4.02337 21 3.86838 21 3.74121 20.9659C3.39612 20.8735 3.12657 20.6039 3.0341 20.2588C3.00003 20.1317 3.00003 19.9767 3.00003 19.6667Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}],[`path`,{d:`M7.00003 18H8.00003C10.8285 18 12.2427 18 13.1214 17.1213C14 16.2426 14 14.8284 14 12`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`3`}]],hi=[[`path`,{d:`M9 6L17 6`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M9 12L19 12`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M9 18L17 18`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.5`,key:`2`}],[`path`,{d:`M5 3L5 21`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`3`}]],gi=[[`path`,{d:`M8 5.5L20 5.5`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M8 12.5L20 12.5`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M8 19.5L20 19.5`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.5`,key:`2`}],[`path`,{d:`M4.375 5.5H4.25M4.5 5.5C4.5 5.63807 4.38807 5.75 4.25 5.75C4.11193 5.75 4 5.63807 4 5.5C4 5.36193 4.11193 5.25 4.25 5.25C4.38807 5.25 4.5 5.36193 4.5 5.5Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`3`}],[`path`,{d:`M4.375 12.5H4.25M4.5 12.5C4.5 12.6381 4.38807 12.75 4.25 12.75C4.11193 12.75 4 12.6381 4 12.5C4 12.3619 4.11193 12.25 4.25 12.25C4.38807 12.25 4.5 12.3619 4.5 12.5Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`4`}],[`path`,{d:`M4.375 19.5H4.25M4.5 19.5C4.5 19.6381 4.38807 19.75 4.25 19.75C4.11193 19.75 4 19.6381 4 19.5C4 19.3619 4.11193 19.25 4.25 19.25C4.38807 19.25 4.5 19.3619 4.5 19.5Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`5`}]],_i=[[`path`,{d:`M5.14286 14C4.41735 12.8082 4 11.4118 4 9.91886C4 8.24668 4.52361 6.69556 5.41738 5.41738M8.03786 3.03786C9.20596 2.37741 10.5585 2 12 2C16.4183 2 20 5.5454 20 9.91886C20 11.3746 19.6032 12.7386 18.9107 13.9107`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M16 16H7L7.54415 17.6325C7.81638 18.4491 8.58066 19 9.44152 19L14.5585 19C15.4193 19 16.1836 18.4491 16.4558 17.6325L16.75 16.75`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M15 19L14.4558 20.6325C14.1836 21.4491 13.4193 22 12.5585 22H11.4415C10.5807 22 9.81638 21.4491 9.54415 20.6325L9 19`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}],[`path`,{d:`M12 15.5V12`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`3`}],[`path`,{d:`M2 2L22 22`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`4`}]],vi=[[`path`,{d:`M10.0195 8C9.32545 7.06743 8.14285 5.76203 8.60385 4.47631C8.91057 3.62086 11.0067 2 12 2C12.9933 2 15.0894 3.62086 15.3962 4.47631C15.8572 5.76203 14.6745 7.06743 13.9805 8`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M8 8H16`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M8 13H16`,stroke:`currentColor`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}],[`path`,{d:`M7.5 18H16.5`,stroke:`currentColor`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`3`}],[`path`,{d:`M9.5 8L7 22M14.5 8L17 22`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`4`}],[`path`,{d:`M5 22H19`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`5`}],[`path`,{d:`M19 7.5L21 7M19 10.5L21 11`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`6`}],[`path`,{d:`M5 7.5L3 7M5 10.5L3 11`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`7`}]],yi=[[`path`,{d:`M9.14339 10.691L9.35031 10.4841C11.329 8.50532 14.5372 8.50532 16.5159 10.4841C18.4947 12.4628 18.4947 15.671 16.5159 17.6497L13.6497 20.5159C11.671 22.4947 8.46279 22.4947 6.48405 20.5159C4.50532 18.5372 4.50532 15.329 6.48405 13.3503L6.9484 12.886`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M17.0516 11.114L17.5159 10.6497C19.4947 8.67095 19.4947 5.46279 17.5159 3.48405C15.5372 1.50532 12.329 1.50532 10.3503 3.48405L7.48405 6.35031C5.50532 8.32904 5.50532 11.5372 7.48405 13.5159C9.46279 15.4947 12.671 15.4947 14.6497 13.5159L14.8566 13.309`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.5`,key:`1`}]],bi=[[`path`,{d:`M22 12C22 17.5228 17.5228 22 12 22C6.47715 22 2 17.5228 2 12C2 6.47715 6.47715 2 12 2C17.5228 2 22 6.47715 22 12Z`,stroke:`currentColor`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M12 13C13.1046 13 14 12.1046 14 11C14 9.89543 13.1046 9 12 9C10.8954 9 10 9.89543 10 11C10 12.1046 10.8954 13 12 13ZM12 13L12 16`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.5`,key:`1`}]],xi=[[`path`,{d:`M15 17.499C15 18.429 15 18.894 14.8978 19.2755C14.6204 20.3108 13.8117 21.1194 12.7765 21.3968C12.395 21.499 11.93 21.499 11 21.499H9C6.17157 21.499 4.75736 21.499 3.87868 20.6204C3 19.7417 3 18.3275 3 15.499V8.50113C3 5.67292 3 4.25882 3.87859 3.38015C4.75718 2.50149 6.17129 2.50137 8.9995 2.50113L11.0016 2.50097C11.9298 2.50089 12.394 2.50085 12.7748 2.60266C13.8113 2.87976 14.621 3.68933 14.8982 4.72584C15 5.10667 15 5.5708 15 6.49904`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M15 19.501C17.8284 19.501 19.2426 19.501 20.1213 18.6223C21 17.7436 21 16.3294 21 13.501V10.501C21 7.67253 21 6.25832 20.1213 5.37964C19.2426 4.50096 17.8284 4.50096 15 4.50096`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M16 12.001H9M14.5001 9.50096C14.5001 9.50096 17 11.3422 17 12.001C17 12.6598 14.5 14.501 14.5 14.501`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}]],Si=[[`path`,{d:`M2 6L8.91302 9.91697C11.4616 11.361 12.5384 11.361 15.087 9.91697L22 6`,stroke:`currentColor`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M2.01577 13.4756C2.08114 16.5412 2.11383 18.0739 3.24496 19.2094C4.37608 20.3448 5.95033 20.3843 9.09883 20.4634C11.0393 20.5122 12.9607 20.5122 14.9012 20.4634C18.0497 20.3843 19.6239 20.3448 20.7551 19.2094C21.8862 18.0739 21.9189 16.5412 21.9842 13.4756C22.0053 12.4899 22.0053 11.5101 21.9842 10.5244C21.9189 7.45886 21.8862 5.92609 20.7551 4.79066C19.6239 3.65523 18.0497 3.61568 14.9012 3.53657C12.9607 3.48781 11.0393 3.48781 9.09882 3.53656C5.95033 3.61566 4.37608 3.65521 3.24495 4.79065C2.11382 5.92608 2.08114 7.45885 2.01576 10.5244C1.99474 11.5101 1.99475 12.4899 2.01577 13.4756Z`,stroke:`currentColor`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}]],Ci=[[`path`,{d:`M6.5 9H8.5`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M17.5 8V4C17.5 2.89543 18.3954 2 19.5 2`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M12.5 18L12.5 22`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.5`,key:`2`}],[`path`,{d:`M17.5 5.15889C16.5351 5 15.2591 5 13.375 5H10.625C7.70671 5 6.24757 5 5.14302 5.59039C4.27088 6.05656 3.55656 6.77088 3.09039 7.64302C2.5 8.74757 2.5 10.2067 2.5 13.125C2.5 14.876 2.5 15.7515 2.85424 16.4142C3.13394 16.9375 3.56253 17.3661 4.08581 17.6458C4.74854 18 5.62403 18 7.375 18H16.625C18.376 18 19.2515 18 19.9142 17.6458C20.4375 17.3661 20.8661 16.9375 21.1458 16.4142C21.5 15.7515 21.5 14.876 21.5 13.125C21.5 10.2067 21.5 8.74757 20.9096 7.64302C20.7356 7.31755 20.5271 7.01406 20.2887 6.73725`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.5`,key:`3`}],[`path`,{d:`M12.5006 18V11C12.5006 10.071 12.5006 9.60649 12.439 9.21782C12.1002 7.07836 10.4222 5.40041 8.28276 5.06155C8.2009 5.04859 8.11566 5.03835 8.02344 5.03027`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.5`,key:`4`}]],wi=[[`path`,{d:`M17 7V11C17 13.7614 14.7614 16 12 16C9.23858 16 7 13.7614 7 11V7C7 4.23858 9.23858 2 12 2C14.7614 2 17 4.23858 17 7Z`,stroke:`currentColor`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M17 7H14M17 11H14`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M20 11C20 15.4183 16.4183 19 12 19M12 19C7.58172 19 4 15.4183 4 11M12 19V22M12 22H15M12 22H9`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.5`,key:`2`}]],Ti=[[`path`,{d:`M17 7V11C17 13.7614 14.7614 16 12 16C9.23858 16 7 13.7614 7 11V7C7 4.23858 9.23858 2 12 2C14.7614 2 17 4.23858 17 7Z`,stroke:`currentColor`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M20 11C20 15.4183 16.4183 19 12 19M12 19C7.58172 19 4 15.4183 4 11M12 19V22M12 22H15M12 22H9`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.5`,key:`1`}]],Ei=[[`path`,{d:`M2 2L22 22`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M4 11C4 15.4183 7.58172 19 12 19M12 19C13.9545 19 15.7454 18.2991 17.1348 17.1348M12 19V22M12 22H15M12 22H9M20 11C20 12.6514 19.4996 14.1859 18.6422 15.4603`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M17.0078 6.99599C17.0078 4.23457 14.7692 2.01599 12.0078 2.01599C10.139 2.01599 8.5379 2.98126 7.67981 4.49999M17.0078 6.99599L13.9798 7.00799M17.0078 6.99599V11.004M7.00781 6.99599V11.016C7.00781 13.7774 9.24639 16.016 12.0078 16.016C13.1432 16.016 14.1725 15.6256 15.0118 14.988M16.4465 13.26C16.8051 12.5705 17.0078 11.8469 17.0078 11.016V11.004M14.1829 11.004H17.0078`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.5`,key:`2`}]],Di=[[`path`,{d:`M6 8.5H4.75C3.57721 8.5 2.99082 8.5 2.58686 8.19003C2.48286 8.11023 2.38977 8.01714 2.30997 7.91314C2 7.50918 2 6.92279 2 5.75C2 4.57721 2 3.99082 2.30997 3.58686C2.38977 3.48286 2.48286 3.38977 2.58686 3.30997C2.99082 3 3.57721 3 4.75 3H17C18.4142 3 19.1213 3 19.5607 3.43934C20 3.87868 20 4.58579 20 6V8.37217C20 9.42821 20 9.95623 19.746 10.3352C19.6371 10.4976 19.4976 10.6371 19.3352 10.746C18.9562 11 18.4282 11 17.3722 11H16.7951C16.3714 11 16.1596 11 15.9688 10.9625C15.4366 10.8581 14.9696 10.5419 14.675 10.0865C14.5693 9.92331 14.4907 9.72663 14.3333 9.33333C14.2547 9.13667 14.2153 9.03835 14.1625 8.95673C14.0152 8.72904 13.7817 8.57096 13.5156 8.51873C13.4202 8.5 13.3143 8.5 13.1025 8.5H12C11.0572 8.5 10.5858 8.5 10.2929 8.79289C10 9.08579 10 9.55719 10 10.5V17C10 19.2091 11.7909 21 14 21`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M4 8.5V21`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M2 21H22`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}],[`path`,{d:`M19.9813 15H15.0187C13.7463 15 14.0261 16.6634 14.0261 17.5C14.0261 19.433 15.5814 21 17.5 21C19.4186 21 20.9739 19.433 20.9739 17.5C20.9739 16.6634 21.2537 15 19.9813 15Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`3`}],[`path`,{d:`M17.5 11V15`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`4`}],[`path`,{d:`M17.125 6H17M17.25 6C17.25 6.13807 17.1381 6.25 17 6.25C16.8619 6.25 16.75 6.13807 16.75 6C16.75 5.86193 16.8619 5.75 17 5.75C17.1381 5.75 17.25 5.86193 17.25 6Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`5`}]],Oi=[[`path`,{d:`M16 3H8C5.17157 3 3.75736 3 2.87868 3.87868C2 4.75736 2 6.17157 2 9V11C2 13.8284 2 15.2426 2.87868 16.1213C3.75736 17 5.17157 17 8 17H16C18.8284 17 20.2426 17 21.1213 16.1213C22 15.2426 22 13.8284 22 11V9C22 6.17157 22 4.75736 21.1213 3.87868C20.2426 3 18.8284 3 16 3Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M16 21C14.8233 20.364 13.4571 20 12 20C10.5429 20 9.17669 20.364 8 21`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}]],ki=[[`path`,{d:`M21.0985 7.84477C20.458 8.55417 19.5311 9 18.5 9C16.567 9 15 7.433 15 5.5C15 4.46895 15.4458 3.54203 16.1552 2.90149M16.1552 2.90149C18.3384 3.90018 20.0998 5.66155 21.0985 7.84477C21.6774 9.11025 22 10.5174 22 12C22 17.5228 17.5228 22 12 22C6.47715 22 2 17.5228 2 12C2 6.47715 6.47715 2 12 2C13.4826 2 14.8898 2.32262 16.1552 2.90149Z`,stroke:`currentColor`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M16 16C16 17.1046 15.1046 18 14 18C12.8954 18 12 17.1046 12 16C12 14.8954 12.8954 14 14 14C15.1046 14 16 14.8954 16 16Z`,stroke:`currentColor`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M7.13086 14H7.00586M7.25586 14C7.25586 14.1381 7.14393 14.25 7.00586 14.25C6.86779 14.25 6.75586 14.1381 6.75586 14C6.75586 13.8619 6.86779 13.75 7.00586 13.75C7.14393 13.75 7.25586 13.8619 7.25586 14Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}],[`path`,{d:`M10.1309 8H10.0059M10.2559 8C10.2559 8.13807 10.1439 8.25 10.0059 8.25C9.86779 8.25 9.75586 8.13807 9.75586 8C9.75586 7.86193 9.86779 7.75 10.0059 7.75C10.1439 7.75 10.2559 7.86193 10.2559 8Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`3`}]],Ai=[[`path`,{d:`M21.5 14.0784C20.3003 14.7189 18.9301 15.0821 17.4751 15.0821C12.7491 15.0821 8.91792 11.2509 8.91792 6.52485C8.91792 5.06986 9.28105 3.69968 9.92163 2.5C5.66765 3.49698 2.5 7.31513 2.5 11.8731C2.5 17.1899 6.8101 21.5 12.1269 21.5C16.6849 21.5 20.503 18.3324 21.5 14.0784Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}]],ji=[[`path`,{d:`M11.9967 12.5V12M11.9967 6.5V6M11.9967 18.5V18M12.9967 12.5C12.9967 11.9477 12.549 11.5 11.9967 11.5C11.4444 11.5 10.9967 11.9477 10.9967 12.5C10.9967 13.0523 11.4444 13.5 11.9967 13.5C12.549 13.5 12.9967 13.0523 12.9967 12.5ZM12.9967 6.5C12.9967 5.94772 12.549 5.5 11.9967 5.5C11.4444 5.5 10.9967 5.94772 10.9967 6.5C10.9967 7.05228 11.4444 7.5 11.9967 7.5C12.549 7.5 12.9967 7.05228 12.9967 6.5ZM12.9967 18.5C12.9967 17.9477 12.549 17.5 11.9967 17.5C11.4444 17.5 10.9967 17.9477 10.9967 18.5C10.9967 19.0523 11.4444 19.5 11.9967 19.5C12.549 19.5 12.9967 19.0523 12.9967 18.5Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}]],Mi=[[`circle`,{cx:`19.5`,cy:`16.5`,r:`2.5`,stroke:`currentColor`,strokeWidth:`1.5`,key:`0`}],[`circle`,{cx:`4.5`,cy:`16.5`,r:`2.5`,stroke:`currentColor`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M20.2348 7.86957C21.5163 9.42897 21.9615 10.9117 21.9994 11.6957C21.3294 11.3893 20.5771 11.2174 19.7821 11.2174C17.3369 11.2174 15.1419 12.8433 14.6177 15.0092C14.4924 15.527 14.4298 15.7859 14.2937 15.8929C14.1577 16 13.9382 16 13.4994 16H10.6206C10.1784 16 9.95733 16 9.82074 15.8915C9.68414 15.7829 9.62431 15.5249 9.50465 15.0088C9.00893 12.8708 6.99671 11.0124 4.90197 11.1698C4.69089 11.1857 4.58535 11.1936 4.51294 11.1775C4.44054 11.1613 4.36764 11.1202 4.22185 11.0378C3.80097 10.8001 3.37061 10.5744 2.95793 10.3227C2.38299 9.97198 2.02315 9.35549 2.00053 8.68241C1.98766 8.29933 2.20797 7.91865 2.65301 8.02338L9.07369 9.53435C9.55601 9.64785 9.79717 9.70461 10.0044 9.66597C10.2116 9.62734 10.4656 9.4536 10.9737 9.10614C12.262 8.22518 14.3037 7.39305 16.339 8.12822C16.8961 8.32947 17.1747 8.4301 17.3334 8.43513C17.4921 8.44016 17.7247 8.37247 18.1899 8.23707C18.9431 8.01785 19.6521 7.90409 20.2348 7.86957ZM20.2348 7.86957C19.4316 6.89211 18.2997 5.88452 16.7336 5`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}]],Ni=[[`path`,{d:`M11.922 4.79004C16.6963 3.16245 19.0834 2.34866 20.3674 3.63261C21.6513 4.91656 20.8375 7.30371 19.21 12.078L18.1016 15.3292C16.8517 18.9958 16.2267 20.8291 15.1964 20.9808C14.9195 21.0216 14.6328 20.9971 14.3587 20.9091C13.3395 20.5819 12.8007 18.6489 11.7231 14.783C11.4841 13.9255 11.3646 13.4967 11.0924 13.1692C11.0134 13.0742 10.9258 12.9866 10.8308 12.9076C10.5033 12.6354 10.0745 12.5159 9.21705 12.2769C5.35111 11.1993 3.41814 10.6605 3.0909 9.64127C3.00292 9.36724 2.97837 9.08053 3.01916 8.80355C3.17088 7.77332 5.00419 7.14834 8.6708 5.89838L11.922 4.79004Z`,stroke:`currentColor`,strokeWidth:`1.5`,key:`0`}]],Pi=[[`path`,{d:`M15.9351 12.6258C15.6807 13.8374 14.327 14.7077 11.6198 16.4481C8.67528 18.3411 7.20303 19.2876 6.01052 18.9229C5.60662 18.7994 5.23463 18.5823 4.92227 18.2876C4 17.4178 4 15.6118 4 12C4 8.38816 4 6.58224 4.92227 5.71235C5.23463 5.41773 5.60662 5.20057 6.01052 5.07707C7.20304 4.71243 8.67528 5.6589 11.6198 7.55186C14.327 9.29233 15.6807 10.1626 15.9351 11.3742C16.0216 11.7865 16.0216 12.2135 15.9351 12.6258Z`,stroke:`currentColor`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M20 5V19`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.5`,key:`1`}]],Fi=[[`path`,{d:`M15.5 18C15.5 19.933 13.933 21.5 12 21.5C10.067 21.5 8.5 19.933 8.5 18`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M19.2311 18H4.76887C3.79195 18 3 17.208 3 16.2311C3 15.762 3.18636 15.3121 3.51809 14.9803L4.12132 14.3771C4.68393 13.8145 5 13.0514 5 12.2558V9.5C5 5.63401 8.13401 2.5 12 2.5C15.866 2.5 19 5.634 19 9.5V12.2558C19 13.0514 19.3161 13.8145 19.8787 14.3771L20.4819 14.9803C20.8136 15.3121 21 15.762 21 16.2311C21 17.208 20.208 18 19.2311 18Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}]],Ii=[[`path`,{d:`M16 22C14.934 20.7553 13.5337 20 12 20C10.4663 20 9.06603 20.7553 8 22`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M12 13C10.7319 13 9.39109 13.2193 8.34002 13.5128C7.54859 13.7338 6.91195 14.7415 7.00999 15.5596C7.04632 15.8627 7.30731 16 7.58173 16H16.4183C16.6927 16 16.9537 15.8627 16.99 15.5596C17.0881 14.7415 16.4514 13.7338 15.66 13.5128C14.6089 13.2193 13.2681 13 12 13Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M21 10C19.8954 10 19 10.8954 19 12V13C19 14.1046 18.1046 15 17 15`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}],[`path`,{d:`M3 10C4.10457 10 5 10.8954 5 12V13C5 14.1046 5.89543 15 7 15`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`3`}],[`path`,{d:`M12 16V22`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`4`}],[`path`,{d:`M12.8197 10H11.1803C9.77811 10 9.07704 10 8.56988 9.57641C8.06272 9.15282 7.89268 8.42526 7.55261 6.97014C7.01792 4.68228 6.75058 3.53835 7.31199 2.76918C7.87341 2 8.97569 2 11.1803 2H12.8197C15.0243 2 16.1266 2 16.688 2.76918C17.2494 3.53835 16.9821 4.68228 16.4474 6.97014C16.1073 8.42526 15.9373 9.15282 15.4301 9.57641C14.923 10 14.2219 10 12.8197 10Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`5`}],[`path`,{d:`M12 10V13`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`6`}]],Li=[[`path`,{d:`M14 22V8C14 5.17157 14 3.75736 13.1213 2.87868C12.2426 2 10.8284 2 8 2C5.17157 2 3.75736 2 2.87868 2.87868C2 3.75736 2 5.17157 2 8V16C2 18.8284 2 20.2426 2.87868 21.1213C3.75736 22 5.17157 22 8 22H14Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M6.5 11H5.5M10.5 11H9.5M6.5 7H5.5M6.5 15H5.5M10.5 7H9.5M10.5 15H9.5`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M18.5 15H17.5M18.5 11H17.5`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.5`,key:`2`}],[`path`,{d:`M18 8H14V22H18C19.8856 22 20.8284 22 21.4142 21.4142C22 20.8284 22 19.8856 22 18V12C22 10.1144 22 9.17157 21.4142 8.58579C20.8284 8 19.8856 8 18 8Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.5`,key:`3`}]],Ri=[[`path`,{d:`M21 11C21 7.22876 21 5.34315 19.8284 4.17157C18.6569 3 16.7712 3 13 3H11C7.22876 3 5.34315 3 4.17157 4.17157C3 5.34315 3 7.22876 3 11V13C3 16.7712 3 18.6569 4.17157 19.8284C5.34315 21 7.22876 21 11 21H13C16.7712 21 18.6569 21 19.8284 19.8284C21 18.6569 21 16.7712 21 13V11Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M9 3V21`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M14 9L15.1082 9.87868C16.3694 10.8787 17 11.3787 17 12C17 12.6213 16.3694 13.1213 15.1082 14.1213L14 15`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}]],zi=[[`path`,{d:`M21 11C21 7.22876 21 5.34315 19.8284 4.17157C18.6569 3 16.7712 3 13 3H11C7.22876 3 5.34315 3 4.17157 4.17157C3 5.34315 3 7.22876 3 11V13C3 16.7712 3 18.6569 4.17157 19.8284C5.34315 21 7.22876 21 11 21H13C16.7712 21 18.6569 21 19.8284 19.8284C21 18.6569 21 16.7712 21 13V11Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M9 3V21`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M16 9L14.8918 9.87868C13.6306 10.8787 13 11.3787 13 12C13 12.6213 13.6306 13.1213 14.8918 14.1213L16 15`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}]],Bi=[[`path`,{d:`M15 3V21M15 3H10M15 3H21M10 12H7.5C5.01472 12 3 9.98528 3 7.5C3 5.01472 5.01472 3 7.5 3H10M10 12V3M10 12V21`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}]],Vi=[[`path`,{d:`M4 7C4 5.58579 4 4.87868 4.43934 4.43934C4.87868 4 5.58579 4 7 4C8.41421 4 9.12132 4 9.56066 4.43934C10 4.87868 10 5.58579 10 7V17C10 18.4142 10 19.1213 9.56066 19.5607C9.12132 20 8.41421 20 7 20C5.58579 20 4.87868 20 4.43934 19.5607C4 19.1213 4 18.4142 4 17V7Z`,stroke:`currentColor`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M14 7C14 5.58579 14 4.87868 14.4393 4.43934C14.8787 4 15.5858 4 17 4C18.4142 4 19.1213 4 19.5607 4.43934C20 4.87868 20 5.58579 20 7V17C20 18.4142 20 19.1213 19.5607 19.5607C19.1213 20 18.4142 20 17 20C15.5858 20 14.8787 20 14.4393 19.5607C14 19.1213 14 18.4142 14 17V7Z`,stroke:`currentColor`,strokeWidth:`1.5`,key:`1`}]],Hi=[[`path`,{d:`M3 21L8 16`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M13.2585 18.8714C9.51516 18.0215 5.97844 14.4848 5.12853 10.7415C4.99399 10.1489 4.92672 9.85266 5.12161 9.37197C5.3165 8.89129 5.55457 8.74255 6.03071 8.44509C7.10705 7.77265 8.27254 7.55888 9.48209 7.66586C11.1793 7.81598 12.0279 7.89104 12.4512 7.67048C12.8746 7.44991 13.1622 6.93417 13.7376 5.90269L14.4664 4.59604C14.9465 3.73528 15.1866 3.3049 15.7513 3.10202C16.316 2.89913 16.6558 3.02199 17.3355 3.26771C18.9249 3.84236 20.1576 5.07505 20.7323 6.66449C20.978 7.34417 21.1009 7.68401 20.898 8.2487C20.6951 8.8134 20.2647 9.05346 19.4039 9.53358L18.0672 10.2792C17.0376 10.8534 16.5229 11.1406 16.3024 11.568C16.0819 11.9955 16.162 12.8256 16.3221 14.4859C16.4399 15.7068 16.2369 16.88 15.5555 17.9697C15.2577 18.4458 15.1088 18.6839 14.6283 18.8786C14.1477 19.0733 13.8513 19.006 13.2585 18.8714Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}]],Ui=[[`path`,{d:`M18.4301 13C18.7891 13.5166 19 14.1471 19 14.8276C19 16.5796 17.6018 18 15.8771 18C15.5726 18 15.2783 17.9557 15 17.8732M18.9805 10C20.7855 11.0188 22 12.924 22 15.1063C22 18.3613 19.298 21 15.9648 21C14.4472 21 13.0605 20.453 12 19.5499`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.5`,key:`0`}],[`circle`,{cx:`9`,cy:`10`,r:`4`,stroke:`currentColor`,strokeWidth:`1.5`,key:`1`}],[`circle`,{cx:`9`,cy:`10`,r:`7`,stroke:`currentColor`,strokeWidth:`1.5`,key:`2`}]],Wi=[[`path`,{d:`M14.9531 12.3948C14.8016 13.0215 14.0857 13.4644 12.6539 14.3502C11.2697 15.2064 10.5777 15.6346 10.0199 15.4625C9.78934 15.3913 9.57925 15.2562 9.40982 15.07C9 14.6198 9 13.7465 9 12C9 10.2535 9 9.38018 9.40982 8.92995C9.57925 8.74381 9.78934 8.60868 10.0199 8.53753C10.5777 8.36544 11.2697 8.79357 12.6539 9.64983C14.0857 10.5356 14.8016 10.9785 14.9531 11.6052C15.0156 11.8639 15.0156 12.1361 14.9531 12.3948Z`,stroke:`currentColor`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M2.5 12C2.5 7.52166 2.5 5.28249 3.89124 3.89124C5.28249 2.5 7.52166 2.5 12 2.5C16.4783 2.5 18.7175 2.5 20.1088 3.89124C21.5 5.28249 21.5 7.52166 21.5 12C21.5 16.4783 21.5 18.7175 20.1088 20.1088C18.7175 21.5 16.4783 21.5 12 21.5C7.52166 21.5 5.28249 21.5 3.89124 20.1088C2.5 18.7175 2.5 16.4783 2.5 12Z`,stroke:`currentColor`,strokeWidth:`1.5`,key:`1`}]],Gi=[[`path`,{d:`M18.8906 12.846C18.5371 14.189 16.8667 15.138 13.5257 17.0361C10.296 18.8709 8.6812 19.7884 7.37983 19.4196C6.8418 19.2671 6.35159 18.9776 5.95624 18.5787C5 17.6139 5 15.7426 5 12C5 8.2574 5 6.3861 5.95624 5.42132C6.35159 5.02245 6.8418 4.73288 7.37983 4.58042C8.6812 4.21165 10.296 5.12907 13.5257 6.96393C16.8667 8.86197 18.5371 9.811 18.8906 11.154C19.0365 11.7084 19.0365 12.2916 18.8906 12.846Z`,stroke:`currentColor`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}]],Ki=[[`path`,{d:`M15.5 2V6M8.5 6V2`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M6.00446 7.61331C5.93719 6.74273 6.63957 6 7.53014 6H16.4699C17.3604 6 18.0628 6.74273 17.9955 7.61331L17.8117 9.99197C17.6796 11.7019 17.1011 13.3498 16.132 14.7773L15.5312 15.6622C14.9638 16.4979 14.0077 17 12.9838 17H11.0162C9.99228 17 9.03617 16.4979 8.46881 15.6622L7.86803 14.7773C6.89885 13.3498 6.32041 11.7019 6.18827 9.99197L6.00446 7.61331Z`,stroke:`currentColor`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M12 17V22`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}],[`path`,{d:`M11 9H13`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`3`}]],qi=[[`path`,{d:`M12 4V20M20 12H4`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}]],Ji=[[`path`,{d:`M8.06492 12.6258C8.31931 13.8374 9.67295 14.7077 12.3802 16.4481C15.3247 18.3411 16.797 19.2876 17.9895 18.9229C18.3934 18.7994 18.7654 18.5823 19.0777 18.2876C20 17.4178 20 15.6118 20 12C20 8.38816 20 6.58224 19.0777 5.71235C18.7654 5.41773 18.3934 5.20057 17.9895 5.07707C16.797 4.71243 15.3247 5.6589 12.3802 7.55186C9.67295 9.29233 8.31931 10.1626 8.06492 11.3742C7.97836 11.7865 7.97836 12.2135 8.06492 12.6258Z`,stroke:`currentColor`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M4 4L4 20`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.5`,key:`1`}]],Yi=[[`path`,{d:`M20.0092 2V5.13219C20.0092 5.42605 19.6418 5.55908 19.4537 5.33333C17.6226 3.2875 14.9617 2 12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22C17.5228 22 22 17.5228 22 12`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}]],Xi=[[`path`,{d:`M19.002 12L5.00001 12`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}]],Zi=[[`path`,{d:`M21.5 12C21.5 17.2467 17.2467 21.5 12 21.5C6.75334 21.5 2.5 17.2467 2.5 12C2.5 6.75329 6.75334 2.5 12 2.5C15.8956 2.5 19.2436 4.84478 20.7095 8.2M21.5 5.5L21.025 8.675L18 8`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M10 11V9.5C10 8.39543 10.8954 7.5 12 7.5C13.1046 7.5 14 8.39543 14 9.5V11M11.25 16.5H12.75C13.9228 16.5 14.5092 16.5 14.9131 16.19C15.0171 16.1102 15.1102 16.0171 15.19 15.9131C15.5 15.5092 15.5 14.9228 15.5 13.75C15.5 12.5772 15.5 11.9908 15.19 11.5869C15.1102 11.4829 15.0171 11.3898 14.9131 11.31C14.5092 11 13.9228 11 12.75 11H11.25C10.0772 11 9.49082 11 9.08686 11.31C8.98286 11.3898 8.88977 11.4829 8.80997 11.5869C8.5 11.9908 8.5 12.5772 8.5 13.75C8.5 14.9228 8.5 15.5092 8.80997 15.9131C8.88977 16.0171 8.98286 16.1102 9.08686 16.19C9.49082 16.5 10.0772 16.5 11.25 16.5Z`,stroke:`currentColor`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}]],Qi=[[`path`,{d:`M15.8787 3H11C7.22876 3 5.34315 3 4.17157 4.17157C3 5.34315 3 7.22876 3 11V13C3 16.7712 3 18.6569 4.17157 19.8284C5.34315 21 7.22876 21 11 21H13C16.7712 21 18.6569 21 19.8284 19.8284C21 18.6569 21 16.7712 21 13V8.12132C21 7.66475 21 7.43646 20.9758 7.2174C20.8924 6.4633 20.5963 5.74846 20.122 5.15629C19.9843 4.98427 19.8228 4.82285 19.5 4.5C19.1772 4.17715 19.0157 4.01573 18.8437 3.87795C18.2515 3.40366 17.5367 3.10757 16.7826 3.02421C16.5635 3 16.3353 3 15.8787 3Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M17 3.5V4C17 5.88562 17 6.82843 16.4142 7.41421C15.8284 8 14.8856 8 13 8H11C9.11438 8 8.17157 8 7.58579 7.41421C7 6.82843 7 5.88562 7 4V3.5`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M17 20.5V17C17 15.1144 17 14.1716 16.4142 13.5858C15.8284 13 14.8856 13 13 13H11C9.11438 13 8.17157 13 7.58579 13.5858C7 14.1716 7 15.1144 7 17V20.5`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}]],$i=[[`path`,{d:`M17.5 19V22`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M6.5 19V22`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M4 10C4 6.22876 4 4.34315 5.17157 3.17157C6.34315 2 8.22876 2 12 2C15.7712 2 17.6569 2 18.8284 3.17157C20 4.34315 20 6.22876 20 10V13C20 15.8284 20 17.2426 19.1213 18.1213C18.2426 19 16.8284 19 14 19H10C7.17157 19 5.75736 19 4.87868 18.1213C4 17.2426 4 15.8284 4 13V10Z`,stroke:`currentColor`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}],[`path`,{d:`M7 16H8`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`3`}],[`path`,{d:`M16 16H17`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`4`}],[`path`,{d:`M2 8L2 10`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`5`}],[`path`,{d:`M22 8L22 10`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`6`}],[`path`,{d:`M4.5 5L19.5 5`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.5`,key:`7`}],[`path`,{d:`M4.5 13L19.5 13`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.5`,key:`8`}],[`path`,{d:`M12 13V5`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`9`}]],ea=[[`path`,{d:`M17 17L21 21`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M19 11C19 6.58172 15.4183 3 11 3C6.58172 3 3 6.58172 3 11C3 15.4183 6.58172 19 11 19C15.4183 19 19 15.4183 19 11Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}]],ta=[[`path`,{d:`M18.7088 3.49534C16.8165 2.55382 14.5009 2 12 2C9.4991 2 7.1835 2.55382 5.29116 3.49534C4.36318 3.95706 3.89919 4.18792 3.4496 4.91378C3 5.63965 3 6.34248 3 7.74814V11.2371C3 16.9205 7.54236 20.0804 10.173 21.4338C10.9067 21.8113 11.2735 22 12 22C12.7265 22 13.0933 21.8113 13.8269 21.4338C16.4576 20.0804 21 16.9205 21 11.2371L21 7.74814C21 6.34249 21 5.63966 20.5504 4.91378C20.1008 4.18791 19.6368 3.95706 18.7088 3.49534Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M9 11.5C9 11.5 10.4079 11.7519 11 13.5C11 13.5 12.5 10.5 15 9.5`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}]],na=[[`path`,{d:`M21.0477 3.05293C18.8697 0.707363 2.48648 6.4532 2.50001 8.551C2.51535 10.9299 8.89809 11.6617 10.6672 12.1581C11.7311 12.4565 12.016 12.7625 12.2613 13.8781C13.3723 18.9305 13.9301 21.4435 15.2014 21.4996C17.2278 21.5892 23.1733 5.342 21.0477 3.05293Z`,stroke:`currentColor`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M11.4999 12.5L14.9999 9`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}]],ra=[[`path`,{d:`M21.3175 7.14139L20.8239 6.28479C20.4506 5.63696 20.264 5.31305 19.9464 5.18388C19.6288 5.05472 19.2696 5.15664 18.5513 5.36048L17.3311 5.70418C16.8725 5.80994 16.3913 5.74994 15.9726 5.53479L15.6357 5.34042C15.2766 5.11043 15.0004 4.77133 14.8475 4.37274L14.5136 3.37536C14.294 2.71534 14.1842 2.38533 13.9228 2.19657C13.6615 2.00781 13.3143 2.00781 12.6199 2.00781H11.5051C10.8108 2.00781 10.4636 2.00781 10.2022 2.19657C9.94085 2.38533 9.83106 2.71534 9.61149 3.37536L9.27753 4.37274C9.12465 4.77133 8.84845 5.11043 8.48937 5.34042L8.15249 5.53479C7.73374 5.74994 7.25259 5.80994 6.79398 5.70418L5.57375 5.36048C4.85541 5.15664 4.49625 5.05472 4.17867 5.18388C3.86109 5.31305 3.67445 5.63696 3.30115 6.28479L2.80757 7.14139C2.45766 7.74864 2.2827 8.05227 2.31666 8.37549C2.35061 8.69871 2.58483 8.95918 3.05326 9.48012L4.0843 10.6328C4.3363 10.9518 4.51521 11.5078 4.51521 12.0077C4.51521 12.5078 4.33636 13.0636 4.08433 13.3827L3.05326 14.5354C2.58483 15.0564 2.35062 15.3168 2.31666 15.6401C2.2827 15.9633 2.45766 16.2669 2.80757 16.8741L3.30114 17.7307C3.67443 18.3785 3.86109 18.7025 4.17867 18.8316C4.49625 18.9608 4.85542 18.8589 5.57377 18.655L6.79394 18.3113C7.25263 18.2055 7.73387 18.2656 8.15267 18.4808L8.4895 18.6752C8.84851 18.9052 9.12464 19.2442 9.2775 19.6428L9.61149 20.6403C9.83106 21.3003 9.94085 21.6303 10.2022 21.8191C10.4636 22.0078 10.8108 22.0078 11.5051 22.0078H12.6199C13.3143 22.0078 13.6615 22.0078 13.9228 21.8191C14.1842 21.6303 14.294 21.3003 14.5136 20.6403L14.8476 19.6428C15.0004 19.2442 15.2765 18.9052 15.6356 18.6752L15.9724 18.4808C16.3912 18.2656 16.8724 18.2055 17.3311 18.3113L18.5513 18.655C19.2696 18.8589 19.6288 18.9608 19.9464 18.8316C20.264 18.7025 20.4506 18.3785 20.8239 17.7307L21.3175 16.8741C21.6674 16.2669 21.8423 15.9633 21.8084 15.6401C21.7744 15.3168 21.5402 15.0564 21.0718 14.5354L20.0407 13.3827C19.7887 13.0636 19.6098 12.5078 19.6098 12.0077C19.6098 11.5078 19.7888 10.9518 20.0407 10.6328L21.0718 9.48012C21.5402 8.95918 21.7744 8.69871 21.8084 8.37549C21.8423 8.05227 21.6674 7.74864 21.3175 7.14139Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M15.5195 12C15.5195 13.933 13.9525 15.5 12.0195 15.5C10.0865 15.5 8.51953 13.933 8.51953 12C8.51953 10.067 10.0865 8.5 12.0195 8.5C13.9525 8.5 15.5195 10.067 15.5195 12Z`,stroke:`currentColor`,strokeWidth:`1.5`,key:`1`}]],ia=[[`path`,{d:`M15.5 12C15.5 13.933 13.933 15.5 12 15.5C10.067 15.5 8.5 13.933 8.5 12C8.5 10.067 10.067 8.5 12 8.5C13.933 8.5 15.5 10.067 15.5 12Z`,stroke:`currentColor`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M21.011 14.0965C21.5329 13.9558 21.7939 13.8854 21.8969 13.7508C22 13.6163 22 13.3998 22 12.9669V11.0332C22 10.6003 22 10.3838 21.8969 10.2493C21.7938 10.1147 21.5329 10.0443 21.011 9.90358C19.0606 9.37759 17.8399 7.33851 18.3433 5.40087C18.4817 4.86799 18.5509 4.60156 18.4848 4.44529C18.4187 4.28902 18.2291 4.18134 17.8497 3.96596L16.125 2.98673C15.7528 2.77539 15.5667 2.66972 15.3997 2.69222C15.2326 2.71472 15.0442 2.90273 14.6672 3.27873C13.208 4.73448 10.7936 4.73442 9.33434 3.27864C8.95743 2.90263 8.76898 2.71463 8.60193 2.69212C8.43489 2.66962 8.24877 2.77529 7.87653 2.98663L6.15184 3.96587C5.77253 4.18123 5.58287 4.28891 5.51678 4.44515C5.45068 4.6014 5.51987 4.86787 5.65825 5.4008C6.16137 7.3385 4.93972 9.37763 2.98902 9.9036C2.46712 10.0443 2.20617 10.1147 2.10308 10.2492C2 10.3838 2 10.6003 2 11.0332V12.9669C2 13.3998 2 13.6163 2.10308 13.7508C2.20615 13.8854 2.46711 13.9558 2.98902 14.0965C4.9394 14.6225 6.16008 16.6616 5.65672 18.5992C5.51829 19.1321 5.44907 19.3985 5.51516 19.5548C5.58126 19.7111 5.77092 19.8188 6.15025 20.0341L7.87495 21.0134C8.24721 21.2247 8.43334 21.3304 8.6004 21.3079C8.76746 21.2854 8.95588 21.0973 9.33271 20.7213C10.7927 19.2644 13.2088 19.2643 14.6689 20.7212C15.0457 21.0973 15.2341 21.2853 15.4012 21.3078C15.5682 21.3303 15.7544 21.2246 16.1266 21.0133L17.8513 20.034C18.2307 19.8187 18.4204 19.711 18.4864 19.5547C18.5525 19.3984 18.4833 19.132 18.3448 18.5991C17.8412 16.6616 19.0609 14.6226 21.011 14.0965Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.5`,key:`1`}]],aa=[[`path`,{d:`M4.5 4.5L18 18`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M18.7088 3.49534C16.8165 2.55382 14.5009 2 12 2C9.4991 2 7.1835 2.55382 5.29116 3.49534C4.36318 3.95706 3.89919 4.18792 3.4496 4.91378C3 5.63965 3 6.34248 3 7.74814V11.2371C3 16.9205 7.54236 20.0804 10.173 21.4338C10.9067 21.8113 11.2735 22 12 22C12.7265 22 13.0933 21.8113 13.8269 21.4338C16.4576 20.0804 21 16.9205 21 11.2371L21 7.74814C21 6.34249 21 5.63966 20.5504 4.91378C20.1008 4.18791 19.6368 3.95706 18.7088 3.49534Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}]],oa=[[`path`,{d:`M8 19.5C8 18.5572 8 18.0858 8.29289 17.7929C8.58579 17.5 9.05719 17.5 10 17.5C10.9428 17.5 11.4142 17.5 11.7071 17.7929C12 18.0858 12 18.5572 12 19.5C12 20.4428 12 20.9142 11.7071 21.2071C11.4142 21.5 10.9428 21.5 10 21.5C9.05719 21.5 8.58579 21.5 8.29289 21.2071C8 20.9142 8 20.4428 8 19.5Z`,stroke:`currentColor`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M12 19.5C12 18.5572 12 18.0858 12.2929 17.7929C12.5858 17.5 13.0572 17.5 14 17.5C14.9428 17.5 15.4142 17.5 15.7071 17.7929C16 18.0858 16 18.5572 16 19.5C16 20.4428 16 20.9142 15.7071 21.2071C15.4142 21.5 14.9428 21.5 14 21.5C13.0572 21.5 12.5858 21.5 12.2929 21.2071C12 20.9142 12 20.4428 12 19.5Z`,stroke:`currentColor`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M10 15.5C10 14.5572 10 14.0858 10.2929 13.7929C10.5858 13.5 11.0572 13.5 12 13.5C12.9428 13.5 13.4142 13.5 13.7071 13.7929C14 14.0858 14 14.5572 14 15.5C14 16.4428 14 16.9142 13.7071 17.2071C13.4142 17.5 12.9428 17.5 12 17.5C11.0572 17.5 10.5858 17.5 10.2929 17.2071C10 16.9142 10 16.4428 10 15.5Z`,stroke:`currentColor`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}],[`path`,{d:`M19 13.532V20.006C19 20.4701 19 20.7021 19.0761 20.8851C19.1776 21.1292 19.3723 21.3231 19.6173 21.4242C19.8011 21.5 20.0341 21.5 20.5 21.5C20.9659 21.5 21.1989 21.5 21.3827 21.4242C21.6277 21.3231 21.8224 21.1292 21.9239 20.8851C22 20.7021 22 20.4701 22 20.006V11.0894C22 9.3667 22 8.50536 21.5824 7.80186C21.1647 7.09835 20.407 6.68326 18.8915 5.85307L14.8915 3.66186C13.4776 2.88729 12.7706 2.5 12 2.5C11.2294 2.5 10.5224 2.88729 9.10849 3.66186L5.10849 5.85307C3.593 6.68326 2.83526 7.09835 2.41763 7.80186C2 8.50536 2 9.3667 2 11.0894V20.006C2 20.4701 2 20.7021 2.07612 20.8851C2.17761 21.1292 2.37229 21.3231 2.61732 21.4242C2.80109 21.5 3.03406 21.5 3.5 21.5C3.96594 21.5 4.19891 21.5 4.38268 21.4242C4.62771 21.3231 4.82239 21.1292 4.92388 20.8851C5 20.7021 5 20.4701 5 20.006V13.532C5 11.6539 5 10.7148 5.58579 10.1314C6.17157 9.54793 7.11438 9.54793 9 9.54793H15C16.8856 9.54793 17.8284 9.54793 18.4142 10.1314C19 10.7148 19 11.6539 19 13.532Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`3`}]],sa=[[`path`,{d:`M6 9V16.6841C6 18.4952 6 19.4008 6.58579 19.9635C7.89989 21.2257 15.8558 21.4604 17.4142 19.9635C18 19.4008 18 18.4952 18 16.6841V9`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M5.74073 12L3.04321 9.38915C2.34774 8.71602 2 8.37946 2 7.96123C2 7.543 2.34774 7.20644 3.04321 6.53331L5.04418 4.59664C5.39088 4.26107 5.56423 4.09329 5.77088 3.96968C5.97753 3.84607 6.21011 3.77103 6.67526 3.62096L8.32112 3.08997C8.56177 3.01233 8.68209 2.97351 8.76391 3.02018C8.84573 3.06686 8.87157 3.2013 8.92324 3.47018C9.19358 4.87684 10.4683 5.94185 12 5.94185C13.5317 5.94185 14.8064 4.87684 15.0768 3.47018C15.1284 3.2013 15.1543 3.06686 15.2361 3.02018C15.3179 2.97351 15.4382 3.01233 15.6789 3.08997L17.3247 3.62096C17.7899 3.77103 18.0225 3.84607 18.2291 3.96968C18.4358 4.09329 18.6091 4.26107 18.9558 4.59664L20.9568 6.53331C21.6523 7.20644 22 7.543 22 7.96123C22 8.37946 21.6523 8.71602 20.9568 9.38915L18.2593 12`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}]],ca=[[`path`,{d:`M3.32352 13.0113C3.6739 10.009 4.18586 7.75784 4.66063 6.15851C5.04994 4.84711 5.24459 4.19141 6.04283 3.5957C6.84107 3 7.65697 3 9.28876 3H14.7113C16.3431 3 17.159 3 17.9572 3.5957C18.7554 4.19141 18.9501 4.84711 19.3394 6.15851C19.8142 7.75784 20.3261 10.009 20.6765 13.0113C21.0895 16.5497 21.2959 18.3189 20.1027 19.6594C18.9095 21 16.9758 21 13.1084 21H10.8916C7.02422 21 5.09052 21 3.89731 19.6594C2.70411 18.3189 2.91058 16.5497 3.32352 13.0113Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M9 7C9 8.65685 10.3431 10 12 10C13.6569 10 15 8.65685 15 7`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}]],la=[[`path`,{d:`M16.5 4.70711V7.5L19.2928 7.50043C19.7456 7.5005 20.1799 7.32065 20.5001 7.00046L21.1463 6.35424C21.3728 6.12777 21.5 5.82061 21.5 5.50033C21.5 5.17998 21.3728 4.87276 21.1462 4.64627L19.3525 2.85316C19.1263 2.62703 18.8195 2.5 18.4997 2.5C18.1797 2.5 17.8729 2.62709 17.6467 2.8533L17 3.5C16.6799 3.82014 16.5 4.25435 16.5 4.70711Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M16.5 7.5L8.50005 15.5`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M5.63517 21.5002H5.45182C4.05997 21.5002 3.36405 21.5002 2.93174 21.0679C2.49943 20.6355 2.49962 19.9396 2.49999 18.5478L2.50004 18.3654C2.50004 16.2778 3.32936 14.2758 4.80556 12.7997C5.95398 11.651 6.52819 11.0766 7.23229 11.0092C7.35699 10.9973 7.48254 10.9973 7.60724 11.0092C8.31135 11.0765 8.88563 11.6508 10.0342 12.7994L11.2005 13.9658C12.3496 15.115 12.9241 15.6895 12.9911 16.3941C13.0029 16.5178 13.0029 16.6424 12.9912 16.7661C12.9244 17.4707 12.35 18.0454 11.2012 19.1949C9.72499 20.671 7.72283 21.5002 5.63517 21.5002Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}]],ua=[[`path`,{d:`M6.13225 16.6536C6.93769 16.9301 7.81546 16.5033 8.09279 15.7002L9.2645 12.3072C9.44939 11.7718 10.0346 11.4873 10.5715 11.6716L11.5438 12.0054C12.0807 12.1898 12.6659 11.9052 12.8508 11.3698L15.1942 4.5839C15.3791 4.04851 15.0937 3.46504 14.5567 3.28069C11.8719 2.35893 8.94606 3.78182 8.02161 6.45878L5.17603 14.6988C4.89869 15.5019 5.32681 16.3771 6.13225 16.6536ZM6.13225 16.6536L5.39668 18.7836C5.01963 19.8755 4.12026 20.7072 3 21M18.0832 5.91908L21 6.92047M17.0789 8.82733L19.9957 9.82872M16.0746 11.7356L18.9914 12.737`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}]],da=[[`path`,{d:`M12 17C15.7593 17 18.9168 14.4405 19.8036 10.9798C20.0098 10.175 20.1129 9.77257 19.8107 9.38629C19.5085 9 19.0187 9 18.039 9H5.96096C4.98134 9 4.49153 9 4.18931 9.38629C3.88709 9.77257 3.99019 10.175 4.19641 10.9798C5.08317 14.4405 8.24074 17 12 17Z`,stroke:`currentColor`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M12 9V3.5C12 2.67157 12.6716 2 13.5 2C14.3284 2 15 2.67157 15 3.5`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M9 9V8C9 7.05719 9 6.58579 8.70711 6.29289C8.41421 6 7.94281 6 7 6`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}],[`path`,{d:`M15 7V9`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`3`}],[`path`,{d:`M9 16.5L9.64223 20.0323C9.84941 21.1717 10.8418 22 12 22C13.1582 22 14.1506 21.1717 14.3578 20.0323L15 16.5`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`4`}]],fa=[[`path`,{d:`M13.5 2H10.5C8.14298 2 6.96447 2 6.23223 2.73223C5.5 3.46447 5.5 4.64298 5.5 7V17C5.5 19.357 5.5 20.5355 6.23223 21.2678C6.96447 22 8.14298 22 10.5 22H13.5C15.857 22 17.0355 22 17.7678 21.2678C18.5 20.5355 18.5 19.357 18.5 17V7C18.5 4.64298 18.5 3.46447 17.7678 2.73223C17.0355 2 15.857 2 13.5 2Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M12.125 19H12M12.25 19C12.25 19.1381 12.1381 19.25 12 19.25C11.8619 19.25 11.75 19.1381 11.75 19C11.75 18.8619 11.8619 18.75 12 18.75C12.1381 18.75 12.25 18.8619 12.25 19Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}]],pa=[[`path`,{d:`M21 14.25L20.1689 13.591C19.223 12.841 18.75 12.466 18.75 12C18.75 11.534 19.223 11.159 20.1689 10.409L21 9.75M3 9.75L3.83115 10.409C4.77705 11.159 5.25 11.534 5.25 12C5.25 12.466 4.77705 12.841 3.83115 13.591L3 14.25`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M14.5718 21L14.7282 19.9412C14.9062 18.7362 14.9951 18.1337 15.4019 17.8986C15.8087 17.6635 16.3744 17.8876 17.5058 18.3358L18.5 18.7296M9.4282 3L9.27182 4.0588C9.09384 5.26379 9.00486 5.86629 8.59808 6.10139C8.1913 6.3365 7.62558 6.1124 6.49416 5.6642L5.5 5.27038`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M5 18.7317L6.07032 18.3375C7.2884 17.8889 7.89747 17.6645 8.33521 17.8994C8.77295 18.1343 8.86844 18.7367 9.05941 19.9414L9.22722 21M19 5.26825L17.9297 5.66249C16.7116 6.11115 16.1025 6.33548 15.6648 6.1006C15.2271 5.86571 15.1316 5.26333 14.9406 4.05859L14.7728 3`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}],[`path`,{d:`M19 12.0003H5M15.5 17.9998L8.5 6M15.5 6.00025L8.5 18`,stroke:`currentColor`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`3`}]],ma=[[`path`,{d:`M6 17V20M18 17V20`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M20 9C20 7.13077 20 6.19615 19.5981 5.5C19.3348 5.04394 18.9561 4.66523 18.5 4.40192C17.8038 4 16.8692 4 15 4H9C7.13077 4 6.19615 4 5.5 4.40192C5.04394 4.66523 4.66523 5.04394 4.40192 5.5C4 6.19615 4 7.13077 4 9`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M20 9C18.8954 9 18 9.89543 18 11V13C18 13.8273 17.8273 14 17 14H7C6.17267 14 6 13.8273 6 13V11C6 9.89543 5.10457 9 4 9C2.89543 9 2 9.89543 2 11C2 11.7403 2.4022 12.3866 3 12.7324V13C3 14.8856 3 15.8284 3.58579 16.4142C4.17157 17 5.11438 17 7 17H17C18.8856 17 19.8284 17 20.4142 16.4142C21 15.8284 21 14.8856 21 13V12.7324C21.5978 12.3866 22 11.7403 22 11C22 9.89543 21.1046 9 20 9Z`,stroke:`currentColor`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}]],ha=[[`path`,{d:`M11 10L18 10`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M11 14H16`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M11 18H14`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}],[`path`,{d:`M11 6H21`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`3`}],[`path`,{d:`M7 18.8125C6.60678 19.255 5.56018 21 5 21M3 18.8125C3.39322 19.255 4.43982 21 5 21M5 21L5 15`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`4`}],[`path`,{d:`M3 5.1875C3.39322 4.74501 4.43982 3 5 3M7 5.1875C6.60678 4.74501 5.56018 3 5 3M5 3L5 9`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`5`}]],ga=[[`path`,{d:`M3.5 10C3.5 6.22876 3.5 4.34315 4.7448 3.17157C5.98959 2 7.99306 2 12 2C16.0069 2 18.0104 2 19.2552 3.17157C20.5 4.34315 20.5 6.22876 20.5 10V14C20.5 17.7712 20.5 19.6569 19.2552 20.8284C18.0104 22 16.0069 22 12 22C7.99306 22 5.98959 22 4.7448 20.8284C3.5 19.6569 3.5 17.7712 3.5 14V10Z`,stroke:`currentColor`,strokeWidth:`1.5`,key:`0`}],[`circle`,{cx:`12`,cy:`14.5`,r:`3.5`,stroke:`currentColor`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M10 6H14`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.5`,key:`2`}]],_a=[[`path`,{d:`M21.9998 6.50195L18.5604 9.94129C17.9746 10.5271 17.0249 10.5271 16.4391 9.94129L15.7498 9.25195L15.0604 8.56261C14.4746 7.97683 14.4746 7.02708 15.0604 6.44129L18.4998 3.00195M15.7498 9.25195L3.99976 21.002`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M20 4.99902L17.5 7.49902`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M7.98914 8.99011C6.79472 10.1845 5.15674 10.4831 3.66377 8.99011C2.17075 7.49709 1.38801 4.77783 2.58243 3.58341C3.77685 2.38899 6.49611 3.17172 7.98914 4.66475C9.48211 6.15772 9.18356 7.79569 7.98914 8.99011ZM7.98914 8.99011L20 21.001`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.5`,key:`2`}],[`path`,{d:`M9.20542 2.39669C10.0923 2.13908 11.03 2.00098 12 2.00098C13.1517 2.00098 14.2579 2.19567 15.2876 2.55394M2.04937 11.001C2.01672 11.3299 2 11.6635 2 12.001C2 14.0328 2.60598 15.9231 3.64707 17.501M7.77267 21.0661C9.05671 21.6659 10.4892 22.001 12 22.001C13.5244 22.001 14.9691 21.6599 16.262 21.0499M20.3529 17.501C21.394 15.9231 22 14.0328 22 12.001C22 11.4228 21.9509 10.8561 21.8567 10.3048`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.5`,key:`3`}]],va=[[`path`,{d:`M6.5 17.3306C7.78183 18.9563 9.76903 20 12 20C13.9587 20 15.7295 19.1955 17 17.8989M8.5 6.93647C9.52961 6.34088 10.725 6 12 6C13.9587 6 15.7295 6.80446 17 8.10101`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M16 13C16 15.2091 14.2091 17 12 17C9.79085 17 8 15.2091 8 13C8 10.7909 9.79085 9 12 9C14.2091 9 16 10.7909 16 13Z`,stroke:`currentColor`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M6 7C6 8.38067 5.10457 9 4 9C2.89543 9 2 8.38067 2 7C2 5.61928 2.89543 4 4 4C5.10457 4 6 5.61928 6 7Z`,stroke:`currentColor`,strokeWidth:`1.5`,key:`2`}],[`path`,{d:`M19.5 13V4H20C21.1046 4 22 4.89543 22 6V13H19.5ZM19.5 13V20`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`3`}],[`path`,{d:`M4 9V20`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`4`}]],ya=[[`path`,{d:`M8 2V9`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M8 14L13 9L8.88388 4.88388C8.31794 4.31794 7.55036 4 6.75 4C5.94964 4 5.18206 4.31794 4.61612 4.88388L3.88388 5.61612C3.31794 6.18206 3 6.94964 3 7.75C3 8.55036 3.31794 9.31794 3.88388 9.88388L8 14Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M13 9L8 14L8.7623 17.0492C8.902 17.608 9.40407 18 9.98006 18C10.313 18 10.6322 17.8678 10.8677 17.6323L16.6323 11.8677C16.8678 11.6322 17 11.313 17 10.9801C17 10.4041 16.608 9.902 16.0492 9.7623L13 9Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}],[`path`,{d:`M18 19L20 21M19 15H21M14 20V22`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`3`}]],ba=[[`path`,{d:`M8.5 8.5V12.5M8.5 12.5V17.5M8.5 12.5H12.5M11.5 6.5H12.5C14.1569 6.5 15.5 7.84315 15.5 9.5C15.5 9.80309 15.4551 10.0957 15.3715 10.3715`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M2 2L22 22`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M20.1088 20.1088C18.7175 21.5 16.4784 21.5 12 21.5C7.52169 21.5 5.28252 21.5 3.89127 20.1088C2.50003 18.7175 2.50003 16.4783 2.50003 12C2.50003 7.52166 2.50003 5.28249 3.89127 3.89124M7.5907 2.59066C8.7583 2.5 10.1979 2.5 12 2.5C16.4784 2.5 18.7175 2.5 20.1088 3.89124C21.5 5.28249 21.5 7.52166 21.5 12C21.5 13.8022 21.5 15.2417 21.4094 16.4093`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}]],xa=[[`path`,{d:`M4.26781 18.8447C4.49269 20.515 5.87613 21.8235 7.55966 21.9009C8.97627 21.966 10.4153 22 12 22C13.5847 22 15.0237 21.966 16.4403 21.9009C18.1239 21.8235 19.5073 20.515 19.7322 18.8447C19.879 17.7547 20 16.6376 20 15.5C20 14.3624 19.879 13.2453 19.7322 12.1553C19.5073 10.485 18.1239 9.17649 16.4403 9.09909C15.0237 9.03397 13.5847 9 12 9C10.4153 9 8.97627 9.03397 7.55965 9.09909C5.87613 9.17649 4.49269 10.485 4.26781 12.1553C4.12104 13.2453 4 14.3624 4 15.5C4 16.6376 4.12104 17.7547 4.26781 18.8447Z`,stroke:`currentColor`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M7.5 9V6.5C7.5 4.01472 9.51472 2 12 2C13.9593 2 15.5 3.5 16 5`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M12.125 15.5H12M12.25 15.5C12.25 15.6381 12.1381 15.75 12 15.75C11.8619 15.75 11.75 15.6381 11.75 15.5C11.75 15.3619 11.8619 15.25 12 15.25C12.1381 15.25 12.25 15.3619 12.25 15.5Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.5`,key:`2`}]],Sa=[[`path`,{d:`M4 12C4 8.72077 4 7.08116 4.81382 5.91891C5.1149 5.48891 5.48891 5.1149 5.91891 4.81382C7.08116 4 8.72077 4 12 4C15.2792 4 16.9188 4 18.0811 4.81382C18.5111 5.1149 18.8851 5.48891 19.1862 5.91891C20 7.08116 20 8.72077 20 12C20 15.2792 20 16.9188 19.1862 18.0811C18.8851 18.5111 18.5111 18.8851 18.0811 19.1862C16.9188 20 15.2792 20 12 20C8.72077 20 7.08116 20 5.91891 19.1862C5.48891 18.8851 5.1149 18.5111 4.81382 18.0811C4 16.9188 4 15.2792 4 12Z`,stroke:`currentColor`,strokeWidth:`1.5`,key:`0`}]],Ca=[[`path`,{d:`M22 12H2`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M20 17H16C14.1144 17 13.1716 17 12.5858 16.4142C12 15.8284 12 14.8856 12 13V12`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M4 12V22M20 12V22`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}],[`path`,{d:`M15.0401 2.59903C14.3088 1.90313 13.1232 1.90313 12.3919 2.59903C11.9784 2.99247 11.8198 3.4444 12.2767 3.87914L13.6927 5.22669C14.149 5.66087 14.6219 5.51714 15.0401 5.11912C15.7714 4.42322 15.7714 3.29494 15.0401 2.59903ZM15.0401 2.59903C15.5358 2.27324 16.0932 1.81764 16.7123 2.0763C17.0028 2.19766 17.2022 2.49474 17.6008 3.08889L19.0993 5.3223C19.6639 6.16376 19.9462 6.5845 19.9931 7.06138C20.0401 7.53825 19.8448 8.00129 19.4542 8.92735L18.1584 12`,stroke:`currentColor`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`3`}],[`path`,{d:`M4 12V7.5C4 6.37313 4.4506 6 5.5 6C6.5494 6 7 6.37313 7 7.5V12`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`4`}],[`path`,{d:`M7 12V7.5C7 6.37313 7.4506 6 8.5 6C9.5494 6 10 6.37313 10 7.5V12`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`5`}]],wa=[[`path`,{d:`M16.9991 12C16.9991 14.7614 14.7605 17 11.9991 17C9.23766 17 6.99908 14.7614 6.99908 12C6.99908 9.23858 9.23766 7 11.9991 7C14.7605 7 16.9991 9.23858 16.9991 12Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M12.1247 3.25H11.9997M12.1242 20.75H11.9992M20.75 12.125V12M3.25 12.125V12M18.2752 5.90098L18.1868 5.81259M5.90051 18.275L5.81212 18.1866M18.0987 18.2756L18.187 18.1872M5.72429 5.9012L5.81267 5.81282M12.2497 3.25C12.2497 3.38807 12.1378 3.5 11.9997 3.5C11.8616 3.5 11.7497 3.38807 11.7497 3.25C11.7497 3.11193 11.8616 3 11.9997 3C12.1378 3 12.2497 3.11193 12.2497 3.25ZM12.2492 20.75C12.2492 20.8881 12.1373 21 11.9992 21C11.8611 21 11.7492 20.8881 11.7492 20.75C11.7492 20.6119 11.8611 20.5 11.9992 20.5C12.1373 20.5 12.2492 20.6119 12.2492 20.75ZM20.75 12.25C20.6119 12.25 20.5 12.1381 20.5 12C20.5 11.8619 20.6119 11.75 20.75 11.75C20.8881 11.75 21 11.8619 21 12C21 12.1381 20.8881 12.25 20.75 12.25ZM3.25 12.25C3.11193 12.25 3 12.1381 3 12C3 11.8619 3.11193 11.75 3.25 11.75C3.38807 11.75 3.5 11.8619 3.5 12C3.5 12.1381 3.38807 12.25 3.25 12.25ZM18.3636 5.98937C18.266 6.087 18.1077 6.087 18.01 5.98937C17.9124 5.89174 17.9124 5.73345 18.01 5.63582C18.1077 5.53819 18.266 5.53819 18.3636 5.63582C18.4612 5.73345 18.4612 5.89174 18.3636 5.98937ZM5.9889 18.3634C5.89127 18.461 5.73297 18.461 5.63534 18.3634C5.53771 18.2658 5.53771 18.1075 5.63534 18.0099C5.73297 17.9122 5.89127 17.9122 5.9889 18.0099C6.08653 18.1075 6.08653 18.2658 5.9889 18.3634ZM18.0103 18.364C17.9126 18.2663 17.9126 18.108 18.0103 18.0104C18.1079 17.9128 18.2662 17.9128 18.3638 18.0104C18.4614 18.108 18.4614 18.2663 18.3638 18.364C18.2662 18.4616 18.1079 18.4616 18.0103 18.364ZM5.6359 5.98959C5.53827 5.89196 5.53827 5.73367 5.6359 5.63604C5.73353 5.53841 5.89182 5.53841 5.98945 5.63604C6.08708 5.73367 6.08708 5.89196 5.98945 5.98959C5.89182 6.08722 5.73353 6.08722 5.6359 5.98959Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}]],Ta=[[`path`,{d:`M17 12C17 14.7614 14.7614 17 12 17C9.23858 17 7 14.7614 7 12C7 9.23858 9.23858 7 12 7C14.7614 7 17 9.23858 17 12Z`,stroke:`currentColor`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M12 2C11.6227 2.33333 11.0945 3.2 12 4M12 20C12.3773 20.3333 12.9055 21.2 12 22M19.5 4.50271C18.9685 4.46982 17.9253 4.72293 18.0042 5.99847M5.49576 17.5C5.52865 18.0315 5.27555 19.0747 4 18.9958M5.00271 4.5C4.96979 5.03202 5.22315 6.0763 6.5 5.99729M18 17.5026C18.5315 17.4715 19.5747 17.7108 19.4958 18.9168M22 12C21.6667 11.6227 20.8 11.0945 20 12M4 11.5C3.66667 11.8773 2.8 12.4055 2 11.5`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.5`,key:`1`}]],Ea=[[`path`,{d:`M9.0784 14.9999L7.30434 17.6837C7.06684 18.043 6.94808 18.2226 7.02165 18.3612C7.09522 18.4999 7.30931 18.4999 7.73747 18.4999H9.26253C9.69069 18.4999 9.90478 18.4999 9.97835 18.6385C10.0519 18.7772 9.93316 18.9568 9.69566 19.3161L7.9216 21.9999`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M16 19.9999L15 21.9999`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M13 19.9999L12 21.9999`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}],[`path`,{d:`M2.95939 9.19373C2.21865 6.47179 3.85922 3.67397 6.6237 2.94463M2.95939 9.19373L2 9.44684M2.95939 9.19373C3.14359 9.87059 3.4577 10.479 3.86823 11M6.6237 2.94463L6.36663 2M6.6237 2.94463C8.66673 2.40563 10.7518 3.14719 12 4.66961M3.4765 5.32297L2.4644 4.74628M11.1407 2.45725L10.557 3.45494`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.5`,key:`3`}],[`path`,{d:`M17.4776 10.9008C17.485 10.9007 17.4925 10.9007 17.5 10.9007C19.9853 10.9007 22 12.8821 22 15.3263C22 17.2532 20.7478 18.8925 19 19.5M17.4776 10.9008C17.4924 10.7388 17.5 10.5748 17.5 10.409C17.5 7.42169 15.0376 5 12 5C9.12324 5 6.76233 7.17208 6.52042 9.9396M17.4776 10.9008C17.3753 12.0165 16.9286 13.0344 16.2428 13.8511M6.52042 9.9396C3.98398 10.177 2 12.2779 2 14.8345C2 16.4433 2.78555 17.8716 4 18.7687M6.52042 9.9396C6.67826 9.92483 6.83823 9.91727 7 9.91727C8.12582 9.91727 9.16474 10.2832 10.0005 10.9007`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`4`}]],Da=[[`path`,{d:`M4 12V22M20 12V22`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M3 12H21`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M4 17L20 17`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}],[`path`,{d:`M11 14.5L13 14.5`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`3`}],[`path`,{d:`M14.386 3.35537C14.2825 3.18589 14.1891 3.02611 14.1062 2.87981C13.8552 2.43706 13.7297 2.21569 13.5302 2.10784C13.3307 2 13.0642 2 12.5312 2H11.4688C10.9358 2 10.6693 2 10.4698 2.10784C10.2703 2.21569 10.1448 2.43706 9.89384 2.87981L9.89383 2.87981C9.81091 3.02611 9.71746 3.18589 9.61404 3.35537C8.41287 5.32381 7.81228 6.30803 8.05201 6.65402C8.29175 7 9.41969 7 11.6756 7H11.6756H12.3244H12.3244C14.5803 7 15.7082 7 15.948 6.65402C16.1877 6.30803 15.5871 5.32381 14.386 3.35537Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`4`}],[`path`,{d:`M12 7V12`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`5`}]],Oa=[[`path`,{d:`M5 20V22M19 20V22`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M17.5556 10H6.44444C4.34931 10 3.30175 10 2.65087 10.5858C2 11.1716 2 12.1144 2 14V16C2 17.8856 2 18.8284 2.65087 19.4142C3.30175 20 4.34931 20 6.44444 20H17.5556C19.6507 20 20.6983 20 21.3491 19.4142C22 18.8284 22 17.8856 22 16V14C22 12.1144 22 11.1716 21.3491 10.5858C20.6983 10 19.6507 10 17.5556 10Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M12 10.0001L12 20.0001`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}],[`path`,{d:`M16 15.0001L17 15.0001`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`3`}],[`path`,{d:`M7 15.0001L8 15.0001`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`4`}],[`path`,{d:`M8 2C6.1038 2 4.51109 3.27976 4.0638 5.01012C3.8557 5.81516 4.15776 6 4.95386 6H11.0461C11.8422 6 12.1443 5.81516 11.9362 5.01012C11.4889 3.27976 9.8962 2 8 2Z`,stroke:`currentColor`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`5`}],[`path`,{d:`M8 6V10`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`6`}],[`path`,{d:`M11 6V7.5`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`7`}]],ka=[[`circle`,{cx:`1.5`,cy:`1.5`,r:`1.5`,transform:`matrix(1 0 0 -1 16 8.00024)`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M2.77423 11.1439C1.77108 12.2643 1.7495 13.9546 2.67016 15.1437C4.49711 17.5033 6.49674 19.5029 8.85633 21.3298C10.0454 22.2505 11.7357 22.2289 12.8561 21.2258C15.8979 18.5022 18.6835 15.6559 21.3719 12.5279C21.6377 12.2187 21.8039 11.8397 21.8412 11.4336C22.0062 9.63798 22.3452 4.46467 20.9403 3.05974C19.5353 1.65481 14.362 1.99377 12.5664 2.15876C12.1603 2.19608 11.7813 2.36233 11.472 2.62811C8.34412 5.31646 5.49781 8.10211 2.77423 11.1439Z`,stroke:`currentColor`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M7.00002 14.0002L10 17.0002`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}]],Aa=[[`path`,{d:`M19 13.5V8C19 5.17157 19 3.75736 18.1213 2.87868C17.2426 2 15.8284 2 13 2H9C6.17157 2 4.75736 2 3.87868 2.87868C3 3.75736 3 5.17157 3 8V16C3 18.8284 3 20.2426 3.87868 21.1213C4.75736 22 6.17157 22 9 22H12`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M14.5 2H7.5C7.5 3.41421 7.5 4.12132 7.93934 4.56066C8.37868 5 9.08579 5 10.5 5H11.5C12.9142 5 13.6213 5 14.0607 4.56066C14.5 4.12132 14.5 3.41421 14.5 2Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M7 15H11M7 11H15`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}],[`path`,{d:`M14 20C14 20 15 20 16 22C16 22 18.1765 17 21 16`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`3`}]],ja=[[`path`,{d:`M12 22C14.7614 22 17 19.7614 17 17C17 15.3644 16.2147 13.9122 15.0005 13V5.00049C15.0005 4.06815 15.0005 3.60198 14.8481 3.23428C14.6451 2.74451 14.256 2.35537 13.7662 2.15239C13.3985 2 12.9323 2 12 2C11.0677 2 10.6015 2 10.2338 2.15239C9.74402 2.35537 9.35488 2.74451 9.1519 3.23428C8.99951 3.60198 8.99951 4.06815 8.99951 5.00049V13C7.78534 13.9122 7 15.3644 7 17C7 19.7614 9.23858 22 12 22Z`,stroke:`currentColor`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M12 15C10.8954 15 10 15.8954 10 17C10 18.1046 10.8954 19 12 19C13.1046 19 14 18.1046 14 17C14 15.8954 13.1046 15 12 15ZM12 15V8`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}]],Ma=[[`path`,{d:`M8 2H16`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M16.2187 13.0044L15.9921 13.6151C15.5219 14.65 14.1115 15.7439 11.7609 14.3182C10.2471 13.4001 8.93663 12.6631 7.9997 13.16L7.21891 13.5412`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M14.5323 2V8.56602C14.5323 9.27829 14.5323 9.63442 14.6304 9.97222C14.7285 10.31 14.9197 10.612 15.3021 11.216L17.2861 14.35C19.4275 17.7326 20.4982 19.4238 19.7751 20.7119C19.0519 22 17.0317 22 12.9914 22H11.0086C6.96825 22 4.94807 22 4.22495 20.7119C3.50182 19.4238 4.57251 17.7326 6.71389 14.35L8.69792 11.216C9.08029 10.612 9.27148 10.31 9.36961 9.97222C9.46773 9.63442 9.46773 9.27829 9.46773 8.56602V2`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}],[`path`,{d:`M15.125 19H15M15.25 19C15.25 19.1381 15.1381 19.25 15 19.25C14.8619 19.25 14.75 19.1381 14.75 19C14.75 18.8619 14.8619 18.75 15 18.75C15.1381 18.75 15.25 18.8619 15.25 19Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`3`}],[`path`,{d:`M10.125 17H10M10.25 17C10.25 17.1381 10.1381 17.25 10 17.25C9.86193 17.25 9.75 17.1381 9.75 17C9.75 16.8619 9.86193 16.75 10 16.75C10.1381 16.75 10.25 16.8619 10.25 17Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`4`}]],Na=[[`path`,{d:`M5 6C5 4.58579 5 3.87868 5.43934 3.43934C5.87868 3 6.58579 3 8 3H12.5789C15.0206 3 17 5.01472 17 7.5C17 9.98528 15.0206 12 12.5789 12H5V6Z`,stroke:`currentColor`,fillRule:`evenodd`,clipRule:`evenodd`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M12.4286 12H13.6667C16.0599 12 18 14.0147 18 16.5C18 18.9853 16.0599 21 13.6667 21H8C6.58579 21 5.87868 21 5.43934 20.5607C5 20.1213 5 19.4142 5 18V12`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}]],Pa=[[`path`,{d:`M12 4H19`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M8 20L16 4`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M5 20H12`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.5`,key:`2`}]],Fa=[[`path`,{d:`M16.5001 22C18.7092 22 20.5001 20.2091 20.5001 18C20.5001 16.9335 20.0827 15.9646 19.4024 15.2475C18.8957 14.7134 18.6424 14.4463 18.5712 14.2679C18.5001 14.0895 18.5001 13.8535 18.5001 13.3815V4C18.5001 2.89543 17.6046 2 16.5001 2C15.3955 2 14.5001 2.89543 14.5001 4V13.3815C14.5001 13.8535 14.5001 14.0895 14.4289 14.2679C14.3577 14.4463 14.1044 14.7134 13.5977 15.2475C12.9174 15.9646 12.5001 16.9335 12.5001 18C12.5001 20.2091 14.2909 22 16.5001 22Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M10.3133 15.8303C8.67792 15.5416 7.36329 14.104 7.20333 12.2607C7.01373 10.076 8.51806 8.14861 10.5634 7.95588C10.883 7.92576 11.197 7.9398 11.5 7.99327M10.2201 4L10.323 5.18677M6.04201 7.57572L5.18359 6.81058M4.611 12.505L3.5 12.6097M6.86776 17.0868L6.15499 18`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.5`,key:`1`}]],Ia=[[`path`,{d:`M2.5 12C2.5 7.52166 2.5 5.28249 3.89124 3.89124C5.28249 2.5 7.52166 2.5 12 2.5C16.4783 2.5 18.7175 2.5 20.1088 3.89124C21.5 5.28249 21.5 7.52166 21.5 12C21.5 16.4783 21.5 18.7175 20.1088 20.1088C18.7175 21.5 16.4783 21.5 12 21.5C7.52166 21.5 5.28249 21.5 3.89124 20.1088C2.5 18.7175 2.5 16.4783 2.5 12Z`,stroke:`currentColor`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M12.0078 10.5082C11.1794 10.5082 10.5078 11.1798 10.5078 12.0082C10.5078 12.8366 11.1794 13.5082 12.0078 13.5082C12.8362 13.5082 13.5078 12.8366 13.5078 12.0082C13.5078 11.1798 12.8362 10.5082 12.0078 10.5082ZM12.0078 10.5082V6.99902M15.0147 15.0198L13.0661 13.0712`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}]],La=[[`path`,{d:`M12 8V12L13.5 13.5`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M19.5454 16.4534C21.1818 17.337 22 17.7789 22 18.5C22 19.2211 21.1818 19.663 19.5454 20.5466L18.4311 21.1484C17.1744 21.827 16.5461 22.1663 16.2439 21.9196C15.504 21.3154 16.6567 19.7561 16.9403 19.2037C17.2277 18.644 17.2225 18.3459 16.9403 17.7963C16.6567 17.2439 15.504 15.6846 16.2439 15.0804C16.5461 14.8337 17.1744 15.173 18.4311 15.8516L19.5454 16.4534Z`,stroke:`currentColor`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M13.0261 21.948C12.6888 21.9824 12.3464 22 12 22C6.47715 22 2 17.5228 2 12C2 6.47715 6.47715 2 12 2C17.5228 2 22 6.47715 22 12C22 12.6849 21.9311 13.3538 21.8 14`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.5`,key:`2`}]],Ra=[[`path`,{d:`M11.0809 13.152L8 7L13.4196 11.2796C14.1901 11.888 14.1941 13.0472 13.4277 13.6607C12.6614 14.2743 11.5189 14.0266 11.0809 13.152Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M5 4.82C3.14864 6.63902 2 9.17385 2 11.9776C2 17.5129 6.47715 22.0001 12 22.0001C17.5228 22.0001 22 17.5129 22 11.9776C22 7.1242 18.5581 3.07656 13.9872 2.15288C13.1512 1.98394 12.7332 1.89947 12.3666 2.20022C12 2.50097 12 2.98714 12 3.95949V4.96175`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}]],za=[[`path`,{d:`M15 2H10`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M4 13.5C4 8.80558 7.80558 5 12.5 5C14.8472 5 16.9722 5.95139 18.5104 7.48959M18.5104 7.48959C20.0486 9.02779 21 11.1528 21 13.5C21 18.1944 17.1944 22 12.5 22H3M18.5104 7.48959L20 6`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M8 19H3`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}],[`path`,{d:`M6 16H3`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`3`}],[`path`,{d:`M12.5 13.5L16 10`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`4`}]],Ba=[[`path`,{d:`M11 12C11 13.6569 9.65685 15 8 15C6.34315 15 5 13.6569 5 12C5 10.3431 6.34315 9 8 9C9.65685 9 11 10.3431 11 12Z`,stroke:`currentColor`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M16 6H8C4.68629 6 2 8.68629 2 12C2 15.3137 4.68629 18 8 18H16C19.3137 18 22 15.3137 22 12C22 8.68629 19.3137 6 16 6Z`,stroke:`currentColor`,strokeWidth:`1.5`,key:`1`}]],Va=[[`path`,{d:`M19 12C19 13.6569 17.6569 15 16 15C14.3431 15 13 13.6569 13 12C13 10.3431 14.3431 9 16 9C17.6569 9 19 10.3431 19 12Z`,stroke:`currentColor`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M16 6H8C4.68629 6 2 8.68629 2 12C2 15.3137 4.68629 18 8 18H16C19.3137 18 22 15.3137 22 12C22 8.68629 19.3137 6 16 6Z`,stroke:`currentColor`,strokeWidth:`1.5`,key:`1`}]],Ha=[[`path`,{d:`M14.4004 14C15.3717 13.0878 16 11.6356 16 10C16 7.23858 14.2091 5 12 5C9.79086 5 8 7.23858 8 10C8 11.6356 8.62827 13.0878 9.59961 14`,stroke:`currentColor`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M8.10669 14H15.8933C16.479 14 17 14.4143 17 15C17 16.5105 16.3302 18.0905 15.2713 19.1262C14.7465 19.6395 14.2349 20.1721 14.8701 20.8686C14.9657 20.9734 15.0766 21.0645 15.1698 21.1715C15.4978 21.5478 15.1458 22 14.7227 22H9.27729C8.85422 22 8.50218 21.5478 8.83018 21.1715C8.9234 21.0645 9.0343 20.9734 9.12991 20.8686C9.76509 20.1721 9.25347 19.6395 8.72869 19.1262C7.66984 18.0905 7 16.5105 7 15C7 14.4143 7.52097 14 8.10669 14Z`,stroke:`currentColor`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M18.2893 12C18.8844 12 19.3826 11.5702 19.4418 11.0059L19.8095 7.50176C20.0228 5.46884 20.1294 4.45238 19.7327 3.68365C18.746 1.77184 16.4338 2.00941 14.5944 2.00941H9.40559C7.56622 2.00941 5.25402 1.77184 4.26731 3.68365C3.87056 4.45238 3.9772 5.46884 4.1905 7.50176L4.55816 11.0059C4.61737 11.5702 5.11562 12 5.71068 12`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}]],Ua=[[`path`,{d:`M12 22V9`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M15 17H16C18.7614 17 21 14.7614 21 12C21 9.5807 19.2818 7.56271 16.999 7.09982C16.999 4.3384 15 2 12 2C9 2 7.00097 4.3384 7.00097 7.09982C4.71825 7.56271 3 9.5807 3 12C3 14.7614 5.23858 17 8 17H9`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M12 15L14.5 12.5`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}],[`path`,{d:`M12 13L9.5 10.5`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`3`}],[`path`,{d:`M10 22H14`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`4`}]],Wa=[[`path`,{d:`M2 14C2 10.2288 2 8.34315 3.17157 7.17157C4.34315 6 6.22876 6 10 6H14C17.7712 6 19.6569 6 20.8284 7.17157C22 8.34315 22 10.2288 22 14C22 17.7712 22 19.6569 20.8284 20.8284C19.6569 22 17.7712 22 14 22H10C6.22876 22 4.34315 22 3.17157 20.8284C2 19.6569 2 17.7712 2 14Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M9 3L12 6L16 2`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}]],Ga=[[`path`,{d:`M14 3H10C6.22876 3 4.34315 3 3.17157 4.17157C2 5.34315 2 7.22876 2 11C2 14.7712 2 16.6569 3.17157 17.8284C4.34315 19 6.22876 19 10 19H14C17.7712 19 19.6569 19 20.8284 17.8284C22 16.6569 22 14.7712 22 11C22 7.22876 22 5.34315 20.8284 4.17157C19.6569 3 17.7712 3 14 3Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M18 19L19 21`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M6 19L5 21`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}]],Ka=[[`path`,{d:`M2.99994 17C2.99994 17.93 2.99994 18.395 3.10216 18.7765C3.37956 19.8117 4.18821 20.6204 5.22348 20.8978C5.60498 21 6.06997 21 6.99994 21L16.9999 21C17.9299 21 18.3949 21 18.7764 20.8978C19.8117 20.6204 20.6203 19.8117 20.8977 18.7765C20.9999 18.395 20.9999 17.93 20.9999 17`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M16.5 7.49993C16.5 7.49993 13.1858 2.99997 12 2.99996C10.8141 2.99995 7.50002 7.49996 7.50002 7.49996M12 3.99996V16`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}]],qa=[[`path`,{d:`M14.5 8C14.5 5.23858 12.2614 3 9.5 3C6.73858 3 4.5 5.23858 4.5 8C4.5 10.7614 6.73858 13 9.5 13C12.2614 13 14.5 10.7614 14.5 8Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M2.5 20C2.5 16.134 5.63401 13 9.5 13C10.5736 13 11.5907 13.2417 12.5 13.6736`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M15.55 15.05L20.45 19.95M21.5 17.5C21.5 15.567 19.933 14 18 14C16.067 14 14.5 15.567 14.5 17.5C14.5 19.433 16.067 21 18 21C19.933 21 21.5 19.433 21.5 17.5Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}]],Ja=[[`path`,{d:`M15.5 11C15.5 9.067 13.933 7.5 12 7.5C10.067 7.5 8.5 9.067 8.5 11C8.5 12.933 10.067 14.5 12 14.5C13.933 14.5 15.5 12.933 15.5 11Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M15.4827 11.3499C15.8047 11.4475 16.1462 11.5 16.5 11.5C18.433 11.5 20 9.933 20 8C20 6.067 18.433 4.5 16.5 4.5C14.6851 4.5 13.1928 5.8814 13.0173 7.65013`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M10.9827 7.65013C10.8072 5.8814 9.31492 4.5 7.5 4.5C5.567 4.5 4 6.067 4 8C4 9.933 5.567 11.5 7.5 11.5C7.85381 11.5 8.19535 11.4475 8.51727 11.3499`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}],[`path`,{d:`M22 16.5C22 13.7386 19.5376 11.5 16.5 11.5`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`3`}],[`path`,{d:`M17.5 19.5C17.5 16.7386 15.0376 14.5 12 14.5C8.96243 14.5 6.5 16.7386 6.5 19.5`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`4`}],[`path`,{d:`M7.5 11.5C4.46243 11.5 2 13.7386 2 16.5`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`5`}]],Ya=[[`path`,{d:`M12.9981 6.5H11.0019C8.13196 6.5 6.19701 9.56909 7.32753 12.328C7.48501 12.7124 7.84633 12.9615 8.24612 12.9615H8.9491C9.18605 12.9615 9.39259 13.1302 9.45006 13.3706L10.3551 17.1567C10.5438 17.9462 11.222 18.5 12 18.5C12.778 18.5 13.4562 17.9462 13.6449 17.1567L14.5499 13.3706C14.6074 13.1302 14.814 12.9615 15.0509 12.9615H15.7539C16.1537 12.9615 16.515 12.7124 16.6725 12.328C17.803 9.56909 15.868 6.5 12.9981 6.5Z`,stroke:`currentColor`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M14.5 4C14.5 5.38071 13.3807 6.5 12 6.5C10.6193 6.5 9.5 5.38071 9.5 4C9.5 2.61929 10.6193 1.5 12 1.5C13.3807 1.5 14.5 2.61929 14.5 4Z`,stroke:`currentColor`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M7 16.5L6 16.5`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}],[`path`,{d:`M12 21.5L12 22.5`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`3`}],[`path`,{d:`M18 16.5L17 16.5`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`4`}]],Xa=[[`path`,{d:`M17 8.5C17 5.73858 14.7614 3.5 12 3.5C9.23858 3.5 7 5.73858 7 8.5C7 11.2614 9.23858 13.5 12 13.5C14.7614 13.5 17 11.2614 17 8.5Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M19 20.5C19 16.634 15.866 13.5 12 13.5C8.13401 13.5 5 16.634 5 20.5`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}]],Za=[[`path`,{d:`M19.439 15.439C20.3636 14.5212 21.0775 13.6091 21.544 12.955C21.848 12.5287 22 12.3155 22 12C22 11.6845 21.848 11.4713 21.544 11.045C20.1779 9.12944 16.6892 5 12 5C11.0922 5 10.2294 5.15476 9.41827 5.41827M6.74742 6.74742C4.73118 8.1072 3.24215 9.94266 2.45604 11.045C2.15201 11.4713 2 11.6845 2 12C2 12.3155 2.15201 12.5287 2.45604 12.955C3.8221 14.8706 7.31078 19 12 19C13.9908 19 15.7651 18.2557 17.2526 17.2526`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M9.85786 10C9.32783 10.53 9 11.2623 9 12.0711C9 13.6887 10.3113 15 11.9289 15C12.7377 15 13.47 14.6722 14 14.1421`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M3 3L21 21`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}]],Qa=[[`path`,{d:`M21.544 11.045C21.848 11.4713 22 11.6845 22 12C22 12.3155 21.848 12.5287 21.544 12.955C20.1779 14.8706 16.6892 19 12 19C7.31078 19 3.8221 14.8706 2.45604 12.955C2.15201 12.5287 2 12.3155 2 12C2 11.6845 2.15201 11.4713 2.45604 11.045C3.8221 9.12944 7.31078 5 12 5C16.6892 5 20.1779 9.12944 21.544 11.045Z`,stroke:`currentColor`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M15 12C15 10.3431 13.6569 9 12 9C10.3431 9 9 10.3431 9 12C9 13.6569 10.3431 15 12 15C13.6569 15 15 13.6569 15 12Z`,stroke:`currentColor`,strokeWidth:`1.5`,key:`1`}]],$a=[[`path`,{d:`M19 9C19.6254 9.81968 20 10.8634 20 12C20 13.1366 19.6254 14.1803 19 15`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M16 14.8135V9.18646C16 6.04126 16 4.46866 15.0747 4.0773C14.1494 3.68593 13.0604 4.79793 10.8823 7.02192C9.7544 8.17365 9.11086 8.42869 7.50605 8.42869C6.10259 8.42869 5.40086 8.42869 4.89677 8.77262C3.85036 9.48655 4.00854 10.882 4.00854 12C4.00854 13.118 3.85036 14.5134 4.89677 15.2274C5.40086 15.5713 6.10259 15.5713 7.50605 15.5713C9.11086 15.5713 9.7544 15.8264 10.8823 16.9781C13.0604 19.2021 14.1494 20.3141 15.0747 19.9227C16 19.5313 16 17.9587 16 14.8135Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}]],eo=[[`path`,{d:`M14 14.8135V9.18646C14 6.04126 14 4.46866 13.0747 4.0773C12.1494 3.68593 11.0603 4.79793 8.88232 7.02192C7.75439 8.17365 7.11085 8.42869 5.50604 8.42869C4.10257 8.42869 3.40084 8.42869 2.89675 8.77262C1.85035 9.48655 2.00852 10.882 2.00852 12C2.00852 13.118 1.85035 14.5134 2.89675 15.2274C3.40084 15.5713 4.10257 15.5713 5.50604 15.5713C7.11085 15.5713 7.75439 15.8264 8.88232 16.9781C11.0603 19.2021 12.1494 20.3141 13.0747 19.9227C14 19.5313 14 17.9587 14 14.8135Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M17 12L22 12`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.5`,key:`1`}]],to=[[`path`,{d:`M22 22L2 2`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M17 10C17.6296 10.7667 18 11.7054 18 12.7195C18 13.1635 17.929 13.593 17.7963 14`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M20 8C21.2508 9.22951 22 10.7952 22 12.5C22 13.9164 21.4829 15.2367 20.5906 16.348`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}],[`path`,{d:`M14 14C14 17.1452 14 19.5313 13.074 19.9227C12.1481 20.3141 11.0583 19.2021 8.8787 16.9781C7.7499 15.8264 7.106 15.5713 5.5 15.5713C4.3879 15.5713 3.02749 15.7187 2.33706 14.6643C2 14.1496 2 13.4331 2 12C2 10.5669 2 9.85038 2.33706 9.33566C3.02749 8.28131 4.3879 8.42869 5.5 8.42869C6.60725 8.42869 7.3569 8.43869 7.96 7.96M14 9.5C14 6.3548 14.026 4.46866 13.1 4.0773C12.3292 3.75147 11.5323 4.46765 10 6`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`3`}]],no=[[`path`,{d:`M14 14.8135V9.18646C14 6.04126 14 4.46866 13.0747 4.0773C12.1494 3.68593 11.0603 4.79793 8.88232 7.02192C7.75439 8.17365 7.11085 8.42869 5.50604 8.42869C4.10257 8.42869 3.40084 8.42869 2.89675 8.77262C1.85035 9.48655 2.00852 10.882 2.00852 12C2.00852 13.118 1.85035 14.5134 2.89675 15.2274C3.40084 15.5713 4.10257 15.5713 5.50604 15.5713C7.11085 15.5713 7.75439 15.8264 8.88232 16.9781C11.0603 19.2021 12.1494 20.3141 13.0747 19.9227C14 19.5313 14 17.9587 14 14.8135Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M17 12H22M19.5 14.5L19.5 9.5`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.5`,key:`1`}]],ro=[[`path`,{d:`M3.99847 14.0034V21.9997`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M3.99847 18.3026L7.95839 19.8479C10.4759 20.8303 11.7348 21.3216 12.6312 20.7699C13.5277 20.2182 13.5277 18.9524 13.5277 16.4205V8.0061`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M13.5512 2.99895V2.00024`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}],[`path`,{d:`M7.07806 8.00604H20.0015M9.34851 6.21058C8.70062 6.81563 8.57262 6.90994 8.39517 7.07597C8.14082 7.31396 8.0538 7.67835 8.14236 8.01464L10.196 15.8126C10.3301 16.3218 10.751 16.7057 11.2719 16.7938C12.7667 17.0466 14.2916 17.0556 15.786 16.7918C16.2798 16.7046 16.6788 16.3416 16.8109 15.8596L18.9668 7.98768C19.0519 7.67688 18.9918 7.33475 18.7674 7.10279C18.5846 6.91382 18.4566 6.84432 17.7779 6.21058C17.0255 5.50786 16.3052 4.23972 16.001 3.85472C15.6968 3.46971 15.4628 3.28072 15.0767 3.19345C14.0804 2.96823 13.0461 2.96823 12.0497 3.19345C11.6637 3.28072 11.4646 3.42312 11.1255 3.85472C10.7863 4.28631 10.101 5.50786 9.34851 6.21058Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`3`}]],io=[[`path`,{d:`M6 20V22M18 20V22`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M3 14V8C3 5.17157 3 3.75736 3.93037 2.87868C4.86073 2 6.35814 2 9.35294 2H14.6471C17.6419 2 19.1393 2 20.0696 2.87868C21 3.75736 21 5.17157 21 8V14C21 16.8284 21 18.2426 20.0696 19.1213C19.1393 20 17.6419 20 14.6471 20H9.35294C6.35814 20 4.86073 20 3.93037 19.1213C3 18.2426 3 16.8284 3 14Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M12 20V2`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}],[`path`,{d:`M3 14H12`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`3`}],[`path`,{d:`M3 8H12`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`4`}],[`path`,{d:`M15 11.5V10.5`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`5`}]],ao=[[`path`,{d:`M6 20V22M18 20V22`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M3 14V8C3 5.17157 3 3.75736 3.93037 2.87868C4.86073 2 6.35814 2 9.35294 2H14.6471C17.6419 2 19.1393 2 20.0696 2.87868C21 3.75736 21 5.17157 21 8V14C21 16.8284 21 18.2426 20.0696 19.1213C19.1393 20 17.6419 20 14.6471 20H9.35294C6.35814 20 4.86073 20 3.93037 19.1213C3 18.2426 3 16.8284 3 14Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M12 20V2`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}],[`path`,{d:`M9 10V11`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`3`}],[`path`,{d:`M15 10V11`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`4`}]],oo=[[`path`,{d:`M12.5 5.5H10.5C9.55719 5.5 9.08579 5.5 8.79289 5.79289C8.5 6.08579 8.5 6.55719 8.5 7.5V9.5C8.5 10.4428 8.5 10.9142 8.79289 11.2071C9.08579 11.5 9.55719 11.5 10.5 11.5H12.5C13.4428 11.5 13.9142 11.5 14.2071 11.2071C14.5 10.9142 14.5 10.4428 14.5 9.5V7.5C14.5 6.55719 14.5 6.08579 14.2071 5.79289C13.9142 5.5 13.4428 5.5 12.5 5.5Z`,stroke:`currentColor`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M13 11.5H10V21.5H13V11.5Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M7.5 21.5H15.5`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}],[`path`,{d:`M14.5 7H18.5C20.1569 7 21.5 8.34315 21.5 10V12.5H18.5V10H14.5V7Z`,stroke:`currentColor`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`3`}],[`path`,{d:`M14.5 2.5H9.09949C7.83781 2.5 7.20696 2.5 6.70992 2.82302C6.21288 3.14603 5.95667 3.7225 5.44425 4.87545L2.5 11.5`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`4`}],[`path`,{d:`M20 15.5L20.5582 14.9991C20.4159 14.8406 20.213 14.75 20 14.75C19.787 14.75 19.5841 14.8406 19.4418 14.9991L20 15.5ZM20.75 18C20.75 18.4142 20.4142 18.75 20 18.75V20.25C21.2426 20.25 22.25 19.2426 22.25 18H20.75ZM20 18.75C19.5858 18.75 19.25 18.4142 19.25 18H17.75C17.75 19.2426 18.7574 20.25 20 20.25V18.75ZM19.25 18C19.25 18.003 19.2507 17.969 19.2771 17.8886C19.3022 17.8119 19.343 17.7162 19.4012 17.6031C19.5182 17.3759 19.6824 17.1227 19.8589 16.8772C20.0335 16.6345 20.2097 16.4137 20.3431 16.2528C20.4094 16.1727 20.4644 16.1084 20.5023 16.0646C20.5212 16.0428 20.5358 16.0262 20.5454 16.0153C20.5502 16.0099 20.5537 16.0059 20.5559 16.0035C20.557 16.0023 20.5577 16.0015 20.5581 16.001C20.5583 16.0008 20.5584 16.0007 20.5584 16.0007C20.5584 16.0007 20.5584 16.0007 20.5584 16.0007C20.5584 16.0007 20.5583 16.0008 20.5583 16.0008C20.5583 16.0008 20.5582 16.0009 20 15.5C19.4418 14.9991 19.4417 14.9992 19.4417 14.9992C19.4416 14.9993 19.4415 14.9994 19.4415 14.9994C19.4414 14.9996 19.4412 14.9997 19.441 14.9999C19.4407 15.0003 19.4403 15.0008 19.4397 15.0014C19.4387 15.0026 19.4373 15.0042 19.4355 15.0061C19.432 15.0101 19.4271 15.0156 19.4209 15.0226C19.4085 15.0367 19.3909 15.0568 19.3688 15.0822C19.3246 15.1332 19.2625 15.2059 19.1882 15.2955C19.0403 15.4739 18.8415 15.7228 18.6411 16.0015C18.4426 16.2774 18.2318 16.5975 18.0675 16.9166C17.9157 17.2115 17.75 17.6053 17.75 18H19.25ZM20 15.5C19.4418 16.0009 19.4417 16.0008 19.4417 16.0008C19.4417 16.0008 19.4416 16.0007 19.4416 16.0007C19.4416 16.0007 19.4416 16.0007 19.4416 16.0007C19.4416 16.0007 19.4417 16.0008 19.4419 16.001C19.4423 16.0015 19.443 16.0023 19.4441 16.0035C19.4463 16.0059 19.4498 16.0099 19.4546 16.0153C19.4642 16.0262 19.4788 16.0428 19.4977 16.0646C19.5356 16.1084 19.5906 16.1727 19.6569 16.2528C19.7903 16.4137 19.9665 16.6345 20.1411 16.8772C20.3176 17.1227 20.4818 17.3759 20.5988 17.6031C20.657 17.7162 20.6978 17.8119 20.7229 17.8886C20.7493 17.969 20.75 18.003 20.75 18H22.25C22.25 17.6053 22.0843 17.2115 21.9325 16.9166C21.7682 16.5975 21.5574 16.2774 21.3589 16.0015C21.1585 15.7228 20.9597 15.4739 20.8118 15.2955C20.7375 15.2059 20.6754 15.1332 20.6312 15.0822C20.6091 15.0568 20.5915 15.0367 20.5791 15.0226C20.5729 15.0156 20.568 15.0101 20.5645 15.0061C20.5627 15.0042 20.5613 15.0026 20.5603 15.0014C20.5597 15.0008 20.5593 15.0003 20.559 14.9999C20.5588 14.9997 20.5586 14.9996 20.5585 14.9994C20.5585 14.9994 20.5584 14.9993 20.5583 14.9992C20.5583 14.9992 20.5582 14.9991 20 15.5Z`,fill:`currentColor`,key:`5`}],[`path`,{d:`M11.5 2.5V5.5`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`6`}]],so=[[`path`,{d:`M8.25 14.5C10.25 12.5 13.75 12.5 15.75 14.5`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M18.5 11.5C14.7324 8.16667 9.5 8.16667 5.5 11.5`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M2 8.5C8.31579 3.16669 15.6842 3.16668 22 8.49989`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}],[`circle`,{cx:`12`,cy:`18`,r:`1.5`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`3`}]],co=[[`path`,{d:`M12 20.5C11.0173 20.5 10.2863 19.503 8.82421 17.509L3.48742 9.73059C2.40801 8.25847 1.86831 7.52241 2.02741 6.57659C2.18651 5.63078 2.81754 5.2161 4.07962 4.38675C6.38289 2.87318 9.0958 2 12 2C14.9042 2 17.6171 2.87318 19.9204 4.38675C21.1825 5.2161 21.8135 5.63078 21.9726 6.57659C22.1317 7.52241 21.592 8.25847 20.5126 9.73059L16 16`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M19 13C14.6871 10.3333 9.31293 10.3333 5 13`,stroke:`currentColor`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M21 10C15.4548 6 8.54519 6 3 10`,stroke:`currentColor`,strokeWidth:`1.5`,key:`2`}],[`path`,{d:`M16 16C13.465 14.6667 10.535 14.6667 8 16`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.5`,key:`3`}],[`path`,{d:`M14 19C14 19 15 19 16 21C16 21 19.1765 16 22 15`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`4`}]],lo=[[`path`,{d:`M8.5 14.5C9.62137 13.3944 10.9643 12.887 12.5 13.0212`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M18.5 11.5C17.0073 10.1794 15.2848 9.27433 13.5 9.00012`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M5.5 11.4999C6.59299 10.5891 7.778 9.91296 9 9.49989`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}],[`path`,{d:`M22 8.49989C18.0717 5.18273 13.7362 3.92879 9.5 4.73808`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`3`}],[`path`,{d:`M2 8.5C3.22409 7.46632 4.5 6.5 5.5 6`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`4`}],[`circle`,{cx:`12`,cy:`18`,r:`1.5`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`5`}],[`path`,{d:`M2 2L22 22`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.5`,key:`6`}]];Yt({WindowsNewIcon:[[`path`,{d:`M13 3H11C7.22876 3 5.34315 3 4.17157 4.17157C3 5.34315 3 7.22876 3 11V13C3 16.7712 3 18.6569 4.17157 19.8284C5.34315 21 7.22876 21 11 21H13C16.7712 21 18.6569 21 19.8284 19.8284C21 18.6569 21 16.7712 21 13V11C21 7.22876 21 5.34315 19.8284 4.17157C18.6569 3 16.7712 3 13 3Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M12 3V21M3 12H21`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}]],GarageIcon:qr,CurtainsIcon:hr,BulbIcon:In,ZapIcon:[[`path`,{d:`M8.62814 12.6736H8.16918C6.68545 12.6736 5.94358 12.6736 5.62736 12.1844C5.31114 11.6953 5.61244 11.0138 6.21504 9.65083L8.02668 5.55323C8.57457 4.314 8.84852 3.69438 9.37997 3.34719C9.91142 3 10.5859 3 11.935 3H14.0244C15.6632 3 16.4826 3 16.7916 3.53535C17.1007 4.0707 16.6942 4.78588 15.8811 6.21623L14.8092 8.10188C14.405 8.81295 14.2029 9.16849 14.2057 9.45952C14.2094 9.83775 14.4105 10.1862 14.7354 10.377C14.9854 10.5239 15.3927 10.5239 16.2074 10.5239C17.2373 10.5239 17.7523 10.5239 18.0205 10.7022C18.3689 10.9338 18.5513 11.3482 18.4874 11.7632C18.4382 12.0826 18.0918 12.4656 17.399 13.2317L11.8639 19.3523C10.7767 20.5545 10.2331 21.1556 9.86807 20.9654C9.50303 20.7751 9.67833 19.9822 10.0289 18.3962L10.7157 15.2896C10.9826 14.082 11.1161 13.4782 10.7951 13.0759C10.4741 12.6736 9.85877 12.6736 8.62814 12.6736Z`,stroke:`currentColor`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}]],Home01Icon:ri,Sun01Icon:wa,Moon01Icon:ki,CloudIcon:dr,CloudMidRainIcon:lr,SnowIcon:pa,Wifi01Icon:so,Settings01Icon:ra,AlertCircleIcon:nn,Cancel01Icon:Gn,LockIcon:bi,SquareUnlock01Icon:xa,Camera01Icon:Hn,CctvCameraIcon:er,Mic01Icon:wi,Speaker01Icon:ga,Tv01Icon:Wa,ModernTvIcon:Oi,Sofa01Icon:ma,SpoonAndForkIcon:_a,KitchenUtensilsIcon:si,OfficeIcon:Li,BedIcon:Tn,DishWasherIcon:yr,Bathtub01Icon:bn,Bathtub02Icon:xn,ShoppingBag01Icon:ca,Add01Icon:O,Remove01Icon:Xi,ArrowUp01Icon:fn,ArrowDown01Icon:cn,ArrowLeft01Icon:un,ArrowRight01Icon:dn,PlayIcon:Gi,PauseIcon:Vi,StopIcon:Sa,NextIcon:Pi,PreviousIcon:Ji,Forward01Icon:Wr,Backward01Icon:gn,Plug01Icon:Ki,FlashIcon:Br,FireIcon:Rr,ThermometerWarmIcon:Fa,Fan01Icon:Pr,Lamp01Icon:li,Lamp02Icon:ui,Lamp03Icon:di,TableLamp01Icon:Da,WallLampIcon:ro,Car01Icon:qn,CalculateIcon:Ln,Time01Icon:Ia,UserIcon:Xa,DoorClosedIcon:Cr,DoorClosedLockedIcon:Sr,Door01Icon:br,Door02Icon:xr,CamperIcon:Wn,CalendarLock01Icon:Vn,Timer02Icon:za,Timer01Icon:Ra,BikeIcon:On,Motorbike02Icon:Mi,Car05Icon:Yn,CarAlertIcon:Xn,ShippingCenterIcon:oa,AmbulanceIcon:rn,Car03Icon:Jn,CarParking02Icon:Zn,SquareParkingOffIcon:ba,LampIcon:fi,LampWallDownIcon:pi,TableLamp02Icon:Oa,LampWallUpIcon:mi,LightbulbOffIcon:_i,Moon02Icon:Ai,FlashlightIcon:Hr,FlashlightOffIcon:Vr,SpotlightIcon:ya,LighthouseIcon:vi,AutomotiveBattery01Icon:mn,AutomotiveBattery02Icon:hn,CameraAutomatically01Icon:Un,CctvOffIcon:tr,Alert02Icon:tn,BellRingIcon:Dn,BellOffIcon:En,Notification01Icon:Fi,ApiGatewayIcon:an,File02Icon:Fr,BoxIcon:Nn,Tv02Icon:Ga,Mailbox01Icon:Ci,Tree02Icon:Ua,HousePlugIcon:ii,BathIcon:yn,ShowerHeadIcon:ua,Toilet02Icon:Ha,OfficeChairIcon:Ii,CanvasIcon:Kn,HeaterIcon:ti,TemperatureIcon:ja,PlateIcon:Ui,SpoonAndKnifeIcon:va,Knife02Icon:ci,SchoolBusIcon:$i,Wardrobe01Icon:io,Shirt01Icon:sa,Dress05Icon:Dr,BlushBrush01Icon:An,SmartPhone01Icon:fa,Beach02Icon:Sn,TestTube01Icon:Ma,GlobeIcon:Yr,Dumbbell01Icon:Ar,BedDoubleIcon:Cn,BedSingle01Icon:wn,ComputerDesk01Icon:pr,HammerIcon:Xr,StudyDeskIcon:Ca,Wardrobe02Icon:ao,Sink02Icon:da,ShovelIcon:la,Chair02Icon:ir,Yoga02Icon:[[`path`,{d:`M7.88598 10C8.57173 11.3968 9.30442 12.7049 9.1352 14.3142C8.86468 16.8869 5.74512 17.8552 3.75022 19.0404C2.44325 19.8169 2.9319 22 4.53582 22C6.48047 22 8.21607 21.8448 9.9706 21.0201L13.4111 18.9028C13.8887 18.6783 14.4913 18.774 15 19`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M16.0105 10C15.3102 11.3968 14.562 12.7049 14.7348 14.3142C15.0111 16.8869 18.1967 17.8552 20.2339 19.0404C21.5685 19.8169 21.0695 22 19.4316 22C17.4458 22 15.6734 21.8448 13.8817 21.0201L10.3683 18.9028C9.95819 18.714 9.45777 18.7517 9 18.9028`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M10 4C10 5.10457 10.8954 6 12 6C13.1046 6 14 5.10457 14 4C14 2.89543 13.1046 2 12 2C10.8954 2 10 2.89543 10 4Z`,stroke:`currentColor`,strokeWidth:`1.5`,key:`2`}],[`path`,{d:`M3 16C5.44586 16 6.54368 13.2949 6.89335 11.4291C6.98463 10.9421 7.13246 10.4565 7.45625 10.0814C8.55651 8.80674 10.184 8 12 8C13.816 8 15.4435 8.80674 16.5437 10.0814C16.8675 10.4565 17.0154 10.9421 17.1067 11.4291C17.4563 13.2949 18.5541 16 21 16`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`3`}]],BodyPartMuscleIcon:jn,ChefIcon:or,MixerIcon:Di,Backward02Icon:_n,Forward02Icon:Gr,Mic02Icon:Ti,MicOff01Icon:Ei,VolumeLowIcon:$a,VolumeMinusIcon:eo,VolumeUpIcon:no,VolumeOffIcon:to,HangerIcon:Zr,TaskDone02Icon:Aa,SecurityCheckIcon:ta,CloudRainWindIcon:ur,DesertIcon:vr,SunCloudAngledRainZap02Icon:Ea,CellularNetworkIcon:rr,CellularNetworkOfflineIcon:nr,Calendar02Icon:zn,Flag03Icon:zr,Navigation03Icon:Ni,PinIcon:Hi,UserRoadsideIcon:Ya,BanIcon:vn,UserBlock01Icon:qa,ShieldBanIcon:aa,DropletOffIcon:Or,DropletIcon:kr,BubblesIcon:Fn,IslandIcon:oi,WaterPumpIcon:oo,FirstBracketIcon:Qt,WorkoutRunIcon:[[`path`,{d:`M17 4.5C17 5.32843 16.3284 6 15.5 6C14.6716 6 14 5.32843 14 4.5C14 3.67157 14.6716 3 15.5 3C16.3284 3 17 3.67157 17 4.5Z`,stroke:`currentColor`,strokeWidth:`1.5`,key:`0`}],[`path`,{d:`M15 21.0008L14.3359 18.3848C14.1161 17.5191 13.6615 16.7284 13.0207 16.0974L11.5 14.5998M6 11.1534C7 9.18366 8.53767 8.0423 12 8.00136M12 8.00136C12.2186 7.99877 12.5444 7.99799 12.8698 7.99805C13.3747 7.99813 13.6271 7.99818 13.8282 8.09214C14.0293 8.18609 14.2356 8.43256 14.6482 8.92548C14.7664 9.06672 14.8878 9.19326 15 9.27743M12 8.00136L10.7309 9.95956C10.0332 11.0362 9.68429 11.5745 9.67069 12.1397C9.66463 12.3914 9.70617 12.642 9.79313 12.8784C9.98834 13.409 10.4922 13.8059 11.5 14.5998M15 9.27743C16.1547 10.1433 17.9627 10.4921 20 8.19913M15 9.27743L11.5 14.5998`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`1`}],[`path`,{d:`M4 17.7303L4.67822 17.8916C6.40663 18.3028 8.20324 17.5164 9 16`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`,key:`2`}]]});var uo=()=>({getItem:()=>null,setItem:()=>void 0,removeItem:()=>void 0});function fo(e){let t,n=new Set,r=()=>t,i=(e,r=!1)=>{let i=typeof e==`function`?e(t):e,a=r||t===void 0?i:{...t,...i};if(Object.is(a,t))return;let o=t;t=a,n.forEach(e=>e(t,o))},a=e=>(n.add(e),()=>n.delete(e)),o=()=>n.clear();return t=e(i,r,{getState:r,setState:i,subscribe:a,destroy:o}),{getState:r,setState:i,subscribe:a,destroy:o}}function po(e){return typeof e==`function`?fo(e):e===void 0?e=>fo(e):fo(()=>e)}function mo(e,t){let{name:n,storage:r,version:i=0,merge:a}=t;return(t,o,s)=>{let c,l=()=>{if(c!==void 0)return c;if(r){try{c=typeof r==`function`?r():r}catch{c=void 0}return c}},u=e=>{let t=l();if(!t)return;let r=e??o();t.setItem(n,{state:r,version:i})},d=e((e,n)=>{t(e,n),u()},o,s),f=d,p=l();if(p){let e=p.getItem(n);if(e)try{e.version===i?f=a?a(e.state,d):{...d,...e.state}:p.removeItem(n)}catch{p.removeItem(n)}u(f)}return f}}function ho(e){return()=>{try{let t=e();return t?{getItem:e=>{let n=t.getItem(e);return n?JSON.parse(n):null},setItem:(e,n)=>{t.setItem(e,JSON.stringify(n))},removeItem:e=>{t.removeItem(e)}}:uo()}catch{return uo()}}}var go=class e{static{this.CONNECTING=0}static{this.OPEN=1}static{this.CLOSED=2}constructor(e,t={}){this.lastEventId=``,this.reconnectDelay=1e3,this.maxReconnectDelay=3e4,this.handlingUnauthorized=!1,this.listeners=new Map,this._readyState=0,this.url=e,this.config=t,this.connect()}get readyState(){return this._readyState}connect(){if(this._readyState===e.CLOSED)return;this._readyState=e.CONNECTING,this.reconnectTimeout!==void 0&&(clearTimeout(this.reconnectTimeout),this.reconnectTimeout=void 0);let t=new XMLHttpRequest;this.xhr=t,t.open(`GET`,this.url,!0),t.setRequestHeader(`Accept`,`text/event-stream`),t.setRequestHeader(`Cache-Control`,`no-cache`),this.lastEventId&&t.setRequestHeader(`Last-Event-ID`,this.lastEventId);let n=this.config.getHeaders?.()??this.config.headers;n&&Object.entries(n).forEach(([e,n])=>{t.setRequestHeader(e,n)}),this.config.withCredentials&&(t.withCredentials=!0);let r=``,i=0,a=``,o=``,s=``;t.onprogress=()=>{if(this.xhr!==t)return;r=t.responseText;let e=r.substring(i).split(/\r\n|\r|\n/);for(let t=0;t<e.length-1;t++){let n=e[t];if(i+=n.length+1,n===``){o&&(this.dispatchEvent(a||`message`,o,s),a=``,o=``,s=``);continue}if(n.startsWith(`:`))continue;let r=n.indexOf(`:`);if(r===-1)continue;let c=n.substring(0,r),l=n.substring(r+1);switch(l.startsWith(` `)&&(l=l.substring(1)),c){case`event`:a=l;break;case`data`:o+=(o?`
`:``)+l;break;case`id`:s=l,this.lastEventId=l;break;case`retry`:let e=parseInt(l,10);isNaN(e)||(this.reconnectDelay=e);break}}},t.onloadstart=()=>{this.xhr===t&&this._readyState===e.CONNECTING&&(this._readyState=e.OPEN,this.onopen?.(new Event(`open`)))},t.onerror=()=>{this.xhr!==t||this._readyState===e.CLOSED||this.handleError()},t.onabort=()=>{this.xhr!==t||this._readyState===e.CLOSED||this.handleError()},t.onloadend=async()=>{if(!(this.xhr!==t||this._readyState===e.CLOSED))if(t.status===200)this.scheduleReconnect();else if(t.status===401&&this.config.onUnauthorized&&!this.handlingUnauthorized){this.handlingUnauthorized=!0;try{await this.config.onUnauthorized()?(this.reconnectDelay=1e3,this.connect()):this.handleError()}finally{this.handlingUnauthorized=!1}}else this.handleError()},t.send()}dispatchEvent(e,t,n){let r;try{r=new URL(this.url).origin}catch{r=window.location.origin}let i=new MessageEvent(e,{data:t,lastEventId:n,origin:r});this.onmessage&&this.onmessage({type:i.type,payload:JSON.parse(i.data||`{}`)});let a=this.listeners.get(e);a&&a.forEach(e=>e(i))}handleError(){this._readyState=e.CONNECTING,this.onerror?.(new Event(`error`)),this.scheduleReconnect()}scheduleReconnect(){this._readyState!==e.CLOSED&&this.reconnectTimeout===void 0&&(this.reconnectTimeout=window.setTimeout(()=>{this.reconnectTimeout=void 0,this.connect(),this.reconnectDelay=Math.min(this.reconnectDelay*1.5,this.maxReconnectDelay)},this.reconnectDelay))}addEventListener(e,t){this.listeners.has(e)||this.listeners.set(e,new Set),this.listeners.get(e).add(t)}removeEventListener(e,t){let n=this.listeners.get(e);n&&n.delete(t)}close(){this._readyState=e.CLOSED,this.reconnectTimeout!==void 0&&(clearTimeout(this.reconnectTimeout),this.reconnectTimeout=void 0),this.xhr&&=(this.xhr.onprogress=null,this.xhr.onloadstart=null,this.xhr.onerror=null,this.xhr.onabort=null,this.xhr.onloadend=null,this.xhr.abort(),void 0),this.listeners.clear(),this.onmessage=void 0,this.onerror=void 0,this.onopen=void 0}},_o=Array.from({length:256},(e,t)=>t.toString(16).padStart(2,`0`)),vo=e=>(e[6]=e[6]&15|64,e[8]=e[8]&63|128,[`${_o[e[0]]}${_o[e[1]]}${_o[e[2]]}${_o[e[3]]}`,`${_o[e[4]]}${_o[e[5]]}`,`${_o[e[6]]}${_o[e[7]]}`,`${_o[e[8]]}${_o[e[9]]}`,`${_o[e[10]]}${_o[e[11]]}${_o[e[12]]}${_o[e[13]]}${_o[e[14]]}${_o[e[15]]}`].join(`-`)),yo=()=>{let e=globalThis.crypto;return e&&typeof e.randomUUID==`function`?e.randomUUID():e&&typeof e.getRandomValues==`function`?vo(e.getRandomValues(new Uint8Array(16))):`fallback-${`${Date.now().toString(16)}-${Math.random().toString(16).slice(2,14)}`}`},bo=new class{constructor(){this.config=null,this.language=`en`,this.catalogs={},this.loading=new Map}configure(e){this.config=e,this.language=e.fallbackLanguage,this.catalogs={},this.loading.clear()}async initialize(e){let t=this.getConfig();await this.loadCatalog(t.fallbackLanguage);let n=localStorage.getItem(this.storageKey),r=t.detectLanguage?.()||this.detectBrowserLanguage(),i=this.resolveLanguage(e||n||r);return await this.setLanguage(i),i}async setLanguage(e){let t=this.resolveLanguage(e);return await this.loadCatalog(t),this.language=t,localStorage.setItem(this.storageKey,t),document.documentElement.lang=t,t}getLanguage(){return this.language}transform(e,t){if(e==null)return``;if(!this.config)return e;let n=this.getConfig(),r=this.catalogs[this.language],i=this.catalogs[n.fallbackLanguage],a=r?.[e]??i?.[e],o=a===void 0?this.matchParameterizedKey(e,r)??this.matchParameterizedKey(e,i):void 0,s=a??o?.template??e,c={...o?.values||{},...t||{}};return Object.keys(c).length===0?s:s.replace(/\{\{\s*([\w.-]+)\s*\}\}/g,(e,t)=>{let n=c[t];return n==null?e:String(n)})}matchParameterizedKey(e,t){if(t)for(let[n,r]of Object.entries(t)){let t=[],i=n.split(/(\{\{\s*[\w.-]+\s*\}\})/g).map(e=>{let n=e.match(/^\{\{\s*([\w.-]+)\s*\}\}$/);return n?(t.push(n[1]),`(.+?)`):e.replace(/[.*+?^${}()|[\]\\]/g,`\\$&`)}).join(``);if(t.length===0)continue;let a=e.match(RegExp(`^${i}$`));if(a)return{template:r,values:Object.fromEntries(t.map((e,t)=>[e,a[t+1]]))}}}get storageKey(){return this.getConfig().storageKey||`app.language`}getConfig(){if(!this.config)throw Error(`i18n is not configured`);return this.config}resolveLanguage(e){let t=this.getConfig();if(!e)return t.fallbackLanguage;let n=e.toLowerCase();return t.supportedLanguages.find(e=>n===e.toLowerCase()||n.startsWith(`${e.toLowerCase()}-`))||t.fallbackLanguage}detectBrowserLanguage(){return(navigator.languages||[navigator.language]).find(Boolean)}async loadCatalog(e){if(this.catalogs[e])return;let t=this.loading.get(e);if(t)return t;let n=this.getConfig().loaders[e];if(!n)return;let r=n().then(t=>{this.catalogs[e]=`default`in t?t.default:t,this.loading.delete(e)});return this.loading.set(e,r),r}},xo=e=>bo.configure(e),So=e=>bo.initialize(e),Co=e=>bo.setLanguage(e),wo=()=>bo.getLanguage(),j=(e,t)=>bo.transform(e,t),M=new class{constructor(){this.toasts=[],this.listeners=new Set}getToasts(){return this.toasts}show(e){let t=yo(),n={id:t,message:j(e.message),details:e.details,variant:e.variant||`error`,duration:e.duration??1e4,actionLabel:e.actionLabel?j(e.actionLabel):void 0,action:e.action};return this.toasts=[...this.toasts,n],this.notify(),t}remove(e){this.toasts=this.toasts.filter(t=>t.id!==e),this.notify()}subscribe(e){return this.listeners.add(e),()=>this.listeners.delete(e)}notify(){this.listeners.forEach(e=>e())}},To=``,Eo=()=>To,Do=e=>{To=e},Oo=()=>{To=``},ko=`modulepreload`,Ao=function(e){return`/`+e},jo={},Mo=function(e,t,n){let r=Promise.resolve();if(t&&t.length>0){let e=document.getElementsByTagName(`link`),i=document.querySelector(`meta[property=csp-nonce]`),a=i?.nonce||i?.getAttribute(`nonce`);function o(e){return Promise.all(e.map(e=>Promise.resolve(e).then(e=>({status:`fulfilled`,value:e}),e=>({status:`rejected`,reason:e}))))}r=o(t.map(t=>{if(t=Ao(t,n),t in jo)return;jo[t]=!0;let r=t.endsWith(`.css`),i=r?`[rel="stylesheet"]`:``;if(n)for(let n=e.length-1;n>=0;n--){let i=e[n];if(i.href===t&&(!r||i.rel===`stylesheet`))return}else if(document.querySelector(`link[href="${t}"]${i}`))return;let o=document.createElement(`link`);if(o.rel=r?`stylesheet`:ko,r||(o.as=`script`),o.crossOrigin=``,o.href=t,a&&o.setAttribute(`nonce`,a),document.head.appendChild(o),r)return new Promise((e,n)=>{o.addEventListener(`load`,e),o.addEventListener(`error`,()=>n(Error(`Unable to preload CSS for ${t}`)))})}))}function i(e){let t=new Event(`vite:preloadError`,{cancelable:!0});if(t.payload=e,window.dispatchEvent(t),!t.defaultPrevented)throw e}return r.then(t=>{for(let e of t||[])e.status===`rejected`&&i(e.reason);return e().catch(i)})},No=`/api`;function Po(e){if(e==null)return e;if(Array.isArray(e))return e.map(Po);if(typeof e==`object`){let t={};for(let[n,r]of Object.entries(e))n.startsWith(`_`)||(t[n]=Po(r));return t}return e}var N=new class{getAuthHeaders(){let e=Eo(),t={"Content-Type":`application/json`,"Accept-Language":localStorage.getItem(`portal.language`)===`pl`?`pl`:`en`};return e&&(t.Authorization=`Bearer ${e}`),t}getAuthHeadersRecord(){let e=Eo(),t={"Accept-Language":localStorage.getItem(`portal.language`)===`pl`?`pl`:`en`};return e&&(t.Authorization=`Bearer ${e}`),t}resolveUrl(e){return/^https?:\/\//i.test(e)||e.startsWith(`/api/`)?e:`${No}${e}`}async request(e,t,n=!0,r=!0){let i=await fetch(this.resolveUrl(e),{...t,credentials:`same-origin`,headers:{...this.getAuthHeaders(),...t?.headers}});if(!i.ok){let a=await i.json().catch(()=>({message:`Request failed`}));console.log(`API Error:`,a);let o=a?.error?.message||a?.message||`HTTP ${i.status}`;if(i.status===401){let{authStore:i,refreshAuthToken:a}=await Mo(async()=>{let{authStore:e,refreshAuthToken:t}=await Promise.resolve().then(()=>Fo);return{authStore:e,refreshAuthToken:t}},void 0),s=/\/auth\/(?:login|refresh|logout)(?:[/?]|$)/i.test(this.resolveUrl(e));if(r&&!s&&await a())return this.request(e,t,n,!1);throw await i.getState().logout(),Error(o)}M.show({message:o,details:a?.error?.details||a?.details});let s=Error(o);throw s.code=a?.error?.code||a?.code,s.details=a?.error?.details||a?.details,s.status=i.status,s}let a=await i.json(),o=t?.method?.toUpperCase();return n&&(o===`POST`||o===`PUT`||o===`PATCH`||o===`DELETE`)&&M.show({message:`OK`,variant:`success`,duration:2e3}),a}get(e,t){if(t){let n=new URLSearchParams;for(let[e,r]of Object.entries(t))if(r!=null){let t=typeof r==`object`?JSON.stringify(r):String(r);n.set(e,t)}let r=n.toString();e=r?`${e}?${r}`:e}return this.request(e)}post(e,t,n){return this.request(e,{method:`POST`,body:JSON.stringify(Po(t))},n?.notify??!0)}put(e,t,n=!0){return this.request(e,{method:`PUT`,body:JSON.stringify(Po(t))},n)}patch(e,t){return this.request(e,{method:`PATCH`,body:t?JSON.stringify(Po(t)):void 0})}delete(e,t){return this.request(e,{method:`DELETE`,body:t===void 0?void 0:JSON.stringify(Po(t))})}sse(e){return new go(this.resolveUrl(e),{getHeaders:()=>this.getAuthHeadersRecord(),onUnauthorized:async()=>{let{refreshAuthToken:e}=await Mo(async()=>{let{refreshAuthToken:e}=await Promise.resolve().then(()=>Fo);return{refreshAuthToken:e}},void 0);return e()},withCredentials:!1})}upload(e,t,n){return this.request(e,{method:`POST`,body:t,headers:n})}async blobUrl(e,t,n=!0){let r=await fetch(this.resolveUrl(e),{signal:t,headers:this.getAuthHeadersRecord()});if(r.status===401&&n){let{refreshAuthToken:n}=await Mo(async()=>{let{refreshAuthToken:e}=await Promise.resolve().then(()=>Fo);return{refreshAuthToken:e}},void 0);if(await n())return this.blobUrl(e,t,!1)}if(!r.ok)throw Error(`Cannot load media: HTTP ${r.status}`);let i=await r.blob();return URL.createObjectURL(i)}},Fo=t({authStore:()=>F,configureAuth:()=>fs,refreshAuthToken:()=>us}),Io=`/api`;function Lo(e){return/^https?:\/\//i.test(e)||e.startsWith(`/api/`)?e:e.startsWith(`api/`)?`/${e}`:`${Io}${e}`}var P=null,Ro=null,zo=null,Bo=null,Vo=!1,Ho=null,Uo=!1,Wo=`nq-auth-token-refresh`,Go=`nq-auth-token-refresh-lock`,Ko=3e4,qo=typeof crypto<`u`&&typeof crypto.randomUUID==`function`?crypto.randomUUID():`${Date.now()}-${Math.random()}`;function Jo(){let e=Eo(),t={"Content-Type":`application/json`};return e&&(t.Authorization=`Bearer ${e}`),t}function Yo(e){let t=e.token||e.accessToken||e.access_token;if(!t)throw Error(`Missing access token in response`);return t}function Xo(e){try{let t=JSON.parse(atob(e.split(`.`)[1]));return t.exp?t.exp*1e3:null}catch{return null}}function Zo(e=6e4){let t=Eo();if(!t)return!1;let n=Xo(t);return n===null||n>Date.now()+e}function Qo(e){return new Promise(t=>window.setTimeout(t,e))}async function $o(e){let t=Date.now()+Ko;for(;Date.now()<t;){let t=Date.now(),n=null;try{n=JSON.parse(localStorage.getItem(Go)||`null`)}catch{n=null}if(!n?.owner||!n.expiresAt||n.expiresAt<=t||n.owner===qo){localStorage.setItem(Go,JSON.stringify({owner:qo,expiresAt:t+Ko})),await Qo(25+Math.floor(Math.random()*25));try{if(JSON.parse(localStorage.getItem(Go)||`null`)?.owner===qo)try{return await e()}finally{JSON.parse(localStorage.getItem(Go)||`null`)?.owner===qo&&localStorage.removeItem(Go)}}catch{}}await Qo(100)}return e()}async function es(e){let t=navigator.locks;return t?t.request(Wo,e):$o(e)}var ts=2147483647;function ns(){Ro&&=(clearTimeout(Ro),null);let e=Eo();if(!e||!P)return;let t=Xo(e);if(!t)return;let n=t-Date.now()-6e4;if(n<=0){ls();return}Ro=window.setTimeout(()=>ns(),Math.min(n,ts))}async function rs(e,t){let n=await fetch(Lo(e),{method:`POST`,credentials:`same-origin`,headers:{"Content-Type":`application/json`},body:JSON.stringify(t)});if(!n.ok)throw Error(`HTTP ${n.status}`);return n.json()}async function is(e){let t=await fetch(Lo(e),{method:`GET`,credentials:`same-origin`,headers:Jo()});if(!t.ok)throw Error(`HTTP ${t.status}`);return t.json()}function as(){let e=P?.endpoints.callbackPath||P?.oauth?.callbackPath||`/oauth-callback`;return`${window.location.origin}${e}`}function os(){return!!(P?.oauth||P?.endpoints.callbackPath)}async function ss(e){let t=P.oauth;if(!t.tokenUrl)throw Error(`OAuth tokenUrl is not configured`);let n=await fetch(t.tokenUrl,{method:`POST`,credentials:`same-origin`,headers:{"Content-Type":`application/json`},body:JSON.stringify(t.clientSecret?{...e,client_id:t.clientId,client_secret:t.clientSecret}:{...e,client_id:t.clientId})});if(!n.ok){let e=await n.json().catch(()=>({}));throw Error(e.error_description||`HTTP ${n.status}`)}return n.json()}async function cs(){return P?.oauth?(Do(Yo(await ss({grant_type:`refresh_token`}))),localStorage.removeItem(`refreshToken`),!0):!1}async function ls(){return zo||(zo=es(async()=>{if(!P)return!1;if(Zo())return ns(),!0;try{Ho?.postMessage({type:`refreshing`})}catch{}try{let e;P.oauth&&!P.endpoints.refresh?(await cs(),e=Eo()):(e=Yo(await rs(P.endpoints.refresh,{})),Do(e));try{Ho?.postMessage({type:`refreshed`,token:e})}catch{}return ns(),!0}catch{return Zo()?(ns(),!0):(Oo(),localStorage.removeItem(`refreshToken`),localStorage.removeItem(`user`),F.setState({isLoggedIn:!1,user:null}),!1)}finally{zo=null}}),zo)}async function us(){return ls()}function ds(){if(!Ho)try{Ho=new BroadcastChannel(`auth-token-refresh`),Ho.onmessage=e=>{let t=e.data;t.type===`refreshing`&&(Ro&&=(clearTimeout(Ro),null)),t.type===`refreshed`&&(Do(t.token),ns()),t.type===`logout`&&(Uo=!0,F.getState().logout())}}catch{}}var F=po()(mo((e,t)=>({user:null,isLoggedIn:!1,isInitialized:!1,configure:e=>{P=e},initialize:async()=>{if(Bo)return Bo;if(!t().isInitialized)return Bo=(async()=>{try{ds();let t=Eo();if(!P){e({isInitialized:!0,isLoggedIn:!1,user:null});return}if(!t){if(!await ls()){e({isInitialized:!0,isLoggedIn:!1,user:null});return}t=Eo()}let n=t?Xo(t):null;if(n&&n<Date.now()&&!await ls()){e({isInitialized:!0});return}e({isLoggedIn:!0,user:await is(P.endpoints.me),isInitialized:!0}),ns(),await P.onLogin?.()}catch{Oo(),localStorage.removeItem(`refreshToken`),localStorage.removeItem(`user`),e({isLoggedIn:!1,user:null,isInitialized:!0})}finally{Bo=null}})(),Bo},login:async(t,n)=>{if(!P)throw Error(`Auth not configured`);if(os()){if(P.oauth){let e=P.oauth,t=new URLSearchParams({response_type:`code`,client_id:e.clientId,redirect_uri:as(),scope:e.scope});window.location.href=`${e.authorizationUrl}?${t}`;return}let e=P.endpoints.login;if(!e)throw Error(`OAuth login endpoint is not configured`);let t=new URLSearchParams({redirect_uri:as()});window.location.href=`${e}?${t.toString()}`;return}if(!t||!n)throw Error(`Email and password required`);let r=await N.post(P.endpoints.login,{email:t.toLowerCase().trim(),password:n});Do(Yo(r)),localStorage.removeItem(`refreshToken`),e({isLoggedIn:!0,user:r.user,isInitialized:!0}),ds(),ns(),await P.onLogin?.()},handleOAuthCallback:async t=>{if(!P||!os())throw Error(`OAuth not configured`);let n=P.endpoints.exchange||`/api/auth/exchange`;if(n){let r=await rs(n,{code:t,redirectUri:as()});Do(Yo(r)),localStorage.removeItem(`refreshToken`),r.user?e({isLoggedIn:!0,user:r.user,isInitialized:!0}):e({isLoggedIn:!0,user:await is(P.endpoints.me),isInitialized:!0})}else Do(Yo(await ss({grant_type:`authorization_code`,code:t,redirect_uri:as()}))),localStorage.removeItem(`refreshToken`),e({isLoggedIn:!0,user:await is(P.endpoints.me),isInitialized:!0});ds(),ns(),await P.onLogin?.()},logout:async()=>{if(Vo)return;Vo=!0;let t=Uo;if(Uo=!1,Ro&&=(clearTimeout(Ro),null),Oo(),localStorage.removeItem(`refreshToken`),localStorage.removeItem(`user`),localStorage.removeItem(Go),e({isLoggedIn:!1,user:null}),!t)try{Ho?.postMessage({type:`logout`})}catch{}!t&&P?.endpoints.logout&&await rs(P.endpoints.logout,{}).catch(()=>void 0),os()&&P?.endpoints.logout?window.location.href=P.endpoints.logout:P?.oauth?window.location.href=P.oauth.logoutUrl:window.location.reload()},fetchMe:async()=>{if(!P)throw Error(`Auth not configured`);return await N.get(P.endpoints.me)},updateMe:async t=>{if(!P)throw Error(`Auth not configured`);let n=await N.put(P.endpoints.me,t);return e({user:n}),n},changePassword:async(e,t)=>{if(os()&&P?.endpoints.changePassword){window.location.href=P.endpoints.changePassword;return}if(!P?.endpoints.changePassword)throw Error(`Change password not configured`);await N.post(P.endpoints.changePassword,{currentPassword:e,newPassword:t})}}),{name:`auth-storage`,storage:ho(()=>localStorage),merge:(e,t)=>({...t,isLoggedIn:e.isLoggedIn??!1,user:e.user??null})}));function fs(e){P=e}function ps(e){let t=e.filter(e=>e.parent===null).sort((e,t)=>e.order-t.order),n=t=>{let r=e.filter(e=>e.parent===t.id).sort((e,t)=>e.order-t.order).map(n);return{id:t.id,label:t.name,data:{type:t.parent===null?`zone`:`subzone`,icon:t.icon,onlineVisible:t.onlineVisible??!1},children:r.length>0?r:void 0}};return t.map(n)}function ms(e,t){let n=e.find(e=>e.id===t);return n?e.filter(e=>e.parent===n.parent).sort((e,t)=>e.order-t.order):[]}function hs(e,t){let n=e.find(e=>e.id===t);if(!n)return``;let r=[n.name],i=n;for(;i.parent;){let t=e.find(e=>e.id===i.parent);if(!t)break;r.unshift(t.name),i=t}return r.join(`: `)}var I=po()((e,t)=>({zones:[],loading:!1,error:null,initialized:!1,getTree:()=>ps(t().zones),getFlatZonesWithParents:()=>{let e=t().zones;return e.map(t=>({id:t.id,name:t.name,fullPath:hs(e,t.id),zone:t})).sort((e,t)=>e.fullPath.localeCompare(t.fullPath))},initializeIfNeeded:async()=>{let e=t();e.initialized||e.loading||await t().fetchZones()},fetchZones:async()=>{e({loading:!0,error:null});try{e({zones:(await N.get(`/zones`)).map(e=>({id:e._id,name:e.name,icon:e.icon||``,parent:e.parent||null,order:e.order??0,onlineVisible:e.onlineVisible??!1})),loading:!1,initialized:!0})}catch(t){e({error:t.message||`Failed to fetch zones`,loading:!1}),console.error(`Failed to fetch zones:`,t)}},addZone:async(n,r,i,a=!1)=>{let o=t(),s=n??null,c=o.zones.filter(e=>e.parent===s),l=c.length>0?Math.max(...c.map(e=>e.order)):-1;try{let t=await N.post(`/zones`,{name:r,icon:i||void 0,order:l+1,parent:s,onlineVisible:a});e({zones:[...o.zones,{id:t._id,name:t.name,icon:t.icon||``,parent:t.parent||null,order:t.order??0,onlineVisible:t.onlineVisible??!1}]})}catch(t){throw e({error:t.message||`Failed to add zone`}),console.error(`Failed to add zone:`,t),t}},updateZone:async(n,r,i,a)=>{let o=t(),s=o.zones.find(e=>e.id===n);if(s)try{let t=await N.put(`/zones/${n}`,{name:r,icon:i??s.icon??``,order:s.order,parent:s.parent,onlineVisible:a??s.onlineVisible??!1});e({zones:o.zones.map(e=>e.id===n?{...e,name:t.name,icon:t.icon||``,onlineVisible:t.onlineVisible??!1}:e)})}catch(t){throw e({error:t.message||`Failed to update zone`}),console.error(`Failed to update zone:`,t),t}},deleteZone:async n=>{let r=t(),i=new Set,a=e=>{i.add(e),r.zones.filter(t=>t.parent===e).forEach(e=>a(e.id))};a(n);try{await N.delete(`/zones/${n}`),e({zones:r.zones.filter(e=>!i.has(e.id))})}catch(t){throw e({error:t.message||`Failed to delete zone`}),console.error(`Failed to delete zone:`,t),t}},getZoneById:e=>{let n=t(),r=n.zones.find(t=>t.id===e);return r&&(r.fullName=hs(n.zones,e)),r},moveZoneTo:async(t,n,r)=>{try{e({zones:(await N.post(`/zones/${t}/move`,{parent:n,order:r})).map(e=>({id:e._id,name:e.name,icon:e.icon||``,parent:e.parent||null,order:e.order??0,onlineVisible:e.onlineVisible??!1}))})}catch(t){throw e({error:t.message||`Failed to move zone`}),console.error(`Failed to move zone:`,t),t}},moveZone:async(n,r)=>{let i=t(),a=ms(i.zones,n),o=a.findIndex(e=>e.id===n);if(o===-1)return;let s=r===`up`?o-1:o+1;if(s<0||s>=a.length)return;let c=a[o],l=a[s];try{await Promise.all([N.put(`/zones/${c.id}`,{name:c.name,icon:c.icon||void 0,order:l.order,parent:c.parent}),N.put(`/zones/${l.id}`,{name:l.name,icon:l.icon||void 0,order:c.order,parent:l.parent})]),e({zones:i.zones.map(e=>e.id===c.id?{...e,order:l.order}:e.id===l.id?{...e,order:c.order}:e)})}catch(t){throw e({error:t.message||`Failed to move zone`}),console.error(`Failed to move zone:`,t),t}}}));function gs(e,t){if(!t)return``;let n=e.find(e=>e.id===t);if(!n)return``;let r=[n.name],i=n;for(;i.parent;){let t=e.find(e=>e.id===i.parent);if(!t)break;r.unshift(t.name),i=t}return r.join(`: `)}function _s(e){let t=gs(I.getState().zones,e.zone);return{...e,_fullName:[t,e.name].filter(Boolean).join(`: `)}}var L=po()((e,t)=>({devices:[],loading:!1,error:null,getDevicesByZone:e=>t().devices.filter(t=>t.zone===e),getDeviceById:e=>t().devices.find(t=>t._id===e),getTags:()=>{let e=new Set;return t().devices.forEach(t=>{(t.tags||[]).forEach(t=>{let n=String(t||``).trim();n&&e.add(n)})}),Array.from(e).sort((e,t)=>e.localeCompare(t))},updateDeviceState:(n,r)=>{e({devices:t().devices.map(e=>e._id===n?{...e,state:{...e.state,...r},lastSeenAt:new Date}:e)})},setDeviceState:async(e,n)=>{try{await N.post(`/cards/${e}/state`,{state:n}),t().updateDeviceState(e,n)}catch(e){throw console.error(`Failed to set card state:`,e),e}},sendCommand:async(e,t)=>{try{return await N.post(`/cards/${e}/command`,t)}catch(e){throw console.error(`Failed to send card command:`,e),e}},setDevices:t=>{e({devices:t})},addDevice:async n=>{try{let r=_s(await N.post(`/cards`,n));return e({devices:[...t().devices,r]}),r}catch(e){throw console.error(`Failed to add card:`,e),e}},updateDevice:async(n,r)=>{try{let i=_s(await N.put(`/cards/${n}`,r));return e({devices:t().devices.map(e=>e._id===n?i:e)}),i}catch(e){throw console.error(`Failed to update card:`,e),e}},updateCardsOrder:async n=>{try{let r=await N.post(`/cards/order`,{cards:n}),i=new Map(r.map(e=>[e._id,e]));return e({devices:t().devices.map(e=>i.get(e._id)||e)}),r}catch(e){throw console.error(`Failed to update cards order:`,e),e}},deleteDevice:async n=>{try{await N.delete(`/cards/${n}`),e({devices:t().devices.filter(e=>e._id!==n)})}catch(e){throw console.error(`Failed to delete card:`,e),e}},fetchDevices:async()=>{try{e({loading:!0,error:null}),await I.getState().initializeIfNeeded(),e({devices:(await N.get(`/cards`)).map(_s),loading:!1})}catch(t){e({error:t instanceof Error?t.message:`Failed to fetch cards`,loading:!1}),console.error(`Failed to fetch cards:`,t)}},getCardHistory:async(e,t)=>N.get(`/cards/${e}/history`,t)}));fs({endpoints:{login:`/auth/login`,logout:`/auth/logout`,me:`/auth/me`,refresh:`/auth/refresh`,changePassword:`/auth/change-password`},onLogin:async()=>{await I.getState().initializeIfNeeded(),L.getState().fetchDevices()}});var vs=class extends _t{constructor(e){if(super(e),this.it=y,e.type!==ht.CHILD)throw Error(this.constructor.directiveName+`() can only be used in child bindings`)}render(e){if(e===y||e==null)return this._t=void 0,this.it=e;if(e===Ae)return e;if(typeof e!=`string`)throw Error(this.constructor.directiveName+`() called with a non-string value`);if(e===this.it)return this._t;this.it=e;let t=[e];return t.raw=t,this._t={_$litType$:this.constructor.resultType,strings:t,values:[]}}};vs.directiveName=`unsafeHTML`,vs.resultType=1;var ys=gt(vs),bs=class extends vs{};bs.directiveName=`unsafeSVG`,bs.resultType=2;var xs=gt(bs),Ss=new Set([`path`,`circle`,`rect`,`line`,`polyline`,`polygon`,`ellipse`]),Cs=new Set(`d.cx.cy.r.rx.ry.x.y.x1.y1.x2.y2.width.height.viewbox.points.fill.stroke.stroke-width.stroke-linecap.stroke-linejoin.stroke-miterlimit.stroke-dasharray.stroke-dashoffset.stroke-opacity.fill-opacity.fill-rule.clip-rule.opacity.transform`.split(`.`)),ws=new Set([`fill`,`stroke`,`stroke-width`,`stroke-linecap`,`stroke-linejoin`,`stroke-miterlimit`,`stroke-dasharray`,`stroke-dashoffset`,`stroke-opacity`,`fill-opacity`,`fill-rule`,`clip-rule`,`opacity`]),Ts=/([:\w-]+)\s*=\s*(?:"([^"]*)"|'([^']*)')/g,Es=/<(path|circle|rect|line|polyline|polygon|ellipse)\b([^>]*)\/?>/gi,Ds=e=>{let t=e.trim().toLowerCase();return!t.includes(`javascript:`)&&!t.includes(`<`)&&!t.includes(`>`)&&!t.includes(`url(`)},Os=e=>{let t={};for(let n of e.matchAll(Ts)){let e=n[1].toLowerCase(),r=n[2]??n[3]??``;!Cs.has(e)||!Ds(r)||(t[e]=r)}return t},ks=e=>{if(!e)return;let t=e.trim();return/^-?\d+(\.\d+)?\s+-?\d+(\.\d+)?\s+\d+(\.\d+)?\s+\d+(\.\d+)?$/.test(t)?t:void 0},As=e=>String(e).replace(/&/g,`&amp;`).replace(/"/g,`&quot;`),js=e=>typeof e==`string`&&e.trim().toLowerCase().startsWith(`<svg`),Ms=e=>{if(!js(e))return{elements:[]};let t=e.trim(),n=t.match(/^<svg\b([^>]*)>/i);if(!n||!/<\/svg>\s*$/i.test(t))return{elements:[]};let r=Os(n[1]),i=Object.fromEntries(Object.entries(r).filter(([e])=>ws.has(e))),a=[];for(let e of t.matchAll(Es)){let t=e[1].toLowerCase();if(!Ss.has(t))continue;let n={...i,...Os(e[2])};Object.keys(n).length>0&&a.push([t,n])}return{elements:a,viewBox:ks(r.viewbox),fill:r.fill}},Ns=(e,t=`24`)=>{let n=e=>`elements`in e,r=n(e)?e.elements:e,i=n(e)&&e.viewBox||`0 0 24 24`,a=n(e)&&e.fill||`none`,o=r.map(([e,t])=>`<${e} ${Object.entries(t).map(([e,t])=>`${e}="${As(t)}"`).join(` `)}/>`).join(``);return`<svg width="${As(t)}" height="${As(t)}" viewBox="${As(i)}" fill="${As(a)}" xmlns="http://www.w3.org/2000/svg">${o}</svg>`},Ps=new Map,Fs=e=>js(e),Is=e=>{if(!e)return;if(!Fs(e))return Xt(e);let t=Ps.get(e);if(t)return t;let n=Ms(e);if(n.elements.length!==0)return Ps.set(e,n),n},Ls=class extends b{constructor(...e){super(...e),this.size=`24`}static{this.styles=c`
		:host {
			display: inline-flex;
			align-items: center;
			justify-content: center;
		}

		svg {
			width: var(--icon-size, 24px);
			height: var(--icon-size, 24px);
		}
	`}getIconSize(){return/^-?\d+(\.\d+)?$/.test(String(this.size))?`${this.size}px`:String(this.size)}willUpdate(){let e=this.getIconSize();this.style.setProperty(`--icon-size`,e),this.style.width=e,this.style.height=e}render(){let e=this.name?Is(this.name):this.icon;return e?v`${ys(Ns(e,this.size))}`:v``}};D([S({attribute:!1}),E(`design:type`,Object)],Ls.prototype,`icon`,void 0),D([S({type:String}),E(`design:type`,String)],Ls.prototype,`name`,void 0),D([S({type:String}),E(`design:type`,Object)],Ls.prototype,`size`,void 0),Ls=D([x(`app-icon`)],Ls);var Rs=class extends w{constructor(...e){super(...e),this.placement=`auto`,this.isOpen=!1,this.popoverStyle={left:`0px`}}handleMouseEnter(e){e.currentTarget.classList.contains(`popover-trigger`)&&this.updatePopoverPosition(e),this.isOpen=!0}handleMouseLeave(){this.isOpen=!1}getFixedPositionContext(e){let t=e.parentElement;for(;t&&t!==document.body;){let e=window.getComputedStyle(t);if(e.transform!==`none`||e.perspective!==`none`||e.filter!==`none`||e.backdropFilter!==`none`||e.contain.includes(`paint`)||e.willChange.includes(`transform`))return t.getBoundingClientRect();t=t.parentElement}return new DOMRect(0,0,window.innerWidth,window.innerHeight)}getPopoverWidth(e,t=220){let n=this.querySelector(`.popover`)?.offsetWidth||t;return Math.min(n,e)}getCenteredHorizontal(e,t,n=220){let r=t.width||window.innerWidth,i=Math.max(120,r-16),a=this.getPopoverWidth(i,n),o=e-t.left-a/2,s=Math.max(8,r-a-8);return{left:Math.min(Math.max(o,8),s),maxWidth:i}}updatePopoverPosition(e){let t=e.currentTarget,n=t.getBoundingClientRect(),r=this.getFixedPositionContext(t),i=r.bottom||window.innerHeight,a=r.right||window.innerWidth,o=this.getCenteredHorizontal(n.left+n.width/2,r);if(this.placement===`right`){this.popoverStyle={top:`${n.top-r.top+n.height/2}px`,left:`${n.right-r.left+6}px`,maxWidth:`${o.maxWidth}px`};return}if(this.placement===`left`){this.popoverStyle={top:`${n.top-r.top+n.height/2}px`,right:`${a-n.left+6}px`,maxWidth:`${o.maxWidth}px`};return}if(this.placement===`top`){this.popoverStyle={bottom:`${i-n.top+6}px`,left:`${o.left}px`,maxWidth:`${o.maxWidth}px`};return}if(this.placement===`bottom`){this.popoverStyle={top:`${n.bottom-r.top+6}px`,left:`${o.left}px`,maxWidth:`${o.maxWidth}px`};return}let s=i-n.bottom,c=n.top-r.top;s>=206||s>c?this.popoverStyle={top:`${n.bottom-r.top+6}px`,left:`${o.left}px`,maxWidth:`${o.maxWidth}px`}:this.popoverStyle={bottom:`${i-n.top+6}px`,left:`${o.left}px`,maxWidth:`${o.maxWidth}px`}}render(){let e=this.popoverStyle,t=this.placement===`right`||this.placement===`left`?`transform: translateY(-50%);`:``,n=`
      ${e.top?`top: ${e.top};`:``}
      ${e.bottom?`bottom: ${e.bottom};`:``}
      ${e.left?`left: ${e.left};`:``}
      ${e.right?`right: ${e.right};`:``}
      ${e.maxWidth?`max-width: ${e.maxWidth};`:``}
      ${t}
    `;return v`
      <div class="popover-wrap">
        <div 
          class="popover-trigger"
          @mouseenter=${this.handleMouseEnter}
          @mouseleave=${this.handleMouseLeave}
        >
          ${this.trigger}
        </div>

        <div 
          class="popover ${this.isOpen?`show`:``}"
          style="${n}"
          @mouseenter=${this.handleMouseEnter}
          @mouseleave=${this.handleMouseLeave}
        >
          ${this.content}
        </div>
      </div>
    `}};D([S({attribute:!1}),E(`design:type`,Object)],Rs.prototype,`trigger`,void 0),D([S({attribute:!1}),E(`design:type`,Object)],Rs.prototype,`content`,void 0),D([S({type:String}),E(`design:type`,Object)],Rs.prototype,`placement`,void 0),D([C(),E(`design:type`,Object)],Rs.prototype,`isOpen`,void 0),D([C(),E(`design:type`,Object)],Rs.prototype,`popoverStyle`,void 0),Rs=D([x(`app-popover`)],Rs);function zs(e,t){let n=t.split(`.`),r=e;for(let e of n){if(r==null)return;r=r[e]}return r}var R=class extends b{constructor(...e){super(...e),this.key=``,this.props={},this.model={},this.inputClass=`form-control`}createRenderRoot(){return this}getValue(){return this.value===void 0?zs(this.model,this.key):this.value}updateModel(e){let t=new CustomEvent(`field-change`,{detail:{key:this.key,value:e,model:{...this.model,[this.key]:e}},bubbles:!0,composed:!0});this.dispatchEvent(t)}handleChange(e){let t=e.target;this.updateModel(t.value)}handleInput(e){let t=e.target;this.updateModel(t.value)}renderHelp(e){return this.props.help?v`
      <span
        class="form-label-help"
        @click=${e=>e.stopPropagation()}
      >
        <app-popover
          placement="auto"
          .trigger=${v`
            <span
              class="form-help-button"
              tabindex="0"
              role="button"
              aria-label="${e} help"
            >
              <app-icon .icon=${ni} size="15"></app-icon>
            </span>
          `}
          .content=${v`
            <div class="form-help-content">
              ${this.translateContent(this.props.help)}
            </div>
          `}
        ></app-popover>
      </span>
    `:``}renderLabel(){return this.props.label?v`
      <label
        class="form-label"
      >
        <span>${j(this.props.label)}</span>
        ${this.props.required?v`<span class="text-danger">*</span>`:``}
        ${this.renderHelp(j(this.props.label))}
      </label>
    `:``}renderDescription(){return this.props.description?v`
      <div class="form-description">${this.translateContent(this.props.description)}</div>
    `:``}renderHelper(){return this.props.helperText?v`
      <div class="form-text">${this.translateContent(this.props.helperText)}</div>
    `:``}translateContent(e){return typeof e==`string`?j(e):e}render(){return v`
      <div class="form-field">
        ${this.renderLabel()}
        ${this.renderDescription()}
        <div class="position-relative">
          ${this.renderField()}
        </div>
        ${this.renderHelper()}
      </div>
    `}};D([S({type:String}),E(`design:type`,String)],R.prototype,`key`,void 0),D([S({type:Object}),E(`design:type`,Object)],R.prototype,`props`,void 0),D([S({type:Object}),E(`design:type`,Object)],R.prototype,`model`,void 0),D([S({type:Array}),E(`design:type`,Array)],R.prototype,`fieldArray`,void 0),D([S(),E(`design:type`,Object)],R.prototype,`value`,void 0);var Bs=gt(class extends _t{constructor(){super(...arguments),this.key=y}render(e,t){return this.key=e,t}update(e,[t,n]){return t!==this.key&&(ft(e),this.key=t),n}});function Vs(e,t){let n=t.split(`.`),r=e;for(let e of n){if(r==null)return;r=r[e]}return r}function Hs(e,t,n){let r=t.split(`.`),i=e;for(let e=0;e<r.length-1;e++){let t=r[e];(!i[t]||typeof i[t]!=`object`)&&(i[t]={}),i=i[t]}i[r[r.length-1]]=n}var Us=class extends R{isFieldHidden(e,t){return e.hide===void 0?!1:typeof e.hide==`boolean`?e.hide:e.hide(t)}processFields(e,t){e.forEach(e=>{e.fieldGroup?this.processFields(e.fieldGroup,t):t(e)})}getElementName(e){let t=e.name.replace(/([a-z])([A-Z])/g,`$1-$2`).toLowerCase().replace(/field$/,``);return customElements.get(t)?t:null}renderNestedField(e,t,n){if(this.isFieldHidden(e,t))return``;if(e.fieldGroup)return this.renderFieldGroup(e,t,n);if(e.template){let r=e.className||``,i=typeof e.template==`function`?e.template(t,n):e.template;return r?v`<div class="${r}">${i}</div>`:i}let r=null;if(typeof e.type==`string`?r=e.type:e.type&&(r=this.getElementName(e.type)),!r)return console.error(`Cannot determine element name for field`,e),``;let i=Wt(r),a=e.key?Vs(t,e.key):void 0,o=e.className||``,s=o?Kt`
      <div class="${o}">
        <${i}
          .key=${e.key}
          .value=${a}
          .props=${e.props||{}}
          .fieldArray=${e.fieldArray}
          .model=${t}
          @field-change=${n}
        ></${i}>
      </div>
    `:Kt`
      <${i}
        .key=${e.key}
        .value=${a}
        .props=${e.props||{}}
        .fieldArray=${e.fieldArray}
        .model=${t}
        @field-change=${n}
      ></${i}>
    `;return e.renderKey===void 0?s:Bs(typeof e.renderKey==`function`?e.renderKey(t):e.renderKey,s)}renderFieldGroup(e,t,n){return e.fieldGroup?v`
      <div class="field-group ${e.fieldGroupClassName||``}">
        ${e.fieldGroup.map(e=>this.renderNestedField(e,t,n))}
      </div>
    `:``}initializeNestedFieldHooks(e,t){this.processFields(e,e=>{e.hooks?.onInit&&e.hooks.onInit(e,t)})}triggerFieldHooks(e,t,n,r){let i=a=>{a.forEach(a=>{if(a.fieldGroup){i(a.fieldGroup);return}a.key===t&&a.hooks?.onModelChange&&a.hooks.onModelChange(n,r,a,e)})};i(e)}refreshParentForm(){this.closest(`app-form-fields`)?.requestUpdate();let e=this.closest(`input-accordion`);e!==this&&e?.requestUpdate()}},Ws=class extends R{disconnectedCallback(){super.disconnectedCallback(),this.inputTimer!==void 0&&window.clearTimeout(this.inputTimer)}handleTextInput(e){let t=e.target.value,n=Number(this.props.debounceMs??500);if(n<=0){this.updateModel(t);return}this.inputTimer!==void 0&&window.clearTimeout(this.inputTimer),this.inputTimer=window.setTimeout(()=>{this.inputTimer=void 0,this.updateModel(t)},n)}handleTextChange(e){this.inputTimer!==void 0&&(window.clearTimeout(this.inputTimer),this.inputTimer=void 0),this.updateModel(e.target.value)}renderField(){let e=this.getValue()??``;return v`
      <input
        type="text"
        class="${this.inputClass}"
        .value=${e}
        placeholder=${j(this.props.placeholder||``)}
        ?required=${this.props.required}
        ?disabled=${this.props.disabled}
        ?readonly=${this.props.readonly}
        @input=${this.handleTextInput}
        @change=${this.handleTextChange}
      />
    `}};Ws=D([x(`input-text`)],Ws);var Gs=class extends w{constructor(...e){super(...e),this.variant=`primary`,this.size=`md`,this.background=!1,this.outline=!1,this.disabled=!1,this.type=`button`,this.className=``}getVariantClass(){return this.outline?`btn-outline-${this.variant}`:(this.background,`btn-${this.variant}`)}render(){let e=this.iconSize||{sm:`16`,md:`20`,lg:`24`}[this.size],t=this.size===`md`?``:`btn-${this.size}`;return v`
      <button
        type=${this.type}
        ?disabled=${this.disabled}
        class="btn ${this.getVariantClass()} ${t} ${this.className}"
      >
        ${this.icon?v`<app-icon .icon=${this.icon} size=${e}></app-icon>`:``}
        ${this.label?v`<span>${j(this.label)}</span>`:``}
        <slot></slot>
        ${this.iconRight?v`<app-icon .icon=${this.iconRight} size=${e}></app-icon>`:``}
        ${this.badge?v`
              <span class="btn-badge">
                ${this.badge}
              </span>
            `:``}
      </button>
    `}};D([S({type:String}),E(`design:type`,Object)],Gs.prototype,`variant`,void 0),D([S({type:String}),E(`design:type`,Object)],Gs.prototype,`size`,void 0),D([S({type:Boolean}),E(`design:type`,Object)],Gs.prototype,`background`,void 0),D([S({type:Boolean}),E(`design:type`,Boolean)],Gs.prototype,`outline`,void 0),D([S({type:Boolean}),E(`design:type`,Boolean)],Gs.prototype,`disabled`,void 0),D([S({attribute:!1}),E(`design:type`,Object)],Gs.prototype,`icon`,void 0),D([S({attribute:!1}),E(`design:type`,Object)],Gs.prototype,`iconRight`,void 0),D([S({type:String}),E(`design:type`,String)],Gs.prototype,`iconSize`,void 0),D([S({type:String}),E(`design:type`,String)],Gs.prototype,`label`,void 0),D([S({type:String}),E(`design:type`,String)],Gs.prototype,`badge`,void 0),D([S({type:String}),E(`design:type`,String)],Gs.prototype,`type`,void 0),D([S({type:String}),E(`design:type`,String)],Gs.prototype,`className`,void 0),Gs=D([x(`app-button`)],Gs);var Ks=class extends b{constructor(...e){super(...e),this.disabled=!1,this.separator=!1,this.submenuOpen=!1,this.submenuStyle=``,this.handleConfirmedClick=e=>{e.target===this&&(!(e instanceof CustomEvent)||!e.detail?.confirmedAction||this.emitItemClick())}}createRenderRoot(){return this}connectedCallback(){super.connectedCallback(),this.addEventListener(`click`,this.handleConfirmedClick)}disconnectedCallback(){super.disconnectedCallback(),this.removeEventListener(`click`,this.handleConfirmedClick)}handleClick(e){this.disabled||this.separator||this.submenu||this.emitItemClick()}emitItemClick(){this.dispatchEvent(new CustomEvent(`item-click`,{detail:{label:this.label},bubbles:!0,composed:!0}))}handleMouseEnter(){this.submenu&&(this.submenuOpen=!0,this.updateComplete.then(()=>this.positionSubmenu()))}handleMouseLeave(){this.submenu&&(this.submenuOpen=!1,this.submenuStyle=``)}positionSubmenu(){let e=this.querySelector(`.dropdown-submenu`),t=this.querySelector(`.dropdown-item-wrap`);if(!e||!t)return;let n=t.getBoundingClientRect(),r=e.getBoundingClientRect(),i=n.right+r.width>window.innerWidth-8,a=Math.max(8,Math.min(n.top,window.innerHeight-r.height-8))-n.top;this.submenuStyle=`${i?`right:calc(100% - 1px);left:auto;`:`left:calc(100% - 1px);right:auto;`}top:${a}px;`}render(){return this.separator?v`<div class="dropdown-divider"></div>`:v`
      <div 
        class="dropdown-item-wrap"
        @mouseenter=${this.handleMouseEnter}
        @mouseleave=${this.handleMouseLeave}
      >
        <button
          @click=${this.handleClick}
          ?disabled=${this.disabled}
          class="dropdown-item ${this.submenuOpen?`show`:``}"
        >
          ${this.icon?v`<app-icon .icon=${this.icon} size="18"></app-icon>`:``}
          <span class="flex-grow-1">${j(this.label)}</span>
          ${this.submenu?v`<app-icon .icon=${dn} size="16" class="dropdown-indicator"></app-icon>`:``}
        </button>

        ${this.submenu&&this.submenuOpen?v`
              <div class="dropdown-menu dropdown-submenu show" style=${this.submenuStyle}>
                ${this.submenu}
              </div>
            `:``}
      </div>
    `}};D([S({type:String}),E(`design:type`,String)],Ks.prototype,`label`,void 0),D([S({attribute:!1}),E(`design:type`,Object)],Ks.prototype,`icon`,void 0),D([S({type:Boolean}),E(`design:type`,Object)],Ks.prototype,`disabled`,void 0),D([S({type:Boolean}),E(`design:type`,Object)],Ks.prototype,`separator`,void 0),D([S({attribute:!1}),E(`design:type`,Object)],Ks.prototype,`submenu`,void 0),D([C(),E(`design:type`,Object)],Ks.prototype,`submenuOpen`,void 0),D([C(),E(`design:type`,Object)],Ks.prototype,`submenuStyle`,void 0),Ks=D([x(`app-dropdown-item`)],Ks);var qs=class extends b{constructor(...e){super(...e),this.align=`left`,this.alignRight=!1,this.showIndicator=!0,this.plainTrigger=!1,this.fixedMenu=!1,this.matchTriggerWidth=!1,this.isOpen=!1,this.fixedMenuStyle=``,this.dropdownId=yo(),this.handleMenuClickCapture=e=>{let t=e.target;if(!(t instanceof Element)||!t.closest(`[data-dropdown-menu]`))return;if(t.closest(`[data-dropdown-close]`)){setTimeout(()=>this.close(),0);return}let n=t.closest(`app-dropdown-item`);!n||n.disabled||n.separator||n.submenu||setTimeout(()=>this.close(),0)},this.handleItemClick=()=>{this.close()},this.handleClickOutside=e=>{let t=e.target;!this.contains(t)&&!this.portalElement?.contains(t)&&this.close()},this.handlePointerDownOutside=e=>{if(!this.isOpen)return;let t=e.target;!this.contains(t)&&!this.portalElement?.contains(t)&&this.close()},this.handleDropdownOpen=e=>{e.detail?.id!==this.dropdownId&&this.close()},this.handleViewportChange=()=>{this.fixedMenu&&this.isOpen&&this.scheduleFixedMenuPosition()}}createRenderRoot(){return this}handleTriggerClick(e){e.stopPropagation();let t=!this.isOpen;t&&document.dispatchEvent(new CustomEvent(`app-dropdown-open`,{detail:{id:this.dropdownId}})),this.isOpen=t,this.dispatchOpenChange(),t||this.cleanupPortal()}close(){let e=this.isOpen;this.isOpen=!1,this.cleanupPortal(),e&&this.dispatchOpenChange()}dispatchOpenChange(){this.dispatchEvent(new CustomEvent(`dropdown-open-change`,{detail:{open:this.isOpen},bubbles:!0,composed:!0}))}updateFixedMenuPosition(){let e=this.querySelector(`[data-dropdown-trigger]`),t=this.portalElement?.querySelector(`[data-dropdown-menu]`);if(!e||!t)return;let n=e.getBoundingClientRect(),r=t.getBoundingClientRect(),i=this.alignRight||this.align===`right`?n.right-r.width:n.left;i=Math.max(8,Math.min(i,window.innerWidth-r.width-8));let a=window.innerHeight-n.bottom-8-8,o=n.top-8-8,s=r.height+32>a&&o>a,c=Math.max(0,s?o:a),l=Math.min(r.height,c),u=s?Math.max(8,n.top-l-8):n.bottom+8,d=c,f=this.matchTriggerWidth?`width:${n.width}px;`:``;this.fixedMenuStyle=`left:${i}px;top:${u}px;max-height:${d}px;${f}`}scheduleFixedMenuPosition(){this.positionFrame&&cancelAnimationFrame(this.positionFrame),this.positionFrame=requestAnimationFrame(()=>{this.positionFrame=void 0,this.updateFixedMenuPosition()})}ensurePortalElement(){return this.portalElement||(this.portalElement=document.createElement(`div`),this.portalElement.dataset.dropdownPortal=this.dropdownId,this.portalElement.addEventListener(`click`,this.handleMenuClickCapture,{capture:!0}),document.body.appendChild(this.portalElement)),this.portalElement}refreshMenu(){if(!this.fixedMenu||!this.isOpen)return;let e=this.ensurePortalElement();Ke(this.renderMenu(!0),e),this.dispatchEvent(new CustomEvent(`dropdown-menu-rendered`,{detail:{open:this.isOpen},bubbles:!0,composed:!0})),this.scheduleFixedMenuPosition()}cleanupPortal(){this.positionFrame&&=(cancelAnimationFrame(this.positionFrame),void 0),this.portalElement&&=(this.portalElement.removeEventListener(`click`,this.handleMenuClickCapture,{capture:!0}),Ke(v``,this.portalElement),this.portalElement.remove(),void 0),this.fixedMenuStyle=``}renderMenu(e=!1){let t=this.alignRight||this.align===`right`?`dropdown-menu-end`:``,n=e?`dropdown-menu-fixed`:`dropdown-menu-popover`,r=e?this.fixedMenuStyle:``;return v`
      <div
        data-dropdown-menu
        class="dropdown-menu ${n} ${t} ${this.isOpen&&(!e||this.fixedMenuStyle)?`show`:``}"
        style=${r}
        @item-click=${this.handleItemClick}
      >
        ${this.menu}
      </div>
    `}updated(){if(!this.fixedMenu||!this.isOpen){this.cleanupPortal();return}this.refreshMenu()}connectedCallback(){super.connectedCallback(),this.addEventListener(`click`,this.handleMenuClickCapture,{capture:!0}),document.addEventListener(`click`,this.handleClickOutside),document.addEventListener(`pointerdown`,this.handlePointerDownOutside,!0),document.addEventListener(`app-dropdown-open`,this.handleDropdownOpen),window.addEventListener(`resize`,this.handleViewportChange),window.addEventListener(`scroll`,this.handleViewportChange,!0)}disconnectedCallback(){super.disconnectedCallback(),this.removeEventListener(`click`,this.handleMenuClickCapture,{capture:!0}),document.removeEventListener(`click`,this.handleClickOutside),document.removeEventListener(`pointerdown`,this.handlePointerDownOutside,!0),document.removeEventListener(`app-dropdown-open`,this.handleDropdownOpen),window.removeEventListener(`resize`,this.handleViewportChange),window.removeEventListener(`scroll`,this.handleViewportChange,!0),this.cleanupPortal()}render(){let e=this.trigger&&typeof this.trigger==`object`&&!(`_$litType$`in this.trigger),t=this.plainTrigger?`dropdown-toggle plain`:`dropdown-toggle ${e?`button-trigger`:``}`,n=e?v`
          <app-button
            variant=${this.trigger.variant||`primary`}
            size=${this.trigger.size||`md`}
            .icon=${this.trigger.icon}
            .iconRight=${this.showIndicator?this.isOpen?fn:cn:void 0}
            label=${this.trigger.label||``}
            .badge=${this.trigger.badge}
            className=${this.trigger.className||``}
            ?disabled=${this.trigger.disabled}
            ?outline=${this.trigger.outline}
          ></app-button>
        `:v`
          ${this.trigger}
          ${this.showIndicator&&this.isOpen?v`<app-icon .icon=${fn} size="16" class="dropdown-indicator"></app-icon>`:this.showIndicator?v`<app-icon .icon=${cn} size="16" class="dropdown-indicator"></app-icon>`:``}
        `;return v`
      <div class="dropdown dropdown-inline">
        <div data-dropdown-trigger @click=${this.handleTriggerClick} class=${t}>
          ${n}
        </div>
        
        ${this.fixedMenu?``:this.renderMenu(!1)}
      </div>
    `}};D([S({attribute:!1}),E(`design:type`,Object)],qs.prototype,`trigger`,void 0),D([S({attribute:!1}),E(`design:type`,Object)],qs.prototype,`menu`,void 0),D([S({type:String}),E(`design:type`,String)],qs.prototype,`align`,void 0),D([S({type:Boolean}),E(`design:type`,Object)],qs.prototype,`alignRight`,void 0),D([S({type:Boolean}),E(`design:type`,Object)],qs.prototype,`showIndicator`,void 0),D([S({type:Boolean}),E(`design:type`,Object)],qs.prototype,`plainTrigger`,void 0),D([S({type:Boolean}),E(`design:type`,Object)],qs.prototype,`fixedMenu`,void 0),D([S({type:Boolean}),E(`design:type`,Object)],qs.prototype,`matchTriggerWidth`,void 0),D([C(),E(`design:type`,Object)],qs.prototype,`isOpen`,void 0),D([C(),E(`design:type`,Object)],qs.prototype,`fixedMenuStyle`,void 0),qs=D([x(`app-dropdown`)],qs);var Js=[`Mon`,`Tue`,`Wed`,`Thu`,`Fri`,`Sat`,`Sun`],Ys=[`January`,`February`,`March`,`April`,`May`,`June`,`July`,`August`,`September`,`October`,`November`,`December`],Xs=class extends R{constructor(...e){super(...e),this.viewMonth=new Date,this.draftValue=``,this.errorMessage=``}connectedCallback(){super.connectedCallback();let e=this.parseModelDate(this.getValue());this.viewMonth=e||new Date,this.draftValue=this.toInputDate(this.getValue())}updated(e){super.updated(e),e.has(`value`)&&(this.draftValue=this.toInputDate(this.getValue()))}startOfDay(e){return new Date(e.getFullYear(),e.getMonth(),e.getDate())}isSameDay(e,t){return e.getFullYear()===t.getFullYear()&&e.getMonth()===t.getMonth()&&e.getDate()===t.getDate()}get withTime(){return this.mode===`day`&&(this.props.withTime===!0||this.props.includeTime===!0)}get mode(){return this.props.mode===`month`||this.props.selectionMode===`month`?`month`:`day`}formatDate(e){return`${e.getFullYear()}-${String(e.getMonth()+1).padStart(2,`0`)}-${String(e.getDate()).padStart(2,`0`)}`}formatDateTime(e){let t=String(e.getHours()).padStart(2,`0`),n=String(e.getMinutes()).padStart(2,`0`);return`${this.formatDate(e)} ${t}:${n}`}formatMonth(e){return`${e.getFullYear()}-${String(e.getMonth()+1).padStart(2,`0`)}`}formatUtcDate(e){return`${e.getUTCFullYear()}-${String(e.getUTCMonth()+1).padStart(2,`0`)}-${String(e.getUTCDate()).padStart(2,`0`)}`}toInputDate(e){if(!e||typeof e!=`string`)return``;if(this.mode===`month`&&/^\d{4}-\d{2}$/.test(e)||this.withTime&&/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}$/.test(e))return e;if(/^\d{4}-\d{2}-\d{2}$/.test(e))return this.withTime?`${e} 00:00`:e;let t=new Date(e);return Number.isNaN(t.getTime())?``:this.mode===`month`?this.formatMonth(t):this.withTime?this.formatDateTime(t):this.formatUtcDate(t)}toModelValue(e){return e?this.props.isoOutput?this.mode===`month`?new Date(`${e}-01T00:00:00.000Z`).toISOString():this.withTime?this.parseStrictDateTime(e)?.toISOString()||``:new Date(`${e}T00:00:00.000Z`).toISOString():e:``}parseModelDate(e){let t=this.toInputDate(e);if(!t)return null;let n=this.mode===`month`?this.parseStrictMonth(t):this.withTime?this.parseStrictDateTime(t):new Date(`${t}T00:00:00`);return n?Number.isNaN(n.getTime())?null:n:null}parseStrictDate(e){if(!/^\d{4}-\d{2}-\d{2}$/.test(e))return null;let[t,n,r]=e.split(`-`),i=Number(t),a=Number(n),o=Number(r),s=new Date(i,a-1,o);return s.getFullYear()!==i||s.getMonth()!==a-1||s.getDate()!==o?null:s}parseStrictMonth(e){if(!/^\d{4}-\d{2}$/.test(e))return null;let[t,n]=e.split(`-`),r=Number(t),i=Number(n),a=new Date(r,i-1,1);return a.getFullYear()!==r||a.getMonth()!==i-1?null:a}parseStrictDateTime(e){let t=e.match(/^(\d{4})-(\d{2})-(\d{2}) (\d{2}):(\d{2})$/);if(!t)return null;let n=Number(t[1]),r=Number(t[2]),i=Number(t[3]),a=Number(t[4]),o=Number(t[5]),s=new Date(n,r-1,i,a,o,0,0);return s.getFullYear()!==n||s.getMonth()!==r-1||s.getDate()!==i||s.getHours()!==a||s.getMinutes()!==o?null:s}handleTextInput(e){let t=e.target.value.trim();if(this.draftValue=t,t===``){this.errorMessage=``,this.updateModel(``);return}let n=this.mode===`month`?7:this.withTime?16:10;if(t.length<n){this.errorMessage=``;return}let r=this.mode===`month`?this.parseStrictMonth(t):this.withTime?this.parseStrictDateTime(t):this.parseStrictDate(t);if(!r){this.errorMessage=this.mode===`month`?`Invalid month format. Use YYYY-MM.`:this.withTime?`Invalid date format. Use YYYY-MM-DD HH:mm.`:`Invalid date format. Use YYYY-MM-DD.`;return}this.errorMessage=``,this.viewMonth=r,this.updateModel(this.toModelValue(t))}handleTextBlur(){if(this.draftValue===``){this.errorMessage=``;return}(this.mode===`month`?this.parseStrictMonth(this.draftValue):this.withTime?this.parseStrictDateTime(this.draftValue):this.parseStrictDate(this.draftValue))||(this.errorMessage=this.mode===`month`?`Invalid month format. Use YYYY-MM.`:this.withTime?`Invalid date format. Use YYYY-MM-DD HH:mm.`:`Invalid date format. Use YYYY-MM-DD.`)}shiftMonth(e){this.viewMonth=new Date(this.viewMonth.getFullYear(),this.viewMonth.getMonth()+e,1)}shiftYear(e){this.viewMonth=new Date(this.viewMonth.getFullYear()+e,this.viewMonth.getMonth(),1)}setToday(){let e=this.startOfDay(new Date);this.viewMonth=e;let t=this.mode===`month`?this.formatMonth(e):this.withTime?this.formatDateTime(new Date):this.toInputDate(e.toISOString());this.draftValue=t,this.errorMessage=``,this.updateModel(this.toModelValue(t))}clearDate(){this.draftValue=``,this.errorMessage=``,this.updateModel(``)}getDefaultTimeForDate(e){if(this.props.futureOnly&&this.isSameDay(e,new Date)){let e=new Date(Date.now()+6e4);return`${String(e.getHours()).padStart(2,`0`)}:${String(e.getMinutes()).padStart(2,`0`)}`}return`00:00`}getTimePart(e){return this.draftValue.match(/\s(\d{2}:\d{2})$/)?.[1]||this.getDefaultTimeForDate(e)}selectDate(e){this.viewMonth=e;let t=this.getTimePart(e),n=this.withTime?`${this.formatDate(e)} ${t}`:this.formatDate(e);this.draftValue=n,this.errorMessage=``,this.updateModel(this.toModelValue(n))}selectMonth(e){let t=new Date(this.viewMonth.getFullYear(),e,1),n=this.formatMonth(t);this.viewMonth=t,this.draftValue=n,this.errorMessage=``,this.updateModel(this.toModelValue(n))}handleTimeInput(e){let t=e.target,n=this.parseStrictDateTime(this.draftValue)||this.parseModelDate(this.getValue())||new Date,r=`${this.formatDate(n)} ${t.value}`;this.draftValue=r;let i=this.parseStrictDateTime(r);if(!i){this.errorMessage=`Invalid date format. Use YYYY-MM-DD HH:mm.`;return}this.errorMessage=``,this.viewMonth=i,this.updateModel(this.toModelValue(r))}buildCalendar(){let e=new Date(this.viewMonth.getFullYear(),this.viewMonth.getMonth(),1),t=(e.getDay()+6)%7,n=new Date(e);return n.setDate(e.getDate()-t),Array.from({length:42},(e,t)=>{let r=new Date(n);return r.setDate(n.getDate()+t),{date:r,inCurrentMonth:r.getMonth()===this.viewMonth.getMonth()}})}renderMonthMenu(){let e=this.parseStrictMonth(this.draftValue)||this.parseModelDate(this.getValue()),t=new Date,n=this.viewMonth.getFullYear();return v`
      <div class="form-calendar form-calendar-months">
        <div class="form-calendar-header">
          <div class="form-calendar-title">${n}</div>
          <div class="form-calendar-navigation">
            <button
              type="button"
              class="btn btn-sm btn-square btn-plain form-calendar-nav"
              @click=${()=>this.shiftYear(-1)}
              title="Previous year"
            >
              <app-icon .icon=${fn} size="14"></app-icon>
            </button>
            <button
              type="button"
              class="btn btn-sm btn-square btn-plain form-calendar-nav"
              @click=${()=>this.shiftYear(1)}
              title="Next year"
            >
              <app-icon .icon=${cn} size="14"></app-icon>
            </button>
          </div>
        </div>

        <div class="form-calendar-month-grid">
          ${Ys.map((r,i)=>{let a=e?e.getFullYear()===n&&e.getMonth()===i:!1,o=t.getFullYear()===n&&t.getMonth()===i,s=new Date(n,i,1),c=new Date(t.getFullYear(),t.getMonth(),1),l=this.props.futureOnly&&s.getTime()<c.getTime();return v`
              <button
                type="button"
                class="btn btn-sm form-calendar-month ${a?`btn-primary`:`btn-plain`} ${o&&!a?`is-current`:``} ${l?`is-disabled`:``}"
                ?disabled=${l}
                @click=${()=>this.selectMonth(i)}
              >
                ${r.slice(0,3)}
              </button>
            `})}
        </div>

        <div class="form-calendar-footer">
          <button
            type="button"
            data-dropdown-close
            class="btn btn-sm btn-plain text-primary form-calendar-link"
            @click=${()=>this.clearDate()}
          >
            Clear
          </button>
          <button
            type="button"
            data-dropdown-close
            class="btn btn-sm btn-plain form-calendar-link"
            @click=${()=>this.setToday()}
          >
            This month
          </button>
        </div>
      </div>
    `}renderCalendarMenu(){if(this.mode===`month`)return this.renderMonthMenu();let e=this.withTime?this.parseStrictDateTime(this.draftValue)||this.parseModelDate(this.getValue()):this.parseStrictDate(this.draftValue)||this.parseModelDate(this.getValue()),t=this.startOfDay(new Date),n=this.buildCalendar();return v`
      <div class="form-calendar">
        <div class="form-calendar-header">
          <div class="form-calendar-title">${`${Ys[this.viewMonth.getMonth()]} ${this.viewMonth.getFullYear()}`}</div>
          <div class="form-calendar-navigation">
            <button
              type="button"
              class="btn btn-sm btn-square btn-plain form-calendar-nav"
              @click=${()=>this.shiftMonth(-1)}
              title="Previous month"
            >
              <app-icon .icon=${fn} size="14"></app-icon>
            </button>
            <button
              type="button"
              class="btn btn-sm btn-square btn-plain form-calendar-nav"
              @click=${()=>this.shiftMonth(1)}
              title="Next month"
            >
              <app-icon .icon=${cn} size="14"></app-icon>
            </button>
          </div>
        </div>

        <div class="form-calendar-weekdays">
          ${Js.map(e=>v`<div>${e}</div>`)}
        </div>

        <div class="form-calendar-days">
          ${n.map(n=>{let r=e?this.isSameDay(n.date,e):!1,i=this.isSameDay(n.date,t),a=this.props.futureOnly&&this.startOfDay(n.date).getTime()<t.getTime(),o=n.inCurrentMonth?``:`is-outside`;return v`
              <button
                type="button"
                class="btn btn-sm btn-square form-calendar-day ${r?`btn-primary`:`btn-plain`} ${o} ${i&&!r?`is-current`:``} ${a?`is-disabled`:``}"
                ?disabled=${a}
                @click=${()=>this.selectDate(n.date)}
              >
                ${n.date.getDate()}
              </button>
            `})}
        </div>

        ${this.withTime?v`
          <div class="form-calendar-time">
            <label class="form-calendar-time-label">Time</label>
            <input
              type="time"
              class="form-control form-calendar-time-input"
              .value=${e?this.getTimePart(e):this.getTimePart(new Date)}
              @input=${this.handleTimeInput}
            />
          </div>
        `:``}

        <div class="form-calendar-footer">
          <button
            type="button"
            data-dropdown-close
            class="btn btn-sm btn-plain text-primary form-calendar-link"
            @click=${()=>this.clearDate()}
          >
            Clear
          </button>
          <button
            type="button"
            data-dropdown-close
            class="btn btn-sm btn-plain form-calendar-link"
            @click=${()=>this.setToday()}
          >
            Today
          </button>
        </div>
      </div>
    `}renderField(){let e=this.draftValue,t=this.props.placeholder||(this.mode===`month`?`YYYY-MM`:this.withTime?`YYYY-MM-DD HH:mm`:`YYYY-MM-DD`);return v`
      <div class="form-date">
      <div class="form-date-control">
        <input
          type="text"
          class="${this.inputClass} form-date-input"
          .value=${e}
          placeholder=${t}
          ?required=${this.props.required}
          ?disabled=${this.props.disabled}
          ?readonly=${this.props.readonly}
          @input=${this.handleTextInput}
          @blur=${this.handleTextBlur}
        />
        <app-dropdown
          class="form-date-dropdown"
          .showIndicator=${!1}
          .alignRight=${!0}
          .plainTrigger=${!0}
          .fixedMenu=${!0}
          .trigger=${v`
            <button
              type="button"
              class="btn btn-sm btn-square btn-plain form-date-button"
              ?disabled=${this.props.disabled||this.props.readonly}
              title="Open calendar"
            >
              <app-icon .icon=${Bn} size="16"></app-icon>
            </button>
          `}
          .menu=${this.renderCalendarMenu()}
        ></app-dropdown>
      </div>
      ${this.errorMessage?v`<div class="form-error">${j(this.errorMessage)}</div>`:``}
      </div>
    `}render(){return this.props.inline?this.renderField():super.render()}};D([C(),E(`design:type`,Object)],Xs.prototype,`viewMonth`,void 0),D([C(),E(`design:type`,Object)],Xs.prototype,`draftValue`,void 0),D([C(),E(`design:type`,Object)],Xs.prototype,`errorMessage`,void 0),Xs=D([x(`input-date`)],Xs);var Zs=class extends R{renderField(){let e=this.getValue()??``;return v`
      <textarea
        class="${this.inputClass}"
        .value=${e}
        placeholder=${j(this.props.placeholder||``)}
        ?required=${this.props.required}
        ?disabled=${this.props.disabled}
        ?readonly=${this.props.readonly}
        rows=${this.props.rows||4}
        @input=${this.handleInput}
        @change=${this.handleChange}
      ></textarea>
    `}};Zs=D([x(`input-textarea`)],Zs);var Qs=new Set(`const.let.var.function.return.if.else.for.while.do.switch.case.break.continue.default.try.catch.finally.throw.class.extends.new.this.super.static.get.set.async.await.import.export.from.as.of.in.typeof.instanceof.null.undefined.true.false.void.delete.yield.debugger.with`.split(`.`)),$s=new Set(`console.Math.JSON.Object.Array.String.Number.Boolean.Date.RegExp.Error.Promise.Map.Set.WeakMap.WeakSet.Symbol.Proxy.Reflect.parseInt.parseFloat.isNaN.isFinite.encodeURI.decodeURI.setTimeout.setInterval.clearTimeout.clearInterval.fetch.window.document`.split(`.`)),ec=[{label:`console.log`,insertText:`console.log()`,description:`Log to console`},{label:`function`,insertText:`function name() {
  
}`,description:`Function declaration`},{label:`const`,insertText:`const name = `,description:`Constant variable`},{label:`let`,insertText:`let name = `,description:`Block-scoped variable`},{label:`if`,insertText:`if (condition) {
  
}`,description:`If statement`},{label:`for`,insertText:`for (let i = 0; i < length; i++) {
  
}`,description:`For loop`},{label:`forEach`,insertText:`.forEach((item) => {
  
})`,description:`Array forEach`},{label:`map`,insertText:`.map((item) => )`,description:`Array map`},{label:`filter`,insertText:`.filter((item) => )`,description:`Array filter`},{label:`async`,insertText:`async function name() {
  
}`,description:`Async function`},{label:`await`,insertText:`await `,description:`Await promise`},{label:`try`,insertText:`try {
  
} catch (error) {
  
}`,description:`Try-catch block`},{label:`class`,insertText:`class ClassName {
  constructor() {
    
  }
}`,description:`Class declaration`},{label:`arrow`,insertText:`() => {}`,description:`Arrow function`},{label:`promise`,insertText:`new Promise((resolve, reject) => {
  
})`,description:`New Promise`}];function tc(e){let t=[],n=0;for(;n<e.length;){let r=e[n];if(r===`/`&&e[n+1]===`/`){let r=``;for(;n<e.length&&e[n]!==`
`;)r+=e[n++];t.push({type:`comment`,value:r});continue}if(r===`"`||r===`'`||r==="`"){let i=r,a=r;for(n++;n<e.length&&e[n]!==i;)e[n]===`\\`&&n+1<e.length&&(a+=e[n++]),a+=e[n++];n<e.length&&(a+=e[n++]),t.push({type:`string`,value:a});continue}if(/\d/.test(r)){let r=``;for(;n<e.length&&/[\d.]/.test(e[n]);)r+=e[n++];t.push({type:`number`,value:r});continue}if(/[a-zA-Z_$]/.test(r)){let r=``;for(;n<e.length&&/[a-zA-Z0-9_$]/.test(e[n]);)r+=e[n++];let i=!1,a=n;for(;a<e.length&&/\s/.test(e[a]);)a++;e[a]===`(`&&(i=!0),r===`true`||r===`false`||r===`null`||r===`undefined`?t.push({type:`boolean`,value:r}):Qs.has(r)?t.push({type:`keyword`,value:r}):$s.has(r)?t.push({type:`builtin`,value:r}):i?t.push({type:`function`,value:r}):t.push({type:`text`,value:r});continue}if(/[+\-*/%=!<>&|^~?:]/.test(r)){let i=r;n++,n<e.length&&/[=&|<>]/.test(e[n])&&(i+=e[n++],n<e.length&&e[n]===`=`&&(i+=e[n++])),t.push({type:`operator`,value:i});continue}if(/[{}[\]();,.]/.test(r)){t.push({type:`punctuation`,value:r}),n++;continue}t.push({type:`text`,value:r}),n++}return t}function nc(e){return e.replace(/&/g,`&amp;`).replace(/</g,`&lt;`).replace(/>/g,`&gt;`)}function rc(e){return e.map(e=>{let t=nc(e.value);switch(e.type){case`keyword`:return`<span class="tk">${t}</span>`;case`builtin`:return`<span class="tb">${t}</span>`;case`string`:return`<span class="ts">${t}</span>`;case`number`:return`<span class="tn">${t}</span>`;case`comment`:return`<span class="tc">${t}</span>`;case`function`:return`<span class="tf">${t}</span>`;case`operator`:return`<span class="to">${t}</span>`;case`punctuation`:return`<span class="tp">${t}</span>`;case`boolean`:return`<span class="tl">${t}</span>`;default:return t}}).join(``)}var ic=class extends b{constructor(...e){super(...e),this.key=``,this.props={},this.model={},this.lines=[``],this.cursorLine=1,this.cursorColumn=0,this.showSuggestions=!1,this.filteredSuggestions=[],this.selectedSuggestionIndex=0,this.currentWord=``,this.code=``}static{this.styles=c`
    :host {
      display: block;
      margin-bottom: var(--nq-field-gap, 8px);
      color: var(--nq-body-color);
    }
    
    .field-label {
      display: flex;
      height: var(--nq-label-height, 20px);
      align-items: center;
      gap: 0.375rem;
      margin-bottom: calc(var(--nq-field-gap, 8px) / 2);
      color: var(--nq-body-color);
      font-size: 0.875rem;
      font-weight: 500;
    }
    
    .field-label .required {
      color: var(--nq-danger);
    }

    .field-label-help {
      display: inline-flex;
      align-items: center;
      opacity: 0;
      transition: opacity 0.2s;
    }

    .field-label:hover .field-label-help,
    .field-label:focus-within .field-label-help {
      opacity: 1;
    }

    .form-help-button {
      display: inline-flex;
      width: 1.125rem;
      height: 1.6rem;
      align-items: center;
      justify-content: center;
      border-radius: 50%;
      color: var(--nq-muted-color);
      line-height: 1;
    }

    .form-help-button:hover,
    .form-help-button:focus-visible {
      color: var(--nq-body-color);
    }

    .form-help-content {
      max-width: 20rem;
      color: var(--nq-body-color);
      font-size: 0.75rem;
      font-weight: 400;
      line-height: 1.25rem;
    }

    app-popover .popover-wrap {
      position: relative;
      display: inline-block;
    }

    app-popover .popover-trigger {
      cursor: pointer;
    }

    app-popover .popover {
      position: fixed;
      z-index: 9999;
      box-sizing: border-box;
      max-width: calc(100vw - 1rem);
      padding: 0.5rem 0.75rem;
      border: 1px solid var(--nq-border-color);
      border-radius: calc(var(--nq-control-radius) * 1.5);
      background: var(--nq-surface-subtle);
      color: var(--nq-body-color);
      font-size: 0.875rem;
      overflow-wrap: anywhere;
      box-shadow: 0 0.75rem 1.5rem rgb(0 0 0 / 35%);
      opacity: 0;
      visibility: hidden;
      pointer-events: none;
      transition: opacity 0.15s, visibility 0.15s;
    }

    app-popover .popover.show {
      opacity: 1;
      visibility: visible;
      pointer-events: auto;
    }
    
    .code-editor-container {
      position: relative;
      font-family: 'JetBrains Mono', 'Fira Code', 'Monaco', 'Consolas', monospace;
      font-size: 14px;
      line-height: 1.5;
      border-radius: var(--nq-control-radius);
      overflow: hidden;
      background: var(--nq-surface);
      border: 1px solid var(--nq-border-color);
    }
    
    .code-editor-container:focus-within {
      border-color: var(--nq-control-focus-color);
      box-shadow: 0 0 0 4px var(--nq-control-focus-ring);
    }
    
    .code-wrapper {
      display: flex;
      overflow: auto;
      resize: vertical;
      scrollbar-width: thin;
      scrollbar-color: var(--nq-primary) var(--nq-surface);
    }

    .code-wrapper::-webkit-scrollbar,
    .suggestions-dropdown::-webkit-scrollbar {
      width: 0.625rem;
      height: 0.625rem;
    }

    .code-wrapper::-webkit-scrollbar-track,
    .suggestions-dropdown::-webkit-scrollbar-track {
      background: var(--nq-surface);
    }

    .code-wrapper::-webkit-scrollbar-thumb,
    .suggestions-dropdown::-webkit-scrollbar-thumb {
      border: 2px solid var(--nq-surface);
      border-radius: 999px;
      background: var(--nq-primary);
    }
    
    .line-numbers {
      flex-shrink: 0;
      padding: 12px 0;
      background: var(--nq-surface-subtle);
      color: var(--nq-muted-color);
      text-align: right;
      user-select: none;
      border-right: 1px solid var(--nq-border-color);
      min-width: 50px;
      position: sticky;
      left: 0;
      z-index: 3;
    }
    
    .line-number {
      padding: 0 12px;
      height: 21px;
      display: flex;
      align-items: center;
      justify-content: flex-end;
      font-size: 13px;
    }
    
    .line-number.active {
      color: var(--nq-primary);
      background: color-mix(in srgb, var(--nq-primary) 10%, transparent);
    }
    
    .code-area {
      position: relative;
      flex: 1;
      min-width: 0;
    }
    
    .code-textarea,
    .code-highlight {
      margin: 0;
      padding: 12px;
      font-family: inherit;
      font-size: inherit;
      line-height: inherit;
      white-space: pre;
      word-wrap: normal;
      overflow-wrap: normal;
      width: 100%;
      box-sizing: border-box;
    }
    
    .code-textarea {
      position: absolute;
      top: 0;
      left: 0;
      min-height: 100%;
      background: transparent;
      color: transparent;
      caret-color: var(--nq-body-color);
      border: none;
      outline: none;
      resize: none;
      z-index: 2;
      overflow: hidden;
    }
    
    .code-highlight {
      position: relative;
      z-index: 1;
      color: var(--nq-body-color);
      min-height: 100%;
      pointer-events: none;
      width: fit-content;
      min-width: 100%;
    }
    
    .code-highlight .line {
      min-height: 21px;
    }
    
    .tk { color: light-dark(#7e22ce, #d8b4fe); } /* keyword */
    .ts { color: light-dark(#15803d, #86efac); } /* string */
    .tn { color: light-dark(#c2410c, #fdba74); } /* number */
    .tc {
      color: light-dark(#64748b, #94a3b8);
      font-style: italic;
    } /* comment */
    .tf { color: light-dark(#1d4ed8, #93c5fd); } /* function */
    .tb { color: light-dark(#b45309, #fde68a); } /* builtin */
    .to { color: light-dark(#0f766e, #67e8f9); } /* operator */
    .tp { color: var(--nq-muted-color); } /* punctuation */
    .tl { color: light-dark(#c2410c, #fdba74); } /* boolean/null */
    
    /* Suggestions dropdown */
    .suggestions-dropdown {
      position: absolute;
      z-index: 100;
      background: var(--nq-surface);
      border: 1px solid var(--nq-border-color);
      border-radius: var(--nq-control-radius);
      max-height: 200px;
      overflow-y: auto;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
      min-width: 250px;
      scrollbar-width: thin;
      scrollbar-color: var(--nq-border-color) var(--nq-surface);
    }
    
    .suggestion-item {
      padding: 8px 12px;
      cursor: pointer;
      display: flex;
      justify-content: space-between;
      align-items: center;
      gap: 12px;
    }
    
    .suggestion-item:hover,
    .suggestion-item.selected {
      background: var(--nq-surface-subtle);
    }
    
    .suggestion-label {
      color: var(--nq-primary);
      font-weight: 500;
    }
    
    .suggestion-desc {
      color: var(--nq-muted-color);
      font-size: 12px;
    }
    
    .cursor-info {
      display: flex;
      justify-content: flex-end;
      padding: 4px 12px;
      background: var(--nq-surface-subtle);
      color: var(--nq-muted-color);
      font-size: 12px;
      border-top: 1px solid var(--nq-border-color);
    }
  `}getValue(){return this.value===void 0?this.model&&this.key?this.model[this.key]??``:``:this.value??``}updateModel(e){let t=new CustomEvent(`field-change`,{detail:{key:this.key,value:e,model:{...this.model,[this.key]:e}},bubbles:!0,composed:!0});this.dispatchEvent(t)}getTextarea(){return this.shadowRoot?.querySelector(`.code-textarea`)}getHighlightElement(){return this.shadowRoot?.querySelector(`.code-highlight`)}connectedCallback(){super.connectedCallback(),this.code=this.getValue(),this.updateLines()}updateLines(){this.lines=this.code.split(`
`),this.lines.length===0&&(this.lines=[``])}highlightCode(){return this.lines.map(e=>e?`<div class="line">${rc(tc(e))}</div>`:`<div class="line">&nbsp;</div>`).join(``)}updated(e){super.updated(e);let t=this.getHighlightElement();t&&(t.innerHTML=this.highlightCode());let n=this.getTextarea();n&&t&&(n.style.height=t.offsetHeight+`px`)}handleInput(e){let t=e.target;this.code=t.value,this.updateModel(this.code),this.updateLines(),this.updateCursorPosition(t),this.checkForSuggestions(t)}handleScroll(e){let t=e.target,n=this.getHighlightElement();n&&(n.scrollTop=t.scrollTop,n.scrollLeft=t.scrollLeft)}handleKeyDown(e){let t=e.target;if(this.showSuggestions)e.key===`ArrowDown`?(e.preventDefault(),this.selectedSuggestionIndex=Math.min(this.selectedSuggestionIndex+1,this.filteredSuggestions.length-1)):e.key===`ArrowUp`?(e.preventDefault(),this.selectedSuggestionIndex=Math.max(this.selectedSuggestionIndex-1,0)):e.key===`Enter`||e.key===`Tab`?(e.preventDefault(),this.insertSuggestion(this.filteredSuggestions[this.selectedSuggestionIndex])):e.key===`Escape`&&(this.showSuggestions=!1);else if(e.key===`Tab`){e.preventDefault();let n=t.selectionStart,r=t.selectionEnd,i=t.value;t.value=i.substring(0,n)+`  `+i.substring(r),t.selectionStart=t.selectionEnd=n+2,this.code=t.value,this.updateModel(this.code),this.updateLines()}}updateCursorPosition(e){let t=e.value,n=e.selectionStart,r=t.substring(0,n).split(`
`);this.cursorLine=r.length,this.cursorColumn=r[r.length-1].length}checkForSuggestions(e){let t=e.value,n=e.selectionStart,r=t.substring(0,n).match(/[\w.]+$/);r&&r[0].length>=2?(this.currentWord=r[0],this.filteredSuggestions=ec.filter(e=>e.label.toLowerCase().startsWith(this.currentWord.toLowerCase())),this.showSuggestions=this.filteredSuggestions.length>0,this.selectedSuggestionIndex=0):(this.showSuggestions=!1,this.filteredSuggestions=[])}insertSuggestion(e){if(!e)return;let t=this.getTextarea();if(!t)return;let n=t.value,r=t.selectionStart,i=n.substring(0,r),a=n.substring(r),o=i.replace(/[\w.]+$/,``),s=o+e.insertText+a;t.value=s,t.selectionStart=t.selectionEnd=o.length+e.insertText.length,this.code=s,this.updateModel(this.code),this.updateLines(),this.showSuggestions=!1,t.focus()}getSuggestionPosition(){let e=this.cursorLine*21+12,t=Math.min(this.cursorColumn*8.4+12,200);return{top:`${e}px`,left:`${t}px`}}renderHelp(){return this.props.help?v`
      <span
        class="field-label-help"
        @click=${e=>e.stopPropagation()}
      >
        <app-popover
          placement="auto"
          .trigger=${v`
            <span
              class="form-help-button"
              tabindex="0"
              role="button"
              aria-label="${j(this.props.label||`Field`)} help"
            >
              <app-icon .icon=${ni} size="15"></app-icon>
            </span>
          `}
          .content=${v`
            <div class="form-help-content">${j(this.props.help)}</div>
          `}
        ></app-popover>
      </span>
    `:``}render(){let e=(this.props.rows||10)*21+24,t=this.getSuggestionPosition();return v`
      ${this.props.label?v`
        <label class="field-label">
          ${j(this.props.label)}
          ${this.props.required?v`<span class="required">*</span>`:``}
          ${this.renderHelp()}
        </label>
      `:``}
      <div class="code-editor-container">
        <div class="code-wrapper" style="min-height: 5rem; height: ${e}px;">
          <div class="line-numbers">
            ${this.lines.map((e,t)=>v`
              <div class="line-number ${t+1===this.cursorLine?`active`:``}">${t+1}</div>
            `)}
          </div>
          <div class="code-area">
            <pre class="code-highlight"></pre>
            <textarea
              class="code-textarea"
              .value=${this.code}
              placeholder=${this.props.placeholder}
              ?disabled=${this.props.disabled}
              ?readonly=${this.props.readonly}
              spellcheck="false"
              autocomplete="off"
              autocorrect="off"
              autocapitalize="off"
              @input=${this.handleInput}
              @keydown=${this.handleKeyDown}
              @click=${e=>this.updateCursorPosition(e.target)}
              @keyup=${e=>this.updateCursorPosition(e.target)}
            ></textarea>
            ${this.showSuggestions?v`
              <div class="suggestions-dropdown" style="top: ${t.top}; left: ${t.left};">
                ${this.filteredSuggestions.map((e,t)=>v`
                  <div 
                    class="suggestion-item ${t===this.selectedSuggestionIndex?`selected`:``}"
                    @click=${()=>this.insertSuggestion(e)}
                    @mouseenter=${()=>this.selectedSuggestionIndex=t}
                  >
                    <span class="suggestion-label">${e.label}</span>
                    <span class="suggestion-desc">${e.description}</span>
                  </div>
                `)}
              </div>
            `:``}
          </div>
        </div>
        <div class="cursor-info">
          Ln ${this.cursorLine}, Col ${this.cursorColumn+1}
        </div>
      </div>
    `}};D([S({type:String}),E(`design:type`,String)],ic.prototype,`key`,void 0),D([S({type:Object}),E(`design:type`,Object)],ic.prototype,`props`,void 0),D([S({type:Object}),E(`design:type`,Object)],ic.prototype,`model`,void 0),D([S(),E(`design:type`,Object)],ic.prototype,`value`,void 0),D([C(),E(`design:type`,Array)],ic.prototype,`lines`,void 0),D([C(),E(`design:type`,Number)],ic.prototype,`cursorLine`,void 0),D([C(),E(`design:type`,Number)],ic.prototype,`cursorColumn`,void 0),D([C(),E(`design:type`,Boolean)],ic.prototype,`showSuggestions`,void 0),D([C(),E(`design:type`,Object)],ic.prototype,`filteredSuggestions`,void 0),D([C(),E(`design:type`,Number)],ic.prototype,`selectedSuggestionIndex`,void 0),D([C(),E(`design:type`,String)],ic.prototype,`currentWord`,void 0),D([C(),E(`design:type`,String)],ic.prototype,`code`,void 0),ic=D([x(`input-code`)],ic);var ac=class extends R{handleInput(e){let t=e.target,n=t.value===``?null:Number(t.value);this.updateModel(n)}handleChange(e){let t=e.target,n=t.value===``?null:Number(t.value);this.updateModel(n)}renderField(){let e=this.getValue()??``,t=(t,n)=>typeof t==`function`?t(e,this.model)??n:t??n,n=t(this.props.min),r=t(this.props.max),i=t(this.props.step,1);return v`
      <input
        type="number"
        class="${this.inputClass}"
        .value=${String(e)}
        placeholder=${j(this.props.placeholder||``)}
        ?required=${this.props.required}
        ?disabled=${this.props.disabled}
        ?readonly=${this.props.readonly}
        min=${n===void 0?``:n}
        max=${r===void 0?``:r}
        step=${i}
        @input=${this.handleInput}
        @change=${this.handleChange}
      />
    `}};ac=D([x(`input-number`)],ac);var oc=[{value:`ms`,label:`ms`,menuLabel:`millisecond(s)`,multiplier:1},{value:`s`,label:`s`,menuLabel:`second(s)`,multiplier:1e3},{value:`m`,label:`m`,menuLabel:`minute(s)`,multiplier:6e4},{value:`h`,label:`h`,menuLabel:`hour(s)`,multiplier:36e5},{value:`d`,label:`d`,menuLabel:`day(s)`,multiplier:864e5}],sc=e=>{let t=String(e||`s`).toLowerCase();return oc.some(e=>e.value===t)?t:`s`},cc=e=>String(Number.isInteger(e)?e:Number(e.toFixed(4))),lc=class extends R{constructor(...e){super(...e),this.amount=``,this.unit=`s`}connectedCallback(){super.connectedCallback(),this.syncFromValue(!0)}willUpdate(e){super.willUpdate(e),(e.has(`value`)||e.has(`model`)||e.has(`key`)||e.has(`props`))&&this.syncFromValue(!1)}getUnits(){return this.props.type===`time`||this.props.type,oc}getMultiplier(e){return this.getUnits().find(t=>t.value===e)?.multiplier||1}syncFromValue(e){let t=this.getValue(),n=t==null||t===``?null:Number(t);if(!e&&n===this.lastSyncedValue)return;if(!e&&n===this.lastEmittedValue){this.lastSyncedValue=n;return}if(this.lastSyncedValue=n,n===null||!Number.isFinite(n)){this.amount=``,this.unit=sc(this.props.defaultUnit);return}let r=[...this.getUnits()].reverse().find(e=>n!==0&&n%e.multiplier===0)?.value||sc(this.props.defaultUnit);this.unit=r,this.amount=cc(n/this.getMultiplier(r))}emitValue(){if(this.amount===``){this.lastEmittedValue=null,this.updateModel(null);return}let e=Number(this.amount);if(!Number.isFinite(e)){this.lastEmittedValue=null,this.updateModel(null);return}let t=Math.round(e*this.getMultiplier(this.unit));this.lastEmittedValue=t,this.lastSyncedValue=t,this.updateModel(t)}handleAmountInput(e){let t=e.target;this.amount=t.value,this.emitValue()}handleUnitChange(e){this.unit=e,this.emitValue()}renderField(){let e=this.props.min??0,t=this.props.max??``,n=this.unit===`ms`?1:this.props.step??`any`;return v`
      <div class="form-control form-control-group">
        <input
          type="number"
          class="form-control-input"
          .value=${this.amount}
          placeholder=${this.props.placeholder||``}
          ?required=${this.props.required}
          ?disabled=${this.props.disabled}
          ?readonly=${this.props.readonly}
          min=${e}
          max=${t}
          step=${n}
          @input=${this.handleAmountInput}
          @change=${this.handleAmountInput}
        />
        <app-dropdown
          class="form-control-addon form-control-addon-dropdown"
          plainTrigger
          fixedMenu
          .showIndicator=${!1}
          .trigger=${v`
            <button
              type="button"
              class="form-control-addon-button"
              ?disabled=${this.props.disabled||this.props.readonly}
            >
              ${this.unit}
            </button>
          `}
          .menu=${v`
            ${this.getUnits().map(e=>v`
              <app-dropdown-item
                label=${e.menuLabel}
                ?disabled=${e.value===this.unit}
                @item-click=${()=>this.handleUnitChange(e.value)}
              ></app-dropdown-item>
            `)}
          `}
        ></app-dropdown>
      </div>
    `}};D([C(),E(`design:type`,Object)],lc.prototype,`amount`,void 0),D([C(),E(`design:type`,Object)],lc.prototype,`unit`,void 0),lc=D([x(`input-unit`)],lc);var uc=class extends R{constructor(...e){super(...e),this.visible=!1}getAutocomplete(){let e=this.props.autocomplete;return typeof e==`string`?e:e===!0?`current-password`:`new-password`}toggleVisibility(){this.visible=!this.visible}generatePassword(){let e=Number(this.props.autogenerateLength)||16,t=new Uint32Array(e);crypto.getRandomValues(t);let n=Array.from(t,e=>"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^*()_+`|}{[]><,.-="[e%85]).join(``);this.updateModel(n),this.visible=!0}renderField(){let e=this.getValue()??``;return v`
      <div class="form-control form-control-group">
        <input
          type=${this.visible?`text`:`password`}
          class="form-control-input"
          .value=${e}
          placeholder=${j(this.props.placeholder||``)}
          autocomplete=${this.getAutocomplete()}
          ?required=${this.props.required}
          ?disabled=${this.props.disabled}
          ?readonly=${this.props.readonly}
          @input=${this.handleInput}
          @change=${this.handleChange}
        />
        ${this.props.autogenerate?v`
          <button
            type="button"
            class="btn btn-square btn-plain"
            @click=${()=>this.generatePassword()}
            title=${j(`Generate password`)}
          >
            <app-icon .icon=${Zi} size="16"></app-icon>
          </button>
        `:``}
        <button
          type="button"
          class="btn btn-square btn-plain"
          @click=${()=>this.toggleVisibility()}
          title=${j(this.visible?`Hide password`:`Show password`)}
        >
          <app-icon .icon=${this.visible?Za:Qa} size="16"></app-icon>
        </button>
      </div>
    `}};D([C(),E(`design:type`,Object)],uc.prototype,`visible`,void 0),uc=D([x(`input-password`)],uc);var dc=0,fc=class extends R{constructor(...e){super(...e),this.uniqueGroupName=``}connectedCallback(){super.connectedCallback(),this.uniqueGroupName=`${this.key}-${++dc}`}handleChange(e){let t=e.target,n=(this.props.options||[]).find(e=>String(e.value)===t.value);n&&this.updateModel(n.value)}renderField(){let e=this.getValue(),t=this.props.options||[];return v`
      <div class="form-radio-list ${this.props.inline===!1?`is-vertical`:``}">
        ${t.map(t=>{let n=`${this.uniqueGroupName}-${t.value}`,r=e===t.value;return v`
            <label class="form-radio">
              <div class="position-relative">
                <input
                  type="radio"
                  id=${n}
                  name=${this.uniqueGroupName}
                  .value=${t.value}
                  .checked=${r}
                  ?disabled=${this.props.disabled}
                  @change=${this.handleChange}
                  class="form-native-control"
                />
                <div class="form-radio-mark ${r?`is-checked`:``}">
                  <div class="form-radio-dot ${r?`is-checked`:``}"></div>
                </div>
              </div>
              <span class="form-radio-label">
                ${j(t.label)}
              </span>
            </label>
          `})}
      </div>
    `}};D([C(),E(`design:type`,String)],fc.prototype,`uniqueGroupName`,void 0),fc=D([x(`input-radio`)],fc);var pc=class extends R{handleChange(e){let t=e.target;this.updateModel(t.checked)}handleToggle(){if(!this.props.disabled&&!this.props.readonly){let e=this.getValue()??!1;this.updateModel(!e)}}renderField(){let e=this.getValue()??!1;return v`
      <div class="form-check-row">
        <label class="form-check">
          <input
            type="checkbox"
            class="form-native-control"
            .checked=${e}
            ?disabled=${this.props.disabled}
            ?readonly=${this.props.readonly}
            @change=${this.handleChange}
          />
          <div class="form-check-mark ${e?`is-checked`:``}">
            ${e?v`
              <svg class="form-check-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M5 13l4 4L19 7"></path>
              </svg>
            `:``}
          </div>
          ${this.props.checkboxLabel?v`
            <span class="form-check-label">
              ${j(this.props.checkboxLabel)}
            </span>
          `:``}
        </label>
      </div>
    `}};pc=D([x(`input-checkbox`)],pc);var mc=class extends R{constructor(...e){super(...e),this.isOpen=!1,this.searchQuery=``,this.highlightedIndex=-1,this.dropdownPosition={top:0,bottom:0,left:0,width:0,openUpwards:!1,maxHeight:400},this.cachedOptions=[],this.draggedTagIndex=null,this.dragOverTagIndex=null,this.triggerElement=null,this.selectId=yo(),this.handleScroll=()=>{this.isOpen&&this.triggerElement&&this.updateDropdownPosition(this.triggerElement,!0)},this.handleClickOutside=e=>{this.isOpen&&setTimeout(()=>{this.isOpen&&(e.composedPath().includes(this)||this.closeDropdown())},0)}}connectedCallback(){super.connectedCallback(),document.addEventListener(`click`,this.handleClickOutside,!0)}disconnectedCallback(){super.disconnectedCallback(),document.removeEventListener(`click`,this.handleClickOutside,!0),document.removeEventListener(`scroll`,this.handleScroll,!0)}getFixedPositionContext(e){let t=e.parentElement;for(;t&&t!==document.body;){let e=window.getComputedStyle(t);if(e.transform!==`none`||e.perspective!==`none`||e.filter!==`none`||e.backdropFilter!==`none`||e.contain.includes(`paint`)||e.willChange.includes(`transform`))return t.getBoundingClientRect();t=t.parentElement}return new DOMRect(0,0,window.innerWidth,window.innerHeight)}updateDropdownPosition(e,t){let n=e.getBoundingClientRect(),r=this.getFixedPositionContext(e),i=r.top,a=r.left,o=r.bottom||window.innerHeight,s=Math.min(520,Math.max(360,window.innerHeight*.65)),c=Math.max(0,o-n.bottom-8),l=Math.max(0,n.top-i-8),u=Math.max(0,window.innerHeight-n.bottom-8),d=Math.max(0,n.top-8),f,p,m,h=t?this.dropdownPosition.openUpwards:!1;t?h?(p=o-n.top+4,m=Math.min(s,d),f=0):(f=n.bottom-i+4,m=Math.min(s,u),p=0):u>=s?(f=n.bottom-i+4,p=0,m=s):d>=s?(p=o-n.top+4,f=0,m=s,h=!0):u>d?(f=n.bottom-i+4,p=0,m=Math.max(u,c)):(m=Math.max(d,l),p=o-n.top+4,f=0,h=!0),this.dropdownPosition={top:f,bottom:p,left:n.left-a,width:n.width,openUpwards:h,maxHeight:m}}prepareDropdown(){if(this.props.disabled||this.props.readonly)return;let e=this.props.options||[];if(typeof e==`function`){let t=this.getValue(),n=this.model;e=e(t,n)}this.cachedOptions=e,this.isOpen||(this.searchQuery=``,this.highlightedIndex=-1)}handleDropdownOpenChange(e){if(this.isOpen=e.detail.open,this.isOpen){this.focusSearchInput();return}this.triggerElement=null,this.searchQuery=``,this.highlightedIndex=-1}focusSearchInput(){requestAnimationFrame(()=>{if(!this.isOpen)return;let e=document.querySelector(`[data-form-select-menu="${this.selectId}"] input`);if(!e){requestAnimationFrame(()=>this.focusSearchInput());return}e.focus()})}handleDropdownMenuRendered(){this.isOpen&&this.focusSearchInput()}handleTriggerKeyDown(e){this.props.disabled||this.props.readonly||(e.key===`Enter`||e.key===` `||e.key===`ArrowDown`)&&(e.preventDefault(),this.prepareDropdown(),this.isOpen?this.focusSearchInput():e.currentTarget.click())}handleSearchInput(e){let t=e.target;this.searchQuery=t.value,this.highlightedIndex=-1,this.refreshDropdownMenu()}getVisibleOptions(){let e=this.getValue(),t=Array.isArray(e)?e:[];return this.props.multiple?this.getFilteredOptions().filter(e=>{let n=typeof e==`string`?e:e.value;return!t.includes(n)}):this.getFilteredOptions()}refreshDropdownMenu(){let e=this.querySelector(`app-dropdown`);if(!e)return;let t=this.getValue(),n=t===void 0?``:t,r=t!==void 0&&t!==``;e.menu=this.renderDropdownMenu(this.getVisibleOptions(),n,r),e.refreshMenu?.()}closeDropdown(){document.removeEventListener(`scroll`,this.handleScroll,!0),this.triggerElement=null,this.isOpen=!1,this.searchQuery=``,this.highlightedIndex=-1}requestDropdownClose(e){e.stopPropagation(),this.closeDropdown(),e.currentTarget.dispatchEvent(new CustomEvent(`item-click`,{bubbles:!0,composed:!0}))}handleRemoveSelected(e){this.props.multiple?this.updateModel([]):this.updateModel(``),this.requestDropdownClose(e)}handleCloseClick(e){this.requestDropdownClose(e)}handleOptionClick(e,t){if(t.stopPropagation(),e?.disabled)return;let n=typeof e==`string`?e:e.value;if(this.props.multiple){let e=this.getValue()||[],t=Array.isArray(e)?e:[];t.includes(n)?this.updateModel(t.filter(e=>e!==n)):this.updateModel([...t,n])}else this.updateModel(n),this.requestDropdownClose(t)}handleSearchKeyDown(e){let t=this.getVisibleOptions();switch(e.key){case`ArrowDown`:e.preventDefault(),this.highlightedIndex=Math.min(this.highlightedIndex+1,t.length-1),this.refreshDropdownMenu(),this.scrollToHighlighted();break;case`ArrowUp`:e.preventDefault(),this.highlightedIndex>0&&(this.highlightedIndex=Math.max(this.highlightedIndex-1,0),this.refreshDropdownMenu(),this.scrollToHighlighted());break;case`Enter`:case`ArrowRight`:if(e.preventDefault(),this.highlightedIndex>=0&&this.highlightedIndex<t.length){let n=t[this.highlightedIndex];if(typeof n!=`string`&&n.disabled===!0)return;let r=typeof n==`string`?n:n.value;this.updateModel(r),this.requestDropdownClose(e)}break;case`Escape`:e.preventDefault(),this.requestDropdownClose(e);break}}scrollToHighlighted(){this.updateComplete.then(()=>{let e=document.querySelectorAll(`[data-form-select-menu="${this.selectId}"] [data-option]`);e&&this.highlightedIndex>=0&&e[this.highlightedIndex]?.scrollIntoView({block:`nearest`})})}getFilteredOptions(){let e=this.isOpen&&this.cachedOptions.length>0?this.cachedOptions:this.props.options||[];if(typeof e==`function`){let t=this.getValue();e=e(t,this.model)}if(!this.searchQuery)return e;let t=this.searchQuery.toLowerCase();return e.filter(e=>(typeof e==`string`?e:e.label).toLowerCase().includes(t))}getSelectedLabel(){let e=this.getValue();if(e===void 0||e===``)return null;let t;if(this.cachedOptions.length>0)t=this.cachedOptions;else{let n=this.props.options||[];if(typeof n==`function`){let r=this.model;t=n(e,r)}else t=n}let n=t.find(t=>(typeof t==`string`?t:t.value)===e);return n?typeof n==`string`?n:n.label:e===null?`Null`:String(e)}removeTag(e,t){t.stopPropagation();let n=this.getValue()||[],r=Array.isArray(n)?n:[];this.updateModel(r.filter(t=>t!==e))}handleTagDragStart(e,t){t.stopPropagation(),this.draggedTagIndex=e,t.dataTransfer?.setData(`text/plain`,String(e)),t.dataTransfer&&(t.dataTransfer.effectAllowed=`move`)}handleTagDragOver(e,t){t.preventDefault(),t.stopPropagation(),this.dragOverTagIndex=e,t.dataTransfer&&(t.dataTransfer.dropEffect=`move`)}handleTagDrop(e,t){t.preventDefault(),t.stopPropagation();let n=Number(t.dataTransfer?.getData(`text/plain`)??this.draggedTagIndex),r=Array.isArray(this.getValue())?[...this.getValue()]:[];if(!Number.isInteger(n)||n<0||n>=r.length||e<0||e>=r.length){this.draggedTagIndex=null,this.dragOverTagIndex=null;return}let[i]=r.splice(n,1);r.splice(e,0,i),this.updateModel(r),this.draggedTagIndex=null,this.dragOverTagIndex=null}handleTagDragEnd(){this.draggedTagIndex=null,this.dragOverTagIndex=null}getSelectedOptions(){let e=this.getValue(),t=Array.isArray(e)?e:[];if(t.length===0)return[];let n;if(this.cachedOptions.length>0)n=this.cachedOptions;else{let t=this.props.options||[];if(typeof t==`function`){let r=this.model;n=t(e,r)}else n=t}return t.map(e=>{let t=n.find(t=>(typeof t==`string`?t:t.value)===e);return t?{value:e,label:typeof t==`string`?t:t.label}:{value:e,label:e}})}renderDropdownMenu(e,t,n){return v`
      <div
        class="form-select-menu"
        data-form-select-menu=${this.selectId}
        @click=${e=>e.stopPropagation()}
      >
        <div class="dropdown-search">
          <div class="position-relative">
            <input
              type="text"
              class="form-control pr-4"
              placeholder=${j(`Search...`)}
              .value=${this.searchQuery}
              @input=${e=>this.handleSearchInput(e)}
              @keydown=${e=>this.handleSearchKeyDown(e)}
              @click=${e=>e.stopPropagation()}
            />
            <svg
              class="dropdown-search-icon"
              width="16"
              height="16"
              viewBox="0 0 20 20"
              fill="currentColor"
            >
              <path
                fill-rule="evenodd"
                d="M8 4a4 4 0 100 8 4 4 0 000-8zM2 8a6 6 0 1110.89 3.476l4.817 4.817a1 1 0 01-1.414 1.414l-4.816-4.816A6 6 0 012 8z"
                clip-rule="evenodd"
              />
            </svg>
          </div>
        </div>

        ${!this.props.required&&(this.props.multiple?Array.isArray(t)&&t.length>0:n)?v`
          <div
            class="dropdown-item border-bottom"
            @click=${e=>this.handleRemoveSelected(e)}
          >
            ${j(this.props.multiple?`Clear all`:`Remove selected`)}
          </div>
        `:``}

        <div class="dropdown-list">
          ${e.length>0?e.map((e,n)=>{let r=typeof e==`string`?e:e.value,i=typeof e==`string`?e:e.label,a=typeof e!=`string`&&e.disabled===!0,o=!this.props.multiple&&t===r,s=n===this.highlightedIndex;return v`
              <div
                data-option
                class="dropdown-item ${a?`is-disabled`:o?`is-selected`:s?`is-highlighted`:``}"
                @click=${t=>this.handleOptionClick(e,t)}
                @mouseenter=${()=>{a||(this.highlightedIndex=n,this.refreshDropdownMenu())}}
              >
                <span>${j(i)}</span>
              </div>
            `}):v`
            <div class="dropdown-empty">
              ${j(`No options found`)}
            </div>
          `}
        </div>

        <div class="dropdown-footer">
          <app-button
            size="sm"
            variant="ghost"
            .label=${`close`}
            .className=${`w-100`}
            @click=${e=>this.handleCloseClick(e)}
          ></app-button>
        </div>
      </div>
    `}renderField(){let e=this.getValue(),t=e===void 0?``:e,n=this.getSelectedLabel(),r=e!==void 0&&e!==``,i=this.getVisibleOptions();return v`
      <app-dropdown
        class="form-select-dropdown"
        plainTrigger
        fixedMenu
        matchTriggerWidth
        .showIndicator=${!1}
        @dropdown-open-change=${this.handleDropdownOpenChange}
        @dropdown-menu-rendered=${this.handleDropdownMenuRendered}
        .trigger=${this.props.multiple?v`
          <!-- Multiple Selection with Tags -->
          <div
            class="form-control form-select multiple ${this.isOpen?`show`:``} ${this.props.disabled?`disabled`:``}"
            ?disabled=${this.props.disabled}
            @click=${()=>this.prepareDropdown()}
            @keydown=${e=>this.handleTriggerKeyDown(e)}
            tabindex="0"
          >
            <div class="d-flex align-items-center justify-content-between gap-2 w-100">
              <div class="flex-grow-1">
                ${this.getSelectedOptions().length>0?v`
                  <div class="d-flex flex-wrap gap-1">
                    ${this.getSelectedOptions().map((e,t)=>v`
                      <div
                        draggable="true"
                        class="badge ${this.dragOverTagIndex===t?`is-drop-target`:``} ${this.draggedTagIndex===t?`is-dragging`:``}"
                        @click=${e=>e.stopPropagation()}
                        @dragstart=${e=>this.handleTagDragStart(t,e)}
                        @dragover=${e=>this.handleTagDragOver(t,e)}
                        @drop=${e=>this.handleTagDrop(t,e)}
                        @dragend=${this.handleTagDragEnd}
                      >
                        <span class="drag-handle">
                          ${Array.from({length:6}).map(()=>v`<span></span>`)}
                        </span>
                        <span>${j(e.label)}</span>
                        <button
                          type="button"
                          class="btn btn-plain btn-danger btn-square badge-action flex-shrink-0"
                          aria-label="Remove"
                          @click=${t=>this.removeTag(e.value,t)}
                        >
                          <app-icon .icon=${Gn} size="14"></app-icon>
                        </button>
                      </div>
                    `)}
                  </div>
                `:v`
                  <span class="text-muted">${j(this.props.placeholder??``)}</span>
                `}
              </div>
              <svg
                class="dropdown-toggle-icon ${this.isOpen?`show`:``}"
                width="20"
                height="20"
                viewBox="0 0 20 20"
                fill="currentColor"
              >
                <path
                  fill-rule="evenodd"
                  d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z"
                  clip-rule="evenodd"
                />
              </svg>
            </div>
          </div>
        `:v`
          <!-- Single Selection Button -->
          <button
            type="button"
            class="form-control form-select ${this.isOpen?`show`:``}"
            ?disabled=${this.props.disabled}
            @click=${()=>this.prepareDropdown()}
            @keydown=${e=>this.handleTriggerKeyDown(e)}
          >
            <span class="${n===null?`text-muted`:``}">
              ${j(n??this.props.placeholder??``)}
            </span>
            <svg
              class="dropdown-toggle-icon ${this.isOpen?`show`:``}"
              width="20"
              height="20"
              viewBox="0 0 20 20"
              fill="currentColor"
            >
              <path
                fill-rule="evenodd"
                d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z"
                clip-rule="evenodd"
              />
            </svg>
          </button>
        `}
        .menu=${this.renderDropdownMenu(i,t,r)}
      ></app-dropdown>
    `}};D([C(),E(`design:type`,Object)],mc.prototype,`isOpen`,void 0),D([C(),E(`design:type`,Object)],mc.prototype,`searchQuery`,void 0),D([C(),E(`design:type`,Object)],mc.prototype,`highlightedIndex`,void 0),D([C(),E(`design:type`,Object)],mc.prototype,`dropdownPosition`,void 0),D([C(),E(`design:type`,Array)],mc.prototype,`cachedOptions`,void 0),D([C(),E(`design:type`,Object)],mc.prototype,`draggedTagIndex`,void 0),D([C(),E(`design:type`,Object)],mc.prototype,`dragOverTagIndex`,void 0),mc=D([x(`input-select`)],mc);var hc=class extends R{handleChange(e){let t=e.target;this.updateModel(t.checked)}handleToggle(){!this.props.disabled&&!this.props.readonly&&this.updateModel(!(this.getValue()??!1))}renderField(){let e=this.getValue()??!1,t=typeof this.props.toggleLabel==`function`?this.props.toggleLabel(this.model):this.props.toggleLabel,n=this.props.layout===`between`,r=!this.props.label&&this.props.help?this.renderHelp(t):``,i=t?v`
      <span class="form-inline-label" @click=${this.handleToggle}>
        <span>${j(t)}</span>
        ${r}
      </span>
    `:``;return v`
      <div class="form-switch-row ${n?`is-between`:``}">
        ${n?i:``}
        <label class="form-switch">
          <input
            type="checkbox"
            class="form-native-control"
            .checked=${e}
            ?disabled=${this.props.disabled}
            ?readonly=${this.props.readonly}
            @change=${this.handleChange}
          />
          <span class="form-switch-track ${this.props.rounded?`rounded-pill`:``}"></span>
        </label>
        ${n?``:i}
      </div>
    `}};hc=D([x(`input-toggle`)],hc);var z=new class{constructor(){this.dialogs=[],this.listeners=new Set}subscribe(e){return this.listeners.add(e),e(this.dialogs),()=>this.listeners.delete(e)}notify(){this.listeners.forEach(e=>e([...this.dialogs]))}generateId(){return`dialog-${Date.now()}-${Math.random().toString(36).substr(2,9)}`}open(e){return new Promise((t,n)=>{let r=this.generateId();this.dialogs.push({id:r,config:e,resolve:t,reject:n}),this.activeDialogId=r,this.notify()})}openForm(e){return new Promise((t,n)=>{let r=this.generateId();this.dialogs.push({id:r,config:e,resolve:t,reject:n}),this.activeDialogId=r,this.notify()})}getFallbackActiveDialog(){return this.dialogs[this.dialogs.length-1]}getActiveDialogIndex(){if(!this.activeDialogId)return this.dialogs.length-1;let e=this.dialogs.findIndex(e=>e.id===this.activeDialogId);return e===-1?this.dialogs.length-1:e}syncActiveDialog(){this.activeDialogId&&this.dialogs.some(e=>e.id===this.activeDialogId)||(this.activeDialogId=this.getFallbackActiveDialog()?.id)}close(e,t){if(t){let n=this.dialogs.findIndex(e=>e.id===t);n!==-1&&(this.dialogs[n].resolve(e),this.dialogs.splice(n,1),this.syncActiveDialog(),this.notify())}else if(this.dialogs.length>0){let t=this.getActiveDialogIndex(),[n]=this.dialogs.splice(t,1);n.resolve(e),this.syncActiveDialog(),this.notify()}}cancel(e,t){if(t){let n=this.dialogs.findIndex(e=>e.id===t);n!==-1&&(this.dialogs[n].reject(e),this.dialogs.splice(n,1),this.syncActiveDialog(),this.notify())}else if(this.dialogs.length>0){let t=this.getActiveDialogIndex(),[n]=this.dialogs.splice(t,1);n.reject(e),this.syncActiveDialog(),this.notify()}}moveToBack(e){let t=this.dialogs.findIndex(t=>t.id===e);if(t<=0)return;let[n]=this.dialogs.splice(t,1);this.dialogs.unshift(n),this.syncActiveDialog(),this.notify()}focus(e){!this.dialogs.some(t=>t.id===e)||this.activeDialogId===e||(this.activeDialogId=e,this.notify())}get isOpen(){return this.dialogs.length>0}get current(){return this.dialogs.length===0?null:this.dialogs[this.getActiveDialogIndex()]||null}get all(){return[...this.dialogs]}get activeId(){return this.activeDialogId}},B=gt(class extends _t{constructor(e){if(super(e),this.element=null,this.clickHandler=null,this.options={},e.type!==ht.ELEMENT)throw Error(`requireConfirmation directive can only be used on elements`)}update(e,[t]){let n=e.element;return this.element!==n&&(this.removeClickHandler(),this.element=n),typeof t==`boolean`?this.options=t?{}:{title:``,message:``}:this.options=t||{},t?this.addClickHandler():this.removeClickHandler(),this.render(t)}render(e){}addClickHandler(){!this.element||this.clickHandler||(this.clickHandler=async e=>{e.stopPropagation(),e.preventDefault();try{await z.open({title:j(this.options.title||`Confirm Action`),content:j(this.options.message||`Are you sure you want to proceed?`),buttons:[{label:`Cancel`,variant:`ghost`,action:()=>z.cancel()},{label:`Confirm`,variant:this.options.variant||`primary`,action:()=>z.close(!0)}]});let e=new CustomEvent(`click`,{bubbles:!0,cancelable:!0,composed:!0,detail:{confirmedAction:!0}});this.removeClickHandler(),this.element.dispatchEvent(e),await Promise.resolve(),this.addClickHandler()}catch{}},this.element.addEventListener(`click`,this.clickHandler,{capture:!0}))}removeClickHandler(){this.element&&this.clickHandler&&(this.element.removeEventListener(`click`,this.clickHandler,{capture:!0}),this.clickHandler=null)}disconnected(){this.removeClickHandler()}reconnected(){this.addClickHandler()}}),V=gt(class extends _t{constructor(e){if(super(e),this.element=null,this.popoverElement=null,this.options=null,this.mouseEnterHandler=null,this.mouseLeaveHandler=null,this.focusHandler=null,this.blurHandler=null,e.type!==ht.ELEMENT)throw Error(`showPopover directive can only be used on elements`)}update(e,[t]){let n=e.element;return this.element!==n&&(this.removeHandlers(),this.hidePopover(),this.element=n),this.options=this.normalizeOptions(t),this.options?this.addHandlers():(this.removeHandlers(),this.hidePopover()),this.render(t)}render(e){}normalizeOptions(e){return e?typeof e==`string`?{content:j(e),placement:`top`}:`content`in e?{content:typeof e.content==`string`?j(e.content):e.content,placement:e.placement||`top`}:{content:e,placement:`top`}:null}addHandlers(){!this.element||this.mouseEnterHandler||(this.mouseEnterHandler=()=>this.showPopover(),this.mouseLeaveHandler=()=>this.hidePopover(),this.focusHandler=()=>this.showPopover(),this.blurHandler=()=>this.hidePopover(),this.element.addEventListener(`mouseenter`,this.mouseEnterHandler),this.element.addEventListener(`mouseleave`,this.mouseLeaveHandler),this.element.addEventListener(`focusin`,this.focusHandler),this.element.addEventListener(`focusout`,this.blurHandler))}removeHandlers(){this.element&&(this.mouseEnterHandler&&=(this.element.removeEventListener(`mouseenter`,this.mouseEnterHandler),null),this.mouseLeaveHandler&&=(this.element.removeEventListener(`mouseleave`,this.mouseLeaveHandler),null),this.focusHandler&&=(this.element.removeEventListener(`focusin`,this.focusHandler),null),this.blurHandler&&=(this.element.removeEventListener(`focusout`,this.blurHandler),null))}showPopover(){if(!this.element||!this.options)return;this.hidePopover();let e=document.createElement(`div`);e.className=`popover show`,e.style.position=`fixed`,e.style.pointerEvents=`none`,Ke(v`<div class="tree-action-popover">${this.options.content}</div>`,e),document.body.appendChild(e),this.popoverElement=e,this.updatePopoverPosition()}hidePopover(){this.popoverElement&&=(Ke(v``,this.popoverElement),this.popoverElement.remove(),null)}updatePopoverPosition(){if(!this.element||!this.popoverElement||!this.options)return;let e=this.element.getBoundingClientRect(),t=this.popoverElement,n=Math.max(120,window.innerWidth-16);t.style.maxWidth=`${n}px`;let r=Math.min(t.offsetWidth||220,n),i=t.offsetHeight||40,a=e.left+e.width/2-r/2,o=Math.min(Math.max(a,8),window.innerWidth-r-8),s=this.getResolvedPlacement(e,i,6);if(s===`right`){t.style.left=`${Math.min(e.right+6,window.innerWidth-r-8)}px`,t.style.top=`${Math.min(Math.max(e.top+e.height/2-i/2,8),window.innerHeight-i-8)}px`;return}if(s===`left`){t.style.left=`${Math.max(e.left-r-6,8)}px`,t.style.top=`${Math.min(Math.max(e.top+e.height/2-i/2,8),window.innerHeight-i-8)}px`;return}t.style.left=`${o}px`,t.style.top=s===`bottom`?`${Math.min(e.bottom+6,window.innerHeight-i-8)}px`:`${Math.max(e.top-i-6,8)}px`}getResolvedPlacement(e,t,n){let r=this.options?.placement||`top`;if(r!==`auto`)return r;let i=e.top,a=window.innerHeight-e.bottom;return a>=t+n||a>i?`bottom`:`top`}disconnected(){this.removeHandlers(),this.hidePopover()}reconnected(){this.options&&this.addHandlers()}}),gc=class extends Us{constructor(...e){super(...e),this.items=[],this.draggingIndex=null,this.dragOverIndex=null}connectedCallback(){super.connectedCallback(),this.items=this.getValue()||[]}getItemFields(){return this.fieldArray||this.props.itemFields||[]}addItem(){let e=this.getItemFields(),t={};this.processItemFields(e,e=>{e.key&&(t[e.key]=e.defaultValue===void 0?this.getDefaultValueForType(e):e.defaultValue)}),this.initializeNestedFieldHooks(e,t),this.items=[...this.items,t],this.updateModel(this.items)}processItemFields(e,t){e.forEach(e=>{e.fieldGroup?this.processItemFields(e.fieldGroup,t):t(e),e.fieldArray&&e.type===`input-accordion`&&this.processItemFields(e.fieldArray,t)})}getDefaultValueForType(e){let t=typeof e.type==`string`?e.type:``;return t===`input-checkbox`||t===`input-toggle`?!1:t===`input-number`||t===`input-range`?0:t===`input-array`?[]:t===`input-json`||t===`input-object-pairs`?{}:``}removeItem(e){this.items=this.items.filter((t,n)=>n!==e),this.updateModel(this.items)}moveItemTo(e,t){if(e===t||e<0||t<0||e>=this.items.length||t>=this.items.length)return;let n=[...this.items],[r]=n.splice(e,1);n.splice(t,0,r),this.items=n,this.updateModel(this.items)}handleDragStart(e,t){t.stopPropagation(),this.draggingIndex=e,t.dataTransfer?.setData(`text/plain`,String(e)),t.dataTransfer&&(t.dataTransfer.effectAllowed=`move`)}handleDragOver(e,t){this.draggingIndex!==null&&(t.preventDefault(),t.stopPropagation(),this.dragOverIndex=e,t.dataTransfer&&(t.dataTransfer.dropEffect=`move`))}handleDrop(e,t){if(this.draggingIndex===null)return;t.preventDefault(),t.stopPropagation();let n=Number(t.dataTransfer?.getData(`text/plain`)??this.draggingIndex);Number.isInteger(n)&&this.moveItemTo(n,e),this.draggingIndex=null,this.dragOverIndex=null}handleDragEnd(e){e.stopPropagation(),this.draggingIndex=null,this.dragOverIndex=null}handleDragLeave(e,t){this.draggingIndex!==null&&(t.stopPropagation(),(!t.currentTarget||!t.currentTarget.contains(t.relatedTarget))&&this.dragOverIndex===e&&(this.dragOverIndex=null))}handleItemFieldChange(e,t){t.stopPropagation();let{key:n,value:r}=t.detail,i=this.getItemFields();this.items=this.items.map((t,a)=>{if(a!==e)return t;let o={...t};return Hs(o,n,r),this.triggerFieldHooks(i,n,r,o),o}),this.updateModel(this.items)}renderItemField(e,t,n){return this.renderNestedField(e,t,e=>this.handleItemFieldChange(n,e))}renderField(){let e=this.getItemFields();return v`
      <div class="form-stack">
        ${this.items.map((t,n)=>v`
          ${this.renderArrayItem(e,t,n)}
        `)}
        <app-button
          .icon=${O}
          variant="primary"
          .outline=${!0}
          .label=${this.props.addLabel||`Add Item`}
          @click=${this.addItem}
        >
        </app-button>
      </div>
    `}renderArrayItem(e,t,n){let r=e.length===1&&e[0]?.type===`input-accordion`,i=this.draggingIndex===n,a=this.dragOverIndex===n&&this.draggingIndex!==null&&this.draggingIndex!==n;return v`
      <div
        class="form-array-item ${i?`is-dragging`:a?`is-drop-target`:``}"
        @dragover=${e=>this.handleDragOver(n,e)}
        @dragleave=${e=>this.handleDragLeave(n,e)}
        @drop=${e=>this.handleDrop(n,e)}
      >
        <div class="flex-shrink-0 ${r?``:`pt-6`}">
          ${this.renderDragHandle(n)}
        </div>
        <div class="min-w-0 flex-grow-1 ${r?``:`form-stack`}">
          ${e.map(e=>this.renderItemField(e,t,n))}
        </div>
        <div class="flex-shrink-0 ${r?``:`pt-6`}">
          ${this.renderRemoveButton(n)}
        </div>
      </div>
    `}renderDragHandle(e){return v`
      <button
        type="button"
        draggable="true"
        class="btn btn-square btn-plain text-muted cursor-grab"
        ${V(`Drag`)}
        @click=${e=>e.stopPropagation()}
        @dragstart=${t=>this.handleDragStart(e,t)}
        @dragend=${e=>this.handleDragEnd(e)}
      >
        <span class="drag-handle">
          ${Array.from({length:6}).map(()=>v`<span></span>`)}
        </span>
      </button>
    `}renderRemoveButton(e){return v`
      <button
        type="button"
        class="btn btn-square btn-plain btn-danger"
        ${V(`Remove`)}
        @click=${t=>{t.stopPropagation(),this.removeItem(e)}}
      >
        <app-icon .icon=${k}></app-icon>
      </button>
    `}};D([C(),E(`design:type`,Array)],gc.prototype,`items`,void 0),D([C(),E(`design:type`,Object)],gc.prototype,`draggingIndex`,void 0),D([C(),E(`design:type`,Object)],gc.prototype,`dragOverIndex`,void 0),gc=D([x(`input-array`)],gc);var _c=class extends R{constructor(...e){super(...e),this.items=[],this.draft=``,this.suppressBlurCommitOnce=!1,this.draggingIndex=null,this.dragOverIndex=null}connectedCallback(){super.connectedCallback(),this.items=this.normalizeItems(this.getValue())}willUpdate(e){e.has(`value`)&&(this.items=this.normalizeItems(this.getValue()))}normalizeItems(e){return Array.isArray(e)?e.filter(e=>typeof e==`string`).map(e=>e):[]}setDraft(e){this.draft=e.target.value}getSeparator(){let e=this.props.separator;return typeof e==`string`&&e.length>0?e:`,`}getOptions(){let e=this.props.options,t=typeof e==`function`?e(this.getValue(),this.model):e;if(!Array.isArray(t))return[];let n=new Set;return t.forEach(e=>{if(typeof e!=`string`)return;let t=e.trim();t&&n.add(t)}),Array.from(n)}getVisibleOptions(){let e=this.draft.trim().toLowerCase(),t=new Set(this.items);return this.getOptions().filter(e=>!t.has(e)).filter(t=>!e||t.toLowerCase().includes(e))}parseDraft(e){let t=this.getSeparator();return e.split(t).map(e=>e.trim()).filter(e=>e.length>0)}commitDraft(){if(this.props.disabled||this.props.readonly)return;let e=this.parseDraft(this.draft);if(e.length===0)return;let t=new Set(this.items),n=[];for(let r of e)t.has(r)||(t.add(r),n.push(r));if(n.length===0){this.draft=``;return}this.items=[...this.items,...n],this.updateModel(this.items),this.draft=``}addOption(e){this.props.disabled||this.props.readonly||!e||this.items.includes(e)||(this.items=[...this.items,e],this.updateModel(this.items),this.draft=``)}onAddMouseDown(){this.suppressBlurCommitOnce=!0}handleBlur(){if(this.suppressBlurCommitOnce){this.suppressBlurCommitOnce=!1;return}this.commitDraft()}removeItem(e){this.items=this.items.filter((t,n)=>n!==e),this.updateModel(this.items)}moveItemTo(e,t){if(e===t||e<0||t<0||e>=this.items.length||t>=this.items.length)return;let n=[...this.items],[r]=n.splice(e,1);n.splice(t,0,r),this.items=n,this.updateModel(n)}handleDragStart(e,t){t.stopPropagation(),this.draggingIndex=e,t.dataTransfer?.setData(`text/plain`,String(e)),t.dataTransfer&&(t.dataTransfer.effectAllowed=`move`)}handleDragOver(e,t){this.draggingIndex!==null&&(t.preventDefault(),t.stopPropagation(),this.dragOverIndex=e,t.dataTransfer&&(t.dataTransfer.dropEffect=`move`))}handleDrop(e,t){if(this.draggingIndex===null)return;t.preventDefault(),t.stopPropagation();let n=Number(t.dataTransfer?.getData(`text/plain`)??this.draggingIndex);Number.isInteger(n)&&this.moveItemTo(n,e),this.draggingIndex=null,this.dragOverIndex=null}handleDragEnd(e){e.stopPropagation(),this.draggingIndex=null,this.dragOverIndex=null}handleKeyDown(e){e.key===`Enter`&&(e.preventDefault(),this.commitDraft())}renderField(){let e=this.props.fullWidthItems===!0,t=this.getVisibleOptions(),n=this.getOptions().length>0,r=v`
      <input
        type="text"
        class="${this.inputClass} max-w-20rem"
        .value=${this.draft}
        placeholder=${this.props.placeholder||``}
        ?disabled=${this.props.disabled}
        ?readonly=${this.props.readonly}
        @input=${e=>this.setDraft(e)}
        @keydown=${e=>this.handleKeyDown(e)}
        @blur=${()=>this.handleBlur()}
      />
    `;return v`
      <div>
        <div class="form-inline">
          ${n?v`
                <app-dropdown
                  class="form-select-dropdown flex-grow-1 max-w-20rem"
                  plainTrigger
                  fixedMenu
                  matchTriggerWidth
                  .showIndicator=${!1}
                  .trigger=${r}
                  .menu=${v`
                    <div @pointerdown=${()=>{this.suppressBlurCommitOnce=!0}}>
                      <div class="dropdown-list">
                        ${t.length?t.map(e=>v`
                              <app-dropdown-item
                                .label=${e}
                                @item-click=${()=>this.addOption(e)}
                              ></app-dropdown-item>
                            `):v`<div class="dropdown-empty">No options found</div>`}
                      </div>
                    </div>
                  `}
                ></app-dropdown>
              `:r}
          <app-button
            type="button"
            ?disabled=${this.props.disabled||this.props.readonly}
            ?outline=${!0}
            @mousedown=${()=>this.onAddMouseDown()}
            @click=${()=>this.commitDraft()}
            label="Add"
          ></app-button>
        </div>

        ${this.items.length?v`
              <div class="d-flex flex-wrap gap-2 mt-2 ${e?`flex-column`:``}">
                ${this.items.map((t,n)=>{let r=this.draggingIndex===n,i=this.dragOverIndex===n&&this.draggingIndex!==null&&this.draggingIndex!==n;return v`
                    <span
                      class="badge ${e?`w-100 justify-content-between`:``} ${r?`opacity-50`:``} ${i?`border-primary`:``}"
                      @dragover=${e=>this.handleDragOver(n,e)}
                      @drop=${e=>this.handleDrop(n,e)}
                    >
                      <button
                        type="button"
                        draggable="true"
                        class="btn btn-plain btn-square badge-action flex-shrink-0 cursor-grab text-muted"
                        ${V(`Drag`)}
                        @click=${e=>e.stopPropagation()}
                        @dragstart=${e=>this.handleDragStart(n,e)}
                        @dragend=${e=>this.handleDragEnd(e)}
                      >
                        <span class="drag-handle">
                          ${Array.from({length:6}).map(()=>v`<span></span>`)}
                        </span>
                      </button>
                      <span class="min-w-0 text-break">${t}</span>
                      <button
                        type="button"
                        class="btn btn-plain btn-danger btn-square badge-action flex-shrink-0"
                        aria-label="Remove"
                        @click=${()=>this.removeItem(n)}
                      >
                        <app-icon .icon=${Gn} size="14"></app-icon>
                      </button>
                    </span>
                  `})}
              </div>
            `:``}
      </div>
    `}};D([C(),E(`design:type`,Array)],_c.prototype,`items`,void 0),D([C(),E(`design:type`,Object)],_c.prototype,`draft`,void 0),D([C(),E(`design:type`,Object)],_c.prototype,`suppressBlurCommitOnce`,void 0),D([C(),E(`design:type`,Object)],_c.prototype,`draggingIndex`,void 0),D([C(),E(`design:type`,Object)],_c.prototype,`dragOverIndex`,void 0),_c=D([x(`input-array-text`)],_c);var vc=class extends R{constructor(...e){super(...e),this.pairs=[]}connectedCallback(){super.connectedCallback();let e=this.getValue()||{};this.pairs=Object.entries(e).map(([e,t])=>({key:e,value:String(t)}))}addPair(){this.pairs=[...this.pairs,{key:``,value:``}],this.updateObject()}removePair(e){this.pairs=this.pairs.filter((t,n)=>n!==e),this.updateObject()}updatePair(e,t,n){this.pairs=this.pairs.map((r,i)=>i===e?{...r,[t]:n}:r),this.updateObject()}updateObject(){let e={};this.pairs.forEach(t=>{t.key&&(e[t.key]=t.value)}),this.updateModel(e)}renderField(){return v`
      <div class="form-stack">
        ${this.pairs.map((e,t)=>v`
          <div class="form-pair">
            <input
              type="text"
              class="form-control"
              .value=${e.key}
              placeholder="${this.props.keyPlaceholder||`Key`}"
              @input=${e=>this.updatePair(t,`key`,e.target.value)}
            />
            <span class="form-pair-separator">-&gt;</span>
            <input
              type="text"
              class="form-control"
              .value=${e.value}
              placeholder="${this.props.valuePlaceholder||`Value`}"
              @input=${e=>this.updatePair(t,`value`,e.target.value)}
            />
            <button
              type="button"
              class="btn btn-square btn-plain btn-danger"
              aria-label="Remove pair"
              @click=${()=>this.removePair(t)}
            >
              <app-icon .icon=${k} size="20"></app-icon>
            </button>
          </div>
        `)}
        <button
          type="button"
          class="btn btn-warning w-100"
          @click=${this.addPair}
        >
          <app-icon .icon=${O} size="20"></app-icon>
          <span>Add Pair</span>
        </button>
      </div>
    `}};D([C(),E(`design:type`,typeof Array>`u`?Object:Array)],vc.prototype,`pairs`,void 0),vc=D([x(`input-object-pairs`)],vc);var yc=class extends Us{constructor(...e){super(...e),this.pairs=[],this.touchedKeyIndexes=new Set}connectedCallback(){super.connectedCallback();let e=this.getValue()||{};this.pairs=Object.entries(e).map(([e,t])=>({key:e,value:t,type:this.detectType(t)}))}detectType(e){return typeof e==`boolean`?`boolean`:typeof e==`number`?`number`:typeof e==`object`&&e&&!Array.isArray(e)?`object`:`string`}addPair(){this.pairs=[...this.pairs,{key:``,value:``,type:`string`}],this.updateObject()}removePair(e){this.pairs=this.pairs.filter((t,n)=>n!==e),this.touchedKeyIndexes=new Set([...this.touchedKeyIndexes].filter(t=>t!==e).map(t=>t>e?t-1:t)),this.updateObject()}updatePairKey(e,t){this.pairs=this.pairs.map((n,r)=>r===e?{...n,key:t}:n),this.updateObject()}markKeyTouched(e){this.touchedKeyIndexes=new Set([...this.touchedKeyIndexes,e])}updatePairType(e,t){let n={string:``,number:0,boolean:!1,object:{}};this.pairs=this.pairs.map((r,i)=>i===e?{...r,type:t,value:n[t]}:r),this.updateObject()}handlePairValueChange(e,t){t.stopPropagation();let{value:n}=t.detail;this.pairs=this.pairs.map((t,r)=>r===e?{...t,value:n}:t),this.updateObject()}updateObject(){let e={};this.pairs.forEach(t=>{t.key.trim()&&(e[t.key]=t.value)}),this.updateModel(e),this.hasInvalidKeys()&&queueMicrotask(()=>{this.dispatchEvent(new CustomEvent(`validation-change`,{detail:{isValid:!1,validationState:{[this.key]:{valid:!1,errors:[`All object keys are required`]}}},bubbles:!0,composed:!0}))})}hasInvalidKeys(){return this.pairs.some(e=>!e.key.trim())}getFieldConfigForType(e){return{string:{type:`input-text`,key:`value`,props:{placeholder:`Enter value`}},number:{type:`input-number`,key:`value`,props:{placeholder:`Enter number`}},boolean:{type:`input-toggle`,key:`value`,props:{toggleLabel:`Value`}},object:{type:`input-object`,key:`value`,props:{keyPlaceholder:`Nested key`}}}[e]}renderValueField(e,t){let n=this.getFieldConfigForType(e.type),r={value:e.value};return this.renderNestedField(n,r,e=>this.handlePairValueChange(t,e))}renderField(){return v`
      <div class="form-stack">
        ${this.pairs.map((e,t)=>v`
          <div class="form-object-item">
            <div class="form-object-row">
              <div class="form-object-key">
                <div @focusout=${()=>this.markKeyTouched(t)}>
                  ${this.renderNestedField({type:`input-text`,key:`key`,className:!e.key.trim()&&this.touchedKeyIndexes.has(t)?`is-invalid`:``,props:{placeholder:this.props.keyPlaceholder||`Key`,required:!0}},{key:e.key},e=>{e.stopPropagation(),this.updatePairKey(t,e.detail.value)})}
                </div>
              </div>
              <div class="form-object-type">
                ${this.renderNestedField({type:`input-select`,key:`type`,defaultValue:`string`,props:{placeholder:`Type`,options:[{value:`string`,label:`String`},{value:`number`,label:`Number`},{value:`boolean`,label:`Boolean`},{value:`object`,label:`Object`}]}},{type:e.type||`string`},e=>{e.stopPropagation(),this.updatePairType(t,e.detail.value)})}
              </div>
              <button
                type="button"
                class="btn btn-square btn-plain btn-danger"
                aria-label="Remove property"
                @click=${()=>this.removePair(t)}
              >
                <app-icon .icon=${k}></app-icon>
              </button>
            </div>
            <div>
              ${this.renderValueField(e,t)}
            </div>
          </div>
        `)}
        <app-button
          .icon=${O}
          .outline=${!0}
          size="sm"
          label="Add Property"
          @click=${this.addPair}
        >
        </app-button>
      </div>
    `}};D([C(),E(`design:type`,Array)],yc.prototype,`pairs`,void 0),D([C(),E(`design:type`,Object)],yc.prototype,`touchedKeyIndexes`,void 0),yc=D([x(`input-object`)],yc);var bc=class extends R{connectedCallback(){super.connectedCallback(),this.props.subscribe&&typeof this.props.subscribe==`function`&&(this.unsubscribe=this.props.subscribe(()=>{this.requestUpdate()}))}disconnectedCallback(){super.disconnectedCallback(),this.unsubscribe?.()}renderField(){let e=this.props.html;return typeof e==`function`&&(e=e(this.model)),e?v`${e}`:v``}render(){return this.props.showLabel===!1?v`${this.renderField()}`:v`
      <div class="form-html">
        ${this.renderLabel()}
        ${this.renderDescription()}
        <div class="position-relative">
          ${this.renderField()}
        </div>
        ${this.renderHelper()}
      </div>
    `}};D([S({type:Object}),E(`design:type`,Object)],bc.prototype,`updateTrigger`,void 0),bc=D([x(`input-html`)],bc);var xc=class extends Us{constructor(...e){super(...e),this.isExpanded=!1,this.handleNestedFieldChange=e=>{e.stopPropagation();let{key:t,value:n}=e.detail,r=this.getFields();Hs(this.model,t,n),this.triggerFieldHooks(r,t,n,this.model),this.refreshParentForm(),this.requestUpdate(),this.dispatchEvent(new CustomEvent(`field-change`,{detail:{key:t,value:n},bubbles:!0,composed:!0}))}}connectedCallback(){super.connectedCallback(),this.props.initExpand===!0&&(this.isExpanded=!0);let e=this.getFields();this.initializeNestedFieldHooks(e,this.model)}getFields(){return this.fieldArray||this.props.fields||[]}toggleAccordion(){this.isExpanded=!this.isExpanded}handleHeaderInput(e){if(!this.key)return;let t=e.target.value;Hs(this.model,this.key,t),this.dispatchEvent(new CustomEvent(`field-change`,{detail:{key:this.key,value:t},bubbles:!0,composed:!0}))}renderHeaderContent(e){if(!this.key)return v`<span class="form-accordion-title">${j(e)}</span>`;let t=Vs(this.model,this.key)??``,n=this.props.label||e;return v`
      <label class="form-accordion-input" @click=${e=>e.stopPropagation()}>
        <input
          type="text"
          class="form-control"
          .value=${t}
          placeholder=${j(this.props.placeholder||n)}
          ?required=${!!this.props.required}
          @input=${this.handleHeaderInput}
        />
      </label>
    `}renderField(){let e=this.getFields(),t=this.props.title||`Options`,n=this.props.border!==!1;return v`
      <div class="form-accordion">
        <div
          class="form-accordion-header ${this.key?`no-hover`:``}"
          @click=${this.toggleAccordion}
        >
          ${this.props.headerBefore||``}
          ${this.renderHeaderContent(t)}
          <div class="form-accordion-actions" @click=${e=>e.stopPropagation()}>
            ${this.props.headerActions||``}
            <button
              type="button"
              class="btn btn-square btn-plain"
              @click=${e=>{e.stopPropagation(),this.toggleAccordion()}}
            >
              <app-icon .icon=${this.isExpanded?fn:cn}></app-icon>
            </button>
          </div>
        </div>
        ${this.isExpanded?v`
          <div class="form-accordion-body ${n?`has-border`:``}">
            ${e.map(e=>this.renderNestedField(e,this.model,this.handleNestedFieldChange))}
          </div>
        `:``}
      </div>
    `}render(){return v`
      <div>
        ${this.renderField()}
      </div>
    `}};D([C(),E(`design:type`,Boolean)],xc.prototype,`isExpanded`,void 0),xc=D([x(`input-accordion`)],xc);var Sc=class extends R{constructor(...e){super(...e),this.config={type:`daily`,minute:0,minutes:`00`,hour:12,times:`12:00`,days:[]}}connectedCallback(){super.connectedCallback();let e=this.getValue();e&&(this.config=this.parseCron(e),this.model?.modificators?.runLastDayOfMonth&&(this.config={...this.config,type:`monthly`,days:[...(this.config.days||[]).filter(e=>e!==28&&e!==29&&e!==30&&e!==31),32]}))}parseCron(e){let t=e.trim().split(/\s+/);if(t.length<5)return{type:`custom`,customCron:e};let n,r,i,a,o;t.length===6?[,n,r,i,a,o]=t:[n,r,i,a,o]=t;let s=parseInt(n),c=parseInt(r);return n!==`*`&&r===`*`&&i===`*`&&a===`*`&&o===`*`?{type:`hourly`,minute:s,minutes:n}:r!==`*`&&n!==`*`&&i===`*`&&a===`*`&&o===`*`?{type:`daily`,minute:s,hour:c,times:this.parseTimeList(r,n)}:o!==`*`&&o!==`?`&&i===`*`&&a===`*`?{type:`weekly`,minute:s,hour:c,days:o.includes(`,`)?o.split(`,`).map(e=>parseInt(e)):[parseInt(o)]}:(i.includes(`L`)||i===`L`)&&a===`*`?{type:`custom`,customCron:e}:i!==`*`&&a===`*`&&(o===`*`||o===`?`)?{type:`monthly`,minute:s,hour:c,days:i.includes(`,`)?i.split(`,`).map(e=>parseInt(e)):[parseInt(i)]}:i!==`*`&&a!==`*`&&(o===`*`||o===`?`)?{type:`yearly`,minute:s,hour:c,days:i.includes(`,`)?i.split(`,`).map(e=>parseInt(e)):[parseInt(i)],months:a.includes(`,`)?a.split(`,`).map(e=>parseInt(e)):[parseInt(a)]}:{type:`custom`,customCron:e}}buildCron(){let{type:e,minute:t=0,minutes:n=`00`,hour:r=12,times:i=`12:00`,days:a=[],months:o=[],customCron:s}=this.config;if(e===`custom`)return s||`0 0 * * *`;switch(e){case`hourly`:return`0 ${this.normalizeNumberInput(n||String(t),0,59).join(`,`)} * * * *`;case`daily`:{let e=this.normalizeTimes(i||`${r}:${t}`);return`0 ${this.normalizeNumberList(e.map(e=>e.minute),0,59).join(`,`)} ${this.normalizeNumberList(e.map(e=>e.hour),0,23).join(`,`)} * * *`}case`weekly`:return`0 ${t} ${r} * * ${a.length>0?a.sort().join(`,`):`0`}`;case`monthly`:return`0 ${t} ${r} ${this.normalizeMonthDays(a.length?a:[1]).cronDays.join(`,`)} * *`;case`yearly`:return`0 ${t} ${r} ${this.normalizeMonthDays(a.length?a:[1]).cronDays.join(`,`)} ${o.length>0?o.sort((e,t)=>e-t).join(`,`):`1`} *`;default:return`0 0 * * *`}}handleTypeChange(e){this.config={...this.config,type:e},this.updateCron()}parseNumberList(e,t,n){return e.split(`,`).map(e=>Number(e.trim())).filter(e=>Number.isInteger(e)&&e>=t&&e<=n)}normalizeNumberList(e,t,n){return[...new Set(e.map(e=>Number(e)).filter(e=>Number.isInteger(e)&&e>=t&&e<=n))].sort((e,t)=>e-t)}parseTimeList(e,t){let n=this.parseNumberList(e,0,23),r=this.parseNumberList(t,0,59);return n.length===0||r.length===0?`12:00`:n.flatMap(e=>r.map(t=>({hour:e,minute:t}))).sort((e,t)=>e.hour-t.hour||e.minute-t.minute).map(e=>`${String(e.hour).padStart(2,`0`)}:${String(e.minute).padStart(2,`0`)}`).join(`,`)}normalizeNumberInput(e,t,n){let r=this.parseNumberList(e,t,n);return r.length?r:[t]}normalizeTimes(e){let t=e.split(`,`).map(e=>String(e).trim()).map(e=>{let t=e.match(/^(\d{1,2}):(\d{1,2})$/);if(!t)return null;let n=Number(t[1]),r=Number(t[2]);return!Number.isInteger(n)||!Number.isInteger(r)||n<0||n>23||r<0||r>59?null:{hour:n,minute:r,value:`${String(n).padStart(2,`0`)}:${String(r).padStart(2,`0`)}`}}).filter(Boolean);return[...new Map(t.map(e=>[e.value,e])).values()].sort((e,t)=>e.hour-t.hour||e.minute-t.minute)}normalizeMonthDays(e){let t=this.normalizeNumberList(e,1,32),n=t.flatMap(e=>e===32?[28,29,30,31]:e>=1&&e<=31?[e]:[]);return{configDays:t,cronDays:this.normalizeNumberList(n,1,31)}}handleMinuteChange(e){let t=parseInt(e.target.value)||0;this.config={...this.config,minute:Math.max(0,Math.min(59,t))},this.updateCron()}handleHourChange(e){let t=parseInt(e.target.value)||0;this.config={...this.config,hour:Math.max(0,Math.min(23,t))},this.updateCron()}handleDayToggle(e){let t=this.config.days||[],n=t.indexOf(e);n>=0?t.splice(n,1):t.push(e),this.config={...this.config,days:[...t]},this.updateCron()}handleMonthToggle(e){let t=this.config.months||[],n=t.indexOf(e);n>=0?t.splice(n,1):t.push(e),this.config={...this.config,months:[...t]},this.updateCron()}handleCustomCronChange(e){let t=e.target.value;this.config={...this.config,customCron:t},this.updateCron()}updateCron(){let e=this.buildCron();this.syncModificatorsToModel(),this.updateModel(e),this.requestUpdate()}syncModificatorsToModel(){if(!this.model)return;let e=this.config.type===`monthly`&&(this.config.days||[]).includes(32),t=this.model.modificators||{};if(e){this.model.modificators={...t,runLastDayOfMonth:!0};return}let{runLastDayOfMonth:n,...r}=t;Object.keys(r).length>0?this.model.modificators=r:delete this.model.modificators}renderHourly(){return v`
      <div>
        <input-text
          .key=${`minutes`}
          .props=${{label:`Every hour at minute`,help:`Use comma-separated values to run more than once per hour, for example: 00,15,30,45.`}}
          .value=${this.config.minutes||`00`}
          @field-change=${e=>{let t=String(e.detail.value||`00`),n=this.normalizeNumberInput(t,0,59)[0]??0;this.config={...this.config,minutes:t,minute:n},this.updateCron()}}
        ></input-text>
      </div>
    `}renderDaily(){return v`
      <div>
        <input-text
          .key=${`times`}
          .props=${{label:`Every day at`,help:`Use comma-separated values to run more than once per day, for example: 08:00,18:30.`}}
          .value=${this.config.times||`12:00`}
          @field-change=${e=>{let t=String(e.detail.value||`12:00`),n=this.normalizeTimes(t)[0];this.config={...this.config,times:t,hour:n?.hour??12,minute:n?.minute??0},this.updateCron()}}
        ></input-text>
      </div>
    `}renderWeekly(){let e=[`SU`,`MO`,`TU`,`WE`,`TH`,`FR`,`SA`],t=this.config.days||[];return v`
      <div class="d-flex flex-column gap-3 mt-2">
        <div class="form-label mb-n2 mt-1">${j(`Every`)} *</div>
        <div class="d-flex flex-wrap align-items-center gap-4">
          ${e.map((e,n)=>v`
            <div class="d-flex align-items-center">
              <input-checkbox
                .key=${`day_`+n}
                .value=${t.includes(n)}
                .props=${{checkboxLabel:e}}
                @field-change=${()=>this.handleDayToggle(n)}
              ></input-checkbox>
            </div>
          `)}
        </div>
        <div class="form-label mb-n2 mt-n4">${j(`At`)}</div>
        <div class="d-inline-flex align-items-center gap-2">
          <input-number
            .key=${`hour`}
            .props=${{placeholder:`HH`,min:0,max:23}}
            .value=${String(this.config.hour||0).padStart(2,`0`)}
            @field-change=${e=>{this.config={...this.config,hour:parseInt(e.detail.value)||0},this.updateCron()}}
            class="d-block w-25 w-md-auto"
          ></input-number>
          <span class="text-muted">:</span>
          <input-number
            .key=${`minute`}
            .props=${{placeholder:`MM`,min:0,max:59}}
            .value=${String(this.config.minute||0).padStart(2,`0`)}
            @field-change=${e=>{this.config={...this.config,minute:parseInt(e.detail.value)||0},this.updateCron()}}
            class="d-block w-25 w-md-auto"
          ></input-number>
        </div>
      </div>
    `}renderMonthly(){let e=this.config.days||[],t=e.includes(32);return v`
      <div class="d-flex flex-column gap-3 mt-4">
        <div class="form-label mb-0">${j(`On day(s) of month`)}</div>
          <div class="d-flex flex-wrap align-items-center gap-4 mt-n2 mb-2">
          ${Array.from({length:31},(e,t)=>t+1).map(n=>v`
            <input-checkbox
              .key=${`day_`+n}
              .value=${e.includes(n)}
              class="d-block mb-n6"
              .props=${{checkboxLabel:String(n),disabled:t}}
              @field-change=${()=>this.handleDayToggle(n)}
            ></input-checkbox>
          `)}
          <input-checkbox
            .key=${`lastDayOfMonth`}
            .value=${t}
            .props=${{checkboxLabel:`Last day of month`,disabled:e.length>0&&!t}}
            class="d-block mb-n6"
            @field-change=${e=>{let t=!!e.detail.value;this.config={...this.config,days:t?[32]:[]},this.updateCron()}}
          ></input-checkbox>
        </div>
        <div class="form-label mb-n2">${j(`At`)}</div>
        <div class="d-inline-flex align-items-center gap-2">
          <input-number
            .key=${`hour`}
            .props=${{placeholder:`HH`,min:0,max:23}}
            .value=${String(this.config.hour||0).padStart(2,`0`)}
            @field-change=${e=>{this.config={...this.config,hour:parseInt(e.detail.value)||0},this.updateCron()}}
            class="d-block w-25 w-md-auto"
          ></input-number>
          <span class="text-muted">:</span>
          <input-number
            .key=${`minute`}
            .props=${{placeholder:`MM`,min:0,max:59}}
            .value=${String(this.config.minute||0).padStart(2,`0`)}
            @field-change=${e=>{this.config={...this.config,minute:parseInt(e.detail.value)||0},this.updateCron()}}
            class="d-block w-25 w-md-auto"
          ></input-number>
        </div>
      </div>
    `}renderYearly(){let e=[`Jan`,`Feb`,`Mar`,`Apr`,`May`,`Jun`,`Jul`,`Aug`,`Sep`,`Oct`,`Nov`,`Dec`],t=this.config.months?.[0]||1,n=this.config.days?.[0]||1;return v`
      <div>
        <div class="d-grid grid-columns-1 grid-columns-md-3 gap-4">
          <input-select
            .key=${`month`}
            .value=${t}
            .props=${{label:`Month`,options:e.map((e,t)=>({value:t+1,label:e}))}}
            @field-change=${e=>{let t=Number(e.detail.value)||1,r=new Date(2024,t,0).getDate();this.config={...this.config,months:[t],days:[Math.min(n,r)]},this.updateCron()}}
          ></input-select>
          <input-select
            .key=${`day`}
            .value=${n}
            .props=${{label:`Day`,options:Array.from({length:new Date(2024,t,0).getDate()},(e,t)=>({value:t+1,label:String(t+1)}))}}
            @field-change=${e=>{this.config={...this.config,days:[Number(e.detail.value)||1]},this.updateCron()}}
          ></input-select>
          <div class="d-inline-flex align-items-center gap-2">
            <input-number
              .key=${`hour`}
              .props=${{label:`Hour`,placeholder:`HH`,min:0,max:23}}
              .value=${String(this.config.hour||0).padStart(2,`0`)}
              @field-change=${e=>{this.config={...this.config,hour:parseInt(e.detail.value)||0},this.updateCron()}}
            ></input-number>
            <input-number
              .key=${`minute`}
              .props=${{label:`Minute`,placeholder:`MM`,min:0,max:59}}
              .value=${String(this.config.minute||0).padStart(2,`0`)}
              @field-change=${e=>{this.config={...this.config,minute:parseInt(e.detail.value)||0},this.updateCron()}}
            ></input-number>
          </div>
        </div>
      </div>
    `}renderCustom(){return v`
      <div>
        <input-text
          .key=${`customCron`}
          .props=${{label:`Cron expression`,placeholder:`0 0 * * *`}}
          .value=${this.config.customCron||``}
          @field-change=${e=>{this.config={...this.config,customCron:e.detail.value},this.updateCron()}}
        ></input-text>
        <div class="form-text">
          ${j(`Format: second minute hour day month dayOfWeek`)}
        </div>
      </div>
    `}renderField(){let e=[{type:`hourly`,label:`Hourly`},{type:`daily`,label:`Daily`},{type:`weekly`,label:`Weekly`},{type:`monthly`,label:`Monthly`},{type:`yearly`,label:`Yearly`},{type:`custom`,label:`Custom`}].map(e=>({value:e.type,label:e.label}));return v`
      <div>
        <input-select
          .key=${`cronType`}
          .value=${this.config.type}
          .props=${{options:e}}
          @field-change=${e=>this.handleTypeChange(e.detail.value)}
        ></input-select>

        <!-- Content -->
        ${this.config.type===`hourly`?this.renderHourly():``}
        ${this.config.type===`daily`?this.renderDaily():``}
        ${this.config.type===`weekly`?this.renderWeekly():``}
        ${this.config.type===`monthly`?this.renderMonthly():``}
        ${this.config.type===`yearly`?this.renderYearly():``}
        ${this.config.type===`custom`?this.renderCustom():``}

      </div>
    `}};D([C(),E(`design:type`,Object)],Sc.prototype,`config`,void 0),Sc=D([x(`input-cron`)],Sc);var Cc=new Set([`true`,`false`,`null`]);function wc(e){let t=[],n=0;for(;n<e.length;){let r=e[n];if(/\s/.test(r)){t.push({type:`text`,value:r}),n++;continue}if(r===`"`){let i=r;n++;let a=!1;for(;n<e.length&&e[n]!==`"`;)e[n]===`\\`&&n+1<e.length&&(i+=e[n++]),i+=e[n++];n<e.length&&(i+=e[n++]);let o=n;for(;o<e.length&&/\s/.test(e[o]);)o++;e[o]===`:`&&(a=!0),t.push({type:a?`key`:`string`,value:i});continue}if(/[-\d]/.test(r)){let i=``;for(r===`-`&&(i+=e[n++]);n<e.length&&/[\d.]/.test(e[n]);)i+=e[n++];if(n<e.length&&(e[n]===`e`||e[n]===`E`))for(i+=e[n++],n<e.length&&(e[n]===`+`||e[n]===`-`)&&(i+=e[n++]);n<e.length&&/\d/.test(e[n]);)i+=e[n++];t.push({type:`number`,value:i});continue}if(/[a-z]/.test(r)){let r=``;for(;n<e.length&&/[a-z]/.test(e[n]);)r+=e[n++];Cc.has(r)?t.push({type:`keyword`,value:r}):t.push({type:`error`,value:r});continue}if(/[{}[\]:,]/.test(r)){t.push({type:`punctuation`,value:r}),n++;continue}t.push({type:`error`,value:r}),n++}return t}function Tc(e){return e.replace(/&/g,`&amp;`).replace(/</g,`&lt;`).replace(/>/g,`&gt;`)}function Ec(e){return e.map(e=>{let t=Tc(e.value);switch(e.type){case`key`:return`<span class="tk">${t}</span>`;case`string`:return`<span class="ts">${t}</span>`;case`number`:return`<span class="tn">${t}</span>`;case`keyword`:return`<span class="tkw">${t}</span>`;case`punctuation`:return`<span class="tp">${t}</span>`;case`error`:return`<span class="te">${t}</span>`;default:return t}}).join(``)}function Dc(e){return e.replace(/^\uFEFF/,``)}var Oc=class extends b{constructor(...e){super(...e),this.key=``,this.props={},this.model={},this.lines=[``],this.cursorLine=1,this.cursorColumn=0,this.code=``,this.validationError=``}static{this.styles=c`
    :host {
      display: block;
      margin-bottom: var(--nq-field-gap, 8px);
      color: var(--nq-body-color);
    }

    .field-label {
      display: flex;
      height: var(--nq-label-height, 20px);
      align-items: center;
      gap: 0.375rem;
      margin-bottom: calc(var(--nq-field-gap, 8px) / 2);
      color: var(--nq-body-color);
      font-size: 0.875rem;
      font-weight: 500;
    }

    .field-label .required {
      color: var(--nq-danger);
    }

    .json-editor-container {
      position: relative;
      font-family: 'JetBrains Mono', 'Fira Code', 'Monaco', 'Consolas', monospace;
      font-size: 14px;
      line-height: 1.5;
      border-radius: var(--nq-control-radius);
      overflow: hidden;
      background: var(--nq-surface);
      border: 1px solid var(--nq-border-color);
    }

    .json-editor-container.error {
      border-color: var(--nq-danger);
    }

    .json-editor-container:focus-within {
      border-color: var(--nq-control-focus-color);
      box-shadow: 0 0 0 4px var(--nq-control-focus-ring);
    }

    .json-editor-container.error:focus-within {
      border-color: var(--nq-danger);
      box-shadow: 0 0 0 4px color-mix(in srgb, var(--nq-danger) 16%, transparent);
    }

    .code-wrapper {
      display: flex;
      overflow: auto;
      resize: vertical;
      scrollbar-width: thin;
      scrollbar-color: var(--nq-border-color) var(--nq-surface);
    }

    .code-wrapper::-webkit-scrollbar {
      width: 0.625rem;
      height: 0.625rem;
    }

    .code-wrapper::-webkit-scrollbar-track {
      background: var(--nq-surface);
    }

    .code-wrapper::-webkit-scrollbar-thumb {
      border: 2px solid var(--nq-surface);
      border-radius: 999px;
      background: var(--nq-border-color);
    }

    .line-numbers {
      flex-shrink: 0;
      padding: 12px 0;
      background: var(--nq-surface-subtle);
      color: var(--nq-muted-color);
      text-align: right;
      user-select: none;
      border-right: 1px solid var(--nq-border-color);
      min-width: 50px;
      position: sticky;
      left: 0;
      z-index: 3;
      height: 100%;
      box-sizing: border-box;
    }

    .line-number {
      padding: 0 12px;
      height: 1.5em;
    }

    .line-number.active {
      background: color-mix(in srgb, var(--nq-primary) 10%, transparent);
      color: var(--nq-primary);
    }

    .editor-content {
      position: relative;
      flex: 1;
      min-width: 0;
      z-index: 0;
    }

    .code-textarea {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      min-height: 100%;
      padding: 12px;
      margin: 0;
      border: none;
      background: transparent;
      color: transparent;
      caret-color: var(--nq-body-color);
      outline: none;
      resize: none;
      font: inherit;
      line-height: inherit;
      white-space: pre;
      overflow-wrap: normal;
      overflow: hidden;
      z-index: 2;
      tab-size: 2;
      box-sizing: border-box;
    }

    .code-highlight {
      padding: 12px;
      margin: 0;
      white-space: pre;
      overflow-wrap: normal;
      pointer-events: none;
      color: var(--nq-body-color);
      z-index: 1;
      width: fit-content;
      min-width: 100%;
      box-sizing: border-box;
    }

    /* JSON syntax highlighting */
    .code-highlight .tk {
      color: light-dark(#1d4ed8, #93c5fd);
    }

    .code-highlight .ts {
      color: light-dark(#15803d, #86efac);
    }

    .code-highlight .tn {
      color: light-dark(#c2410c, #fdba74);
    }

    .code-highlight .tkw {
      color: light-dark(#7e22ce, #d8b4fe);
    }

    .code-highlight .tp {
      color: var(--nq-muted-color);
    }

    .code-highlight .te {
      color: var(--nq-danger);
      text-decoration: underline wavy;
    }

    .status-bar {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 6px 12px;
      background: var(--nq-surface-subtle);
      border-top: 1px solid var(--nq-border-color);
      font-size: 12px;
      color: var(--nq-muted-color);
    }

    .status-info {
      display: flex;
      gap: 16px;
    }

    .field-error {
      margin-top: 8px;
      font-size: 12px;
      color: var(--nq-danger);
    }

    .field-helper {
      margin-top: 8px;
      font-size: 12px;
      color: var(--nq-muted-color);
    }

    .btn {
      display: inline-flex;
      min-height: var(--nq-control-height, 44px);
      align-items: center;
      justify-content: center;
      gap: 0.5rem;
      padding: 0 1rem;
      border: 1px solid transparent;
      border-radius: var(--nq-control-radius);
      background: transparent;
      color: var(--nq-body-color);
      font: inherit;
      font-weight: 600;
      cursor: pointer;
      transition: border-color 0.2s, background-color 0.2s, color 0.2s, box-shadow 0.2s;
    }

    .btn-sm {
      min-height: 2rem;
      padding: 0 0.625rem;
      font-size: 0.75rem;
    }

    .fw-normal {
      font-weight: 400;
    }

    .json-format-button {
      min-height: 0;
      &:hover {
        background: color-mix(in srgb, var(--nq-primary) 10%, transparent);
      }
    }

    .btn-outline-primary {
      border-color: var(--nq-primary);
      color: var(--nq-primary);
    }

    .btn-outline-primary:hover {
      background: color-mix(in srgb, var(--nq-primary) 10%, transparent);
    }

  `}connectedCallback(){super.connectedCallback(),this.value&&typeof this.value==`object`?this.code=JSON.stringify(this.value,null,2):typeof this.value==`string`?this.code=Dc(this.value):this.code=``,this.updateLines()}updateLines(){this.lines=this.code.split(`
`)}handleInput(e){let t=e.target;this.code=Dc(t.value);try{this.value=this.code.trim()?JSON.parse(this.code):null}catch{this.value=this.code}this.updateLines(),this.updateCursor(t),this.validateJson(),this.dispatchChange()}handleKeyDown(e){let t=e.target;if(e.key===`Tab`){e.preventDefault();let n=t.selectionStart,r=t.selectionEnd;this.code=this.code.substring(0,n)+`  `+this.code.substring(r);try{this.value=this.code.trim()?JSON.parse(this.code):null}catch{this.value=this.code}this.updateLines(),requestAnimationFrame(()=>{t.selectionStart=t.selectionEnd=n+2,this.updateCursor(t)}),this.dispatchChange()}if(e.key===`{`||e.key===`[`){e.preventDefault();let n=t.selectionStart,r=t.selectionEnd,i=e.key===`{`?`}`:`]`;this.code=this.code.substring(0,n)+e.key+i+this.code.substring(r);try{this.value=this.code.trim()?JSON.parse(this.code):null}catch{this.value=this.code}this.updateLines(),requestAnimationFrame(()=>{t.selectionStart=t.selectionEnd=n+1,this.updateCursor(t)}),this.dispatchChange()}}updateCursor(e){let t=e.value.substring(0,e.selectionStart).split(`
`);this.cursorLine=t.length,this.cursorColumn=t[t.length-1].length+1}handleScroll(e){let t=e.target,n=this.shadowRoot?.querySelector(`.code-highlight`);n&&(n.scrollLeft=t.scrollLeft,n.scrollTop=t.scrollTop)}validateJson(){if(!this.code.trim()){this.validationError=``;return}try{JSON.parse(Dc(this.code)),this.validationError=``}catch(e){this.validationError=e instanceof Error?e.message:`Invalid JSON`}}formatJson(){if(this.code.trim())try{let e=JSON.parse(Dc(this.code));this.code=JSON.stringify(e,null,2),this.value=e,this.updateLines(),this.validationError=``,this.dispatchChange()}catch{}}dispatchChange(){this.dispatchEvent(new CustomEvent(`field-change`,{detail:{key:this.key,value:this.value},bubbles:!0,composed:!0}))}updated(e){super.updated(e);let t=this.shadowRoot?.querySelector(`.code-textarea`),n=this.shadowRoot?.querySelector(`.code-highlight`),r=this.shadowRoot?.querySelector(`.line-numbers`);t&&n&&(t.style.height=n.offsetHeight+`px`,t.style.width=n.offsetWidth+`px`,r&&(r.style.height=n.offsetHeight+`px`))}render(){let{label:e,helperText:t,required:n}=this.props,r=(this.props.rows||10)*21+24,i=Ec(wc(this.code));return v`
      ${e?v`<label class="field-label">
            ${e}${n?v`<span class="required">*</span>`:``}
          </label>`:``}

      <div class="json-editor-container ${this.validationError?`error`:``}">
        <div class="code-wrapper" style="min-height: 5rem; height: ${r}px;">
          <div class="line-numbers">
            ${this.lines.map((e,t)=>v`
                <div class="line-number ${t+1===this.cursorLine?`active`:``}">${t+1}</div>
              `)}
          </div>

          <div class="editor-content">
            <textarea
              class="code-textarea"
              .value=${this.code}
              ?disabled=${this.props.disabled}
              ?readonly=${this.props.readonly}
              @input=${this.handleInput}
              @keydown=${this.handleKeyDown}
              @scroll=${this.handleScroll}
              @click=${e=>this.updateCursor(e.target)}
              @keyup=${e=>this.updateCursor(e.target)}
              spellcheck="false"
              autocomplete="off"
              autocorrect="off"
              autocapitalize="off"
            ></textarea>

            <pre class="code-highlight" .innerHTML=${i}></pre>
          </div>
        </div>

        <div class="status-bar">
          <div class="status-info">
            <span>Ln ${this.cursorLine}, Col ${this.cursorColumn}</span>
            <span>${this.lines.length} lines</span>
          </div>
          <button
            type="button"
            class="btn btn-sm fw-normal json-format-button"
            @click=${this.formatJson}
            title="Format JSON (Ctrl+Shift+F)"
          >
            Format
          </button>
        </div>
      </div>

      ${this.validationError?v`<div class="field-error">${j(this.validationError)}</div>`:t?v`<div class="field-helper">${t}</div>`:``}
    `}};D([S({type:String}),E(`design:type`,String)],Oc.prototype,`key`,void 0),D([S({type:Object}),E(`design:type`,Object)],Oc.prototype,`props`,void 0),D([S({type:Object}),E(`design:type`,Object)],Oc.prototype,`model`,void 0),D([S(),E(`design:type`,Object)],Oc.prototype,`value`,void 0),D([C(),E(`design:type`,Array)],Oc.prototype,`lines`,void 0),D([C(),E(`design:type`,Number)],Oc.prototype,`cursorLine`,void 0),D([C(),E(`design:type`,Number)],Oc.prototype,`cursorColumn`,void 0),D([C(),E(`design:type`,String)],Oc.prototype,`code`,void 0),D([C(),E(`design:type`,String)],Oc.prototype,`validationError`,void 0),Oc=D([x(`input-json`)],Oc);var kc=class extends b{constructor(...e){super(...e),this.options=[],this.selectedValue=``,this.allowCustomSvg=!1,this.required=!1,this.query=``,this.customSvg=``,this.customSvgError=``}createRenderRoot(){return this}connectedCallback(){super.connectedCallback(),this.customSvg=this.isSvgValue(this.selectedValue)?this.selectedValue:``}firstUpdated(){this.querySelector(`.input-picker-search-input`)?.focus()}get filteredOptions(){let e=this.query.trim().toLowerCase();return e?this.options.filter(t=>t.value.toLowerCase().includes(e)):this.options}isSvgValue(e){return typeof e==`string`&&e.trim().startsWith(`<svg`)}get customSvgIcon(){if(!this.customSvg.trim())return;let e=Ms(this.customSvg.trim());return e.elements.length>0?e:void 0}selectIcon(e){z.close(e)}confirmCustomSvg(){let e=this.customSvg.trim(),t=e?Ms(e):void 0;if(!e||!t||t.elements.length===0){this.customSvgError=`Paste a valid SVG first.`;return}this.customSvgError=``,z.close(e)}render(){let e=this.filteredOptions,t=this.customSvgIcon;return v`
      <div class="input-picker">
        <div class="d-grid grid-columns-1 ${this.allowCustomSvg?`grid-columns-md-2`:``} gap-4 min-h-0 flex-grow-1">
          <section class="d-flex flex-column gap-3 min-h-0">
            <div class="input-picker-search">
              <app-icon
                class="input-picker-search-icon"
                .icon=${ea}
                size="18"
              ></app-icon>
              <input
                class="form-control input-picker-search-input"
                type="search"
                placeholder="Search icons"
                .value=${this.query}
                @input=${e=>{this.query=e.target.value}}
              />
            </div>

            <div class="input-picker-meta">
              ${e.length} of ${this.options.length} icons
            </div>

            <div
              class="d-grid gap-2 overflow-auto min-h-0 flex-grow-1 pr-1"
              style="grid-template-columns: repeat(auto-fill, minmax(3.5rem, 1fr)); align-content: start;"
            >
              ${e.length?e.map(e=>{let t=this.selectedValue===e.value;return v`
                  <button
                    type="button"
                    class="btn btn-outline-secondary p-2 d-inline-flex align-items-center justify-content-center ${t?`border-primary`:``}"
                    style="min-height: 3.5rem; ${t?`box-shadow: 0 0 0 1px color-mix(in srgb, var(--nq-primary) 40%, transparent);`:``}"
                    title=${e.value}
                    @click=${()=>this.selectIcon(e.value)}
                  >
                    <app-icon .icon=${e.icon} size="32"></app-icon>
                  </button>
                `}):v`
                <div class="empty-state text-center text-muted p-4" style="grid-column: 1 / -1; min-height: 10rem;">
                  No icons match your search.
                </div>
              `}
            </div>
          </section>

          ${this.allowCustomSvg?v`
            <section class="d-flex flex-column gap-3 min-h-0">
              <div>
                <div class="input-picker-item-title">Custom SVG</div>
                <div class="input-picker-item-description">
                  Paste SVG code here. It will be parsed into the same icon format as built-in icons.
                </div>
              </div>

              <textarea
                class="form-control textarea font-monospace flex-grow-1"
                style="min-height: 12rem; resize: vertical;"
                placeholder="<svg viewBox=&quot;0 0 24 24&quot;>...</svg>"
                .value=${this.customSvg}
                @input=${e=>{this.customSvg=e.target.value,this.customSvgError=``}}
              ></textarea>

              <div class="d-flex align-items-center gap-3 p-3 border rounded">
                ${t?v`
                  <span class="d-inline-flex flex-shrink-0 align-items-center justify-content-center">
                    <app-icon .icon=${t} size="36"></app-icon>
                  </span>
                  <span>Preview</span>
                `:v`
                  <span class="text-muted">Preview will appear after pasting a valid SVG.</span>
                `}
              </div>

              ${this.customSvgError?v`
                <div class="form-error">${this.customSvgError}</div>
              `:``}

              <div class="d-flex justify-content-end">
                <app-button
                  background
                  label="Use custom SVG"
                  @click=${()=>this.confirmCustomSvg()}
                ></app-button>
              </div>
            </section>
          `:``}
        </div>

      </div>
    `}};D([S({attribute:!1}),E(`design:type`,Array)],kc.prototype,`options`,void 0),D([S({type:String}),E(`design:type`,Object)],kc.prototype,`selectedValue`,void 0),D([S({type:Boolean}),E(`design:type`,Object)],kc.prototype,`allowCustomSvg`,void 0),D([S({type:Boolean}),E(`design:type`,Object)],kc.prototype,`required`,void 0),D([C(),E(`design:type`,Object)],kc.prototype,`query`,void 0),D([C(),E(`design:type`,Object)],kc.prototype,`customSvg`,void 0),D([C(),E(`design:type`,Object)],kc.prototype,`customSvgError`,void 0),kc=D([x(`icon-picker-dialog`)],kc);var Ac=class extends R{getOptions(){return this.props.options||[]}isSvgValue(e){return typeof e==`string`&&e.trim().startsWith(`<svg`)}getSelectedIcon(){let e=this.getValue();if(e){if(this.isSvgValue(e)){let t=Ms(e);return t.elements.length>0?t:void 0}return this.getOptions().find(t=>t.value===e)?.icon}}async openPicker(){if(!(this.props.disabled||this.props.readonly))try{let e=await z.open({title:this.props.dialogTitle||`Select icon`,width:`min(92vw, 64rem)`,height:`min(84vh, 46rem)`,maxWidth:`92vw`,maxHeight:`90vh`,closeOnBackdrop:!0,closeOnEscape:!0,content:v`
          <icon-picker-dialog
            class="input-picker-dialog"
            .options=${this.getOptions()}
            .selectedValue=${String(this.getValue()||``)}
            .allowCustomSvg=${this.props.allowCustomSvg===!0}
            .required=${this.props.required===!0}
          ></icon-picker-dialog>
        `});e!=null&&this.updateModel(e)}catch{}}clearValue(e){e.stopPropagation(),!(this.props.disabled||this.props.readonly)&&this.updateModel(``)}renderField(){let e=this.getValue()??``,t=this.getSelectedIcon(),n=e!==``,r=t?this.isSvgValue(e)?`Custom SVG`:String(e):this.props.placeholder;return v`
      <button
        type="button"
        class="input-picker-control"
        ?disabled=${this.props.disabled}
        @click=${()=>this.openPicker()}
      >
        <span class="input-picker-value d-flex align-items-center gap-2 text-truncate ${n?``:`input-picker-placeholder`}">
          ${t?v`
            <span class="d-inline-flex flex-shrink-0 align-items-center justify-content-center">
              <app-icon .icon=${t} size="20"></app-icon>
            </span>
          `:``}
          <span class="text-truncate">${r}</span>
        </span>
        <span class="input-picker-actions">
          ${n&&!this.props.required?v`
            <span
              class="input-picker-clear"
              role="button"
              tabindex="0"
              title="Clear"
              @click=${this.clearValue}
            >
              <app-icon .icon=${Gn} size="16"></app-icon>
            </span>
          `:``}
          <app-icon .icon=${cn} size="16"></app-icon>
        </span>
      </button>
    `}};Ac=D([x(`input-icon`)],Ac);var jc=new Set([`A`,`B`,`BLOCKQUOTE`,`BR`,`CODE`,`DIV`,`EM`,`H1`,`H2`,`H3`,`I`,`IMG`,`LI`,`OL`,`P`,`STRONG`,`UL`]),Mc=new Set([`EMBED`,`IFRAME`,`MATH`,`OBJECT`,`SCRIPT`,`STYLE`,`SVG`,`TEMPLATE`]);function Nc(e){let t=e.trim();if(t.startsWith(`#`)||t.startsWith(`/`))return!0;try{return[`http:`,`https:`,`mailto:`].includes(new URL(t,window.location.origin).protocol)}catch{return!1}}function Pc(e){let t=e.trim();if(t.startsWith(`/`))return!0;try{return[`http:`,`https:`].includes(new URL(t,window.location.origin).protocol)}catch{return!1}}function Fc(e){let t=new DOMParser().parseFromString(e||``,`text/html`),n=e=>{if(e.nodeType===Node.COMMENT_NODE){e.parentNode?.removeChild(e);return}if(!(e instanceof Element))return;if(Mc.has(e.tagName)){e.remove();return}if(!jc.has(e.tagName)){if(!e.parentNode)return;let t=Array.from(e.childNodes);e.replaceWith(...t),t.forEach(n);return}let t=e.tagName===`A`&&e.getAttribute(`href`)||``,r=e.tagName===`IMG`&&e.getAttribute(`src`)||``,i=e.tagName===`IMG`&&e.getAttribute(`alt`)||``;for(let t of Array.from(e.attributes))e.removeAttribute(t.name);if(e.tagName===`A`&&t&&Nc(t)&&(e.setAttribute(`href`,t),e.setAttribute(`rel`,`noopener noreferrer`)),e.tagName===`IMG`){if(!r||!Pc(r)){e.remove();return}e.setAttribute(`src`,r),e.setAttribute(`alt`,i),e.setAttribute(`loading`,`lazy`)}Array.from(e.childNodes).forEach(n)};return Array.from(t.body.childNodes).forEach(n),t.body.innerHTML}var Ic=class extends R{constructor(...e){super(...e),this.rows=14,this.activeFormats=new Set,this.initialized=!1,this.handleSelectionChange=()=>{let e=window.getSelection();e?.anchorNode&&this.editor?.contains(e.anchorNode)&&this.updateActiveFormats()}}connectedCallback(){super.connectedCallback(),document.addEventListener(`selectionchange`,this.handleSelectionChange)}disconnectedCallback(){document.removeEventListener(`selectionchange`,this.handleSelectionChange),super.disconnectedCallback()}firstUpdated(){let e=this.editor;e&&!this.initialized&&(this.value=Fc(this.getValue()??``),e.innerHTML=this.value,this.initialized=!0)}updated(e){if(!this.initialized||!e.has(`value`))return;let t=this.editor,n=Fc(this.value??``);t&&t.innerHTML!==n&&(t.innerHTML=n)}get editor(){return this.querySelector(`.input-wysiwyg-content`)}emitValue(){let e=this.editor;e&&(this.value=Fc(e.innerHTML),e.innerHTML!==this.value&&(e.innerHTML=this.value),this.updateModel(this.value),this.updateActiveFormats())}updateActiveFormats(){let e=this.selectedElement(),t=new Set;document.queryCommandState(`bold`)&&t.add(`bold`),document.queryCommandState(`italic`)&&t.add(`italic`),document.queryCommandState(`insertUnorderedList`)&&t.add(`list`),e?.closest(`a`)&&t.add(`link`),e?.closest(`blockquote`)&&t.add(`quote`),e?.closest(`code`)&&t.add(`code`);let n=e?.closest(`h1, h2, h3`);n&&t.add(n.tagName.toLowerCase()),e?.closest(`p`)&&t.add(`p`),this.activeFormats=t}buttonClass(e){return this.activeFormats.has(e)?`border`:``}run(e,t){let n=this.editor;n&&(n.focus(),document.execCommand(e,!1,t),this.emitValue())}addLink(){let e=window.prompt(`Enter the link URL:`,`https://`);e&&this.run(`createLink`,e)}addImage(){let e=window.prompt(j(`Enter the image URL:`),`https://`);e&&Pc(e)&&this.run(`insertHTML`,`<img src="${this.escapeHtml(e)}" alt=""><br>`)}selectedElement(){let e=window.getSelection()?.anchorNode;return e instanceof Element?e:e?.parentElement||null}toggleQuote(){let e=!!this.selectedElement()?.closest(`blockquote`);this.run(`formatBlock`,e?`div`:`blockquote`)}toggleHeading(e){let t=`h${e}`,n=!!this.selectedElement()?.closest(t);this.run(`formatBlock`,n?`div`:t)}toggleCode(){let e=this.selectedElement()?.closest(`code`);if(e&&this.editor?.contains(e)){let t=document.createTextNode(e.textContent||``);e.replaceWith(t);let n=window.getSelection(),r=document.createRange();r.selectNodeContents(t),n?.removeAllRanges(),n?.addRange(r),this.editor?.focus(),this.emitValue();return}let t=window.getSelection()?.toString()||`code`;this.run(`insertHTML`,`<code>${this.escapeHtml(t)}</code>`)}escapeHtml(e){return e.replaceAll(`&`,`&amp;`).replaceAll(`<`,`&lt;`).replaceAll(`>`,`&gt;`).replaceAll(`"`,`&quot;`)}handlePaste(e){e.preventDefault();let t=e.clipboardData?.getData(`text/html`),n=e.clipboardData?.getData(`text/plain`)||``,r=t?Fc(t):this.escapeHtml(n).replaceAll(`
`,`<br>`);this.run(`insertHTML`,r)}renderField(){return v`
      <div class="border rounded overflow-hidden">
        <div class="d-flex flex-wrap gap-2 border-bottom p-2 bg-body-secondary" aria-label="Formatting tools" @mousedown=${e=>e.preventDefault()}>
          <app-button type="button" variant="ghost" size="sm" label="Bold" .icon=${Na} .className=${this.buttonClass(`bold`)} @click=${()=>this.run(`bold`)}></app-button>
          <app-button type="button" variant="ghost" size="sm" label="Italic" .icon=${Pa} .className=${this.buttonClass(`italic`)} @click=${()=>this.run(`italic`)}></app-button>
          <app-button type="button" variant="ghost" size="sm" label="H1" .icon=${Qr} .className=${this.buttonClass(`h1`)} @click=${()=>this.toggleHeading(1)}></app-button>
          <app-button type="button" variant="ghost" size="sm" label="H2" .icon=${$r} .className=${this.buttonClass(`h2`)} @click=${()=>this.toggleHeading(2)}></app-button>
          <app-button type="button" variant="ghost" size="sm" label="H3" .icon=${ei} .className=${this.buttonClass(`h3`)} @click=${()=>this.toggleHeading(3)}></app-button>
          <app-button type="button" variant="ghost" size="sm" label="P" .icon=${Bi} .className=${this.buttonClass(`p`)} @click=${()=>this.run(`formatBlock`,`p`)}></app-button>
          <app-button type="button" variant="ghost" size="sm" label="Link" .icon=${yi} .className=${this.buttonClass(`link`)} @click=${this.addLink}></app-button>
          <app-button type="button" variant="ghost" size="sm" label="Image" .icon=${ai} @click=${this.addImage}></app-button>
          <app-button type="button" variant="ghost" size="sm" label="Quote" .icon=${hi} .className=${this.buttonClass(`quote`)} @click=${this.toggleQuote}></app-button>
          <app-button type="button" variant="ghost" size="sm" label="Code" .icon=${fr} .className=${this.buttonClass(`code`)} @click=${this.toggleCode}></app-button>
          <app-button type="button" variant="ghost" size="sm" label="List" .icon=${gi} .className=${this.buttonClass(`list`)} @click=${()=>this.run(`insertUnorderedList`)}></app-button>
        </div>
        <div
          class="input-wysiwyg-content p-3"
          contenteditable="true"
          role="textbox"
          aria-multiline="true"
          data-placeholder=${j(this.props.placeholder||`Write your message...`)}
          style=${`min-height:${Math.max(8,Number(this.props.rows??this.rows)*1.5)}rem; outline:none;`}
          @input=${this.emitValue}
          @paste=${this.handlePaste}
        ></div>
      </div>
    `}};D([S({type:Number}),E(`design:type`,Object)],Ic.prototype,`rows`,void 0),D([C(),E(`design:type`,Object)],Ic.prototype,`activeFormats`,void 0),Ic=D([x(`input-wysiwyg`)],Ic);function Lc(e,t){let n=t.split(`.`),r=e;for(let e of n){if(r==null)return;r=r[e]}return r}function Rc(e,t,n){let r=t.split(`.`),i=e;for(let e=0;e<r.length-1;e++){let t=r[e];(!i[t]||typeof i[t]!=`object`)&&(i[t]={}),i=i[t]}i[r[r.length-1]]=n}var zc=class extends b{constructor(...e){super(...e),this.fields=[],this.model={},this._internalModel={},this._validationState={},this._isValid=!0}createRenderRoot(){return this}connectedCallback(){super.connectedCallback(),this._internalModel={...this.model},this.options?.model&&(this._internalModel={...this.options.model}),this.processFields(this.fields,e=>{e.key&&e.defaultValue!==void 0&&Lc(this._internalModel,e.key)===void 0&&Rc(this._internalModel,e.key,e.defaultValue)}),this.model&&typeof this.model==`object`&&Object.assign(this.model,this._internalModel),this.processFields(this.fields,e=>{e.hooks?.onInit&&e.hooks.onInit(e,this._internalModel)}),this.validateForm()}willUpdate(e){super.willUpdate(e),e.has(`model`)&&(this._internalModel={...this.model})}refreshForm(e,t){this.fields=e,t&&(this._internalModel={...this._internalModel,...t},this.model&&typeof this.model==`object`&&Object.assign(this.model,t)),this.validateForm(),this.requestUpdate()}handleFieldChange(e){let{key:t,value:n}=e.detail;Rc(this._internalModel,t,n),this.model&&typeof this.model==`object`&&(Object.keys(this.model).forEach(e=>delete this.model[e]),Object.assign(this.model,JSON.parse(JSON.stringify(this._internalModel))));let r;this.processFields(this.fields,e=>{e.key===t&&(r=e)}),r?.hooks?.onModelChange&&r.hooks.onModelChange(n,this._internalModel),this.model&&typeof this.model==`object`&&(Object.keys(this.model).forEach(e=>delete this.model[e]),Object.assign(this.model,JSON.parse(JSON.stringify(this._internalModel)))),this.options?.onModelChange&&this.options.onModelChange(this._internalModel),this.dispatchEvent(new CustomEvent(`model-change`,{detail:{model:this._internalModel},bubbles:!0,composed:!0})),this.validateForm(),this.requestUpdate()}processFields(e,t){e.forEach(e=>{e.fieldGroup?this.processFields(e.fieldGroup,t):t(e)})}async validateField(e){if(!e.key)return{valid:!0,errors:[]};let t=[],n=Lc(this._internalModel,e.key);if(e.props?.required&&this.isRequiredValueMissing(e,n)&&t.push(e.props.label?j(`{{label}} is required`,{label:j(e.props.label)}):j(`This field is required`)),e.validators)for(let r of e.validators){let e=await r.validate(n,this._internalModel);e!==!0&&t.push(j(typeof e==`string`?e:r.message||`Validation failed`))}if(e.fieldArray&&Array.isArray(n))for(let t=0;t<n.length;t++){let r=n[t];if(!await this.validateNestedFields(e.fieldArray,r))return{valid:!1,errors:[`Some fields in array are invalid`]}}return{valid:t.length===0,errors:t}}async validateNestedFields(e,t){for(let n of e)if(!this.isNestedFieldHidden(n,t)){if(n.fieldGroup){if(!await this.validateNestedFields(n.fieldGroup,t))return!1}else if(n.key){if(!(await this.validateNestedField(n,t)).valid)return!1;if(n.fieldArray){let e=Lc(t,n.key);if(typeof n.type==`string`&&n.type===`input-array`&&Array.isArray(e)){for(let t of e)if(!await this.validateNestedFields(n.fieldArray,t))return!1}else if(!await this.validateNestedFields(n.fieldArray,t))return!1}}}return!0}async validateNestedField(e,t){if(!e.key||this.isNestedFieldHidden(e,t))return{valid:!0,errors:[]};let n=[],r=Lc(t,e.key);if(e.props?.required&&this.isRequiredValueMissing(e,r)&&n.push(e.props.label?j(`{{label}} is required`,{label:j(e.props.label)}):j(`This field is required`)),e.validators)for(let i of e.validators){let e=await i.validate(r,t);e!==!0&&n.push(j(typeof e==`string`?e:i.message||`Validation failed`))}return{valid:n.length===0,errors:n}}isRequiredValueMissing(e,t){let n=typeof e.type==`string`?e.type:``;return!!(t==null||t===``||t===!1&&!(n===`input-toggle`||n===`input-checkbox`)||Array.isArray(t)&&t.length===0||n===`input-object`&&typeof t==`object`&&Object.keys(t).length===0)}async validateForm(){let e={},t=!0,n=[],r=e=>{for(let t of e)this.isFieldHidden(t)||(t.fieldGroup?r(t.fieldGroup):t.key&&n.push(t))};r(this.fields);for(let r of n)if(r.key){let n=await this.validateField(r);e[r.key]=n,n.valid||(t=!1)}return this._validationState=e,this._isValid=t,this.dispatchEvent(new CustomEvent(`validation-change`,{detail:{isValid:t,validationState:e},bubbles:!0,composed:!0})),t}isFieldHidden(e){return e.hide===void 0?!1:typeof e.hide==`boolean`?e.hide:e.hide(this._internalModel)}isNestedFieldHidden(e,t){return e.hide===void 0?!1:typeof e.hide==`boolean`?e.hide:e.hide(t)}renderField(e){if(this.isFieldHidden(e))return``;if(e.fieldGroup)return this.renderFieldGroup(e);if(e.template)return typeof e.template==`function`?e.template(this.model,()=>void 0):e.template;let t=null;if(typeof e.type==`string`?t=e.type:e.type&&(t=this.getElementName(e.type)),!t)return console.error(`Cannot determine element name for field`,e),``;let n=Wt(t),r=e.key?Lc(this._internalModel,e.key):void 0,i=e.className||``,a=i?Kt`
      <div class="${i}">
        <${n}
          .key=${e.key}
          .value=${r}
          .props=${e.props||{}}
          .fieldArray=${e.fieldArray}
          .model=${this._internalModel}
          @field-change=${this.handleFieldChange}
        ></${n}>
      </div>
    `:Kt`
      <${n}
        .key=${e.key}
        .value=${r}
        .props=${e.props||{}}
        .fieldArray=${e.fieldArray}
        .model=${this._internalModel}
        @field-change=${this.handleFieldChange}
      ></${n}>
    `;return e.renderKey===void 0?a:Bs(typeof e.renderKey==`function`?e.renderKey(this._internalModel):e.renderKey,a)}renderFieldGroup(e){return e.fieldGroup?v`
      <div class="field-group ${e.fieldGroupClassName||``}">
        ${e.fieldGroup.map(e=>this.renderField(e))}
      </div>
    `:``}getElementName(e){let t=e.name.replace(/([a-z])([A-Z])/g,`$1-$2`).toLowerCase().replace(/field$/,``);return customElements.get(t)?t:null}reset(){this._internalModel=this.model?{...this.model}:{},this.requestUpdate()}setValues(e){this._internalModel={...this._internalModel,...e},this.model&&typeof this.model==`object`&&Object.assign(this.model,JSON.parse(JSON.stringify(this._internalModel))),this.validateForm(),this.requestUpdate()}getValues(){return{...this._internalModel}}render(){return v`
      <div class="app-form">
        ${this.fields.map(e=>this.renderField(e))}
      </div>
    `}};D([S({type:Array}),E(`design:type`,Array)],zc.prototype,`fields`,void 0),D([S({type:Object}),E(`design:type`,Object)],zc.prototype,`model`,void 0),D([S({type:Object}),E(`design:type`,Object)],zc.prototype,`options`,void 0),D([C(),E(`design:type`,Object)],zc.prototype,`_internalModel`,void 0),D([C(),E(`design:type`,Object)],zc.prototype,`_validationState`,void 0),D([C(),E(`design:type`,Boolean)],zc.prototype,`_isValid`,void 0),zc=D([x(`app-form-fields`)],zc);var Bc=class extends R{constructor(...e){super(...e),this.isFocused=!1,this.localValue=void 0,this.hasLocalValue=!1,this.mobileRangeArmed=!1,this.lastCommittedValue=void 0,this.hasLastCommittedValue=!1}disconnectedCallback(){super.disconnectedCallback(),this.clearInputDebounce(),this.clearMobileRangeArmTimeout()}updated(e){super.updated(e),e.has(`value`)&&!Object.is(this.value,this.lastCommittedValue)&&(this.hasLastCommittedValue=!1),e.has(`value`)&&this.hasLocalValue&&Object.is(this.value,this.localValue)&&(this.hasLocalValue=!1)}get useSteps(){return Array.isArray(this.props.steps)&&this.props.steps.length>0}get steps(){return this.props.steps||[]}findStepIndex(e){if(!this.useSteps)return 0;let t=this.steps.findIndex(t=>t.value===e);return t>=0?t:0}getStepValue(e){return this.useSteps?this.steps[e]?.value??this.steps[0]?.value??0:0}getStepLabel(e){return this.useSteps?this.steps.find(t=>t.value===e)?.label??String(e):String(e)}getDisplayValue(){return this.hasLocalValue?this.localValue??null:this.getValue()??(this.useSteps?this.steps[0]?.value:this.props.min??0)}getEventValue(e){let t=e.target;if(this.useSteps){let e=Number(t.value);return this.getStepValue(e)}return t.value===``?null:Number(t.value)}clearInputDebounce(){this.inputDebounceTimeout&&=(clearTimeout(this.inputDebounceTimeout),void 0)}clearMobileRangeArmTimeout(){this.mobileRangeArmTimeout&&=(clearTimeout(this.mobileRangeArmTimeout),void 0)}armMobileRange(){this.props.disabled||this.props.readonly||(this.mobileRangeArmed=!0,this.clearMobileRangeArmTimeout(),this.mobileRangeArmTimeout=setTimeout(()=>{this.mobileRangeArmed=!1,this.mobileRangeArmTimeout=void 0},4e3))}disarmMobileRange(){this.clearMobileRangeArmTimeout(),this.mobileRangeArmed=!1}commitValue(e){this.clearInputDebounce(),this.localValue=e,this.hasLocalValue=!0,!(this.hasLastCommittedValue&&Object.is(this.lastCommittedValue,e))&&(this.lastCommittedValue=e,this.hasLastCommittedValue=!0,this.updateModel(e))}handleInput(e){let t=this.getEventValue(e);this.localValue=t,this.hasLocalValue=!0}handleChange(e){this.commitValue(this.getEventValue(e))}handleRangeChange(e){this.commitValue(this.getEventValue(e)),this.disarmMobileRange()}renderMobileRangeGuard(){return this.mobileRangeArmed||this.props.disabled||this.props.readonly?``:v`
      <button
        type="button"
        class="form-range-guard"
        aria-label="Activate slider"
        @click=${this.armMobileRange}
      ></button>
    `}handleNumberInput(e){let t=this.getEventValue(e);this.localValue=t,this.hasLocalValue=!0,this.clearInputDebounce(),this.inputDebounceTimeout=setTimeout(()=>{this.commitValue(t)},500)}renderField(){let e=this.getDisplayValue();return this.useSteps?this.renderStepsMode(e):this.renderContinuousMode(e)}renderStepsMode(e){let t=e??this.steps[0]?.value??0,n=this.findStepIndex(t),r=this.getStepLabel(t),i=this.steps.length-1;return v`
      <div class="form-range">
        <!-- Value Display -->
        <div class="form-range-header">
          ${this.props.label?v`
            <label class="form-inline-label">
              ${this.props.label}:
            </label>
          `:``}
          <span class="form-range-value">
            ${r}
          </span>
        </div>

        <!-- Slider -->
        <div class="form-range-track-wrap ${this.mobileRangeArmed?`is-armed`:``}">
          ${this.renderMobileRangeGuard()}
          <input
            type="range"
            class="form-range-input"
            style="--nq-range-progress: ${i===0?0:n/i*100}%"
            .value=${String(n)}
            min=${0}
            max=${i}
            step="1"
            ?disabled=${this.props.disabled}
            ?readonly=${this.props.readonly}
            @input=${this.handleInput}
            @change=${this.handleRangeChange}
          />
          
          <!-- Min/Max Labels -->
          <div class="form-range-limits">
            <span>${this.steps[0]?.label}</span>
            <span>${this.steps[i]?.label}</span>
          </div>
        </div>

        ${this.props.helperText?v`
          <p class="form-text">${this.props.helperText}</p>
        `:``}
      </div>
    `}renderContinuousMode(e){let t=this.props.min??0,n=this.props.max??100,r=this.props.step??1,i=e??t,a=Math.max(String(t).length,String(n).length,String(i).length)+String(this.props.suffix||``).trim().length<=3,o=n===t?0:(i-t)/(n-t)*100;return v`
      <div class="form-range">
        <!-- Value Display / Manual Input -->
        <div class="form-range-header is-between">
          ${this.props.label?v`
            <label class="form-inline-label">
              ${this.props.label}
            </label>
          `:``}
          <div class="form-control form-control-group form-range-number ${a?`is-compact`:``}">
            <input
              type="number"
              class="form-control-input form-range-number-input"
              .value=${e===null?``:String(e)}
              min=${t}
              max=${n}
              step=${r}
              ?disabled=${this.props.disabled}
              ?readonly=${this.props.readonly}
              @input=${this.handleNumberInput}
              @change=${this.handleChange}
              @focus=${()=>this.isFocused=!0}
              @blur=${e=>{this.isFocused=!1,this.commitValue(this.getEventValue(e))}}
            />
            ${this.props.suffix?v`
              <span class="form-range-suffix">
                ${this.props.suffix}
              </span>
            `:``}
          </div>
        </div>

        <!-- Slider -->
        <div class="form-range-track-wrap ${this.mobileRangeArmed?`is-armed`:``}">
          ${this.renderMobileRangeGuard()}
          <input
            type="range"
            class="form-range-input"
            style="--nq-range-progress: ${o}%"
            .value=${String(i)}
            min=${t}
            max=${n}
            step=${r}
            ?disabled=${this.props.disabled}
            ?readonly=${this.props.readonly}
            @input=${this.handleInput}
            @change=${this.handleRangeChange}
          />
          
          <!-- Min/Max Labels -->
          <div class="form-range-limits">
            <span>${t}${this.props.suffix||``}</span>
            <span>${n}${this.props.suffix||``}</span>
          </div>
        </div>

        ${this.props.helperText?v`
          <p class="form-text">${this.props.helperText}</p>
        `:``}
      </div>
    `}render(){return this.renderField()}};D([C(),E(`design:type`,Object)],Bc.prototype,`isFocused`,void 0),D([C(),E(`design:type`,Object)],Bc.prototype,`localValue`,void 0),D([C(),E(`design:type`,Object)],Bc.prototype,`hasLocalValue`,void 0),D([C(),E(`design:type`,Object)],Bc.prototype,`mobileRangeArmed`,void 0),Bc=D([x(`input-range`)],Bc);function Vc(e,t){let n=1-e-t,r=1/t*e,i=1/t*n,a=r*1.656492-1*.354851-i*.255038,o=-r*.707196+1*1.655397+i*.036152,s=r*.051713-1*.121364+i*1.01153;return a=a<=.0031308?12.92*a:1.055*a**(1/2.4)-.055,o=o<=.0031308?12.92*o:1.055*o**(1/2.4)-.055,s=s<=.0031308?12.92*s:1.055*s**(1/2.4)-.055,a=Math.max(0,Math.min(1,a)),o=Math.max(0,Math.min(1,o)),s=Math.max(0,Math.min(1,s)),{r:Math.round(a*255),g:Math.round(o*255),b:Math.round(s*255)}}function Hc(e,t,n){e/=255,t/=255,n/=255,e=e>.04045?((e+.055)/1.055)**2.4:e/12.92,t=t>.04045?((t+.055)/1.055)**2.4:t/12.92,n=n>.04045?((n+.055)/1.055)**2.4:n/12.92;let r=e*.664511+t*.154324+n*.162028,i=e*.283881+t*.668433+n*.047685,a=e*88e-6+t*.07231+n*.986039,o=r+i+a;return o===0?{x:0,y:0}:{x:parseFloat((r/o).toFixed(4)),y:parseFloat((i/o).toFixed(4))}}function Uc(e,t){let n=Vc(e,t);return`rgb(${n.r}, ${n.g}, ${n.b})`}function Wc(e){let t=/^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(e);return t?{r:parseInt(t[1],16),g:parseInt(t[2],16),b:parseInt(t[3],16)}:null}function Gc(e,t,n){return`#`+[e,t,n].map(e=>{let t=e.toString(16);return t.length===1?`0`+t:t}).join(``)}var Kc=class extends R{constructor(...e){super(...e),this.currentColor=`#ffffff`}syncCurrentColor(){let e=this.getValue();if(typeof e==`string`&&e.startsWith(`#`)){this.currentColor=e;return}if(e&&typeof e==`object`&&`x`in e&&`y`in e){let t=Vc(e.x,e.y);this.currentColor=Gc(t.r,t.g,t.b)}}connectedCallback(){super.connectedCallback(),this.syncCurrentColor()}willUpdate(e){super.willUpdate(e),(e.has(`model`)||e.has(`value`))&&this.syncCurrentColor()}handleColorChange(e){let t=e.target.value;if(this.currentColor=t,typeof this.getValue()==`string`){this.updateModel(t);return}let n=Wc(t);n&&this.updateModel(Hc(n.r,n.g,n.b))}handleColorInput(e){let t=e.target;this.currentColor=t.value}renderField(){return v`
      <div class="form-color">
        <!-- Label and Color Display -->
        <div class="form-color-row">
          <label class="form-inline-label">
            ${this.props.label||`Color`}
          </label>
          <div class="form-color-control">
            <!-- Color picker -->
            <input
              type="color"
              class="form-color-picker"
              .value=${this.currentColor}
              ?disabled=${this.props.disabled}
              ?readonly=${this.props.readonly}
              @input=${this.handleColorInput}
              @change=${this.handleColorChange}
            />
          </div>
        </div>
        ${this.props.helperText?v`
          <p class="form-text">${this.props.helperText}</p>
        `:``}
      </div>
    `}render(){return this.renderField()}};D([C(),E(`design:type`,String)],Kc.prototype,`currentColor`,void 0),Kc=D([x(`input-color`)],Kc);var qc=`<?xml version="1.0" encoding="UTF-8" standalone="no"?>\r
<!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.1//EN" "http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd">\r
<svg width="100%" height="100%" viewBox="0 0 900 300" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" xml:space="preserve" xmlns:serif="http://www.serif.com/" style="fill-rule:evenodd;clip-rule:evenodd;stroke-linejoin:round;stroke-miterlimit:2;">\r
    <g id="Artboard1" transform="matrix(4.378353,0,0,0.927454,-2627.012019,0)">\r
        <rect x="600" y="0" width="205.557" height="323.466" style="fill:none;"/>\r
        <g transform="matrix(0.145087,0,0,0.684933,651.368612,-215.852783)">\r
            <g transform="matrix(1,0,0,1,843.122424,0)">\r
                <g transform="matrix(1.022397,0,0,1,-868.928696,-96.360638)">\r
                    <path fill="currentColor" d="M175.844,602.76L175.844,771.641L122.083,771.641L122.083,528.384L175.844,528.384L175.844,528.433L175.888,528.384L356.825,697.224L356.825,528.384L410.587,528.384L410.587,771.641L356.825,771.641L175.844,602.76Z"/>\r
                </g>\r
                <g transform="matrix(0,0.995607,-0.973797,0,352.396686,310.476418)">\r
                    <path fill="currentColor" d="M366.414,478.066L366.414,784.313L122.083,784.313L122.083,528.384L311.206,528.384L311.206,478.066L366.414,478.066ZM175.844,727.869L311.206,727.869L311.206,584.828L175.844,584.828L175.844,727.869Z"/>\r
                </g>\r
                <g transform="matrix(1.022397,0,0,0.530711,-200.178704,265.762439)">\r
                    <path fill="currentColor" d="M356.825,416.849L122.083,416.849L122.083,313.279L410.587,313.279L410.587,594.245L175.844,594.245L175.844,668.072L410.587,668.072L410.587,771.641L122.083,771.641L122.083,490.676L356.825,490.676L356.825,416.849Z"/>\r
                </g>\r
            </g>\r
        </g>\r
        <g transform="matrix(0.18148,-0.523558,0,0.985755,550.463665,283.294907)">\r
            <path fill="currentColor" d="M398.802,-15.001L272.957,-15.001L272.957,-75.576L398.802,-75.576L584.117,121.275L584.117,252.558L524.646,252.558L524.646,252.565L398.802,252.565L398.802,191.99L524.646,191.99L524.646,118.677L398.802,-15.001Z"/>\r
        </g>\r
        <g transform="matrix(0.891145,0,0,0.839516,91.601083,-41.757461)">\r
            <g transform="matrix(0.169262,-0.518339,0,0.880537,507.326017,254.058666)">\r
                <path fill="currentColor" d="M524.646,252.565L398.802,252.565L398.802,191.99L524.646,191.99L650.491,340.15L650.491,345.832L600.897,342.336L524.646,252.565Z"/>\r
                <path fill="currentColor" d="M524.646,252.565L398.802,252.565L398.802,191.99L524.646,191.99L650.491,340.15L650.491,345.832L600.897,342.336L524.646,252.565ZM630.285,330.606L524.646,206.235L430.891,206.235L411.42,206.235L411.42,238.32L524.646,238.32L601.297,328.563L630.285,330.606Z"/>\r
            </g>\r
            <g transform="matrix(0.169262,-0.518339,0,0.880537,528.62671,319.244247)">\r
                <path fill="currentColor" d="M524.646,191.99L524.646,252.565L398.802,252.565L398.802,191.99L524.646,191.99ZM512.028,206.235L411.42,206.235L411.42,238.32L512.028,238.32L512.028,206.235Z"/>\r
            </g>\r
        </g>\r
    </g>\r
</svg>\r
`;function H(e,t,n){return(r,i)=>{let a=i,o=Symbol(`__store_${a}`),s=Symbol(`__unsub_${a}`),c=(e,r)=>t?n&&r?t(e,n(r)):t(e):e,l=r.constructor.prototype.connectedCallback,u=r.constructor.prototype.disconnectedCallback,d=r.constructor.prototype.updated;r.constructor.prototype.connectedCallback=function(){l?.call(this);let t=c(e.getState(),this);this[o]=t,this[a]=t,this[s]=e.subscribe(e=>{let t=c(e,this);this[o]!==t&&(this[o]=t,this[a]=t,this.requestUpdate(a))})},r.constructor.prototype.disconnectedCallback=function(){this[s]?.(),this[s]=void 0,u?.call(this)},n&&(r.constructor.prototype.updated=function(t){d?.call(this,t),n(this);let r=c(e.getState(),this);JSON.stringify(this[o])!==JSON.stringify(r)&&(this[o]=r,this[a]=r)}),Object.defineProperty(r,a,{get(){return this[o]},set(e){this[o]=e},enumerable:!0,configurable:!0})}}var Jc=po()((e,t)=>({version:``,initialized:!1,initialize:async()=>{if(!t().initialized)try{e({version:(await N.get(`/version`)).version||``,initialized:!0})}catch{e({initialized:!0})}}})),Yc=class extends w{constructor(...e){super(...e),this.formModel={email:``,password:``},this.error=``,this.isLoading=!1,this.formFields=[{key:`email`,type:`input-text`,props:{label:`Email`,placeholder:`Enter your email address`,required:!0,autocomplete:`email`}},{key:`password`,type:`input-password`,props:{label:`Password`,placeholder:`Enter your password`,required:!0,autocomplete:`current-password`}}]}createRenderRoot(){return this}async handleSubmit(e){if(e.preventDefault(),!this.formModel.email||!this.formModel.password){this.error=`Enter your email address and password.`;return}this.isLoading=!0,this.error=``;try{await F.getState().login(this.formModel.email,this.formModel.password);let{redirect:e}=tt();T(e||`cards`)}catch(e){this.error=e.message||`Invalid email address or password.`}finally{this.isLoading=!1}}handleModelChange(e){this.formModel=e.detail.model}render(){return v`
      <main class="auth-layout">
        <section class="card auth-panel">
          <div class="card-body p-8">
            <div class="d-flex justify-content-center mb-6 text-primary">
              <button type="button" class="border-0 bg-transparent p-0 text-primary" aria-label="Go to cards" @click=${()=>T(`cards`)}><span class="d-inline-block w-10rem" aria-label="NQ2" role="img">${xs(qc)}</span></button>
            </div>

            <p class="m-0 mb-6 text-center text-muted">Access and manage your NQ2 Local system.</p>

            <form @submit=${this.handleSubmit} class="d-flex flex-column gap-5">
              <app-form-fields
                .fields=${this.formFields}
                .model=${this.formModel}
                @model-change=${this.handleModelChange}
              ></app-form-fields>

              ${this.error?v`<div class="alert alert-danger">${this.error}</div>`:``}

              <button
                type="submit"
                class="btn btn-primary w-100"
                ?disabled=${this.isLoading}
              >
                ${this.isLoading?`Signing in...`:`Sign in`}
              </button>
            </form>

            <p class="m-0 mt-6 text-center text-muted small">
              &copy; NQ2 ${new Date().getFullYear()} ${this.appVersion?v`&bull; ${this.appVersion}`:``}
            </p>
          </div>
        </section>
      </main>
    `}};D([H(Jc,e=>e.version)],Yc.prototype,`appVersion`,void 0),D([C()],Yc.prototype,`formModel`,void 0),D([C()],Yc.prototype,`error`,void 0),D([C()],Yc.prototype,`isLoading`,void 0),Yc=D([x(`login-view`)],Yc);var Xc=new Set([`__proto__`,`prototype`,`constructor`]),Zc=[`===`,`!==`,`==`,`!=`,`>=`,`<=`,`&&`,`||`,`??`,`?.`,`+`,`-`,`*`,`/`,`%`,`>`,`<`,`!`,`?`,`:`,`.`],Qc=class{constructor(e,t){this.context=t,this.index=0,this.tokens=this.tokenize(this.unwrapArrow(e))}evaluate(){let e=this.parseTernary();if(this.peek().type!==`eof`)throw Error(`Unexpected token '${this.peek().value}'`);return e}unwrapArrow(e){let t=e.trim(),n=t.match(/^\(?\s*[A-Za-z_$][\w$]*\s*\)?\s*=>\s*([\s\S]+)$/);if(!n)return t;let r=n[1].trim();if(r.startsWith(`{`))throw Error(`Function bodies are not allowed`);return r}tokenize(e){let t=[],n=0;for(;n<e.length;){let r=e[n];if(/\s/.test(r)){n+=1;continue}if(/\d/.test(r)||r===`.`&&/\d/.test(e[n+1]||``)){let r=e.slice(n).match(/^(?:\d+(?:\.\d*)?|\.\d+)/);t.push({type:`number`,value:r[0]}),n+=r[0].length;continue}if(r===`'`||r===`"`){let i=r,a=``;n+=1;let o=!1;for(;n<e.length;){let t=e[n++];if(t===i){o=!0;break}if(t===`\\`){let t=e[n++];a+={n:`
`,r:`\r`,t:`	`,"\\":`\\`,"'":`'`,'"':`"`}[t]??t}else a+=t}if(!o)throw Error(`Unterminated string`);t.push({type:`string`,value:a});continue}let i=e.slice(n).match(/^[A-Za-z_$][\w$]*/);if(i){t.push({type:`identifier`,value:i[0]}),n+=i[0].length;continue}if(`()[]`.includes(r)){t.push({type:`punctuation`,value:r}),n+=1;continue}let a=Zc.find(t=>e.startsWith(t,n));if(!a)throw Error(`Unsupported character '${r}'`);t.push({type:`operator`,value:a}),n+=a.length}return t.push({type:`eof`,value:``}),t}peek(){return this.tokens[this.index]}consume(e){let t=this.tokens[this.index++];if(e!==void 0&&t.value!==e)throw Error(`Expected '${e}'`);return t}match(e){return this.peek().value===e?(this.index+=1,!0):!1}parseTernary(){let e=this.parseNullish();if(!this.match(`?`))return e;let t=this.parseTernary();this.consume(`:`);let n=this.parseTernary();return e?t:n}parseNullish(){let e=this.parseOr();for(;this.match(`??`);){let t=this.parseOr();e??=t}return e}parseOr(){let e=this.parseAnd();for(;this.match(`||`);){let t=this.parseAnd();e||=t}return e}parseAnd(){let e=this.parseEquality();for(;this.match(`&&`);){let t=this.parseEquality();e&&=t}return e}parseEquality(){let e=this.parseComparison();for(;[`===`,`!==`,`==`,`!=`].includes(this.peek().value);){let t=this.consume().value,n=this.parseComparison();e=t===`===`?e===n:t===`!==`?e!==n:t===`==`?e==n:e!=n}return e}parseComparison(){let e=this.parseAdditive();for(;[`>`,`<`,`>=`,`<=`].includes(this.peek().value);){let t=this.consume().value,n=this.parseAdditive();e=t===`>`?e>n:t===`<`?e<n:t===`>=`?e>=n:e<=n}return e}parseAdditive(){let e=this.parseMultiplicative();for(;[`+`,`-`].includes(this.peek().value);){let t=this.consume().value,n=this.parseMultiplicative();e=t===`+`?e+n:Number(e)-Number(n)}return e}parseMultiplicative(){let e=this.parseUnary();for(;[`*`,`/`,`%`].includes(this.peek().value);){let t=this.consume().value,n=this.parseUnary();e=t===`*`?Number(e)*Number(n):t===`/`?Number(e)/Number(n):Number(e)%Number(n)}return e}parseUnary(){return this.match(`!`)?!this.parseUnary():this.match(`-`)?-Number(this.parseUnary()):this.match(`+`)?Number(this.parseUnary()):this.parsePrimary()}parsePrimary(){let e=this.peek(),t;if(this.match(`(`))t=this.parseTernary(),this.consume(`)`);else if(e.type===`number`)t=Number(this.consume().value);else if(e.type===`string`)t=this.consume().value;else if(e.type===`identifier`){let e=this.consume().value;if(e===`true`)t=!0;else if(e===`false`)t=!1;else if(e===`null`)t=null;else if(e===`undefined`)t=void 0;else if(Object.prototype.hasOwnProperty.call(this.context,e))t=this.context[e];else throw Error(`Unknown identifier '${e}'`)}else throw Error(`Unexpected token '${e.value}'`);for(;this.peek().value===`.`||this.peek().value===`?.`||this.peek().value===`[`;)if(this.match(`[`)){let e=this.parseTernary();this.consume(`]`),t=this.readProperty(t,e)}else{let e=this.consume().value===`?.`,n=this.consume();if(n.type!==`identifier`)throw Error(`Expected property name`);t=e&&t==null?void 0:this.readProperty(t,n.value)}if(this.peek().value===`(`)throw Error(`Function calls are not allowed`);return t}readProperty(e,t){let n=String(t);if(Xc.has(n))throw Error(`Property '${n}' is not allowed`);if(!(e==null||typeof e!=`object`&&typeof e!=`string`))return e[n]}};function $c(e,t){return e.trim()?new Qc(e,t).evaluate():``}function el(e,t){if(!e)return``;let n=$c(e,t);return typeof n==`string`&&n.length<=512?n:``}function tl(e){let t=e.button||{},n=[`white`,`red`,`blue`,`green`,`yellow`].includes(t.color||``)?t.color:`white`,r=[`left`,`right`,`top`,`bottom`].includes(t.iconPosition||``)?t.iconPosition:`left`;return{color:n,outline:t.outline===!0,iconPosition:r}}function nl(e,t){if(t)switch(e){case`blue`:return`btn-outline-info`;case`green`:return`btn-outline-success`;case`red`:return`btn-outline-danger`;case`yellow`:return`btn-outline-warning`;default:return`btn-outline-primary`}switch(e){case`blue`:return`btn-info`;case`green`:return`btn-success`;case`red`:return`btn-danger`;case`yellow`:return`btn-warning`;default:return`btn-primary`}}function rl(e,t){let n=!!t.commands?.length;if(!t.control&&!n)return v``;let r=tl(t),i=t.extra?.width?`d-flex h-100 w-100`:``,a=r.iconPosition===`right`?`flex-row-reverse`:r.iconPosition===`top`?`flex-column`:r.iconPosition===`bottom`?`flex-column-reverse`:``,o=r.iconPosition===`top`||r.iconPosition===`bottom`,s=o?48:24,c=o?`gap-1`:`gap-2`,l=nl(r.color,r.outline),u=e.getFieldClassName(t),d=e.isFieldCommandLocked(t),f=t.extra?.icon,p=e.getFieldLabel(t),m=f?v`
		<span class="d-flex align-items-center justify-content-center" style=${`height: ${s}px; width: ${s}px;`}>
			<app-icon
				.name=${f}
				class="flex-shrink-0"
				size=${String(s)}
			></app-icon>
		</span>
	`:``;return v`
		<div class="h-100">
			<button
				type="button"
				?disabled=${d}
				class="btn ${a} ${i} ${c} ${l} ${u}"
				@pointerdown=${n=>e.handleActionPointerDown(n,t,void 0)}
				@pointerup=${e.handleActionPointerEnd}
				@pointercancel=${e.handleActionPointerEnd}
				@pointerleave=${e.handleActionPointerEnd}
				@contextmenu=${n=>e.handleActionContextMenu(n,t,void 0)}
				@click=${r=>{e.shouldSuppressActionClick(r)||(n?e.handleFieldCommand(t):e.handleFieldChange(t,void 0))}}
			>
				${m}
				${p?v`<span>${p}</span>`:``}
			</button>
		</div>
	`}function il(e,t,n){let r=e.getFieldSuffix(t),i=e.formatValue(n);if(!i)return v``;let a=`${i}${r}`,o=e.getFieldLabel(t);return v`
		<div class="small text-muted mt-2 pt-2 border-top">
			${o?v`${o}: `:``}${a}
		</div>
	`}function al(e,t,n,r){let i=e.getFieldSuffix(t),a=e.formatValue(n),o=a?`${a}${i}`:`-`,s=`field-value ${(r??e.getFieldClassName(t))||``}`,c=e.getFieldLabel(t);return v`
		<div class="field-hero">
			<div class="${s}">${o}</div>
			${c?v`
				<div class="small text-muted mt-2">${c}</div>
			`:``}
		</div>
	`}function ol(e,t,n=`buttons-inline`){if(!t.options||t.options.length===0)return v``;let r=e.isFieldCommandLocked(t),i=/^buttons-([123])$/.exec(n)?.[1];return v`
		<div>
			<div class=${i?`d-grid gap-2`:`d-flex flex-wrap gap-2`} style=${i?`grid-template-columns: repeat(${i}, minmax(0, 1fr));`:``}>
				${t.options.map(n=>{let a=i?null:cl(n.width);return v`
					<button
						?disabled=${r}
						style=${a?`flex: 0 0 ${ll(a)};`:``}
						class="${e.getOptionClassName(n,t)}"
						@pointerdown=${r=>e.handleActionPointerDown(r,t,n.value)}
						@pointerup=${e.handleActionPointerEnd}
						@pointercancel=${e.handleActionPointerEnd}
						@pointerleave=${e.handleActionPointerEnd}
						@contextmenu=${r=>e.handleActionContextMenu(r,t,n.value)}
						@click=${r=>!e.shouldSuppressActionClick(r)&&e.handleOptionClick(t,n)}
					>
						${n.icon?v`
							<span class="field-icon">
								<app-icon .name=${n.icon}></app-icon>
							</span>
						`:``}
						${n.name}
					</button>
				`})}
			</div>
		</div>
	`}function sl(e,t,n=!1){if(!t.options||t.options.length===0)return v``;let r=e.isFieldCommandLocked(t),i=e.card.state?.[t.key];return v`
		<div class=${n?`d-grid gap-2`:`d-flex flex-wrap align-items-center gap-3`}>
			${t.options.map(n=>{let a=String(i)===String(n.value);return v`
					<button
						type="button"
						?disabled=${r}
						class="d-inline-flex align-items-center justify-self-start gap-2 border-0 bg-transparent p-0 text-body"
						@pointerdown=${r=>e.handleActionPointerDown(r,t,n.value)}
						@pointerup=${e.handleActionPointerEnd}
						@pointercancel=${e.handleActionPointerEnd}
						@pointerleave=${e.handleActionPointerEnd}
						@contextmenu=${r=>e.handleActionContextMenu(r,t,n.value)}
						@click=${r=>!e.shouldSuppressActionClick(r)&&e.handleOptionClick(t,n)}
					>
						<span class="form-check-mark rounded-circle ${a?`is-checked`:``}">
						</span>
						${n.icon?v`
							<span class="field-icon">
								<app-icon .name=${n.icon} size="20"></app-icon>
							</span>
						`:``}
						<span>${n.name}</span>
					</button>
				`})}
		</div>
	`}function cl(e){let t=Number(e);return!Number.isInteger(t)||t<1||t>12?null:t}function ll(e){return e===12?`100%`:`calc(((100% - 0.5rem * 11) / 12 * ${e}) + 0.5rem * ${e-1})`}function ul(e,t){let n=t.extra?.boolean;if(n?.valueTrue!==void 0&&e===n.valueTrue)return!0;if(n?.valueFalse!==void 0&&e===n.valueFalse)return!1;if(typeof e==`boolean`)return e;if(typeof e==`number`)return e!==0;if(typeof e==`string`){let t=e.trim().toLowerCase();if([`true`,`1`,`yes`,`on`,`open`].includes(t))return!0;if([`false`,`0`,`no`,`off`,`close`,`closed`].includes(t))return!1}return!!e}function dl(e,t,n){let r=e.getFieldLabel(t),i=t.extra?.boolean,a=ul(n,t),o=!!t.control,s=t.extra?.display||``,c=t.control?[`jumbo`,`icon`,`enum`].includes(s)?s:`toggle`:s===`checkbox`||s===`toggle`?`normal`:s||`normal`,l=i?.trueLabel||`Yes`,u=i?.falseLabel||`No`,d=a?l:u,f=(a?i?.trueIcon:i?.falseIcon)||t.extra?.icon,p=t.control&&e.isFieldCommandLocked(t),m=e.getFieldClassName(t)||`text-body`,h=!a,g=n=>{e.shouldSuppressActionClick(n)||e.handleFieldToggle(t,a,o)},_=n=>e.handleActionPointerDown(n,t,h),ee=n=>e.handleActionContextMenu(n,t,h),te=t.control?`${p?`opacity-50`:`cursor-pointer`}`:``;if(c===`enum`){let n={...t,options:[{name:l,value:!0,icon:i?.trueIcon},{name:u,value:!1,icon:i?.falseIcon}]};return v`
			<div>
				${r?v`<label class="form-label field-label mb-2">${r}</label>`:``}
				${ol(e,n,`buttons-2`)}
			</div>
		`}return c===`icon`?v`
			<div
				class="field-hero ${te}"
				@pointerdown=${t.control&&!p?_:void 0}
				@pointerup=${e.handleActionPointerEnd}
				@pointercancel=${e.handleActionPointerEnd}
				@pointerleave=${e.handleActionPointerEnd}
				@contextmenu=${t.control&&!p?ee:void 0}
				@click=${t.control&&!p?g:void 0}
				title=${d}
			>
				${f?v`
					<app-icon
						.name=${f}
						size="48"
						class="${m}"
						style="--icon-size: 48px;"
					></app-icon>
				`:v`
					<div class="field-value fs-2 ${m}">${d}</div>
				`}
				${r?v`
					<div class="mt-2 small text-muted">${r}</div>
				`:``}
			</div>
		`:c===`jumbo`?v`
			<div
				class="${te}"
				@pointerdown=${t.control&&!p?_:void 0}
				@pointerup=${e.handleActionPointerEnd}
				@pointercancel=${e.handleActionPointerEnd}
				@pointerleave=${e.handleActionPointerEnd}
				@contextmenu=${t.control&&!p?ee:void 0}
				@click=${t.control&&!p?g:void 0}
			>
				${f?v`
					<div class="field-hero">
						<app-icon
							.name=${f}
							size="48"
							class="${m}"
							style="--icon-size: 48px;"
						></app-icon>
						<div class="field-value fs-2 ${m}">${d}</div>
						${r?v`
							<div class="mt-2 small text-muted">${r}</div>
						`:``}
					</div>
				`:al(e,t,d,m)}
			</div>
		`:c===`checkbox`?v`
			<div class="field-row">
				${r||f?v`
					<div class="field-label">
						${f?v`<span class="field-icon"><app-icon .name=${f}></app-icon></span>`:``}
						${r?v`<span>${r}</span>`:``}
					</div>
				`:v`<div></div>`}
				<button
					?disabled=${!t.control||p}
					@pointerdown=${_}
					@pointerup=${e.handleActionPointerEnd}
					@pointercancel=${e.handleActionPointerEnd}
					@pointerleave=${e.handleActionPointerEnd}
					@contextmenu=${ee}
					@click=${g}
					class="form-check-mark ${a?`is-checked ${m}`:``}"
					title=${d}
				>
					&#10003;
				</button>
			</div>
		`:c===`toggle`?v`
			<div class="field-row">
				${r||f?v`
					<div class="field-label">
						${f?v`<span class="field-icon"><app-icon .name=${f}></app-icon></span>`:``}
						${r?v`<span>${r}</span>`:``}
					</div>
				`:v`<div></div>`}
				<button
					?disabled=${!t.control||p}
					@pointerdown=${_}
					@pointerup=${e.handleActionPointerEnd}
					@pointercancel=${e.handleActionPointerEnd}
					@pointerleave=${e.handleActionPointerEnd}
					@contextmenu=${ee}
					@click=${g}
					class="form-switch-track ${a?`is-checked`:``}"
					title=${d}
				></button>
			</div>
		`:v`
		<div class="field-row">
			${r||f?v`
				<div class="field-label">
					${f?v`<span class="field-icon"><app-icon .name=${f}></app-icon></span>`:``}
					${r?v`<span>${r}</span>`:``}
				</div>
			`:``}
			<span class="field-value ${m}">
				${d}
			</span>
		</div>
	`}var fl=e=>e??y,pl=[{value:`24h`,label:`Last 24h`,range:`24h`,bucket:`1h`},{value:`7d`,label:`7 days`,range:`7d`,bucket:`1d`},{value:`30d`,label:`30 days`,range:`30d`,bucket:`1d`},{value:`day`,label:`Day`,bucket:`1h`},{value:`month`,label:`Month`,bucket:`1d`},{value:`custom`,label:`Custom`}],ml={blue:`var(--nq-chart-blue)`,green:`var(--nq-chart-green)`,red:`var(--nq-chart-red)`,yellow:`var(--nq-chart-yellow)`,orange:`var(--nq-chart-orange)`,purple:`var(--nq-chart-purple)`,pink:`var(--nq-chart-pink)`,white:`var(--nq-chart-light)`,gray:`var(--nq-chart-gray)`},hl=e=>{if(typeof e!=`number`||!Number.isFinite(e)||e<=0)return``;let t=[{suffix:`d`,ms:864e5},{suffix:`h`,ms:36e5},{suffix:`m`,ms:6e4},{suffix:`s`,ms:1e3},{suffix:`ms`,ms:1}],n=t.find(t=>e%t.ms===0)||t[t.length-1];return`${e/n.ms}${n.suffix}`};function gl(e,t){return v`
		<nq-card-chart-field
			.card=${e.card}
			.field=${t}
		></nq-card-chart-field>
	`}var U=class extends w{constructor(...e){super(...e),this.expanded=!1,this.history=null,this.loading=!1,this.error=``,this.rangePreset=`24h`,this.detailed=!1,this.hoverTimestamp=``,this.hoverPosition=null,this.selectedSeriesIndex=null,this.selectedDate=this.formatDateInputValue(new Date),this.selectedMonth=this.formatMonthInputValue(new Date),this.customFrom=this.formatDateTimeInputValue(new Date(Date.now()-1440*60*1e3)),this.customTo=this.formatDateTimeInputValue(new Date),this.customBuckets=24,this.chartWidth=0,this.lastRequestKey=``,this.chartResizeObserver=null}connectedCallback(){super.connectedCallback(),this.chartResizeObserver=new ResizeObserver(e=>{let t=Math.round(e[0]?.contentRect.width||0);t>0&&t!==this.chartWidth&&(this.chartWidth=t)}),this.chartResizeObserver.observe(this)}disconnectedCallback(){this.chartResizeObserver?.disconnect(),this.chartResizeObserver=null,super.disconnectedCallback()}updated(){let e=this.getRequestKey();!e||e===this.lastRequestKey||(this.lastRequestKey=e,this.loadHistory())}getRequestKey(){return!this.card?._id||!this.field?.key?``:`${this.card._id}:${this.field.key}:${JSON.stringify(this.field.extra?.chart||{})}:${this.expanded?`${this.rangePreset}:${this.detailed}:${this.selectedDate}:${this.selectedMonth}:${this.customFrom}:${this.customTo}:${this.customBuckets}`:`card`}`}async loadHistory(){if(!(!this.card?._id||!this.field?.key)){this.loading=!0,this.error=``;try{let e=this.expanded?this.getExpandedQueryParams():{};this.history=await N.get(`/cards/${this.card._id}/history`,{field:this.field.key,...e}),this.selectedSeriesIndex!==null&&!this.history.series[this.selectedSeriesIndex]&&(this.selectedSeriesIndex=null)}catch(e){this.error=e instanceof Error?e.message:`Cannot load chart`}finally{this.loading=!1}}}getExpandedQueryParams(){if(this.rangePreset===`custom`){let e=this.parseDateTimeInputValue(this.customFrom),t=this.parseDateTimeInputValue(this.customTo);if(!e||!t||t.getTime()<=e.getTime())throw Error(`Custom range requires "To" to be later than "From"`);let n=Math.min(200,Math.max(1,Math.round(this.customBuckets||1))),r=Math.max(1,Math.ceil((t.getTime()-e.getTime())/n/1e3));return{from:e.toISOString(),to:t.toISOString(),bucket:`${r}s`}}if(this.rangePreset===`day`){let e=this.getDayRange(this.selectedDate);return{from:e.from,to:e.to,bucket:this.detailed?`15min`:`1h`}}if(this.rangePreset===`month`){let e=this.getMonthRange(this.selectedMonth);return{from:e.from,to:e.to,bucket:this.detailed?`4h`:`1d`}}let e=pl.find(e=>e.value===this.rangePreset);return{range:e?.range,bucket:this.detailed?{"24h":`15min`,"7d":`1h`,"30d":`4h`}[this.rangePreset]:e?.bucket}}openDialog(){this.expanded||z.open({title:j(this.field.name||`Chart`),content:v`
				<nq-card-chart-field
					.card=${this.card}
					.field=${this.field}
					.expanded=${!0}
				></nq-card-chart-field>
			`,closeOnBackdrop:!0,closeOnEscape:!0,width:`min(96vw, 72rem)`,height:`min(86vh, 44rem)`,maxWidth:`96vw`,maxHeight:`90vh`}).catch(()=>void 0)}getColor(e,t){return e?ml[e]||e:[`var(--nq-chart-blue)`,`var(--nq-chart-green)`,`var(--nq-chart-light)`,`var(--nq-chart-yellow)`][t%4]}formatValue(e){let t=this.field?.extra?.suffix||``;return`${Math.abs(e)>=100?Math.round(e):Math.round(e*100)/100}${t?` ${t}`:``}`}formatAxisValue(e){let t=Math.abs(e)<1e-9?0:e;return Math.abs(t)>=1e3||Math.abs(t)>=100?`${Math.round(t)}`:Math.abs(t)>=10?`${Math.round(t*10)/10}`:`${Math.round(t*100)/100}`}getNiceStep(e){if(!Number.isFinite(e)||e<=0)return 1;let t=Math.floor(Math.log10(e)),n=e/10**t;return(n<=1?1:n<=2?2:n<=2.5?2.5:n<=5?5:10)*10**t}normalizeTickValue(e){return Math.abs(e)<1e-9?0:Number(e.toPrecision(12))}buildNiceScale(e,t,n=5){let r=e<0,i=r?e:0,a=t>i?t:i+1,o=this.getNiceStep((a-i)/Math.max(1,n-1)),s=r?Math.floor(i/o)*o:0,c=Math.ceil(a/o)*o;c<=s&&(c=s+o);let l=[];for(let e=s;e<=c+o*.5;e+=o)l.push(this.normalizeTickValue(e));return{min:this.normalizeTickValue(s),max:this.normalizeTickValue(c),ticks:l}}getLegendValue(e){return this.history?.mode===`counter-delta`||this.history?.mode===`consumption`?e.items.reduce((e,t)=>e+t.value,0):e.items[e.items.length-1]?.value||0}formatDate(e){let t=new Date(e);return Number.isNaN(t.getTime())?e:this.shouldFormatAsDate()?t.toLocaleDateString(void 0,{day:`2-digit`,month:`2-digit`}):t.toLocaleTimeString(void 0,{hour:`2-digit`,minute:`2-digit`})}formatTooltipDate(e){let t=new Date(e);return Number.isNaN(t.getTime())?e:t.toLocaleString(void 0,{day:`2-digit`,month:`2-digit`,hour:`2-digit`,minute:`2-digit`})}shouldFormatAsDate(){if(this.expanded){if(this.rangePreset===`custom`){let e=this.parseDateTimeInputValue(this.customFrom),t=this.parseDateTimeInputValue(this.customTo);return!!(e&&t&&t.getTime()-e.getTime()>2160*60*1e3)}return this.rangePreset===`7d`||this.rangePreset===`30d`||this.rangePreset===`month`}return(this.field.extra?.chart?.range||0)>=2160*60*1e3}formatDateInputValue(e){return`${e.getFullYear()}-${String(e.getMonth()+1).padStart(2,`0`)}-${String(e.getDate()).padStart(2,`0`)}`}formatMonthInputValue(e){return`${e.getFullYear()}-${String(e.getMonth()+1).padStart(2,`0`)}`}formatDateTimeInputValue(e){let t=String(e.getHours()).padStart(2,`0`),n=String(e.getMinutes()).padStart(2,`0`);return`${this.formatDateInputValue(e)} ${t}:${n}`}parseDateTimeInputValue(e){let t=e.match(/^(\d{4})-(\d{2})-(\d{2}) (\d{2}):(\d{2})$/);if(!t)return null;let n=new Date(Number(t[1]),Number(t[2])-1,Number(t[3]),Number(t[4]),Number(t[5]));return Number.isNaN(n.getTime())?null:n}getRangeLabel(){return this.expanded?this.rangePreset===`day`?this.selectedDate:this.rangePreset===`month`?this.selectedMonth:this.rangePreset===`custom`?`${this.customFrom} - ${this.customTo}`:pl.find(e=>e.value===this.rangePreset)?.label||``:hl(this.field.extra?.chart?.range)}getDayRange(e){let[t,n,r]=e.split(`-`).map(Number),i=new Date(t,n-1,r,0,0,0,0),a=new Date(t,n-1,r+1,0,0,0,0);return{from:i.toISOString(),to:a.toISOString()}}getMonthRange(e){let[t,n]=e.split(`-`).map(Number),r=new Date(t,n-1,1,0,0,0,0),i=new Date(t,n,1,0,0,0,0);return{from:r.toISOString(),to:i.toISOString()}}renderChart(e){let t=Math.max(this.chartWidth||1e3,280),n=this.expanded?368:208,r=t<600,i={top:this.expanded?28:10,right:r?12:28,bottom:44,left:r?48:64},a=t-i.left-i.right,o=n-i.top-i.bottom,s=e.flatMap(e=>e.items);if(!s.length)return v`<div class="empty-state">No chart data</div>`;let c=Array.from(new Set(s.map(e=>e.timestamp))).sort((e,t)=>Date.parse(e)-Date.parse(t)),l=Math.min(...s.map(e=>e.value)),u=Math.max(...s.map(e=>e.value)),d=this.buildNiceScale(l,u),f=d.min,p=d.max-f||1,m=e=>{let t=Math.max(0,c.indexOf(e));return c.length<=1?i.left+a:i.left+t/(c.length-1)*a},h=e=>i.top+o-(e-f)/p*o,g=d.ticks.map(e=>({value:e,y:h(e)})).reverse(),_=this.expanded?r?4:6:r?3:4,ee=Array.from({length:Math.min(_,c.length)},(e,t)=>{if(c.length===1)return c[0];let n=t/(Math.min(_,c.length)-1);return c[Math.round(n*(c.length-1))]}).filter((e,t,n)=>n.indexOf(e)===t),te=this.field.extra?.suffix||``,ne=this.hoverTimestamp&&c.includes(this.hoverTimestamp)?this.hoverTimestamp:c[c.length-1],re=m(ne),ie=e.map((e,t)=>{let n=e.items.find(e=>e.timestamp===ne),r=this.history?.series.indexOf(e)??t;return n?{item:e,point:n,color:this.getColor(e.color,r)}:void 0}).filter(e=>!!e),ae=this.hoverPosition&&ie.length?{left:Math.min(Math.max(this.hoverPosition.x+14,12),t),top:Math.max(this.hoverPosition.y-16,12)}:null,oe=e=>{let n=e.currentTarget.getBoundingClientRect(),r=(e.clientX-n.left)/n.width*t,s=Math.min(1,Math.max(0,(r-i.left)/a)),l=Math.round(s*(c.length-1)),u=c[Math.min(Math.max(l,0),c.length-1)];this.hoverTimestamp=u,this.hoverPosition={x:m(u),y:i.top+o/2}};return v`
			<div class="position-relative w-100">
				<svg
					viewBox="0 0 ${t} ${n}"
					class="chart-canvas ${this.expanded?`expanded`:``}"
					role="img"
					aria-label=${this.field.name||`Chart`}
					preserveAspectRatio="none"
					@pointerdown=${e=>{e.pointerType!==`mouse`&&e.preventDefault(),e.currentTarget.setPointerCapture?.(e.pointerId),oe(e)}}
					@pointermove=${oe}
					@pointerleave=${e=>{e.pointerType===`mouse`&&(this.hoverTimestamp=``,this.hoverPosition=null)}}
				>
					<defs>
						${e.map((e,t)=>{let n=this.history?.series.indexOf(e)??t,r=this.getColor(e.color,n);return ke`
								<linearGradient id="chart-fill-${this.card._id}-${this.field.key}-${n}" x1="0" y1="0" x2="0" y2="1">
									<stop offset="0%" stop-color=${r} stop-opacity="0.2"></stop>
									<stop offset="100%" stop-color=${r} stop-opacity="0"></stop>
								</linearGradient>
							`})}
					</defs>

					<rect x=${i.left} y=${i.top} width=${a} height=${o} fill="var(--nq-chart-plot-bg)" rx="4"></rect>
					${te?ke`
						<text x=${i.left} y="14" fill="var(--nq-chart-unit-color)" font-size="12" font-weight="600">${te}</text>
					`:``}
					${g.map(e=>ke`
						<line x1=${i.left} x2=${t-i.right} y1=${e.y} y2=${e.y} stroke="var(--nq-chart-grid-color)" stroke-width="1"></line>
						<text x=${i.left-10} y=${e.y+4} fill="var(--nq-chart-label-color)" font-size="11" text-anchor="end">${this.formatAxisValue(e.value)}</text>
					`)}
					${ee.map(e=>ke`
						<line x1=${m(e)} x2=${m(e)} y1=${i.top} y2=${i.top+o} stroke="var(--nq-chart-grid-subtle-color)" stroke-width="1"></line>
						<text x=${m(e)} y=${n-10} fill="var(--nq-chart-label-color)" font-size="11" text-anchor="middle">${this.formatDate(e)}</text>
					`)}
					<line x1=${i.left} x2=${t-i.right} y1=${i.top+o} y2=${i.top+o} stroke="var(--nq-chart-axis-color)" stroke-width="1"></line>
					<line x1=${i.left} x2=${i.left} y1=${i.top} y2=${i.top+o} stroke="var(--nq-chart-axis-color)" stroke-width="1"></line>
					${ie.length?ke`
						<line x1=${re} x2=${re} y1=${i.top} y2=${i.top+o} stroke="var(--nq-chart-hover-color)" stroke-width="1" stroke-dasharray="3 4"></line>
					`:``}
					${e.map((e,t)=>{let n=this.history?.series.indexOf(e)??t,r=this.getColor(e.color,n),a=[...e.items].sort((e,t)=>Date.parse(e.timestamp)-Date.parse(t.timestamp)),s=a.map((e,t)=>`${t===0?`M`:`L`} ${m(e.timestamp)} ${h(e.value)}`).join(` `),c=a.length?`${s} L ${m(a[a.length-1].timestamp)} ${i.top+o} L ${m(a[0].timestamp)} ${i.top+o} Z`:``,l=a.find(e=>e.timestamp===ne);return ke`
							${c?ke`<path d=${c} fill="url(#chart-fill-${this.card._id}-${this.field.key}-${n})"></path>`:``}
							<path d=${s} fill="none" stroke=${r} stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"></path>
							${l?ke`
								<circle cx=${m(l.timestamp)} cy=${h(l.value)} r="4.5" fill=${r} stroke="var(--nq-chart-point-outline)" stroke-width="2"></circle>
							`:``}
						`})}
				</svg>
				${ae?v`
					<div
						class="chart-tooltip"
						style=${`left: min(calc(100% - 11rem), max(0px, ${ae.left/t*100}%)); top: ${ae.top}px;`}
					>
						<div class="mb-1 fw-semibold">${this.formatTooltipDate(ne)}</div>
						${ie.map(({item:e,point:t,color:n})=>v`
							<div class="d-flex align-items-center justify-content-between gap-4">
								<span class="d-inline-flex align-items-center gap-2 text-muted">
									<span class="circle" style=${`background:${n}`}></span>
									${e.name}
								</span>
								<span class="fw-semibold">${this.formatValue(t.value)}</span>
							</div>
						`)}
					</div>
				`:``}
			</div>
		`}setRangePreset(e){this.rangePreset!==e&&(this.rangePreset=e,this.detailed=!1)}render(){let e=this.history?.series||[],t=this.selectedSeriesIndex===null?e:e.filter((e,t)=>t===this.selectedSeriesIndex),n=e.map((e,t)=>({series:e,index:t})).filter(e=>e.series.items.length>0).map(e=>({...e,value:this.getLegendValue(e.series)}));return v`
			<div
				class="chart ${this.expanded?``:`chart-preview`}"
				title=${this.expanded?``:`Open chart`}
				@click=${e=>{e.stopPropagation(),this.openDialog()}}
				@keydown=${e=>{this.expanded||e.key!==`Enter`&&e.key!==` `||(e.preventDefault(),this.openDialog())}}
				tabindex=${fl(this.expanded?void 0:`0`)}
			>
				${this.expanded?``:v`<div class="d-flex align-items-start justify-content-between gap-2">
					<div class="min-w-0">
						${this.field.name&&!this.field.extra?.hideName?v`<div class="field-label">${this.field.name}</div>`:``}
					</div>
					${this.loading?v`<div class="small text-muted">Loading</div>`:``}
				</div>`}
				${this.expanded?v`
					<div class="chart-controls mb-4" data-no-dialog-drag>
						${pl.map(e=>v`
							<button
								class="btn ${this.rangePreset===e.value?`btn-primary`:`btn-outline-primary`}"
								@click=${t=>{t.stopPropagation(),this.setRangePreset(e.value)}}
							>
								${j(e.label)}
							</button>
						`)}
						${this.rangePreset===`day`?v`
							<div
								style="width: 11rem;"
								@click=${e=>e.stopPropagation()}
							>
								<input-date
									.value=${this.selectedDate}
									.props=${{mode:`day`,inline:!0}}
									@field-change=${e=>{e.stopPropagation();let t=e.detail?.value;t&&(this.selectedDate=t)}}
								></input-date>
							</div>
						`:``}
						${this.rangePreset===`month`?v`
							<div
								style="width: 11rem;"
								@click=${e=>e.stopPropagation()}
							>
								<input-date
									.value=${this.selectedMonth}
									.props=${{mode:`month`,inline:!0}}
									@field-change=${e=>{e.stopPropagation();let t=e.detail?.value;t&&(this.selectedMonth=t)}}
								></input-date>
							</div>
						`:``}
						${this.rangePreset===`custom`?``:v`<div class="btn-group">
							${[{value:!1,label:`Normal`},{value:!0,label:`Detailed`}].map(e=>v`
								<button
									type="button"
									class="btn ${this.detailed===e.value?`btn-primary`:`btn-outline-primary`}"
									@click=${t=>{t.stopPropagation(),this.detailed=e.value}}
								>
									${j(e.label)}
								</button>
							`)}
						</div>`}
						${this.loading?v`<div class="small text-muted">Loading</div>`:``}
					</div>
					${this.rangePreset===`custom`?v`
						<div class="chart-controls mb-4 gap-4" data-no-dialog-drag>
							<div style="width: 14rem;">
								<input-date
									.value=${this.customFrom}
									.props=${{label:`From`,mode:`day`,withTime:!0}}
									@field-change=${e=>{e.stopPropagation(),this.customFrom=e.detail?.value||``}}
								></input-date>
							</div>
							<div style="width: 14rem;">
								<input-date
									.value=${this.customTo}
									.props=${{label:`To`,mode:`day`,withTime:!0}}
									@field-change=${e=>{e.stopPropagation(),this.customTo=e.detail?.value||``}}
								></input-date>
							</div>
							<div style="width: 7rem;">
								<input-number
									.value=${this.customBuckets}
									.props=${{label:`Buckets`,min:1,max:200,step:1}}
									@field-change=${e=>{e.stopPropagation();let t=Number(e.detail?.value);this.customBuckets=Number.isFinite(t)?Math.min(200,Math.max(1,Math.round(t))):1}}
								></input-number>
							</div>
						</div>
					`:``}
				`:``}
				${this.error?v`
					<div class="alert alert-danger">${this.error}</div>
				`:this.renderChart(t)}
				${n.length?v`
					<div class="chart-legend mt-2" data-no-dialog-drag>
						${n.map(e=>{let t=this.selectedSeriesIndex===e.index,n=this.selectedSeriesIndex!==null&&!t;return v`
								<button
									type="button"
									class="btn ${t?`btn-primary`:`btn-outline-primary ${n?`opacity-50`:``}`}"
									aria-pressed=${t}
									@click=${n=>{n.stopPropagation(),this.selectedSeriesIndex=t?null:e.index,this.hoverTimestamp=``,this.hoverPosition=null}}
								>
									<span class="circle" style=${`background:${this.getColor(e.series.color,e.index)}`}></span>
									<span class="fw-medium">${j(e.series.name)}</span>
									<span class="fw-semibold">${this.formatValue(e.value)}</span>
								</button>
							`})}
					</div>
				`:``}
			</div>
		`}};D([S({type:Object})],U.prototype,`card`,void 0),D([S({type:Object})],U.prototype,`field`,void 0),D([S({type:Boolean})],U.prototype,`expanded`,void 0),D([C()],U.prototype,`history`,void 0),D([C()],U.prototype,`loading`,void 0),D([C()],U.prototype,`error`,void 0),D([C()],U.prototype,`rangePreset`,void 0),D([C()],U.prototype,`detailed`,void 0),D([C()],U.prototype,`hoverTimestamp`,void 0),D([C()],U.prototype,`hoverPosition`,void 0),D([C()],U.prototype,`selectedSeriesIndex`,void 0),D([C()],U.prototype,`selectedDate`,void 0),D([C()],U.prototype,`selectedMonth`,void 0),D([C()],U.prototype,`customFrom`,void 0),D([C()],U.prototype,`customTo`,void 0),D([C()],U.prototype,`customBuckets`,void 0),D([C()],U.prototype,`chartWidth`,void 0),U=D([x(`nq-card-chart-field`)],U);function _l(e,t){if(!t||t===`normal`||t===`jumbo`||t===`chart`)return;if(e==null||e===``)return``;let n;if(n=typeof e==`number`?new Date(e<0xe8d4a51000?e*1e3:e):new Date(e),Number.isNaN(n.getTime()))return String(e);if(t===`date`)return n.toLocaleDateString();if(t===`time`)return n.toLocaleTimeString(void 0,{hour:`2-digit`,minute:`2-digit`});if(t===`datetime`)return`${n.toLocaleDateString()} ${n.toLocaleTimeString(void 0,{hour:`2-digit`,minute:`2-digit`})}`}function vl(e,t,n){let r=t.extra?.icon,i=e.getFieldLabel(t),a=_l(n,[`date`,`time`,`datetime`].includes(t.type||``)?t.type:t.extra?.display)??n?.toString()??``;if(t.control&&t.options&&t.options.length>0)return ol(e,t);let o=`field-value`,s=e.getFieldClassName(t);if(s&&(o=`field-value ${s}`),t.control)return v`
			<div>
				<app-button
					variant="ghost"
					size="sm"
					@click=${()=>e.handleFieldChange(t,a)}
					className="w-100"
				>
					${r?v`<span class="field-icon"><app-icon .name=${r}></app-icon></span>`:``}
					${i}
				</app-button>
			</div>
		`;if(!a)return v``;if(t.extra?.display===`jumbo`)return al(e,t,a);let c=e.formatValue(a);return v`
		<div class="field-row">
			${i||r?v`
				<div class="field-label">
					${r?v`<span class="field-icon"><app-icon .name=${r}></app-icon></span>`:``}
					${i?v`<span class="text-truncate">${i}</span>`:``}
				</div>
			`:``}
			<div class="${o} text-end text-break">
				${c}
			</div>
		</div>
	`}function yl(e,t,n){let r=t.extra?.icon,i=e.getFieldLabel(t);if(t.options&&t.options.length>0){let a=t.extra?.display||(t.control?`buttons-inline`:`normal`);return!t.control&&a===`normal`?bl(e,t,n,a):v`
			<div>
				${(t.control||![`icon-value`,`jumbo`,`icon`,`icon-large`,`icon-as-value`].includes(a))&&(i||r)?v`
					<label class="form-label field-label mb-2">
						${r?v`<span class="field-icon"><app-icon .name=${r}></app-icon></span>`:``}
						${i}
					</label>
				`:``}
				${t.control?a.startsWith(`radio-`)?sl(e,t,a===`radio-1`):ol(e,t,a):bl(e,t,n,a)}
			</div>
		`}return vl(e,t,n)}function bl(e,t,n,r){let i=t.options?.find(e=>String(e.value)===String(n)),a=i?.name||n,o=t.extra?.icon,s=i?.icon,c=s||o,l=c?v`<app-icon .name=${c} style=${`--icon-size: ${r===`icon-large`||r===`icon-value-bottom`?`48px`:`24px`};`}></app-icon>`:``,u=e.getFieldLabel(t),d=e.getFieldClassName(t);return r===`normal`?v`
			<div class="field-row">
				${u||o?v`
					<div class="field-label">
						${o?v`<span class="field-icon"><app-icon .name=${o}></app-icon></span>`:``}
						${u?v`<span class="text-truncate">${u}</span>`:``}
					</div>
				`:``}
				<div class="field-value text-end text-break ${d||``}">
					${s?v`<span class="field-icon">${l}</span>`:``}
					${a}
				</div>
			</div>
		`:r===`icon`?v`
			<div class="text-center py-2">
				${l||v`<div class="field-value">${a}</div>`}
				${u?v`
					<div class="mt-2 small text-muted">${u}</div>
				`:``}
			</div>
		`:r===`icon-large`?v`
			<div class="field-hero py-2">
				${l}
				${c?``:v`<div class="field-value fs-4">${a}</div>`}
				${u?v`
					<div class="small text-muted">${u}</div>
				`:``}
			</div>
		`:r===`icon-as-value`?v`
			<div class="field-row">
				${u||o?v`
					<span class="field-label">
						${o?v`
							<span class="field-icon">
								<app-icon .name=${o}></app-icon>
							</span>
						`:``}
						${u?v`<span class="text-truncate">${u}</span>`:``}
					</span>
				`:v`<span></span>`}
				${s?v`
					<span class="field-icon">
						<app-icon .name=${s} style="--icon-size: 24px;"></app-icon>
					</span>
				`:v`
					<span class="field-value">${a}</span>
				`}
			</div>
		`:r===`icon-value-bottom`?v`
			<div class="field-hero py-2">
				${l}
				<div class="field-value">${a}</div>
			</div>
		`:r===`icon-value`||r===`jumbo`?v`
			<div class="field-hero">
				${c?v`
					<app-icon
						.name=${c}
						size="48"
						class="text-body"
						style="--icon-size: 48px;"
					></app-icon>
				`:``}
				<div class="field-value">${a}</div>
				${u?v`
					<div class="mt-2 small text-muted">${u}</div>
				`:``}
			</div>
		`:v`
		<div class="field-row field-value">
			${c?v`<span class="field-icon">${l}</span>`:``}
			${a}
		</div>
	`}function xl(e,t){let n={key:e.key},r={label:t,required:e.required,placeholder:e.placeholder};switch(e.type){case`boolean`:return{...n,type:`input-toggle`,props:{required:e.required,toggleLabel:t}};case`enum`:{let t=e.options?.length?e.options:e.values;return{...n,type:`input-select`,props:{...r,multiple:e.extra?.multiple===!0,options:(t||[]).map(e=>({value:typeof e==`string`?e:e.value??e.name,label:typeof e==`string`?e:e.name??e.label??String(e.value??e.name)}))}}}case`number`:{let t=typeof e.extra?.min==`number`&&typeof e.extra?.max==`number`;return{...n,type:t?`input-range`:`input-number`,props:{...r,min:e.extra?.min,max:e.extra?.max,suffix:e.extra?.suffix}}}case`color`:return{...n,type:`input-color`,props:r};case`date`:return{...n,type:`input-date`,props:r};case`datetime`:return{...n,type:`input-text`,props:{...r,placeholder:e.placeholder||`YYYY-MM-DDTHH:mm:ss.sssZ`}};case`time`:return{...n,type:`input-text`,props:{...r,placeholder:e.placeholder||`HH:mm`}};case`array-string`:return{...n,type:`input-array-text`,props:r};case`array-object`:return{...n,type:`input-array`,props:r,fieldArray:(e.fields||[]).map(e=>xl(e,e.extra?.hideName?``:e.name||e.key))};case`object`:return e.fields?.length?{fieldGroupClassName:`d-grid grid-columns-1 gap-3`,fieldGroup:e.fields.map(e=>xl(e,e.extra?.hideName?``:e.name||e.key))}:{...n,type:`input-json`,props:{...r,rows:4}};case`form`:return{fieldGroupClassName:`d-grid grid-columns-1 gap-3`,fieldGroup:(e.fields||[]).map(e=>xl(e,e.extra?.hideName?``:e.name||e.key))};default:return{...n,type:`input-text`,props:r}}}function Sl(e,t,n,r){let i=n.extra?.hideName?``:n.name;if((n.type===`form`||n.type===`object`)&&n.fields?.length){let a=r[n.key]&&typeof r[n.key]==`object`&&!Array.isArray(r[n.key])?r[n.key]:{},o=[xl(n,i)];return v`
			<div class="d-flex flex-column gap-2">
				${i?v`<div class="field-label">${i}</div>`:``}
				<app-form-fields
					.fields=${o}
					.model=${a}
					@model-change=${r=>{r.stopPropagation(),e.updateFormDraft(t,n.key,r.detail.model||{})}}
				></app-form-fields>
			</div>
		`}let a={[n.key]:r[n.key]??n.defaultValue??(n.type===`array-string`||n.type===`array-object`?[]:n.type===`object`?{}:``)};return v`
		<app-form-fields
			.fields=${[xl(n,i)]}
			.model=${a}
			@model-change=${r=>{r.stopPropagation(),e.updateFormDraft(t,n.key,r.detail.model?.[n.key])}}
		></app-form-fields>
	`}function Cl(e,t){let n=e.getFormDraft(t),r=t.fields||[],i=e.isFieldCommandLocked(t),a=e.getFieldLabel(t),o=!!(t.extra?.width&&t.extra?.height);return v`
		<div class="${o?`d-flex h-100 min-h-0 flex-column`:``}">
			${a?v`<div class="field-label flex-shrink-0 mb-2">${a}</div>`:``}
			<div class="${o?`min-h-0 overflow-auto pr-1`:``} d-flex flex-column gap-2">
				${r.map(r=>Sl(e,t,r,n))}
			</div>
			<div class="d-flex flex-shrink-0 justify-content-end ${o?`mt-auto pt-2`:`pt-3`}">
				<app-button
					label=${t.extra?.form?.submitLabel||`Submit`}
					variant="primary"
					size="md"
					background
					.disabled=${i}
					@pointerdown=${n=>e.handleFormActionPointerDown(n,t)}
					@pointerup=${e.handleActionPointerEnd}
					@pointercancel=${e.handleActionPointerEnd}
					@pointerleave=${e.handleActionPointerEnd}
					@contextmenu=${n=>e.handleFormActionContextMenu(n,t)}
					@click=${n=>{e.shouldSuppressActionClick(n)||e.handleFormSubmit(t)}}
				></app-button>
			</div>
		</div>
	`}var wl=class extends w{constructor(...e){super(...e),this.src=``,this.alt=``,this.imageClass=``,this.loading=`lazy`,this.preview=!0,this.objectUrl=``,this.failed=!1}updated(e){e.has(`src`)&&this.loadImage()}disconnectedCallback(){super.disconnectedCallback(),this.abortController?.abort(),this.revokeObjectUrl()}revokeObjectUrl(){this.objectUrl&&=(URL.revokeObjectURL(this.objectUrl),``)}async loadImage(){if(this.abortController?.abort(),this.revokeObjectUrl(),this.failed=!1,!(!this.src||!this.shouldFetchWithAuth(this.src))){this.abortController=new AbortController;try{this.objectUrl=await N.blobUrl(this.src,this.abortController.signal)}catch(e){e?.name!==`AbortError`&&(this.failed=!0)}}}shouldFetchWithAuth(e){if(e.startsWith(`/api/`))return!0;try{let t=new URL(e,window.location.origin);return t.origin===window.location.origin&&t.pathname.startsWith(`/api/`)}catch{return!1}}getImageSrc(){return this.objectUrl||(this.shouldFetchWithAuth(this.src)?``:this.src)}encodeBase64Url(e){let t=new TextEncoder().encode(e),n=``;return t.forEach(e=>{n+=String.fromCharCode(e)}),btoa(n).replace(/\+/g,`-`).replace(/\//g,`_`).replace(/=+$/,``)}decodeBase64Url(e){let t=e.replace(/-/g,`+`).replace(/_/g,`/`).padEnd(Math.ceil(e.length/4)*4,`=`),n=atob(t),r=Uint8Array.from(n,e=>e.charCodeAt(0));return new TextDecoder().decode(r)}getPreviewSource(){let e=Math.max(1,Math.round(window.innerWidth*.8)),t=Math.max(1,Math.round(window.innerHeight*.8));try{let n=new URL(this.src,window.location.origin),r=n.searchParams.get(`target`);if(n.pathname.includes(`/providers/`)&&n.pathname.endsWith(`/media`)&&r){let i=new URL(this.decodeBase64Url(r));return i.searchParams.has(`size`)?(i.searchParams.set(`size`,`${e}x${t}`),n.searchParams.set(`target`,this.encodeBase64Url(i.toString())),n.origin===window.location.origin?`${n.pathname}${n.search}`:n.toString()):this.src}if(n.searchParams.has(`size`))return n.searchParams.set(`size`,`${e}x${t}`),n.toString()}catch{return this.src}return this.src}openPreview(){if(!this.preview||!this.getImageSrc())return;let e=this.getPreviewSource();z.open({title:j(this.alt||`Image`),content:v`
        <div class="image-preview-dialog" data-no-dialog-drag>
          <auth-image
            src=${e}
            alt=${this.alt}
            imageClass="image-preview-dialog-image"
            .preview=${!1}
          ></auth-image>
        </div>
      `,closeOnBackdrop:!0,closeOnEscape:!0,width:`fit-content`,height:`auto`,maxWidth:`calc(100vw - 2rem)`,maxHeight:`calc(100vh - 2rem)`}).catch(()=>void 0)}handleKeydown(e){e.key!==`Enter`&&e.key!==` `||(e.preventDefault(),this.openPreview())}render(){if(this.failed)return v`<span class="text-xs text-red-400">Image unavailable</span>`;let e=this.getImageSrc();return e?v`
      <img
        src=${e}
        alt=${this.alt}
        class=${`${this.imageClass} ${this.preview?`cursor-zoom-in`:``}`.trim()}
        style="display: block;"
        loading=${this.loading}
        tabindex=${this.preview?`0`:`-1`}
        role=${this.preview?`button`:`img`}
        @click=${this.openPreview}
        @keydown=${this.handleKeydown}
      />
    `:v`<span class="text-xs text-gray-500">Loading...</span>`}};D([S({type:String}),E(`design:type`,Object)],wl.prototype,`src`,void 0),D([S({type:String}),E(`design:type`,Object)],wl.prototype,`alt`,void 0),D([S({type:String}),E(`design:type`,Object)],wl.prototype,`imageClass`,void 0),D([S({type:String}),E(`design:type`,String)],wl.prototype,`loading`,void 0),D([S({type:Boolean}),E(`design:type`,Object)],wl.prototype,`preview`,void 0),D([C(),E(`design:type`,Object)],wl.prototype,`objectUrl`,void 0),D([C(),E(`design:type`,Object)],wl.prototype,`failed`,void 0),wl=D([x(`auth-image`)],wl);var Tl=class extends w{constructor(...e){super(...e),this.cardId=``,this.fieldKey=``,this.fallbackSrc=``,this.alt=`Image`,this.src=``}connectedCallback(){super.connectedCallback(),this.src=this.getCurrentSrc(),this.unsubscribe=L.subscribe(()=>{let e=this.getCurrentSrc();e&&e!==this.src&&(this.src=e)})}disconnectedCallback(){super.disconnectedCallback(),this.unsubscribe?.()}getCurrentSrc(){return L.getState().getDeviceById(this.cardId)?.state?.[this.fieldKey]?.toString()||this.fallbackSrc}encodeBase64Url(e){let t=new TextEncoder().encode(e),n=``;return t.forEach(e=>{n+=String.fromCharCode(e)}),btoa(n).replace(/\+/g,`-`).replace(/\//g,`_`).replace(/=+$/,``)}decodeBase64Url(e){let t=e.replace(/-/g,`+`).replace(/_/g,`/`).padEnd(Math.ceil(e.length/4)*4,`=`),n=atob(t),r=Uint8Array.from(n,e=>e.charCodeAt(0));return new TextDecoder().decode(r)}getViewportImageSrc(){let e=Math.max(1,Math.round(window.innerWidth*.8)),t=Math.max(1,Math.round(window.innerHeight*.8));try{let n=new URL(this.src,window.location.origin),r=n.searchParams.get(`target`);if(n.pathname.includes(`/providers/`)&&n.pathname.endsWith(`/media`)&&r){let i=new URL(this.decodeBase64Url(r));return i.searchParams.has(`size`)?(i.searchParams.set(`size`,`${e}x${t}`),n.searchParams.set(`target`,this.encodeBase64Url(i.toString())),n.origin===window.location.origin?`${n.pathname}${n.search}`:n.toString()):this.src}if(n.searchParams.has(`size`))return n.searchParams.set(`size`,`${e}x${t}`),n.toString()}catch{return this.src}return this.src}render(){return v`
			<div class="d-flex w-100 align-items-center justify-content-center rounded overflow-hidden">
				<auth-image
					src=${this.getViewportImageSrc()}
					alt=${this.alt}
					imageClass="image-fluid"
					.preview=${!1}
				></auth-image>
			</div>
		`}};D([S({type:String})],Tl.prototype,`cardId`,void 0),D([S({type:String})],Tl.prototype,`fieldKey`,void 0),D([S({type:String})],Tl.prototype,`fallbackSrc`,void 0),D([S({type:String})],Tl.prototype,`alt`,void 0),D([C()],Tl.prototype,`src`,void 0),Tl=D([x(`nq-card-image-command-preview`)],Tl);function El(e,t,n){let r=n?.toString();if(!r)return v``;let i=!!t.commands?.length,a=e.getFieldLabel(t),o=!!t.extra?.width,s=o&&t.extra?.height?`h-100 object-fit-cover`:`object-fit-contain`;return v`
		<div class="${o?`d-flex h-100 min-h-0 flex-column`:`py-2`}">
			${a?v`
				<div class="mb-1 flex-shrink-0 small text-muted">${a}</div>
			`:``}
			<div class="${o?`min-h-0 flex-grow-1`:``}">
				<auth-image
					class="d-block ${o?`h-100`:``}"
					src=${r}
					alt=${e.getFieldFallbackLabel(t)}
					imageClass="img-thumbnail ${s} ${i?`cursor-pointer`:``}"
					loading="lazy"
					.preview=${!i}
					title=${i?`Open preview`:``}
					@click=${i?()=>e.handleImageCommandClick(t,r):void 0}
					@keydown=${i?n=>{n.key!==`Enter`&&n.key!==` `||e.handleImageCommandClick(t,r)}:void 0}
				></auth-image>
			</div>
		</div>
	`}function Dl(e,t,n){let r=t.extra?.icon,i=e.getFieldLabel(t),a=typeof n==`number`?n:Number(n),o=Number.isFinite(a)?a:0,s=e.getFieldSuffix(t),c=typeof t.extra?.min==`number`&&typeof t.extra?.max==`number`,l=t.extra?.display||``,u=_l(n,l)??`${o}${s?` ${s}`:``}`,d=`field-value`,f=e.getFieldClassName(t);if(f&&(d=`field-value ${f}`),!t.control&&l.startsWith(`chart`))return Ol(e,t,o,s,d);if(!t.control&&l===`jumbo`)return al(e,t,o);if(t.control){let n=e.isFieldCommandLocked(t);return c?v`
				<div class=${f}>
					<div class="${n?`opacity-50`:``}">
						<input-range
							.key=${t.key}
							.value=${o}
							.props=${{label:e.getFieldLabel(t),min:t.extra?.min,max:t.extra?.max,suffix:s}}
							@field-change=${n=>{n.stopPropagation(),e.handleFieldChange(t,n.detail.value)}}
						></input-range>
					</div>
				</div>
			`:v`
			<div class=${f}>
				${i||r?v`
					<label class="form-label field-label">
						${r?v`<span class="field-icon"><app-icon .name=${r}></app-icon></span>`:``}
						${i}
					</label>
				`:``}
				<div class="d-flex align-items-center gap-2">
					<input
						type="number"
						?disabled=${n}
						.min=${t.extra?.min===void 0?``:String(t.extra.min)}
						.max=${t.extra?.max===void 0?``:String(t.extra.max)}
						.value=${o.toString()}
						@change=${n=>{let r=n.target;e.handleFieldChange(t,parseFloat(r.value))}}
						class="form-control flex-grow-1"
					/>
					${s?v`<span class="text-muted">${s}</span>`:``}
				</div>
			</div>
		`}return v`
		<div class="field-row">
			${i||r?v`
				<div class="field-label">
					${r?v`<span class="field-icon"><app-icon .name=${r}></app-icon></span>`:``}
					${i?v`<span>${i}</span>`:``}
				</div>
			`:``}
			<span class="${d}">
				${u}
			</span>
		</div>
	`}function Ol(e,t,n,r,i){let a=typeof t.extra?.min==`number`?t.extra.min:0,o=typeof t.extra?.max==`number`&&t.extra.max!==a?t.extra.max:100,s=Math.min(1,Math.max(0,(n-a)/(o-a))),c=Math.PI-Math.PI*s,l=72+Math.cos(c)*56,u=68-Math.sin(c)*56,d=Math.round(s*100),f=_l(n,t.extra?.display)??`${n}${r?` ${r}`:``}`,p=e.getFieldLabel(t),m=i.replace(`field-value`,``).trim();return v`
		<div class="gauge">
			<div class="min-w-0">
				<div class="field-value fs-2 ${m}">${f}</div>
				${p?v`<div class="mt-1 text-muted">${p}</div>`:``}
			</div>
			<div class="overflow-hidden">
				<svg viewBox="0 0 144 80" aria-hidden="true">
						<path
							d="M16 68 A56 56 0 0 1 128 68"
							fill="none"
							stroke="var(--nq-chart-axis-color)"
							stroke-width="4"
							stroke-linecap="round"
						></path>
						<path
							d="M16 68 A56 56 0 0 1 128 68"
							fill="none"
							stroke="currentColor"
							class=${m||`text-body`}
							stroke-width="4"
							stroke-linecap="round"
							pathLength="100"
							stroke-dasharray="${s*100} 100"
						></path>
						<circle
							cx=${l}
							cy=${u}
							r="8"
							fill="currentColor"
							class=${m||`text-body`}
						></circle>
						<text
							x="72"
							y="58"
							text-anchor="middle"
							fill="currentColor"
							class=${m||`text-body`}
							font-size="18"
							font-weight="700"
						>${d}%</text>
				</svg>
			</div>
		</div>
	`}function kl(e,t,n){let r=Array.isArray(n)?n:[],i=t.list,a=i?.item||{},o=a.title||`title`,s=a.description||`description`,c=a.badge,l=i?.check?.checkedKey||`completed`,u=i?.check?.enabled===!0,d=i?.delete?.enabled===!0,f=e.getFieldLabel(t),p=!!(t.extra?.width&&t.extra?.height),m=e.getFieldClassName(t),h=m.split(/\s+/).filter(Boolean),g=r.map((t,n)=>({item:t,originalIndex:n,checked:typeof t==`object`&&t?!!e.getObjectValue(t,l,!1):!1})).sort((e,t)=>u?Number(e.checked)-Number(t.checked):0);return h.includes(`hidden`)?v``:v`
		<div class="${p?`d-flex h-100 min-h-0 flex-column`:``}">
			${f?v`
				<div class="d-flex flex-shrink-0 align-items-center justify-content-between mb-2">
					<div class="field-label">${f}</div>
					<div class="small text-muted">${r.length}</div>
				</div>
			`:``}
			<div class="${p?`min-h-0 flex-grow-1 overflow-auto pr-1`:``}">
				${r.length===0?v`
					<div class="empty-state ${m}">
						${j(`No items`)}
					</div>
				`:r.length>0?v`
					<div class="list-group">
						${g.map(({item:n,originalIndex:r,checked:i},l)=>{let f=typeof n==`object`&&!!n,p=f?e.getObjectValue(n,o,n?.name||n?.id||`Item ${l+1}`):n,h=f?e.getObjectValue(n,s,``):``,g=f&&c?e.getObjectValue(n,c,``):``,_=[a.className||``,Al(a.classNameExpression,n)].filter(Boolean).join(` `),ee=jl(a.templateExpression,n);return v`
								<div class="list-group-item ${m} ${_}">
									${u?v`
										<button
											type="button"
											class="form-check-mark ${i?`is-checked`:``}"
											@click=${()=>e.handleListCheckbox(t,n,r,!i)}
											title=${i?`Uncheck`:`Check`}
										>
											${i?v`
												<svg class="form-check-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
													<path stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M5 13l4 4L19 7"></path>
												</svg>
											`:``}
										</button>
									`:``}
									<div class="min-w-0 flex-grow-1">
										${ee?ys(Fc(ee)):v`
												<div class="d-flex align-items-start gap-2">
													<div class="min-w-0 flex-grow-1 field-value">${e.formatValue(p)}</div>
													${g?v`
														<span class="badge badge-sm">
															${e.formatValue(g)}
														</span>
													`:``}
												</div>
												${h?v`<div class="small text-muted">${h}</div>`:``}
											`}
									</div>
									${d?v`
										<button
											type="button"
											class="btn btn-plain btn-danger btn-sm btn-square"
											${B({title:`Delete item`,message:`Are you sure you want to delete this item?`,variant:`danger`})}
											@click=${()=>e.handleListDelete(t,n)}
											title="Delete"
										>
											<app-icon .icon=${_r} size="16"></app-icon>
										</button>
									`:``}
								</div>
							`})}
					</div>
				`:``}
			</div>
		</div>
	`}function Al(e,t){try{return el(e,{option:t})}catch(e){return console.error(`Error evaluating list item classNameExpression:`,e),``}}function jl(e,t){if(!e)return``;try{let n=$c(e,{option:t});return typeof n==`string`?n:``}catch(e){return console.error(`Error evaluating list item templateExpression:`,e),``}}function Ml(e){return typeof e==`object`&&!!e}function Nl(e){return e.extra?.hideName?``:e.name||e.key}function Pl(e){return v`
		<pre class="overflow-auto text-break rounded bg-body-secondary p-3 small text-muted font-monospace" style="max-height: 16rem; white-space: pre-wrap;">${JSON.stringify(e,null,2)}</pre>
	`}function Fl(e,t,n){if(n==null)return v`<span class="text-muted">-</span>`;if(Array.isArray(n)){if(!n.length)return v`<span class="text-muted">[]</span>`;let r=t.fields||[];return v`
			<div class="d-flex flex-column gap-2 text-left">
				${n.map((t,n)=>v`
					<div class="border border-subtle rounded p-3 bg-body-secondary">
						<div class="mb-2 small fw-semibold text-uppercase text-muted">#${n+1}</div>
						${r.length&&Ml(t)?Il(e,r,t):Pl(t)}
					</div>
				`)}
			</div>
		`}if(Ml(n)){let r=t.fields||[];return r.length?v`<div class="w-100 border border-subtle rounded p-3 bg-body-secondary text-left">${Il(e,r,n)}</div>`:Pl(n)}let r=e.formatValue(n),i=t.extra?.suffix||``;return v`
		<span class="field-value text-break">
			${r}${i?` ${i}`:``}
		</span>
	`}function Il(e,t,n){let r=new Set(t.map(e=>e.key)),i=Object.keys(n||{}).filter(e=>!r.has(e));return v`
		<div class="d-flex flex-column gap-1">
			${t.filter(e=>n?.[e.key]!==void 0&&n?.[e.key]!==null).map(t=>v`
					<div class="d-flex justify-content-between gap-3 py-1">
						<span class="text-muted">${Nl(t)}:</span>
						<div class="min-w-0 text-right text-break">${Fl(e,t,n[t.key])}</div>
					</div>
				`)}
			${i.map(t=>v`
				<div class="d-flex justify-content-between gap-3 py-1">
					<span class="text-muted">${t}:</span>
					<div class="min-w-0 text-right text-break">${Fl(e,{key:t,name:t,type:Ml(n[t])?`object`:`string`},n[t])}</div>
				</div>
			`)}
		</div>
	`}function Ll(e,t,n){if(n==null)return v``;let r=e.getFieldLabel(t),i=t.fields?.length&&Ml(n)?Fl(e,t,n):Pl(n);return v`
		<div class="py-2">
			${r?v`<div class="field-label mb-1">${r}</div>`:``}
			${i}
		</div>
	`}function Rl(e){if(e==null||e===``)return null;if(e instanceof Date)return Number.isNaN(e.getTime())?null:e;if(typeof e==`number`){let t=new Date(e<0xe8d4a51000?e*1e3:e);return Number.isNaN(t.getTime())?null:t}if(typeof e==`string`){let t=e.match(/^(\d{4})-(\d{2})-(\d{2})$/);if(t){let[,e,n,r]=t;return new Date(Number(e),Number(n)-1,Number(r))}}let t=new Date(e);return Number.isNaN(t.getTime())?null:t}function zl(e,t=`standard`){let n=Rl(e);return n?t===`date`?n.toLocaleDateString(void 0,{day:`2-digit`,month:`2-digit`,year:`numeric`}):t===`time`?n.toLocaleTimeString(void 0,{hour:`2-digit`,minute:`2-digit`}):t===`full`?n.toLocaleString(void 0,{day:`2-digit`,month:`2-digit`,year:`numeric`,hour:`2-digit`,minute:`2-digit`,second:`2-digit`}):`${n.toLocaleDateString(void 0,{day:`2-digit`,month:`2-digit`,year:`2-digit`})} ${n.toLocaleTimeString(void 0,{hour:`2-digit`,minute:`2-digit`})}`:e==null||e===``?``:String(e)}var Bl=(e,t,n)=>{let r=new Map;for(let i=t;i<=n;i++)r.set(e[i],i);return r},Vl=gt(class extends _t{constructor(e){if(super(e),e.type!==ht.CHILD)throw Error(`repeat() can only be used in text expressions`)}dt(e,t,n){let r;n===void 0?n=t:t!==void 0&&(r=t);let i=[],a=[],o=0;for(let t of e)i[o]=r?r(t,o):o,a[o]=n(t,o),o++;return{values:a,keys:i}}render(e,t,n){return this.dt(e,t,n).values}update(e,[t,n,r]){let i=pt(e),{values:a,keys:o}=this.dt(t,n,r);if(!Array.isArray(i))return this.ut=o,a;let s=this.ut??=[],c=[],l,u,d=0,f=i.length-1,p=0,m=a.length-1;for(;d<=f&&p<=m;)if(i[d]===null)d++;else if(i[f]===null)f--;else if(s[d]===o[p])c[p]=ut(i[d],a[p]),d++,p++;else if(s[f]===o[m])c[m]=ut(i[f],a[m]),f--,m--;else if(s[d]===o[m])c[m]=ut(i[d],a[m]),lt(e,c[m+1],i[d]),d++,m--;else if(s[f]===o[p])c[p]=ut(i[f],a[p]),lt(e,i[d],i[f]),f--,p++;else if(l===void 0&&(l=Bl(o,p,m),u=Bl(s,d,f)),l.has(s[d]))if(l.has(s[f])){let t=u.get(o[p]),n=t===void 0?null:i[t];if(n===null){let t=lt(e,i[d]);ut(t,a[p]),c[p]=t}else c[p]=ut(n,a[p]),lt(e,i[d],n),i[t]=null;p++}else mt(i[f]),f--;else mt(i[d]),d++;for(;p<=m;){let t=lt(e,c[m+1]);ut(t,a[p]),c[p++]=t}for(;d<=f;){let e=i[d++];e!==null&&mt(e)}return this.ut=o,ft(e,c),Ae}}),Hl=class extends w{constructor(...e){super(...e),this.variant=`default`,this.size=`md`,this.background=!1}getColorVariant(){return this.variant==="default"||this.variant===`neutral`?`secondary`:this.variant}getVariantClasses(){let e=this.getColorVariant();return this.background?`badge-${e}`:`border-${e} text-${e} bg-transparent`}getSizeClass(){return this.size===`sm`?`badge-sm`:this.size===`lg`?`badge-lg`:``}render(){let e=`badge ${this.getSizeClass()}`;return this.color?v`
        <span class=${e} style="${`background: ${this.background?`${this.color}22`:`transparent`}; color: ${this.color}; border-color: ${this.color};`}">
          ${this.content}
        </span>
      `:v`
      <span class="${e} ${this.getVariantClasses()}">
        ${this.content}
      </span>
    `}};D([S({type:String}),E(`design:type`,Object)],Hl.prototype,`variant`,void 0),D([S({type:String}),E(`design:type`,String)],Hl.prototype,`color`,void 0),D([S({type:String}),E(`design:type`,Object)],Hl.prototype,`size`,void 0),D([S({type:Boolean}),E(`design:type`,Object)],Hl.prototype,`background`,void 0),D([S({attribute:!1}),E(`design:type`,Object)],Hl.prototype,`content`,void 0),Hl=D([x(`app-badge`)],Hl);var Ul=class extends w{constructor(...e){super(...e),this.data=[],this.columns=[],this.options={},this.visibleColumns=new Set}connectedCallback(){super.connectedCallback(),this.style.display=`block`}getCellValue(e,t){return t.includes(`.`)?t.split(`.`).reduce((e,t)=>e?.[t],e):e[t]}formatCellValue(e,t){return t.format?t.format(e):t.type===`date`&&e?zl(e,t.dateFormat??`standard`):t.type===`boolean`?j(e?`Yes`:`No`):String(e??``)}hasRenderableActionsContent(e){if(e===y||e==null)return!1;if(typeof e==`string`)return e.trim().length>0;if(typeof e==`number`||typeof e==`boolean`)return!0;if(Array.isArray(e))return e.length>0;let t=e;if(Array.isArray(t.strings)){let e=t.strings.some(e=>typeof e==`string`&&e.trim().length>0),n=(Array.isArray(t.values)?t.values:[]).some(e=>e!==y&&e!=null);return e||n}return!0}render(){if(this.data.length===0)return v`
        <div class="table-empty">
          ${j(this.options.emptyMessage||`No data available`)}
        </div>
      `;let e=this.columns.filter(e=>this.visibleColumns.has(e.key));return v`
      <div class="table-card-list">
        ${this.data.map((t,n)=>{let r=this.options.actions?this.options.actions(t,n):y,i=this.hasRenderableActionsContent(r);return v`
          <div class="table-card">
            ${e.map(e=>{let r=this.getCellValue(t,e.key);return v`
                <div class="table-card-row">
                  <span class="table-card-label">${j(e.label)}:</span>
                  <span class="table-card-value">
                    ${e.renderCell?e.renderCell(r,t,n):e.type===`array`&&Array.isArray(r)?v`<div class="d-flex flex-wrap gap-1">${r.map(e=>v`<app-badge .content=${String(e)}></app-badge>`)}</div>`:e.type===`double`?v`<div><div>${r}</div><div class="table-secondary">${e.key2?this.getCellValue(t,e.key2):``}</div></div>`:this.formatCellValue(r,e)}
                  </span>
                </div>
              `})}
            ${this.options.actions&&i?v`
              <div class="table-card-actions">
                ${r}
              </div>
            `:y}
          </div>
        `})}
      </div>
    `}};D([S({type:Array}),E(`design:type`,Array)],Ul.prototype,`data`,void 0),D([S({type:Array}),E(`design:type`,Array)],Ul.prototype,`columns`,void 0),D([S({attribute:!1}),E(`design:type`,Object)],Ul.prototype,`options`,void 0),D([S({attribute:!1}),E(`design:type`,typeof Set>`u`?Object:Set)],Ul.prototype,`visibleColumns`,void 0),Ul=D([x(`nq-table-cards`)],Ul);var W=class extends w{constructor(...e){super(...e),this.data=[],this.columns=[],this.options={},this.sortState=null,this.filterState={},this.activeFilters=[],this.paginationState={page:1,limit:25,total:0},this.visibleColumns=new Set,this.showColumnsDropdown=!1,this.columnsDropdownPosition={top:0,right:0},this.tempFilterValue=``,this.tempFilterValue2=``,this.openActionsMenuIndex=null,this.pageInputDebounceTimer=null,this.actionsMenuPosition={top:0,right:0},this.isMobileView=!1,this.searchQuery=``,this.searchDebounceTimer=null,this._knownColumnKeys=``,this.stateLoaded=!1}connectedCallback(){super.connectedCallback(),this.style.display=`block`,this.loadState(),this._handleClickOutside=this._handleClickOutside.bind(this),document.addEventListener(`click`,this._handleClickOutside),(this.options.mobileBreakpoint??600)>0&&requestAnimationFrame(()=>{this.isMobileView=this.offsetWidth>0&&this.offsetWidth<(this.options.mobileBreakpoint??600)}),this.options.mode===`api`&&this.options.onParamsChange&&requestAnimationFrame(()=>{this.options.onParamsChange?.(this.buildApiQueryParams())})}disconnectedCallback(){super.disconnectedCallback(),document.removeEventListener(`click`,this._handleClickOutside)}_handleClickOutside(e){let t=e.target;this.contains(t)||(this.showColumnsDropdown=!1,this.hideActionsMenu())}willUpdate(e){if(e.has(`data`)||e.has(`columns`)||e.has(`options`)){!this.stateLoaded&&this.options.id&&(this.loadState(),this.stateLoaded=!0);let t=this.columns.map(e=>e.key).join(`,`);if(t!==this._knownColumnKeys&&(this._knownColumnKeys=t,this.visibleColumns=new Set(this.columns.filter(e=>!e.hidden).map(e=>e.key))),this.options.pagination!==!1){let t=e.has(`options`)&&this.options.limit?this.options.limit:this.paginationState.limit,n;n=this.options.mode===`api`?typeof this.options.total==`number`?this.options.total:this.paginationState.total:this.options.filterable===!1?this.data.length:this.applyFilters([...this.data]).length,(this.paginationState.limit!==t||this.paginationState.total!==n)&&(this.paginationState={...this.paginationState,limit:t,total:n})}if(this.options.sort&&!this.sortState){let e=this.options.sort;e.startsWith(`-`)?this.sortState={key:e.substring(1),direction:`desc`}:this.sortState={key:e,direction:`asc`}}}}shouldUseQueryState(){return!!(this.options.id&&this.options.queryState!==!1)}getQueryStateParamName(){return typeof this.options.queryState==`string`&&this.options.queryState.trim()?this.options.queryState.trim():`filter`}getHashQueryParams(){if(typeof window>`u`)return new URLSearchParams;let e=window.location.hash||``,t=e.indexOf(`?`);return new URLSearchParams(t===-1?``:e.slice(t+1))}getAllQueryState(){let e=this.getHashQueryParams().get(this.getQueryStateParamName());if(!e)return{};try{let t=JSON.parse(e);return t&&typeof t==`object`&&!Array.isArray(t)?t:{}}catch(e){return console.error(`Failed to parse table state from URL:`,e),{}}}getQueryState(){if(!this.options.id)return null;let e=this.getAllQueryState()[this.options.id];return e&&typeof e==`object`&&!Array.isArray(e)?e:null}updateQueryState(e){if(typeof window>`u`||!this.options.id)return;let t=window.location.hash||`#`,n=t.indexOf(`?`),r=n===-1?t:t.slice(0,n),i=this.getHashQueryParams(),a=this.getAllQueryState(),o=Object.fromEntries(Object.entries(e).filter(([,e])=>e==null||e===``?!1:Array.isArray(e)?e.length>0:!0));Object.keys(o).length>0?a[this.options.id]=o:delete a[this.options.id],Object.keys(a).length>0?i.set(this.getQueryStateParamName(),JSON.stringify(a)):i.delete(this.getQueryStateParamName());let s=i.toString(),c=`${r||`#`}${s?`?${s}`:``}`,l=`${window.location.pathname}${window.location.search}${c}`;window.history.replaceState(null,``,l)}loadState(){if(this.options.id)try{let e=null;if(this.options.saveState&&(e=JSON.parse(localStorage.getItem(`tables`)||`{}`)[this.options.id]),e&&(e.sortState&&(this.sortState=e.sortState),e.activeFilters&&(this.activeFilters=e.activeFilters),e.searchQuery&&(this.searchQuery=e.searchQuery),e.paginationState&&(this.paginationState={...this.paginationState,page:Number(e.paginationState.page)||this.paginationState.page,limit:Number(e.paginationState.limit)||this.paginationState.limit})),this.shouldUseQueryState()){let e=this.getQueryState(),t=Number(e?.page),n=Number(e?.limit),r=e?.sort,i=e?.search,a=e?.filters;(t>0||n>0)&&(this.paginationState={...this.paginationState,page:t>0?t:this.paginationState.page,limit:n>0?n:this.paginationState.limit}),r&&(this.sortState=String(r).startsWith(`-`)?{key:r.substring(1),direction:`desc`}:{key:r,direction:`asc`}),typeof i==`string`&&(this.searchQuery=i),Array.isArray(a)&&(this.activeFilters=a)}}catch(e){console.error(`Failed to load table state:`,e)}}saveState(){if(this.options.id)try{let e={sortState:this.sortState,activeFilters:this.activeFilters,searchQuery:this.searchQuery,paginationState:{page:this.paginationState.page,limit:this.paginationState.limit}};if(this.options.saveState){let t=JSON.parse(localStorage.getItem(`tables`)||`{}`);t[this.options.id]=e,localStorage.setItem(`tables`,JSON.stringify(t))}this.shouldUseQueryState()&&this.updateQueryState({page:this.paginationState.page>1?this.paginationState.page:null,limit:this.paginationState.limit===25?null:this.paginationState.limit,sort:this.sortStateToString(this.sortState),search:this.searchQuery||null,filters:this.activeFilters})}catch(e){console.error(`Failed to save table state:`,e)}}get processedData(){let e=[...this.data];return this.options.mode!==`api`&&this.searchQuery&&(e=this.applySearch(e)),this.options.mode!==`api`&&this.options.filterable!==!1&&(e=this.applyFilters(e)),this.options.mode!==`api`&&this.sortState&&(e=this.applySorting(e)),this.options.mode!==`api`&&this.options.pagination!==!1&&(e=this.applyPagination(e)),e}applySearch(e){let t=this.searchQuery.toLowerCase(),n=this.columns.filter(e=>e.searchable);return n.length===0?e:e.filter(e=>n.some(n=>{let r=this.getCellValue(e,n.key);if(r!=null&&(Array.isArray(r)?r.some(e=>String(e).toLowerCase().includes(t)):String(r).toLowerCase().includes(t)))return!0;if(n.key2){let r=this.getCellValue(e,n.key2);return r!=null&&String(r).toLowerCase().includes(t)}return!1}))}handleSearchInput(e){let t=e.target.value;this.searchDebounceTimer&&clearTimeout(this.searchDebounceTimer),this.searchDebounceTimer=setTimeout(()=>{this.searchQuery=t,this.paginationState.page!==1&&(this.paginationState={...this.paginationState,page:1}),this.saveState(),this.options.mode===`api`&&this.options.onParamsChange&&this.options.onParamsChange(this.buildApiQueryParams())},300)}applyFilters(e){return e.filter(e=>this.activeFilters.every(t=>{let n=this.columns.find(e=>e.key===t.columnKey);if(!n)return!0;if(n.filterFn)return n.filterFn(e,t);let r=this.getCellValue(e,t.columnKey);return this.evaluateFilter(r,t,n.type||`text`)}))}evaluateFilter(e,t,n){let{operator:r,value:i,value2:a}=t;if(r===`$exists`){let t=e!=null&&e!==``;return i?t:!t}if(n===`text`){let t=String(e||``).toLowerCase(),n=String(i||``).toLowerCase();switch(r){case`$eq`:return t===n;case`$ne`:return t!==n;case`$regex`:return t.includes(n);case`$not`:return!t.includes(n);case`startsWith`:return t.startsWith(n);case`endsWith`:return t.endsWith(n);default:return!0}}if(n===`number`){let t=Number(e),n=Number(i);switch(r){case`$eq`:return t===n;case`$ne`:return t!==n;case`$gt`:return t>n;case`$lt`:return t<n;case`$gte`:return t>=n;case`$lte`:return t<=n;default:return!0}}if(n===`boolean`)return e===(i===`true`||i===!0);if(n===`enum`)switch(r){case`$eq`:return Object.is(e,i);case`$ne`:return!Object.is(e,i);default:return!0}if(n===`date`){let t=new Date(e),n=new Date(i);switch(r){case`$eq`:return t.toDateString()===n.toDateString();case`$lt`:return t<n;case`$gt`:return t>n;case`$gte`:return t>=n;case`$lte`:return t<=n;case`between`:let e=new Date(a);return t>=n&&t<=e;default:return!0}}return!0}applySorting(e){if(!this.sortState||!this.sortState.direction)return e;let t=this.columns.find(e=>e.key===this.sortState.key);return t?[...e].sort((e,n)=>{if(t.compareFn)return t.compareFn(e,n,this.sortState.direction);let r=this.getCellValue(e,this.sortState.key),i=this.getCellValue(n,this.sortState.key);if(r===i)return 0;let a=r>i?1:-1;return this.sortState.direction===`asc`?a:-a}):e}applyPagination(e){let{page:t,limit:n}=this.paginationState,r=(t-1)*n,i=r+n;return e.slice(r,i)}getCellValue(e,t){return t.includes(`.`)?t.split(`.`).reduce((e,t)=>e?.[t],e):e[t]}handleSort(e){if(e.sortable===!1||this.options.sortable===!1)return;let t=`asc`;this.sortState?.key===e.key&&(this.sortState.direction===`asc`?t=`desc`:this.sortState.direction===`desc`&&(t=`asc`)),this.sortState=t?{key:e.key,direction:t}:null,this.options.pagination!==!1&&(this.paginationState={...this.paginationState,page:1}),this.saveState(),this.options.onParamsChange&&this.options.onParamsChange(this.buildApiQueryParams()),this.dispatchEvent(new CustomEvent(`table-sort`,{detail:{sortState:this.sortState}})),this.requestUpdate()}handleFilter(e,t){this.filterState={...this.filterState,[e]:t},this.paginationState={...this.paginationState,page:1},this.saveState(),this.options.onParamsChange&&this.options.onParamsChange(this.buildApiQueryParams()),this.dispatchEvent(new CustomEvent(`table-filter`,{detail:{activeFilters:this.activeFilters}})),this.requestUpdate()}addFilter(e,t,n,r){if(!e||!t||!n&&n!==0&&n!==!1)return;let i={columnKey:e,operator:t,value:n};t===`between`&&r&&(i.value2=r),this.activeFilters=[...this.activeFilters,i],this.paginationState={...this.paginationState,page:1},this.tempFilterValue=``,this.tempFilterValue2=``,this.saveState(),this.options.onParamsChange&&this.options.onParamsChange(this.buildApiQueryParams()),this.dispatchEvent(new CustomEvent(`table-filter`,{detail:{activeFilters:this.activeFilters}})),this.requestUpdate()}removeFilter(e){this.activeFilters=this.activeFilters.filter((t,n)=>n!==e),this.paginationState={...this.paginationState,page:1},this.saveState(),this.options.onParamsChange&&this.options.onParamsChange(this.buildApiQueryParams()),this.dispatchEvent(new CustomEvent(`table-filter`,{detail:{activeFilters:this.activeFilters}})),this.requestUpdate()}setExternalFilter(e,t){if(!e.columnKey||!e.operator||!e.value&&e.value!==0&&e.value!==!1)return;let n=t||e.columnKey;this.activeFilters=[...this.activeFilters.filter(e=>e.columnKey!==n),e],this.paginationState={...this.paginationState,page:1},this.saveState(),this.options.onParamsChange&&this.options.onParamsChange(this.buildApiQueryParams()),this.dispatchEvent(new CustomEvent(`table-filter`,{detail:{activeFilters:this.activeFilters}})),this.requestUpdate()}clearExternalFilter(e){e&&(this.activeFilters=this.activeFilters.filter(t=>t.columnKey!==e),this.paginationState={...this.paginationState,page:1},this.saveState(),this.options.onParamsChange&&this.options.onParamsChange(this.buildApiQueryParams()),this.dispatchEvent(new CustomEvent(`table-filter`,{detail:{activeFilters:this.activeFilters}})),this.requestUpdate())}handleExternalFilterSet(e){e.stopPropagation(),this.setExternalFilter(e.detail.filter,e.detail.replaceColumnKey)}handleExternalFilterClear(e){e.stopPropagation(),this.clearExternalFilter(e.detail.columnKey)}getOperatorsForColumn(e){let t=this.columns.find(t=>t.key===e);if(!t)return[];switch(t.type||`text`){case`text`:return[`$eq`,`$ne`,`$regex`,`$not`,`startsWith`,`endsWith`,`$exists`];case`number`:return[`$eq`,`$ne`,`$gt`,`$lt`,`$gte`,`$lte`,`$exists`];case`boolean`:return[`$eq`,`$exists`];case`enum`:return[`$eq`,`$ne`,`$exists`];case`date`:return[`$eq`,`$lt`,`$gt`,`$gte`,`$lte`,`between`,`$exists`];default:return[`$eq`,`$regex`,`$exists`]}}getOperatorLabel(e){return{$eq:`Equals`,$ne:`Not Equals`,$regex:`Contains`,$not:`Not Contains`,startsWith:`Starts With`,endsWith:`Ends With`,$gt:`Greater Than`,$lt:`Less Than`,$gte:`Greater or Equal`,$lte:`Less or Equal`,between:`Between`,$exists:`Exists`}[e]||e}renderFilterMenu(){return v`
      ${this.columns.filter(e=>e.filterable===!0).map(e=>{let t=this.getOperatorsForColumn(e.key);return v`
          <app-dropdown-item
            label=${j(e.label)}
            .submenu=${v`
              ${t.map(t=>{if(t===`$exists`)return v`
                    <app-dropdown-item
                      label=${this.getOperatorLabel(t)}
                      .submenu=${v`
                        <app-dropdown-item
                          label="Exists"
                          @click=${()=>this.addFilter(e.key,t,!0)}
                        ></app-dropdown-item>
                        <app-dropdown-item
                          label="Not Exists"
                          @click=${()=>this.addFilter(e.key,t,!1)}
                        ></app-dropdown-item>
                      `}
                    ></app-dropdown-item>
                  `;let n=e.type||`text`;if((n===`enum`||n===`boolean`)&&(t===`$eq`||t===`$ne`)){let r=n===`boolean`?[{value:!0,label:`True`},{value:!1,label:`False`}]:e.options||[];return v`
                    <app-dropdown-item
                      label=${this.getOperatorLabel(t)}
                      .submenu=${v`${r.map(n=>v`
                        <app-dropdown-item
                          label=${j(n.label)}
                          @item-click=${()=>this.addFilter(e.key,t,n.value)}
                        ></app-dropdown-item>
                      `)}`}
                    ></app-dropdown-item>
                  `}let r=this.renderOperatorInput(e.key,t),i=r!==y;return v`
                  <app-dropdown-item
                    label=${this.getOperatorLabel(t)}
                    .submenu=${i?r:void 0}
                    @click=${i?void 0:()=>this.addFilter(e.key,t,!0)}
                  ></app-dropdown-item>
                `})}
            `}
          ></app-dropdown-item>
        `})}
    `}hasFilterableColumns(){return this.columns.some(e=>e.filterable===!0)}renderOperatorInput(e,t){let n=this.columns.find(t=>t.key===e);if(!n||t===`$exists`)return y;let r=n.type||`text`;return v`
      <div class="table-filter-panel" @click=${e=>e.stopPropagation()}>
        ${this.renderInputForType(r,t,e)}
        <app-button
          variant="primary"
          size="md"
          label="Add"
          @click=${()=>{this.addFilter(e,t,this.tempFilterValue,this.tempFilterValue2)}}
          className="w-100 mt-2"
        ></app-button>
      </div>
    `}renderInputForType(e,t,n){let r=this.columns.find(e=>e.key===n);if(e===`boolean`)return v`
        <select
          class="form-control"
          .value=${this.tempFilterValue}
          @change=${e=>this.tempFilterValue=e.target.value}
        >
          <option value="">Select...</option>
          <option value="true">True</option>
          <option value="false">False</option>
        </select>
      `;if(e===`enum`){let e=r?.options??[],t=e.findIndex(e=>Object.is(e.value,this.tempFilterValue));return v`
        <select
          class="form-control"
          .value=${t>=0?String(t):``}
          @change=${t=>{let n=t.target.value;this.tempFilterValue=n===``?``:e[Number(n)]?.value}}
        >
          <option value="">Select...</option>
          ${e.map((e,t)=>v`
            <option value=${String(t)}>${j(e.label)}</option>
          `)}
        </select>
      `}return e===`date`?v`
        <input
          type="date"
          class="form-control"
          .value=${this.tempFilterValue}
          @input=${e=>this.tempFilterValue=e.target.value}
        />
        ${t===`between`?v`
              <input
                type="date"
                class="form-control table-filter-input"
                placeholder="To"
                .value=${this.tempFilterValue2}
                @input=${e=>this.tempFilterValue2=e.target.value}
              />
            `:y}
      `:e===`number`?v`
        <input
          type="number"
          class="form-control"
          placeholder="Enter value..."
          .value=${this.tempFilterValue}
          @input=${e=>this.tempFilterValue=e.target.value}
        />
      `:v`
      <input
        type="text"
        class="form-control"
        placeholder="Enter value..."
        .value=${this.tempFilterValue}
        @input=${e=>this.tempFilterValue=e.target.value}
      />
    `}handlePageChange(e){let{limit:t,total:n}=this.paginationState,r=Math.ceil((n||0)/(t||1)),i=r>0?Math.min(Math.max(1,e),r):1;this.paginationState={...this.paginationState,page:i},this.saveState(),this.options.onParamsChange&&this.options.onParamsChange(this.buildApiQueryParams()),this.dispatchEvent(new CustomEvent(`table-page-change`,{detail:{paginationState:this.paginationState}})),this.requestUpdate()}handlePageInput(e){let t=e.target;this.pageInputDebounceTimer&&clearTimeout(this.pageInputDebounceTimer),this.pageInputDebounceTimer=setTimeout(()=>{let{limit:e,total:n}=this.paginationState,r=Math.ceil(n/e),i=parseInt(t.value);isNaN(i)||i<1?i=1:i>r&&(i=r||1),t.value=String(i),this.handlePageChange(i)},500)}changePageSize(e){this.paginationState={...this.paginationState,limit:e,page:1},this.saveState(),this.options.onParamsChange&&this.options.onParamsChange(this.buildApiQueryParams()),this.dispatchEvent(new CustomEvent(`table-page-change`,{detail:{paginationState:this.paginationState}})),this.requestUpdate()}toggleColumnVisibility(e){this.visibleColumns.has(e)?this.visibleColumns.delete(e):this.visibleColumns.add(e),this.requestUpdate()}setColumnVisibility(e,t){t!==this.visibleColumns.has(e)&&this.toggleColumnVisibility(e)}formatCellValue(e,t){if(t.format)return t.format(e);if(t.type===`date`&&e)return zl(e,t.dateFormat??`standard`);if(t.type===`boolean`)return j(e?`Yes`:`No`);if(t.type===`enum`){let n=t.options?.find(t=>Object.is(t.value,e));return j(n?.label??String(e??``))}return String(e??``)}formatFilterValue(e,t){return e.operator===`between`?`${e.value} - ${e.value2}`:this.formatCellValue(e.value,t)}hasRenderableActionsContent(e){if(e===y||e==null)return!1;if(typeof e==`string`)return e.trim().length>0;if(typeof e==`number`||typeof e==`boolean`)return!0;if(Array.isArray(e))return e.length>0;let t=e;if(Array.isArray(t.strings)){let e=t.strings.some(e=>typeof e==`string`&&e.trim().length>0),n=(Array.isArray(t.values)?t.values:[]).some(e=>e!==y&&e!=null);return e||n}return!0}showActionsMenu(e,t){let n=t.currentTarget.getBoundingClientRect();this.actionsMenuPosition={top:n.top+n.height/2,right:window.innerWidth-n.left-n.width/2},this.openActionsMenuIndex=e}toggleActionsMenu(e,t){if(t.stopPropagation(),this.openActionsMenuIndex===e){this.hideActionsMenu();return}this.showColumnsDropdown=!1,this.showActionsMenu(e,t)}hideActionsMenu(){this.openActionsMenuIndex=null}sortStateToString(e){return!e||!e.direction?null:`${e.direction===`desc`?`-`:``}${e.key}`}escapeRegexValue(e){return e.replace(/[.*+?^${}()|[\]\\]/g,`\\$&`)}buildFiltersWhere(){let e={};return this.activeFilters.forEach(t=>{let{columnKey:n,operator:r,value:i,value2:a}=t;r===`startsWith`?e[n]={$regex:`^${this.escapeRegexValue(String(i))}`,$options:`i`}:r===`endsWith`?e[n]={$regex:`${this.escapeRegexValue(String(i))}$`,$options:`i`}:r===`between`?e[n]={$gte:i,$lte:a}:r===`$regex`?e[n]={$regex:i,$options:`i`}:r===`$not`?e[n]={$not:{$regex:i,$options:`i`}}:r===`$exists`?i?e[n]={$exists:!0,$ne:null}:e[n]={$in:[null,``]}:e[n]={[r]:i}}),e}buildSearchWhere(){let e=this.searchQuery.trim(),t=this.columns.filter(e=>e.searchable);if(!e||t.length===0)return{};let n=`^${this.escapeRegexValue(e)}`;return{$or:t.flatMap(e=>{let t=[{[e.key]:{$regex:n,$options:`i`}}];return e.key2&&t.push({[e.key2]:{$regex:n,$options:`i`}}),t})}}buildWhere(){return{...this.buildFiltersWhere(),...this.buildSearchWhere()}}buildApiQuery(){let e={},t=this.sortStateToString(this.sortState);t&&(e.sort=t),e.page=String(this.paginationState.page),e.limit=String(this.paginationState.limit);let n=this.buildWhere();return Object.keys(n).length>0&&(e.where=JSON.stringify(n)),e}buildApiQueryParams(){let e={page:this.paginationState.page,limit:this.paginationState.limit},t=this.sortStateToString(this.sortState);t&&(e.sort=t);let n=this.buildWhere();return Object.keys(n).length>0&&(e.where=n),e}renderHeader(){return v`
      <thead class="table-head">
        <tr>
          ${this.columns.filter(e=>this.visibleColumns.has(e.key)).map(e=>v`
              <th
                class="table-th ${e.sortable!==!1&&this.options.sortable!==!1?`table-th-sortable`:``}"
                style="${e.width?`width: ${e.width}`:``}"
                @click=${()=>this.handleSort(e)}
              >
                ${e.renderHeader?e.renderHeader(e):v`
                      ${j(e.label)}
                      ${e.sortable!==!1&&this.options.sortable!==!1?v`<span
                            class="table-sort ${this.sortState?.key===e.key?`opacity-100`:`opacity-50`}"
                            >${this.sortState?.key===e.key?this.sortState.direction===`asc`?`↑`:`↓`:`↕`}</span
                          >`:y}
                    `}
              </th>
            `)}
          ${this.options.actions?v`
                <th
                  class="table-th text-end"
                  style="width: 100px;"
                >
                  <div class="d-flex justify-content-end">
                    <div class="position-relative">
                      <button
                        type="button"
                        class="table-menu-button"
                        aria-label="Choose visible columns"
                        aria-expanded=${this.showColumnsDropdown?`true`:`false`}
                        @click=${e=>{if(e.stopPropagation(),!this.showColumnsDropdown){this.hideActionsMenu();let t=e.currentTarget.getBoundingClientRect();this.columnsDropdownPosition={top:t.bottom+8,right:window.innerWidth-t.right}}this.showColumnsDropdown=!this.showColumnsDropdown}}
                      >
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="currentColor">
                          <circle cx="10" cy="4" r="1.5"></circle>
                          <circle cx="10" cy="10" r="1.5"></circle>
                          <circle cx="10" cy="16" r="1.5"></circle>
                        </svg>
                      </button>
                      ${this.showColumnsDropdown?v`
                            <div
                              class="table-columns-menu"
                              style="top: ${this.columnsDropdownPosition.top}px; right: ${this.columnsDropdownPosition.right}px;"
                              @click=${e=>e.stopPropagation()}
                            >
                              ${this.columns.map(e=>v`
                                  <div
                                    class="table-column-option"
                                  >
                                    <input-checkbox
                                      .key=${`table-column-${e.key}`}
                                      .value=${this.visibleColumns.has(e.key)}
                                      .props=${{checkboxLabel:e.label}}
                                      @field-change=${t=>{t.stopPropagation(),this.setColumnVisibility(e.key,!!t.detail.value)}}
                                    ></input-checkbox>
                                  </div>
                                `)}
                            </div>
                          `:y}
                    </div>
                  </div>
                </th>
              `:y}
        </tr>
      </thead>
    `}renderBody(){let e=this.processedData,t=this.columns.filter(e=>this.visibleColumns.has(e.key)),n=t.length+ +!!this.options.actions;return e.length===0?v`
        <tbody>
          <tr>
            <td colspan="${n}" class="table-empty">
              ${j(this.options.emptyMessage||`No data available`)}
            </td>
          </tr>
        </tbody>
      `:v`
      <tbody>
        ${Vl(e,(e,t)=>t,(e,n)=>{let r=this.options.actions?this.options.actions(e,n):y,i=this.hasRenderableActionsContent(r);return v`
            <tr
              class="table-row ${this.options.hoverable===!1?``:`table-row-hover`} ${this.options.striped?`table-row-striped`:``}"
            >
              ${t.map(t=>{let r=this.getCellValue(e,t.key);return v`
                  <td class="table-td">
                    ${t.renderCell?t.renderCell(r,e,n):t.type===`array`&&Array.isArray(r)?v`<div class="d-flex flex-wrap gap-1">${r.map(e=>v`<app-badge size="sm" .content=${String(e)}></app-badge>`)}</div>`:t.type===`double`?v`<div><div>${r}</div><div class="table-secondary">${t.key2?this.getCellValue(e,t.key2):``}</div></div>`:this.formatCellValue(r,t)}
                  </td>
                `})}
              ${this.options.actions&&i?v`
                    <td class="table-td text-end">
                      <div
                        class="table-actions"
                        @mouseenter=${e=>this.showActionsMenu(n,e)}
                        @mouseleave=${()=>this.hideActionsMenu()}
                      >
                        <button
                          type="button"
                          class="table-menu-button"
                          aria-label="Open row actions"
                          aria-expanded=${this.openActionsMenuIndex===n?`true`:`false`}
                          @click=${e=>this.toggleActionsMenu(n,e)}
                        >
                          <svg width="20" height="20" viewBox="0 0 20 20" fill="currentColor">
                            <circle cx="10" cy="4" r="1.5"></circle>
                            <circle cx="10" cy="10" r="1.5"></circle>
                            <circle cx="10" cy="16" r="1.5"></circle>
                          </svg>
                        </button>
                        ${this.openActionsMenuIndex===n?v`
                          <div
                            class="table-actions-menu"
                            style="top: ${this.actionsMenuPosition.top}px; right: ${this.actionsMenuPosition.right}px;"
                            @click=${()=>this.hideActionsMenu()}
                          >
                            ${r}
                          </div>
                        `:y}
                      </div>
                    </td>
                  `:y}
            </tr>
          `})}
      </tbody>
    `}renderPagination(){if(this.options.pagination===!1)return y;let{page:e,limit:t,total:n}=this.paginationState,r=Math.ceil(n/t),i=(e-1)*t+1,a=Math.min(e*t,n),o=this.options.limitOptions||[10,25,50,100];return v`
      <div
        class="table-pagination"
      >
        <div class="d-flex gap-3 align-items-center small">
          <span class="text-muted">${i}-${a} of ${n}</span>
          ${this.isMobileView?y:v`
            <span class="text-muted px-2">|</span>
            <span class="text-muted">${j(`Rows per page:`)}</span>
            ${o.map(e=>v`
                <button
                  class="btn btn-sm ${e===t?`btn-primary`:`btn-plain`}"
                  @click=${()=>{e!==t&&this.changePageSize(e)}}
                >${e}</button>
              `)}
          `}
        </div>
        <div class="d-flex gap-2 align-items-center">
          <app-button
            variant="ghost"
            size="sm"
            className="btn-square"
            .icon=${un}
            ?disabled=${e===1}
            @click=${()=>this.handlePageChange(e-1)}
          ></app-button>
          <span class="text-muted small text-nowrap d-flex align-items-center gap-1">${j(`Page`)} <input
              type="number"
              .value=${String(e)}
              min="1"
              max=${r}
              @input=${this.handlePageInput}
              class="form-control form-control-sm table-page-input"
            /> ${j(`of`)} ${r}</span>
          <app-button
            variant="ghost"
            size="sm"
            className="btn-square"
            .icon=${dn}
            ?disabled=${e===r||r===0}
            @click=${()=>this.handlePageChange(e+1)}
          ></app-button>
        </div>
      </div>
    `}renderColumnVisibility(){return v`
      <div class="p-4 border-bottom">
        ${this.columns.map(e=>v`
            <div class="d-inline-flex mr-4 mb-2">
              <input-checkbox
                .key=${`table-column-inline-${e.key}`}
                .value=${this.visibleColumns.has(e.key)}
                .props=${{checkboxLabel:e.label}}
                @field-change=${t=>{this.setColumnVisibility(e.key,!!t.detail.value)}}
              ></input-checkbox>
            </div>
          `)}
      </div>
    `}renderToolbar(){let e=this.activeFilters.length,t=this.options.filterable!==!1&&this.hasFilterableColumns();return v`
      <div class="table-toolbar">
        <div class="table-toolbar-row">
          <div
            class="table-toolbar-group"
            @table-filter-set=${this.handleExternalFilterSet}
            @table-filter-clear=${this.handleExternalFilterClear}
          >
            ${this.columns.some(e=>e.searchable)?v`
              <div class="table-search">
                <app-icon .icon=${ea} size="16" class="table-search-icon"></app-icon>
                <input
                  type="text"
                  placeholder=${j(`Search...`)}
                  .value=${this.searchQuery}
                  @input=${e=>this.handleSearchInput(e)}
                  class="table-search-input"
                />
              </div>
            `:y}
            ${this.options.filtersExtra?this.options.filtersExtra:y}
            ${t?v`
                  <app-dropdown
                    fixedMenu
                    .trigger=${{variant:`primary`,outline:!0,icon:Lr,label:`Filter`,badge:e>0?String(e):void 0}}
                    .menu=${this.renderFilterMenu()}
                  ></app-dropdown>
                `:y}
          </div>

          ${this.options.extra?v`<div>${this.options.extra}</div>`:v`<div></div>`}
        </div>
      </div>
    `}renderActiveFilters(){let e=this.activeFilters;return e.length===0?y:v`
      <div class="d-flex flex-wrap gap-2 py-3 px-4 border-bottom">
          ${e.map(e=>{let t=this.columns.find(t=>t.key===e.columnKey),n=t?.label||e.columnKey,r=this.activeFilters.indexOf(e),i=e.operator!==`$exists`,a=e.operator===`$exists`?e.value?`(true)`:`(false)`:``;return v`
              <div class="badge text-body">
                <span class="fw-medium">${n}</span>
                <span>${this.getOperatorLabel(e.operator)} ${a}</span>
                ${i?v`<span class="fw-medium"
                      >${t?this.formatFilterValue(e,t):e.value}</span
                    >`:y}
                <button
                  type="button"
                  class="btn btn-sm btn-square btn-plain text-body ml-1"
                  @click=${()=>this.removeFilter(r)}
                  title="Remove filter"
                  aria-label="Remove filter"
                >
                  <app-icon .icon=${Gn} size="14"></app-icon>
                  <span hidden>
                  ✕
                  </span>
                </button>
              </div>
            `})}
      </div>
    `}render(){return v`
      <div class="table-root">
        ${this.renderToolbar()} ${this.renderActiveFilters()}
        ${this.isMobileView?v`
          <nq-table-cards
            .data=${this.processedData}
            .columns=${this.columns}
            .options=${this.options}
            .visibleColumns=${this.visibleColumns}
          ></nq-table-cards>
        `:v`
          <div class="table-scroll">
            <div class="${this.options.loading?`table-loading-wrap`:``}">
              ${this.options.loading?v`<div
                    class="table-loading"
                  >
                    Loading...
                  </div>`:y}
              <table class="table">
                ${this.renderHeader()} ${this.renderBody()}
              </table>
            </div>
          </div>
        `}
        ${this.renderPagination()}
      </div>
    `}};D([S({type:Array}),E(`design:type`,Array)],W.prototype,`data`,void 0),D([S({type:Array}),E(`design:type`,Array)],W.prototype,`columns`,void 0),D([S({type:Object}),E(`design:type`,Object)],W.prototype,`options`,void 0),D([C(),E(`design:type`,Object)],W.prototype,`sortState`,void 0),D([C(),E(`design:type`,Object)],W.prototype,`filterState`,void 0),D([C(),E(`design:type`,Array)],W.prototype,`activeFilters`,void 0),D([C(),E(`design:type`,Object)],W.prototype,`paginationState`,void 0),D([C(),E(`design:type`,typeof Set>`u`?Object:Set)],W.prototype,`visibleColumns`,void 0),D([C(),E(`design:type`,Object)],W.prototype,`showColumnsDropdown`,void 0),D([C(),E(`design:type`,Object)],W.prototype,`columnsDropdownPosition`,void 0),D([C(),E(`design:type`,Object)],W.prototype,`tempFilterValue`,void 0),D([C(),E(`design:type`,Object)],W.prototype,`tempFilterValue2`,void 0),D([C(),E(`design:type`,Object)],W.prototype,`openActionsMenuIndex`,void 0),D([C(),E(`design:type`,Object)],W.prototype,`actionsMenuPosition`,void 0),D([C(),E(`design:type`,Object)],W.prototype,`isMobileView`,void 0),D([C(),E(`design:type`,Object)],W.prototype,`searchQuery`,void 0),W=D([x(`nq-table`)],W);var Wl=e=>{if(e===void 0)return`undefined`;if(e===null)return`null`;if(typeof e==`string`)return e;if(typeof e==`number`||typeof e==`boolean`)return String(e);try{let t=JSON.stringify(e);return t.length>100?`${t.slice(0,97)}...`:t}catch{return`[unserializable]`}},Gl=(e,t)=>{let n=t?.extra?.boolean;if(n?.valueTrue!==void 0&&e===n.valueTrue)return!0;if(n?.valueFalse!==void 0&&e===n.valueFalse)return!1;if(typeof e==`boolean`)return e;if(typeof e==`number`)return e!==0;if(typeof e==`string`){let t=e.trim().toLowerCase();if([`true`,`1`,`yes`,`on`,`open`].includes(t))return!0;if([`false`,`0`,`no`,`off`,`close`,`closed`].includes(t))return!1}return!!e},Kl=(e,t)=>{if(e?.type===`boolean`)return j(Gl(t,e)?e.extra?.boolean?.trueLabel||`Yes`:e.extra?.boolean?.falseLabel||`No`);if(e?.type===`enum`){let n=e.options?.find(e=>String(e.value)===String(t));if(n?.name)return j(n.name)}let n=Wl(t);return e?.type===`number`&&e.extra?.suffix?`${n} ${e.extra.suffix}`:n},ql=(e,t=[],n=``)=>Object.entries(e||{}).flatMap(([e,r])=>{let i=n?`${n}.${e}`:e,a=t.find(t=>t.key===e);return r&&typeof r==`object`&&!Array.isArray(r)?ql(r,a?.fields||[],i):[{key:j(a?.name||i),value:Kl(a,r)}]}),Jl=class extends w{constructor(...e){super(...e),this.items=[],this.total=0,this.loading=!1,this.error=``}async load(e){if(this.card?._id){this.loading=!0,this.error=``;try{let t=await L.getState().getCardHistory(this.card._id,e);this.items=t.items||[],this.total=t.total||0}catch(e){this.error=e instanceof Error?e.message:`Cannot load card history`}finally{this.loading=!1}}}get columns(){return[{key:`timestamp`,label:`Time`,sortable:!0,type:`date`},{key:`value`,label:`Value`,sortable:!1,renderCell:(e,t)=>v`
					<div class="d-flex flex-wrap gap-1">
						${ql(t.state,this.card.fields).map(e=>v`
							<app-badge size="sm" .content=${`${e.key}: ${e.value}`}></app-badge>
						`)}
					</div>
				`}]}render(){if(!this.card)return v``;let e={id:`card-history-${this.card._id}`,mode:`api`,total:this.total,loading:this.loading,sort:`-timestamp`,saveState:!0,onParamsChange:e=>void this.load(e)};return v`
			${this.error?v`<div class="p-3 mb-3 bg-surface-subtle rounded text-danger small">${this.error}</div>`:``}
			<nq-table .data=${this.items} .columns=${this.columns} .options=${e}></nq-table>
		`}};D([S({type:Object})],Jl.prototype,`card`,void 0),D([C()],Jl.prototype,`items`,void 0),D([C()],Jl.prototype,`total`,void 0),D([C()],Jl.prototype,`loading`,void 0),D([C()],Jl.prototype,`error`,void 0),Jl=D([x(`nq-card-history-content`)],Jl);var Yl=e=>z.open({title:`${j(`History`)}: ${e.name}`,content:v`<nq-card-history-content .card=${e}></nq-card-history-content>`,width:`min(96vw, 64rem)`,maxWidth:`96vw`,maxHeight:`90vh`,closeOnBackdrop:!0,closeOnEscape:!0}),Xl=new Set([`button`,`form`,`enum`,`number`,`boolean`]),Zl=650,Ql=class extends w{constructor(...e){super(...e),this.editMode=!1,this.externalCommandCooldowns={},this.formDrafts={},this.fieldChangeDebounceTimers=new Map,this.externalCommandCooldownTimers=new Map}disconnectedCallback(){super.disconnectedCallback();for(let e of this.fieldChangeDebounceTimers.values())window.clearTimeout(e);this.fieldChangeDebounceTimers.clear();for(let e of this.externalCommandCooldownTimers.values())window.clearTimeout(e);this.externalCommandCooldownTimers.clear(),this.cancelActionLongPress()}updated(e){e.has(`externalCommandCooldowns`)&&this.scheduleExternalCommandCooldownUnlocks()}get renderContext(){return{card:this.card,getFieldLabel:e=>this.getFieldLabel(e),getFieldFallbackLabel:e=>this.getFieldFallbackLabel(e),formatValue:e=>this.formatValue(e),getFieldSuffix:e=>this.getFieldSuffix(e),getFieldClassName:e=>this.getFieldClassName(e),getOptionClassName:(e,t)=>this.getOptionClassName(e,t),getObjectValue:(e,t,n)=>this.getObjectValue(e,t,n),handleOptionClick:(e,t)=>this.handleOptionClick(e,t),handleFieldToggle:(e,t,n)=>this.handleFieldToggle(e,t,n),handleFieldChange:(e,t)=>this.handleFieldChange(e,t),handleFieldCommand:(e,t)=>this.handleFieldCommand(e,t),handleImageCommandClick:(e,t)=>this.handleImageCommandClick(e,t),handleListCheckbox:(e,t,n,r)=>this.handleListCheckbox(e,t,n,r),handleListDelete:(e,t)=>this.handleListDelete(e,t),handleFormSubmit:(e,t)=>this.handleFormSubmit(e,t),handleFormActionPointerDown:(e,t)=>this.handleFormActionPointerDown(e,t),handleFormActionContextMenu:(e,t)=>this.handleFormActionContextMenu(e,t),handleActionPointerDown:(e,t,n)=>this.handleActionPointerDown(e,t,n),handleActionPointerEnd:()=>this.cancelActionLongPress(),handleActionContextMenu:(e,t,n)=>this.handleActionContextMenu(e,t,n),shouldSuppressActionClick:e=>this.shouldSuppressActionClick(e),isFieldCommandLocked:e=>this.isFieldCommandLocked(e),renderField:e=>this.renderField(e),getFormDraft:e=>this.formDrafts[e.key]||{},updateFormDraft:(e,t,n)=>this.updateFormDraft(e,t,n)}}getFieldLabel(e){return e.extra?.hideName?``:e.name||``}getFieldFallbackLabel(e){return e.name||e.key}formatValue(e){return e==null?``:typeof e==`boolean`?j(e?`True`:`False`):e.toString().replace(/_/g,` `)}getFieldSuffix(e){return e.extra?.suffix||e.suffix||``}getFieldCooldownKey(e){return e.key}isFieldCommandLocked(e){if(!this.shouldUseFieldCooldown(e))return!1;let t=this.getFieldCooldownKey(e);return(this.externalCommandCooldowns[t]||0)>Date.now()}shouldUseFieldCooldown(e){return Xl.has(e.type||``)}scheduleExternalCommandCooldownUnlocks(){let e=Date.now();for(let e of this.externalCommandCooldownTimers.values())window.clearTimeout(e);this.externalCommandCooldownTimers.clear();for(let[t,n]of Object.entries(this.externalCommandCooldowns||{})){if(n<=e)continue;let r=window.setTimeout(()=>{this.externalCommandCooldownTimers.delete(t),this.requestUpdate()},n-e);this.externalCommandCooldownTimers.set(t,r)}}evaluateExpression(e,t){try{return el(e,t)}catch(e){return console.error(`Error evaluating card expression:`,e),``}}getOptionClassName(e,t){let n=this.card.state?.[t.key],r=String(n)===String(e.value),i=`btn `;if(e.classNameExpression){let t=this.evaluateExpression(e.classNameExpression,{state:this.card.state,option:e,value:n});if(t)return i+=t,i}return e.className?(i+=e.className,i):r?`${i}btn-primary`:`${i}btn-outline-primary`}getFieldClassName(e){if(e.classNameExpression){let t=this.evaluateExpression(e.classNameExpression,{state:this.card.state,value:this.card.state?.[e.key]});if(t)return t}return e.className||``}getObjectValue(e,t,n){return!t||!e||typeof e!=`object`?n:t.split(`.`).reduce((e,t)=>e?.[t],e)??n}updateFormDraft(e,t,n){this.formDrafts={...this.formDrafts,[e.key]:{...this.formDrafts[e.key]||{},[t]:n}}}renderField(e){if(e.extra?.hideField)return v``;let t=this.card.state?.[e.key],n=this.getFieldClassName(e),r=this.renderContext;if(n.includes(`hero`))return al(r,e,t,n);if(n.includes(`buttons`))return ol(r,e);if(n.includes(`muted`))return il(r,e,t);switch(e.type){case`chart`:return gl(r,e);case`button`:return rl(r,e);case`list`:return kl(r,e,t);case`boolean`:return dl(r,e,t);case`number`:return Dl(r,e,t);case`enum`:return yl(r,e,t);case`image`:return El(r,e,t);case`object`:case`array-object`:return Ll(r,e,t);case`form`:return Cl(r,e);default:return vl(r,e,t)}}renderFields(e){let t=[],n=[],r=()=>{if(!n.length)return;let e=n;n=[],t.push(this.renderPackedFieldGrid(e))};for(let i of e)if(!i.extra?.hideField){if(this.getFieldGridWidth(i)){n.push(i);continue}r(),t.push(this.renderField(i))}return r(),t}getFieldGridWidth(e){let t=Number(e.extra?.width);return!Number.isInteger(t)||t<1||t>12?null:t}getFieldGridHeight(e){let t=Number(e.extra?.height);return!Number.isInteger(t)||t<1||t>6?1:t}renderPackedFieldGrid(e){let t=Array(12).fill(0),n=e=>{let n=0,r=1/0;for(let i=0;i<=12-e;i+=1){let a=Math.max(...t.slice(i,i+e));a<r&&(r=a,n=i)}return{x:n,y:r}};return v`
			<div class="card-grid">
				${e.map(e=>{let r=this.getFieldGridWidth(e)||12,i=this.getFieldGridHeight(e),{x:a,y:o}=n(r);for(let e=a;e<a+r;e+=1)t[e]=o+i;return{field:e,x:a,y:o,width:r,height:i}}).map(({field:e,x:t,y:n,width:r,height:i})=>v`
					<div
						class="h-100 min-h-0 min-w-0"
						style="grid-column: ${t+1} / span ${r}; grid-row: ${n+1} / span ${i};"
					>
						${this.renderField(e)}
					</div>
				`)}
			</div>
		`}handleOptionClick(e,t){this.dispatchEvent(new CustomEvent(`field-change`,{detail:{cardId:this.card._id,fieldKey:e.key,value:t.value,option:t,field:e},bubbles:!0,composed:!0}))}handleFieldToggle(e,t,n){let r=!t;if(n){this.dispatchFieldChange(e,r);return}this.handleFieldChange(e,r)}handleFieldChange(e,t){if(e.type===`number`){let n=e.key,r=this.fieldChangeDebounceTimers.get(n);r&&window.clearTimeout(r);let i=window.setTimeout(()=>{this.fieldChangeDebounceTimers.delete(n),this.dispatchFieldChange(e,t)},500);this.fieldChangeDebounceTimers.set(n,i);return}this.dispatchFieldChange(e,t)}dispatchFieldChange(e,t,n=!1){this.dispatchEvent(new CustomEvent(`field-change`,{detail:{cardId:this.card._id,fieldKey:e.key,value:t,field:e,forceConfirm:n},bubbles:!0,composed:!0}))}handleFieldCommand(e,t){e.commands?.length&&this.dispatchEvent(new CustomEvent(`field-change`,{detail:{cardId:this.card._id,fieldKey:e.key,value:t,field:e},bubbles:!0,composed:!0}))}handleImageCommandClick(e,t){let n=this.getDefaultFieldCommandName(e);z.open({title:this.getFieldFallbackLabel(e),headerActions:v`
				<div
					class="position-absolute"
					style="left: 50%; top: 1.5rem; transform: translateX(-50%);"
					data-no-dialog-drag
				>
					<app-button
						variant="primary"
						size="md"
						.background=${!0}
						.label=${n}
						@click=${t=>{t.stopPropagation(),this.handleFieldCommand(e)}}
					></app-button>
				</div>
			`,content:v`
				<nq-card-image-command-preview
					.cardId=${this.card._id}
					.fieldKey=${e.key}
					.fallbackSrc=${t}
					.alt=${this.getFieldFallbackLabel(e)}
				></nq-card-image-command-preview>
			`,closeOnBackdrop:!0,closeOnEscape:!0,width:`min(96vw, 72rem)`,maxWidth:`96vw`,maxHeight:`90vh`}).catch(()=>void 0)}getDefaultFieldCommandName(e){return e.type===`form`?`submit`:e.type===`list`?`list`:e.type===`image`?`open`:e.type===`button`?`click`:`command`}handleListCheckbox(e,t,n,r){this.dispatchEvent(new CustomEvent(`field-change`,{detail:{cardId:this.card._id,fieldKey:e.key,value:{action:`check`,id:this.getListItemId(e,t),checked:r},field:e},bubbles:!0,composed:!0}))}handleListDelete(e,t){this.dispatchEvent(new CustomEvent(`field-change`,{detail:{cardId:this.card._id,fieldKey:e.key,value:{action:`delete`,id:this.getListItemId(e,t)},field:e},bubbles:!0,composed:!0}))}getListItemId(e,t){let n=e.list?.item?.id||`id`;return t&&typeof t==`object`?this.getObjectValue(t,n,t?.id||t?._id):t}handleFormSubmit(e,t=!1){let n=this.getFormSubmitValue(e);if(!e.commands?.length){this.dispatchFieldChange(e,n,t),this.formDrafts={...this.formDrafts,[e.key]:{}};return}this.dispatchEvent(new CustomEvent(`field-change`,{detail:{cardId:this.card._id,fieldKey:e.key,field:e,value:{...n},forceConfirm:t},bubbles:!0,composed:!0})),this.formDrafts={...this.formDrafts,[e.key]:{}}}getFormSubmitValue(e){let t={...this.formDrafts[e.key]||{}};for(let n of e.fields||[]){if(t[n.key]===void 0&&n.defaultValue!==void 0){t[n.key]=n.defaultValue;continue}n.type===`boolean`&&t[n.key]===void 0&&(t[n.key]=!1)}return t}renderCardCommands(){return v``}handleEditClick(e){e.stopPropagation(),this.dispatchEvent(new CustomEvent(`edit-card`,{detail:{card:this.card},bubbles:!0,composed:!0}))}handleFormActionPointerDown(e,t){if(e.pointerType===`mouse`||this.isFieldCommandLocked(t))return;this.cancelActionLongPress();let n=e.currentTarget;this.actionLongPressTimer=window.setTimeout(()=>{this.actionLongPressTimer=void 0,this.suppressNextActionClick(n),this.handleFormSubmit(t,!0)},Zl)}handleFormActionContextMenu(e,t){this.isFieldCommandLocked(t)||(e.preventDefault(),e.stopPropagation(),this.cancelActionLongPress(),e.button===0&&this.suppressNextActionClick(e.currentTarget),this.handleFormSubmit(t,!0))}handleActionPointerDown(e,t,n){if(e.pointerType===`mouse`||this.isFieldCommandLocked(t))return;this.cancelActionLongPress();let r=e.currentTarget;this.actionLongPressTimer=window.setTimeout(()=>{this.actionLongPressTimer=void 0,this.suppressNextActionClick(r),this.dispatchFieldChange(t,n,!0)},Zl)}cancelActionLongPress(){this.actionLongPressTimer!==void 0&&window.clearTimeout(this.actionLongPressTimer),this.actionLongPressTimer=void 0}handleActionContextMenu(e,t,n){this.isFieldCommandLocked(t)||(e.preventDefault(),e.stopPropagation(),this.cancelActionLongPress(),e.button===0&&this.suppressNextActionClick(e.currentTarget),this.dispatchFieldChange(t,n,!0))}shouldSuppressActionClick(e){return this.suppressedActionTarget===e.currentTarget?(this.suppressedActionTarget=void 0,e.preventDefault(),e.stopPropagation(),!0):!1}suppressNextActionClick(e){this.suppressedActionTarget=e,window.setTimeout(()=>{this.suppressedActionTarget===e&&(this.suppressedActionTarget=void 0)},1e3)}handleRemoveClick(e){e.stopPropagation(),this.dispatchEvent(new CustomEvent(`remove-card`,{detail:{card:this.card},bubbles:!0,composed:!0}))}handleHistoryClick(e){e.stopPropagation(),Yl(this.card).catch(()=>void 0)}getCardDynamicClassName(){if(this.card.classNameExpression){let e=this.evaluateExpression(this.card.classNameExpression,{state:this.card.state});if(e)return e}return this.card.className||``}getCardClassName(){let e=this.getCardDynamicClassName();return e?`card ${e}`:`card`}render(){return this.card?v`
			<div class="${this.getCardClassName()}" style="container-type: inline-size;">
				${this.editMode||this.card.history?.enabled?v`
					<div class="card-actions d-flex align-items-center gap-1">
						${this.card.history?.enabled?v`
							<app-button
								variant="ghost"
								className="p-1"
								title=${j(`History`)}
								aria-label=${j(`History`)}
								.icon=${cr}
								@click=${this.handleHistoryClick}
							></app-button>
						`:``}
						${this.editMode?v`
						<app-button
							variant="ghost"
							className="p-1"
							.icon=${A}
							@click=${this.handleEditClick}
						></app-button>
						<app-button
							variant="ghost"
							className="p-1 text-danger"
							title=${j(`Remove`)}
							aria-label=${j(`Remove`)}
							.icon=${k}
							@click=${this.handleRemoveClick}
						></app-button>
						`:``}
					</div>
				`:``}
				<div class="card-body">
					<div class="card-header">
						${this.card.icon?v`
							<div class="card-icon">
								<app-icon .name=${this.card.icon}></app-icon>
							</div>
						`:v`
							<div class="card-icon">
								<span></span>
							</div>
						`}
						<div class="flex-grow-1">
							<h3 class="card-title">${this.card.name}</h3>
							${this.card.subtitle?v`
								<div class="card-subtitle">${this.card.subtitle}</div>
							`:``}
						</div>
					</div>

					<div class="card-content">
						${this.renderFields(this.card.fields)}
					</div>

					${this.renderCardCommands()}
				</div>
			</div>
		`:v``}};D([S({type:Object})],Ql.prototype,`card`,void 0),D([S({type:Boolean})],Ql.prototype,`editMode`,void 0),D([S({type:Object})],Ql.prototype,`externalCommandCooldowns`,void 0),D([C()],Ql.prototype,`formDrafts`,void 0),Ql=D([x(`nq-card`)],Ql);var $l=class extends b{constructor(...e){super(...e),this.items=[],this.size=`default`,this.iconSize=`18`,this.ariaLabel=`Tabs`,this.showLeftArrow=!1,this.showRightArrow=!1,this.isOverflowing=!1,this.currentRoute=nt.currentPath,this.cachedNav=null,this.resizeObserver=null,this.scrollHandler=()=>this.updateArrows(),this.unsubscribeRouter=null}connectedCallback(){super.connectedCallback(),this.unsubscribeRouter=nt.subscribe(e=>{this.currentRoute=e})}createRenderRoot(){return this}get navEl(){return this.cachedNav||=this.querySelector(`.tabs-nav`),this.cachedNav}firstUpdated(){this.setupObservers(),this.updateArrows(),this.scrollToActive()}updated(e){(e.has(`items`)||e.has(`activeId`)||e.has(`currentRoute`))&&requestAnimationFrame(()=>{this.updateArrows(),this.scrollToActive()})}disconnectedCallback(){super.disconnectedCallback(),this.resizeObserver?.disconnect(),this.resizeObserver=null,this.cachedNav?.removeEventListener(`scroll`,this.scrollHandler),this.cachedNav=null,this.unsubscribeRouter?.(),this.unsubscribeRouter=null}setupObservers(){let e=this.navEl;e&&(this.resizeObserver=new ResizeObserver(()=>this.updateArrows()),this.resizeObserver.observe(e),e.addEventListener(`scroll`,this.scrollHandler,{passive:!0}))}updateArrows(){let e=this.navEl;if(!e)return;let{scrollLeft:t,scrollWidth:n,clientWidth:r}=e,i=n>r+1,a=t>1,o=t+r<n-1;i!==this.isOverflowing&&(this.isOverflowing=i),a!==this.showLeftArrow&&(this.showLeftArrow=a),o!==this.showRightArrow&&(this.showRightArrow=o)}handleScrollLeft(){let e=this.navEl;e&&e.scrollBy({left:-e.clientWidth*.75,behavior:`smooth`})}handleScrollRight(){let e=this.navEl;e&&e.scrollBy({left:e.clientWidth*.75,behavior:`smooth`})}scrollToActive(){let e=this.navEl,t=this.items.find(e=>this.isItemActive(e));if(!e||!t)return;let n=e.querySelector(`[data-tab-id="${t.id}"]`);if(!n)return;let r=e.getBoundingClientRect(),i=n.getBoundingClientRect(),a=i.left+i.width/2,o=r.left+r.width/2,s=e.scrollLeft+(a-o);e.scrollTo({left:Math.max(0,s),behavior:`smooth`})}handleClick(e){this.dispatchEvent(new CustomEvent(`tab-change`,{detail:{id:e.id},bubbles:!0,composed:!0}))}isItemActive(e){if(this.activeId!==void 0)return this.activeId===e.id;if(!e.routerLink)return!1;let t=$e(e.routerLink.split(`?`)[0]);return this.currentRoute===t||this.currentRoute.startsWith(`${t}/`)}render(){let e=this.size===`lg`?`tab-link-lg`:this.size===`sm`?`tab-link-sm`:``,t=this.isOverflowing;return v`
      <div class="tabs ${t?`is-overflowing`:``}">
        ${t?v`
          <button
            type="button"
            class="btn btn-plain tab-scroll-button ${this.showLeftArrow?``:`disabled`}"
            @click=${()=>this.handleScrollLeft()}
            ?disabled=${!this.showLeftArrow}
          >
            <app-icon .icon=${un} size="16"></app-icon>
          </button>
        `:y}

        <nav
          class="tabs-nav tab-list"
          aria-label=${this.ariaLabel}
        >
          ${this.items.map(t=>{let n=this.isItemActive(t);return v`
              <button
                type="button"
                data-tab-id=${t.id}
                routerLink=${fl(t.routerLink)}
                @click=${()=>this.handleClick(t)}
                class="tab-link ${e} ${n?`active`:``}"
              >
                ${t.iconName?v`<app-icon .name=${t.iconName} size=${this.iconSize}></app-icon>`:t.icon?v`<app-icon .icon=${t.icon} size=${this.iconSize}></app-icon>`:y}
                <span>${j(t.label)}</span>
              </button>
            `})}
        </nav>

        ${t?v`
          <button
            type="button"
            class="btn btn-plain tab-scroll-button ${this.showRightArrow?``:`disabled`}"
            @click=${()=>this.handleScrollRight()}
            ?disabled=${!this.showRightArrow}
          >
            <app-icon .icon=${dn} size="16"></app-icon>
          </button>
        `:y}
      </div>
    `}};D([S({type:Array}),E(`design:type`,Array)],$l.prototype,`items`,void 0),D([S({type:String}),E(`design:type`,String)],$l.prototype,`activeId`,void 0),D([S({type:String}),E(`design:type`,String)],$l.prototype,`size`,void 0),D([S({type:String}),E(`design:type`,Object)],$l.prototype,`iconSize`,void 0),D([S({type:String}),E(`design:type`,String)],$l.prototype,`ariaLabel`,void 0),D([C(),E(`design:type`,Object)],$l.prototype,`showLeftArrow`,void 0),D([C(),E(`design:type`,Object)],$l.prototype,`showRightArrow`,void 0),D([C(),E(`design:type`,Object)],$l.prototype,`isOverflowing`,void 0),D([C(),E(`design:type`,Object)],$l.prototype,`currentRoute`,void 0),$l=D([x(`app-tabs`)],$l);var eu=class extends w{constructor(...e){super(...e),this.selectedPath=[],this.includeSubzones=!1}getRootZones(){return(this.zones||[]).filter(e=>e.parent===null).sort((e,t)=>e.order-t.order)}getChildren(e){return(this.zones||[]).filter(t=>t.parent===e).sort((e,t)=>e.order-t.order)}getSelectedZoneId(){return this.selectedPath[this.selectedPath.length-1]}getSelectedZone(){let e=this.getSelectedZoneId();if(e)return this.zones?.find(t=>t.id===e)}getPathToZone(e){let t=[],n=this.zones?.find(t=>t.id===e);for(;n;)t.unshift(n.id),n=n.parent?this.zones.find(e=>e.id===n?.parent):void 0;return t}getSelectedZoneName(){return this.getSelectedZone()?.name||`Select zone`}getSelectedZoneParentPath(){let e=this.getSelectedZoneId();return e?this.getPathToZone(e).slice(0,-1).map(e=>this.zones?.find(t=>t.id===e)?.name).filter(Boolean).join(`: `):``}getTabLevels(){let e=[],t=this.getRootZones();t.length>0&&e.push({zones:t,selectedId:this.selectedPath[0]||null,showAll:!1});for(let t=0;t<this.selectedPath.length;t+=1){let n=this.getChildren(this.selectedPath[t]);n.length>0&&e.push({zones:n,selectedId:this.selectedPath[t+1]||null,showAll:!0})}return e}emitZoneChange(e,t=!1){let n=this.getPathToZone(e);n.length&&this.dispatchEvent(new CustomEvent(`zone-change`,{detail:{zoneId:e,path:n,includeSubzones:t},bubbles:!0,composed:!0}))}handleZoneSelect(e,t){if(t===null){let t=this.selectedPath[e-1];t&&this.emitZoneChange(t,!0);return}this.emitZoneChange(t,!1)}openDialog(){z.open({title:`Change zone`,content:v`
				<div class="form-stack">
					${this.renderZoneChoiceList(this.getRootZones(),0)}
				</div>
			`,closeOnBackdrop:!0,closeOnEscape:!0,width:`min(92vw, 26rem)`,maxWidth:`92vw`}).catch(()=>void 0)}renderZoneIcon(e,t=20){return e.icon?e.icon.trim().startsWith(`<svg`)||e.icon.endsWith(`Icon`)?v`<app-icon .name=${e.icon} size=${String(t)} class="text-muted"></app-icon>`:v`<span class="fs-6 lh-1">${e.icon}</span>`:null}renderZoneChoiceList(e,t){let n=this.getSelectedZoneId();return v`
			${e.map(e=>{let r=this.getChildren(e.id),i=n===e.id&&!this.includeSubzones,a=n===e.id&&this.includeSubzones;return v`
					<div>
						<button
							type="button"
							class="btn w-100 justify-content-start text-start ${i?`btn-primary`:`btn-plain`}"
							style=${`padding-left: ${12+t*18}px;`}
							@click=${()=>{this.emitZoneChange(e.id),z.close(!0)}}
						>
							<span class="d-flex flex-shrink-0 align-items-center justify-content-center text-muted" style="width: 1.5rem; height: 1.5rem;">
								${e.icon?this.renderZoneIcon(e,20):v`<app-icon .icon=${wr} size="20"></app-icon>`}
							</span>
							<span class="flex-grow-1 min-w-0 text-truncate text-start">${e.name}</span>
						</button>
						${r.length?v`
							<button
								type="button"
								class="btn w-100 justify-content-start text-start ${a?`btn-primary`:`btn-plain`}"
								style=${`padding-left: ${12+(t+1)*18}px;`}
								@click=${()=>{this.emitZoneChange(e.id,!0),z.close(!0)}}
							>
								<span class="d-flex flex-shrink-0 align-items-center justify-content-center text-muted" style="width: 1.5rem; height: 1.5rem;">
									<app-icon .icon=${Pn} size="20"></app-icon>
								</span>
								<span class="flex-grow-1 min-w-0 text-truncate text-start">All</span>
							</button>
						`:``}
						${r.length?this.renderZoneChoiceList(r,t+1):``}
					</div>
				`})}
		`}renderMobilePicker(){let e=this.getSelectedZone();return v`
			<div class="d-md-none mb-3">
				<button
					type="button"
					class="btn btn-plain w-100 justify-content-start text-start gap-3 p-1"
					@click=${this.openDialog}
				>
					${e?.icon?v`
							<span class="d-flex flex-shrink-0 align-items-center justify-content-center text-muted" style="width: 2rem; height: 2rem;">
								${this.renderZoneIcon(e,22)}
							</span>
						`:``}
					<div class="flex-grow-1 min-w-0">
						<div class="small text-secondary text-truncate">${this.getSelectedZoneParentPath()}</div>
						<div class="fs-5 fw-semibold lh-sm text-body text-truncate">${this.includeSubzones?`${this.getSelectedZoneName()} - All`:this.getSelectedZoneName()}</div>
					</div>
					<span class="d-flex flex-shrink-0 align-items-center justify-content-center text-muted" style="width: 2rem; height: 2rem;">
						<app-icon .icon=${sn} size="22"></app-icon>
					</span>
				</button>
			</div>
		`}renderDesktopTabs(){return v`
			<div class="d-none d-md-block mb-3">
				${this.getTabLevels().map((e,t)=>{let n=v`
						<app-tabs
							class="flex-grow-1 min-w-0 "
							.items=${[...e.showAll?[{id:`__all__`,label:`All`,icon:Pn}]:[],...e.zones.map(e=>({id:e.id,label:e.name,iconName:e.icon||void 0}))]}
							.activeId=${e.selectedId||(e.showAll&&this.includeSubzones&&this.selectedPath.length===t?`__all__`:void 0)}
							size=${t===0?`lg`:`default`}
							iconSize=${t===0?`18`:`16`}
							@tab-change=${e=>{let n=e.detail.id;this.handleZoneSelect(t,n===`__all__`?null:n)}}
						></app-tabs>
					`;return t!==0||!this.desktopActions?n:v`
						<div class="d-flex align-items-center gap-3">
							${n}
							${this.desktopActions}
						</div>
					`})}
			</div>
		`}render(){return v`
			${this.renderMobilePicker()}
			${this.renderDesktopTabs()}
		`}};D([S({type:Array})],eu.prototype,`selectedPath`,void 0),D([S({type:Boolean})],eu.prototype,`includeSubzones`,void 0),D([S({attribute:!1})],eu.prototype,`desktopActions`,void 0),D([H(I,e=>e.zones)],eu.prototype,`zones`,void 0),eu=D([x(`select-zone`)],eu);var tu=class extends w{constructor(...e){super(...e),this.cards=[],this.initialZoneId=``,this.orderedCards=[],this.draggedCardId=null,this.dropTargetCardId=null}firstUpdated(){this.resetOrderedCards()}getZoneCards(e){return this.cards.filter(t=>t.zone===e).sort((e,t)=>(e.order??0)-(t.order??0)||e.name.localeCompare(t.name))}resetOrderedCards(){this.orderedCards=this.initialZoneId?this.getZoneCards(this.initialZoneId):[]}moveCard(e,t){if(e<0||t<0||e===t||t>=this.orderedCards.length)return;let n=[...this.orderedCards],[r]=n.splice(e,1);n.splice(t,0,r),this.orderedCards=n}handleDragStart(e,t){this.draggedCardId=t._id,e.dataTransfer?.setData(`text/plain`,t._id),e.dataTransfer&&(e.dataTransfer.effectAllowed=`move`)}handleDragOver(e,t){e.preventDefault(),this.dropTargetCardId=t._id,e.dataTransfer&&(e.dataTransfer.dropEffect=`move`)}handleDrop(e,t){e.preventDefault();let n=this.draggedCardId||e.dataTransfer?.getData(`text/plain`);if(this.draggedCardId=null,this.dropTargetCardId=null,!n||n===t._id)return;let r=this.orderedCards.findIndex(e=>e._id===n),i=this.orderedCards.findIndex(e=>e._id===t._id);this.moveCard(r,i)}handleDragEnd(){this.draggedCardId=null,this.dropTargetCardId=null}async save(){this.orderedCards.length&&await L.getState().updateCardsOrder(this.orderedCards.map((e,t)=>({id:e._id,order:t})))}render(){return v`
      <div class="form-stack gap-4">
        ${this.orderedCards.length===0?v`
              <div class="empty-state">
                No cards in this zone
              </div>
            `:v`
              <div class="list-group">
                ${this.orderedCards.map((e,t)=>v`
                  <div
                    class="list-group-item align-items-center ${this.dropTargetCardId===e._id?`border-primary`:``}"
                    draggable="true"
                    @dragstart=${t=>this.handleDragStart(t,e)}
                    @dragover=${t=>this.handleDragOver(t,e)}
                    @dragleave=${()=>{this.dropTargetCardId=null}}
                    @drop=${t=>this.handleDrop(t,e)}
                    @dragend=${this.handleDragEnd}
                  >
                    <span class="small text-secondary tabular-nums" style="width: 2rem;">${t+1}</span>
                    <span class="text-muted cursor-grab">
                      <app-icon .icon=${Er} size="18"></app-icon>
                    </span>
                    <span class="flex-grow-1 min-w-0 text-truncate text-body">${e.name}</span>
                    <span class="small text-secondary">${j(`order:`)} ${e.order??0}</span>
                    <div class="d-flex gap-1">
                      <app-button
                        variant="ghost"
                        size="sm"
                        .icon=${fn}
                        ?disabled=${t===0}
                        @click=${()=>this.moveCard(t,t-1)}
                        title=${j(`Move up`)}
                      ></app-button>
                      <app-button
                        variant="ghost"
                        size="sm"
                        .icon=${cn}
                        ?disabled=${t===this.orderedCards.length-1}
                        @click=${()=>this.moveCard(t,t+1)}
                        title=${j(`Move down`)}
                      ></app-button>
                    </div>
                  </div>
                `)}
              </div>
            `}
      </div>
    `}};D([S({attribute:!1})],tu.prototype,`cards`,void 0),D([S({type:String})],tu.prototype,`initialZoneId`,void 0),D([C()],tu.prototype,`orderedCards`,void 0),D([C()],tu.prototype,`draggedCardId`,void 0),D([C()],tu.prototype,`dropTargetCardId`,void 0),tu=D([x(`cards-order-dialog-content`)],tu);async function nu(e){if(!e.zoneId)return;await Promise.all([I.getState().fetchZones(),L.getState().fetchDevices()]);let t=`cards-order-${Date.now()}-${Math.random().toString(36).slice(2,9)}`,n=I.getState().getZoneById(e.zoneId),r=L.getState().devices;await z.open({title:`${j(`Cards order`)}${n?.fullName?`: ${n.fullName}`:``}`,width:`42rem`,closeOnBackdrop:!1,closeOnEscape:!0,content:v`
      <cards-order-dialog-content
        id=${t}
        .cards=${r}
        .initialZoneId=${e.zoneId}
      ></cards-order-dialog-content>
    `,buttons:[{label:j(`Cancel`),variant:`ghost`,action:()=>z.cancel()},{label:j(`Save order`),variant:`primary`,action:async()=>{await document.getElementById(t)?.save()}}]}).catch(()=>null)}var ru=class extends b{constructor(...e){super(...e),this.checked=!1,this.onModeChanged=e=>{this.checked=e.detail}}createRenderRoot(){return this}connectedCallback(){super.connectedCallback(),document.addEventListener(`json-mode-changed`,this.onModeChanged)}disconnectedCallback(){super.disconnectedCallback(),document.removeEventListener(`json-mode-changed`,this.onModeChanged)}handleClick(){document.dispatchEvent(new CustomEvent(`json-toggle-clicked`))}render(){return v`
      <div class="form-switch-row">
        <label class="form-switch">
          <input
            type="checkbox"
            class="form-native-control"
            .checked=${this.checked}
            @change=${this.handleClick}
          />
          <span class="form-switch-track"></span>
        </label>
        <span
          class="form-check-label cursor-pointer"
          @click=${this.handleClick}
        >JSON</span>
      </div>
    `}};D([C(),E(`design:type`,Object)],ru.prototype,`checked`,void 0),ru=D([x(`json-mode-toggle`)],ru);var iu=class extends w{constructor(...e){super(...e),this.fields=[],this.model={},this.advancedMode=!1,this.currentFields=[],this.codeValue=``,this.parseError=``,this.onToggleClicked=()=>{this.handleToggle()}}connectedCallback(){super.connectedCallback(),this.currentFields=[...this.rebuildFields?.()||this.fields],document.addEventListener(`json-toggle-clicked`,this.onToggleClicked)}disconnectedCallback(){super.disconnectedCallback(),document.removeEventListener(`json-toggle-clicked`,this.onToggleClicked)}willUpdate(e){super.willUpdate(e),e.has(`fields`)&&!this.advancedMode&&(this.currentFields=[...this.rebuildFields?.()||this.fields])}switchToAdvanced(){this.codeValue=JSON.stringify(this.model,null,2),this.parseError=``,this.advancedMode=!0,document.dispatchEvent(new CustomEvent(`json-mode-changed`,{detail:!0}))}switchToForm(){try{let e=JSON.parse(this.codeValue);for(let e of Object.keys(this.model))delete this.model[e];Object.assign(this.model,e),this.rebuildFields&&(this.currentFields=this.rebuildFields()),this.parseError=``,this.advancedMode=!1,document.dispatchEvent(new CustomEvent(`json-mode-changed`,{detail:!1}))}catch{this.parseError=`Invalid JSON`}}handleToggle(){this.advancedMode?this.switchToForm():this.switchToAdvanced()}handleCodeChange(e){let t=e.detail.value;if(this.codeValue=typeof t==`string`?t:JSON.stringify(t,null,2),t&&typeof t==`object`&&!Array.isArray(t)){for(let e of Object.keys(this.model))delete this.model[e];Object.assign(this.model,t)}this.parseError&&=``}refreshForm(e,t){this.fields=e,this.advancedMode||(this.currentFields=[...e]),t&&this.model&&typeof this.model==`object`&&Object.assign(this.model,t),this.formElement&&(this.formElement.fields=e,t?this.formElement.setValues(t):this.formElement.requestUpdate()),this.requestUpdate()}render(){return v`
      ${this.advancedMode?v`
            <div>
              <input-json
                .value=${this.codeValue}
                .props=${{rows:15}}
                @field-change=${this.handleCodeChange}
              ></input-json>
              ${this.parseError?v`<p class="form-error">${j(this.parseError)}</p>`:``}
            </div>
          `:v`
            <app-form-fields
              .fields=${this.currentFields}
              .model=${this.model}
            ></app-form-fields>
          `}
    `}};D([S({attribute:!1}),E(`design:type`,Array)],iu.prototype,`fields`,void 0),D([S({attribute:!1}),E(`design:type`,Object)],iu.prototype,`model`,void 0),D([S({attribute:!1}),E(`design:type`,Function)],iu.prototype,`rebuildFields`,void 0),D([C(),E(`design:type`,Object)],iu.prototype,`advancedMode`,void 0),D([C(),E(`design:type`,Array)],iu.prototype,`currentFields`,void 0),D([C(),E(`design:type`,Object)],iu.prototype,`codeValue`,void 0),D([C(),E(`design:type`,Object)],iu.prototype,`parseError`,void 0),D([Qe(`app-form-fields`),E(`design:type`,Object)],iu.prototype,`formElement`,void 0),iu=D([x(`form-dialog-advanced`)],iu);async function G(e){return new Promise(async t=>{let n=`form-dialog-${Date.now()}-${Math.random().toString(36).slice(2,9)}`,r=`${n}-form`,i=`${n}-save-button`,a=typeof e.fields==`function`?await e.fields():e.fields,o=typeof e.model==`function`?await e.model():e.model,s=!0,c=!1,l=null,u=(e,t=3)=>{let n=document.getElementById(i);if(!n){t>0&&setTimeout(()=>u(e,t-1),0);return}n.disabled=e,e?n.setAttribute(`disabled`,`true`):n.removeAttribute(`disabled`)},d=e=>{s=e.detail.isValid,u(!s||c)},f=e=>{let t=document.getElementById(i);t&&(t.label=e)},p=async n=>{if(n.preventDefault(),!(!s||c)){c=!0,u(!0),f(j(`Saving...`));try{if(e.onBeforeSubmit&&!await e.onBeforeSubmit(o))return;e.onAfterSubmit&&await e.onAfterSubmit(o),z.close(o),t(o)}catch(e){console.error(`Failed to submit dialog form:`,e)}finally{c=!1,u(!s),f(j(e.submitLabel||`Save`))}}},m=()=>{z.close(null),t(null)},h=v`
      <div class="form-dialog-body">
        <form @submit=${p} id=${r}>
          ${e.advancedEditor?v`
                <form-dialog-advanced
                  .fields=${a}
                  .model=${o}
                  .rebuildFields=${e.advancedEditor}
                  @validation-change=${d}
                ></form-dialog-advanced>
              `:v`
                <app-form-fields
                  .fields=${a}
                  .model=${o}
                  @validation-change=${d}
                ></app-form-fields>
            `}
        </form>
      </div>
    `,g=v`
        <app-button
          type="button"
          variant="ghost"
          @click=${m}
          label=${j(e.cancelLabel||`Cancel`)}
        >
        </app-button>
        <app-button
          id=${i}
          type="submit"
          form=${r}
          variant="primary"
          background
          @click=${p}
          label=${j(e.submitLabel||`Save`)}
        >
        </app-button>
    `;z.openForm({title:j(e.title),template:h,footer:g,headerActions:e.advancedEditor?v`<json-mode-toggle></json-mode-toggle>`:void 0,closeOnBackdrop:e.closeOnBackdrop??!1,size:e.size||`md`,heightSize:e.heightSize||`auto`,width:e.width,height:e.height,maxWidth:e.maxWidth,maxHeight:e.maxHeight,closeOnEscape:e.closeOnEscape??!0,onCancel:()=>{z.close(null),t(null)}}),setTimeout(()=>{l=document.getElementById(r)?.querySelector(`app-form-fields, form-dialog-advanced`),e.onFormReady&&l&&e.onFormReady(l),u(!s)},0)})}var au=class extends w{constructor(...e){super(...e),this.tabs=[],this.activeTab=``,this.showLeftArrow=!1,this.showRightArrow=!1,this.isOverflowing=!1,this.cachedNav=null,this.resizeObserver=null,this.scrollHandler=()=>this.updateArrows()}get navEl(){return this.cachedNav||=this.querySelector(`.tab-list`),this.cachedNav}firstUpdated(){this.setupObservers(),this.updateArrows(),this.scrollToActive()}updated(e){(e.has(`tabs`)||e.has(`activeTab`))&&requestAnimationFrame(()=>{this.updateArrows(),this.scrollToActive()})}disconnectedCallback(){super.disconnectedCallback(),this.resizeObserver?.disconnect(),this.resizeObserver=null,this.cachedNav?.removeEventListener(`scroll`,this.scrollHandler),this.cachedNav=null}setupObservers(){let e=this.navEl;e&&(this.resizeObserver=new ResizeObserver(()=>this.updateArrows()),this.resizeObserver.observe(e),e.addEventListener(`scroll`,this.scrollHandler,{passive:!0}))}updateArrows(){let e=this.navEl;if(!e)return;let{scrollLeft:t,scrollWidth:n,clientWidth:r}=e,i=n>r+1,a=t>1,o=t+r<n-1;i!==this.isOverflowing&&(this.isOverflowing=i),a!==this.showLeftArrow&&(this.showLeftArrow=a),o!==this.showRightArrow&&(this.showRightArrow=o)}handleScrollLeft(){let e=this.navEl;e&&e.scrollBy({left:-e.clientWidth*.75,behavior:`smooth`})}handleScrollRight(){let e=this.navEl;e&&e.scrollBy({left:e.clientWidth*.75,behavior:`smooth`})}scrollToActive(){let e=this.navEl;if(!e||!this.activeTab)return;let t=e.querySelector(`[data-tab-id="${this.activeTab}"]`);if(!t)return;let n=e.getBoundingClientRect(),r=t.getBoundingClientRect(),i=r.left+r.width/2,a=n.left+n.width/2,o=e.scrollLeft+(i-a);e.scrollTo({left:Math.max(0,o),behavior:`smooth`})}handleTabClick(e){e!==this.activeTab&&this.dispatchEvent(new CustomEvent(`tab-change`,{detail:{tabId:e},bubbles:!0,composed:!0}))}render(){let e=this.isOverflowing;return v`
      <div class="tabs ${e?`is-overflowing`:``}">
        ${e?v`
          <button
            type="button"
            class="btn btn-plain tab-scroll-button ${this.showLeftArrow?``:`disabled`}"
            @click=${()=>this.handleScrollLeft()}
            ?disabled=${!this.showLeftArrow}
          >
            <app-icon .icon=${un} size="16"></app-icon>
          </button>
        `:``}
        <div class="tab-list">
          ${this.tabs.map(e=>{let t=this.activeTab===e.id;return v`
              <button
                type="button"
                data-tab-id=${e.id}
                class="tab-link ${t?`active`:``}"
                @click=${()=>this.handleTabClick(e.id)}
              >
                ${j(e.label)}
              </button>
            `})}
        </div>
        ${e?v`
          <button
            type="button"
            class="btn btn-plain tab-scroll-button ${this.showRightArrow?``:`disabled`}"
            @click=${()=>this.handleScrollRight()}
            ?disabled=${!this.showRightArrow}
          >
            <app-icon .icon=${dn} size="16"></app-icon>
          </button>
        `:``}
      </div>
    `}};D([S({type:Array}),E(`design:type`,Array)],au.prototype,`tabs`,void 0),D([S({type:String}),E(`design:type`,String)],au.prototype,`activeTab`,void 0),D([C(),E(`design:type`,Object)],au.prototype,`showLeftArrow`,void 0),D([C(),E(`design:type`,Object)],au.prototype,`showRightArrow`,void 0),D([C(),E(`design:type`,Object)],au.prototype,`isOverflowing`,void 0),au=D([x(`app-button-tabs`)],au);var K=po()((e,t)=>({definitions:[],loading:!1,getDefinitions(){return t().definitions},getTags(){let e=new Set;return t().definitions.forEach(t=>{(t.tags||[]).forEach(t=>{let n=String(t||``).trim();n&&e.add(n)})}),Array.from(e).sort((e,t)=>e.localeCompare(t))},fetchDefinitions:async(n=!1)=>{t().definitions.length>0&&!n||(e({loading:!0}),e({definitions:await N.get(`/definitions`),loading:!1}))},addDefinition:async n=>{let r=await N.post(`/definitions`,n);return e({definitions:[...t().definitions,r]}),r},removeDefinition:async n=>{await N.delete(`/definitions/${n}`),e({definitions:t().definitions.filter(e=>e._id!==n)})},updateDefinition:async(n,r)=>{let i=await N.put(`/definitions/${n}`,r);e({definitions:t().definitions.map(e=>e._id===n?i:e)})},reassignDevices:async(e,t)=>await N.post(`/definitions/${e}/reassign-devices`,{targetDefinition:t}),getDefinitionById:e=>t().definitions.find(t=>t._id===e)})),q=po()((e,t)=>({devices:[],loading:!1,getDevices:()=>t().devices,getTags:()=>{let e=new Set;return t().devices.forEach(t=>{(t.tags||[]).forEach(t=>{let n=String(t||``).trim();n&&e.add(n)})}),Array.from(e).sort((e,t)=>e.localeCompare(t))},fetchDevices:async(n=!1)=>{if(t().devices.length>0&&!n)return;e({loading:!0}),await I.getState().initializeIfNeeded(),await K.getState().fetchDefinitions();let r=await N.get(`/devices`),i=I.getState().zones,a=K.getState().getDefinitions();e({devices:r.map(e=>{let t=[];if(e.zone){let n=i.find(t=>t.id===e.zone);if(n){let e=[n.name],r=n;for(;r.parent;){let t=i.find(e=>e.id===r.parent);if(!t)break;e.unshift(t.name),r=t}t.push(e.join(`: `))}}if(e.definition){let n=a.find(t=>t._id===e.definition);n&&t.push(n.name)}return t.push(e.name),{...e,_fullName:t.join(`: `)}}),loading:!1})},getDeviceHistory:async(e,t)=>await N.get(`/devices/${e}/history`,t),addDevice:async n=>{let r=await N.post(`/devices`,n);return e({devices:[...t().devices,r]}),r},removeDevice:async n=>{await N.delete(`/devices/${n}`),e({devices:t().devices.filter(e=>e._id!==n)})},updateDevice:async(n,r)=>{let i=await N.put(`/devices/${n}`,r);e({devices:t().devices.map(e=>e._id===n?i:e)})},updateDeviceState:(n,r)=>{e({devices:t().devices.map(e=>e._id===n?{...e,...r}:e)})},getDeviceById:e=>t().devices.find(t=>t._id===e)})),J=po()((e,t)=>({scripts:[],loading:!1,getScripts(){return t().scripts},getTags(){let e=new Set;return t().scripts.forEach(t=>{(t.tags||[]).forEach(t=>{let n=String(t||``).trim();n&&e.add(n)})}),Array.from(e).sort((e,t)=>e.localeCompare(t))},fetchScripts:async(n=!1)=>{t().scripts.length>0&&!n||(e({loading:!0}),e({scripts:await N.get(`/scripts`),loading:!1}))},addScript:async n=>{let r=await N.post(`/scripts`,n);return e({scripts:[...t().scripts,r]}),r},removeScript:async n=>{await N.delete(`/scripts/${n}`),e({scripts:t().scripts.filter(e=>e._id!==n)})},updateScript:async(n,r)=>{let i=await N.put(`/scripts/${n}`,r);e({scripts:t().scripts.map(e=>e._id===n?i:e)})},executeScript:async(e,t,n)=>await N.post(`/scripts/${e}/execute`,{params:t},n),getScriptById:e=>t().scripts.find(t=>t._id===e)})),ou=class extends b{constructor(...e){super(...e),this.devices=[],this.zones=[],this.definitions=[],this.options=[],this.selectedValue=``,this.multiple=!1,this.query=``,this.selectedTags=new Set,this.selectedZoneId=``,this.selectedIds=new Set}createRenderRoot(){return this}connectedCallback(){super.connectedCallback();let e=Array.isArray(this.selectedValue)?this.selectedValue:this.selectedValue?[this.selectedValue]:[];this.selectedIds=new Set(e)}get tags(){return[...new Set(this.devices.flatMap(e=>e.tags||[]))].filter(Boolean).sort((e,t)=>e.localeCompare(t))}get rootZones(){return this.getChildren(null)}get selectedZone(){return this.zones.find(e=>e.id===this.selectedZoneId)}get visibleZones(){return this.selectedZoneId?this.getChildren(this.selectedZoneId):this.rootZones}get filteredDevices(){let e=this.query.trim().toLowerCase();return this.devices.filter(e=>!this.selectedZoneId||this.isZoneWithin(e.zone,this.selectedZoneId)).filter(e=>[...this.selectedTags].every(t=>(e.tags||[]).includes(t))).filter(t=>e?[this.getDeviceLabel(t),t.name,t._id,t.externalId,...t.tags||[]].some(t=>String(t||``).toLowerCase().includes(e)):!0).sort((e,t)=>this.getDeviceLabel(e).localeCompare(this.getDeviceLabel(t)))}getChildren(e){return this.zones.filter(t=>t.parent===e).sort((e,t)=>e.order-t.order||e.name.localeCompare(t.name))}getZonePath(e){let t=[],n=this.zones.find(t=>t.id===e);for(;n;)t.unshift(n),n=n.parent?this.zones.find(e=>e.id===n?.parent):void 0;return t}isZoneWithin(e,t){return this.getZonePath(e).some(e=>e.id===t)}getDefinitionName(e){return this.definitions.find(t=>t._id===e.definition)?.name||e.definition||``}getDeviceLabel(e){let t=this.getZonePath(e.zone),n=this.selectedZoneId?t.findIndex(e=>e.id===this.selectedZoneId):-1;return[...(n>=0?t.slice(n+1):t).map(e=>e.name),this.getDefinitionName(e),e.name].filter(Boolean).join(`: `)}toggleTag(e){let t=new Set(this.selectedTags);t.has(e)?t.delete(e):t.add(e),this.selectedTags=t}selectDevice(e){if(!this.multiple){z.close(e);return}let t=new Set(this.selectedIds);t.has(e)?t.delete(e):t.add(e),this.selectedIds=t}confirmSelection(){z.close([...this.selectedIds])}renderZoneNavigation(){let e=this.selectedZoneId?this.getZonePath(this.selectedZoneId):[];return v`
      <div class="input-picker-navigation">
        ${e.length?v`
          <div class="input-picker-breadcrumbs">
            <button
              type="button"
              class="input-picker-breadcrumb"
              @click=${()=>{this.selectedZoneId=``}}
            >
              <app-icon .icon=${un} size="15"></app-icon>
              ${j(`All zones`)}
            </button>
            ${e.map((t,n)=>v`
              <app-icon class="text-muted" .icon=${dn} size="14"></app-icon>
              <button
                type="button"
                class="input-picker-breadcrumb ${n===e.length-1?`active`:``}"
                @click=${()=>{this.selectedZoneId=t.id}}
              >
                ${t.name}
              </button>
            `)}
          </div>
        `:``}

        ${this.visibleZones.length?v`
          <div class="input-picker-zones">
            ${this.visibleZones.map(e=>v`
              <button
                type="button"
                class="input-picker-zone"
                @click=${()=>{this.selectedZoneId=e.id}}
              >
                ${e.name}
                <app-icon .icon=${dn} size="14"></app-icon>
              </button>
            `)}
          </div>
        `:``}
      </div>
    `}render(){let e=this.filteredDevices;return v`
      <div class="input-picker">
        <div class="input-picker-search">
          <app-icon
            class="input-picker-search-icon"
            .icon=${ea}
            size="18"
          ></app-icon>
          <input
            class="form-control input-picker-search-input"
            type="search"
            placeholder=${j(`Search devices`)}
            .value=${this.query}
            @input=${e=>{this.query=e.target.value}}
          />
        </div>

        ${this.tags.length?v`
          <div class="input-picker-filters">
            ${this.tags.map(e=>v`
                <button
                  type="button"
                  class="input-picker-filter ${this.selectedTags.has(e)?`active`:``}"
                  @click=${()=>this.toggleTag(e)}
                >
                  ${e}
                </button>
              `)}
          </div>
        `:``}

        ${this.renderZoneNavigation()}

        <div class="input-picker-meta">
          ${e.length} of ${this.devices.length} devices
        </div>

        <div class="input-picker-list">
          ${this.options.map(e=>v`
            <button
              type="button"
              class="input-picker-item"
              @click=${()=>this.selectDevice(e.value)}
            >
              ${e.label}
            </button>
          `)}

          ${e.length?e.map(e=>{let t=e._id||``,n=this.selectedIds.has(t);return v`
              <button
                type="button"
                class="input-picker-item ${n?`active`:``}"
                @click=${()=>this.selectDevice(t)}
              >
                <div class="input-picker-item-header align-items-center">
                  <span class="input-picker-item-title text-truncate">${this.getDeviceLabel(e)}</span>
                  ${n?v`<span class="input-picker-selected">Selected</span>`:``}
                </div>
              </button>
            `}):v`
            <div class="input-picker-empty">
              No devices match the selected filters.
            </div>
          `}
        </div>

        ${this.multiple?v`
          <div class="input-picker-footer">
            <app-button
              background
              .label=${`${j(`Select devices`)} (${this.selectedIds.size})`}
              @click=${this.confirmSelection}
            ></app-button>
          </div>
        `:``}
      </div>
    `}};D([S({attribute:!1})],ou.prototype,`devices`,void 0),D([S({attribute:!1})],ou.prototype,`zones`,void 0),D([S({attribute:!1})],ou.prototype,`definitions`,void 0),D([S({attribute:!1})],ou.prototype,`options`,void 0),D([S({attribute:!1})],ou.prototype,`selectedValue`,void 0),D([S({type:Boolean})],ou.prototype,`multiple`,void 0),D([C()],ou.prototype,`query`,void 0),D([C()],ou.prototype,`selectedTags`,void 0),D([S({type:String})],ou.prototype,`selectedZoneId`,void 0),D([C()],ou.prototype,`selectedIds`,void 0),ou=D([x(`devices-picker-dialog`)],ou);var su=class extends R{constructor(...e){super(...e),this.draggedTagIndex=null,this.dragOverTagIndex=null}get devices(){let e=this.props.devices,t=typeof e==`function`?e(this.getValue(),this.model):e||[];return e===void 0?q.getState().getDevices():t}get options(){return this.props.options||[]}get multiple(){return this.props.multiple===!0}get defaultZoneId(){let e=this.props.defaultZoneId,t=typeof e==`function`?e(this.getValue(),this.model):e,n=typeof t==`string`?t:``;return I.getState().zones.some(e=>e.id===n)?n:``}get selectedValues(){return this.multiple?Array.isArray(this.getValue())?this.getValue():[]:[this.getValue()].filter(Boolean)}get selectedLabels(){return this.selectedValues.map(e=>{let t=this.options.find(t=>t.value===e);return t?t.label:this.devices.find(t=>t._id===e)?._fullName||e})}async openPicker(){if(!(this.props.disabled||this.props.readonly)){await Promise.all([q.getState().fetchDevices(),I.getState().initializeIfNeeded(),K.getState().fetchDefinitions()]);try{let e=await z.open({title:j(this.props.dialogTitle||(this.multiple?`Select devices`:`Select device`)),width:`min(92vw, 62rem)`,height:`min(86vh, 50rem)`,maxWidth:`92vw`,maxHeight:`92vh`,closeOnBackdrop:!0,closeOnEscape:!0,content:v`
          <devices-picker-dialog
            class="input-picker-dialog"
            .devices=${this.devices}
            .zones=${I.getState().zones}
            .definitions=${K.getState().getDefinitions()}
            .options=${this.options}
            .selectedValue=${this.getValue()||(this.multiple?[]:``)}
            .selectedZoneId=${this.defaultZoneId}
            .multiple=${this.multiple}
          ></devices-picker-dialog>
        `});e!==void 0&&this.updateModel(e)}catch{}}}clearValue(e){e.stopPropagation(),!(this.props.disabled||this.props.readonly)&&this.updateModel(this.multiple?[]:``)}removeSelected(e,t){t.stopPropagation(),!(this.props.disabled||this.props.readonly)&&this.updateModel(this.selectedValues.filter(t=>t!==e))}handleTagDragStart(e,t){t.stopPropagation(),this.draggedTagIndex=e,t.dataTransfer?.setData(`text/plain`,String(e)),t.dataTransfer&&(t.dataTransfer.effectAllowed=`move`)}handleTagDragOver(e,t){t.preventDefault(),t.stopPropagation(),this.dragOverTagIndex=e,t.dataTransfer&&(t.dataTransfer.dropEffect=`move`)}handleTagDrop(e,t){t.preventDefault(),t.stopPropagation();let n=Number(t.dataTransfer?.getData(`text/plain`)??this.draggedTagIndex),r=[...this.selectedValues];if(!Number.isInteger(n)||n<0||n>=r.length)return;let[i]=r.splice(n,1);r.splice(e,0,i),this.updateModel(r),this.handleTagDragEnd()}handleTagDragEnd(){this.draggedTagIndex=null,this.dragOverTagIndex=null}renderField(){let e=this.selectedLabels,t=this.selectedValues;return this.multiple?v`
        <div
          class="input-picker-multiple"
          @click=${this.openPicker}
        >
          <div class="d-flex w-100 align-items-center justify-content-between gap-2">
            <div class="input-picker-value">
              ${e.length?v`
                <div class="input-picker-selected-tags">
                  ${e.map((e,n)=>v`
                    <div
                      draggable="true"
                      class="input-picker-selected-tag ${this.dragOverTagIndex===n?`drop-target`:``} ${this.draggedTagIndex===n?`dragging`:``}"
                      @click=${e=>e.stopPropagation()}
                      @dragstart=${e=>this.handleTagDragStart(n,e)}
                      @dragover=${e=>this.handleTagDragOver(n,e)}
                      @drop=${e=>this.handleTagDrop(n,e)}
                      @dragend=${this.handleTagDragEnd}
                    >
                      <span class="input-picker-drag-handle">
                        ${Array.from({length:6}).map(()=>v`<span class="input-picker-drag-dot"></span>`)}
                      </span>
                      <span>${e}</span>
                      <button
                        type="button"
                        class="input-picker-tag-remove"
                        @click=${e=>this.removeSelected(t[n],e)}
                      >
                        <svg
                          fill="none"
                          stroke="currentColor"
                          viewBox="0 0 24 24"
                        >
                          <path
                            stroke-linecap="round"
                            stroke-linejoin="round"
                            stroke-width="2"
                            d="M6 18L18 6M6 6l12 12"
                          ></path>
                        </svg>
                      </button>
                    </div>
                  `)}
                </div>
              `:v`
                <span class="input-picker-placeholder">${j(this.props.placeholder||`Select devices`)}</span>
              `}
            </div>
            <app-icon class="flex-shrink-0 text-muted" .icon=${cn} size="16"></app-icon>
          </div>
        </div>
      `:v`
      <button
        type="button"
        class="input-picker-control"
        ?disabled=${this.props.disabled}
        @click=${this.openPicker}
      >
        <span class="input-picker-value ${e.length?``:`input-picker-placeholder`}">
          <span class="d-block text-truncate">${e[0]||j(this.props.placeholder||`Select device`)}</span>
        </span>
        <span class="input-picker-actions">
          ${e.length&&!this.multiple&&!this.props.required?v`
            <span
              class="input-picker-clear"
              role="button"
              tabindex="0"
              title="Clear"
              @click=${this.clearValue}
            >
              <app-icon .icon=${Gn} size="16"></app-icon>
            </span>
          `:``}
          <app-icon .icon=${cn} size="16"></app-icon>
        </span>
      </button>
    `}};D([C()],su.prototype,`draggedTagIndex`,void 0),D([C()],su.prototype,`dragOverTagIndex`,void 0),su=D([x(`input-devices`)],su);function cu(e,t,n,r){let i=(t,r)=>{let i=r?.device||t,a=new Set((n()||[]).map(e=>e?.device).filter(Boolean));return e.filter(e=>e.value===i||!a.has(e.value))};return[{fieldGroupClassName:`grid grid-cols-1 md:grid-cols-[1fr_1fr_auto] gap-4 items-end`,fieldGroup:[{key:`name`,type:`input-text`,props:{label:`Name`,required:!0}},{key:`zone`,type:`input-select`,props:{label:`Zone`,required:!0,options:t}},{key:`onlineVisible`,type:`input-toggle`,className:`pb-2`,props:{toggleLabel:`Online`}}]},{key:`watchedDevices`,type:`input-array`,props:{label:`Devices`},fieldArray:[{fieldGroupClassName:`d-grid grid-columns-1 grid-columns-md-2 gap-4`,fieldGroup:[{key:`device`,type:`input-devices`,props:{label:`Device`,devices:(e,t)=>{let n=new Set(i(e,t).map(e=>e.value));return q.getState().getDevices().filter(e=>n.has(e._id))},required:!0,defaultZoneId:r}},{key:`name`,type:`input-text`,props:{label:`Name`,placeholder:`device`,required:!0}}]}]},{key:`tags`,type:`input-array-text`,props:{label:`Tags`,type:`string`,options:()=>L.getState().getTags()}}]}function lu(e,t){return t||=e.slice(0),Object.freeze(Object.defineProperties(e,{raw:{value:Object.freeze(t)}}))}var uu,du=e=>{let t=e?.params||[];return t.length?t.map(e=>e.label||e.key).filter(Boolean).join(`, `):``},fu=class extends b{constructor(...e){super(...e),this.scripts=[],this.selectedScriptId=``,this.selectedValue=``,this.options=[],this.multiple=!1,this.query=``,this.selectedTags=new Set,this.selectedIds=new Set,this.showSpecialized=!1}createRenderRoot(){return this}connectedCallback(){super.connectedCallback();let e=this.selectedValue||this.selectedScriptId;this.selectedIds=new Set(Array.isArray(e)?e:e?[e]:[])}get visibleScripts(){return this.showSpecialized?this.scripts:this.scripts.filter(e=>e.specialized!==!0)}get tags(){return[...new Set(this.visibleScripts.flatMap(e=>e.tags||[]))].filter(Boolean).sort((e,t)=>e.localeCompare(t))}get filteredScripts(){let e=this.query.trim().toLowerCase();return this.visibleScripts.filter(e=>{let t=e.tags||[];return[...this.selectedTags].every(e=>t.includes(e))}).filter(t=>e?[t.name,t.description,t._id,t.id,...t.tags||[]].some(t=>String(t||``).toLowerCase().includes(e)):!0).sort((e,t)=>e.name.localeCompare(t.name))}toggleTag(e){let t=new Set(this.selectedTags);t.has(e)?t.delete(e):t.add(e),this.selectedTags=t}setShowSpecialized(e){this.showSpecialized=e;let t=new Set(this.tags);this.selectedTags=new Set([...this.selectedTags].filter(e=>t.has(e)))}selectScript(e){if(!this.multiple){z.close(e);return}let t=new Set(this.selectedIds);t.has(e)?t.delete(e):t.add(e),this.selectedIds=t}confirmSelection(){z.close([...this.selectedIds])}render(){let e=this.filteredScripts;return v`
      <div class="input-picker">
        <div class="input-picker-search-row">
          <div class="input-picker-search">
            <app-icon
              class="input-picker-search-icon"
              .icon=${ea}
              size="18"
            ></app-icon>
            <input
              class="form-control input-picker-search-input"
              type="search"
              placeholder="Search scripts"
              .value=${this.query}
              @input=${e=>{this.query=e.target.value}}
            />
          </div>
          <label class="form-check flex-shrink-0">
            <input
              type="checkbox"
              class="form-native-control"
              .checked=${this.showSpecialized}
              @change=${e=>this.setShowSpecialized(e.target.checked)}
            />
            <span class="form-check-mark ${this.showSpecialized?`is-checked`:``}">
              ${this.showSpecialized?v`
                <svg class="form-check-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M5 13l4 4L19 7"></path>
                </svg>
              `:``}
            </span>
            <span class="form-check-label">Show specialized</span>
          </label>
        </div>

        ${this.tags.length?v`
          <div class="input-picker-filters">
            ${this.tags.map(e=>v`
                <button
                  type="button"
                  class="input-picker-filter ${this.selectedTags.has(e)?`active`:``}"
                  @click=${()=>this.toggleTag(e)}
                >
                  ${e}
                </button>
              `)}
          </div>
        `:``}

        <div class="input-picker-meta">
          ${e.length} of ${this.scripts.length} scripts
        </div>

        <div class="input-picker-list">
          ${this.options.map(e=>v`
              <button
                type="button"
                class="input-picker-item ${this.selectedIds.has(e.value)?`active`:``}"
                @click=${()=>this.selectScript(e.value)}
              >
                ${e.label}
              </button>
            `)}

          ${e.length?e.map(e=>{let t=e._id||e.id||``,n=this.selectedIds.has(t);return v`
              <button
                type="button"
                class="input-picker-item ${n?`active`:``}"
                @click=${()=>this.selectScript(t)}
              >
                <div class="input-picker-item-header">
                  <div class="min-w-0">
                    <div class="input-picker-item-title text-truncate">${e.name}</div>
                    ${du(e)?v`<div class="input-picker-item-description">Params: ${du(e)}</div>`:``}
                    ${e.description?v`<div class="input-picker-item-description">${e.description}</div>`:``}
                  </div>
                  ${n?v`<span class="input-picker-selected">Selected</span>`:``}
                </div>
                ${e.tags?.length?v`
                  <div class="input-picker-tags mt-2">
                    ${e.tags.map(e=>v`
                      <span class="input-picker-tag">${e}</span>
                    `)}
                  </div>
                `:``}
              </button>
            `}):v`
            <div class="input-picker-empty">
              No scripts match the selected filters.
            </div>
          `}
        </div>

        ${this.multiple?v`
          <div class="input-picker-footer">
            <app-button
              background
              label="Select scripts (${this.selectedIds.size})"
              @click=${this.confirmSelection}
            ></app-button>
          </div>
        `:``}
      </div>
    `}};D([S({attribute:!1})],fu.prototype,`scripts`,void 0),D([S({type:String})],fu.prototype,`selectedScriptId`,void 0),D([S({attribute:!1})],fu.prototype,`selectedValue`,void 0),D([S({attribute:!1})],fu.prototype,`options`,void 0),D([S({type:Boolean})],fu.prototype,`multiple`,void 0),D([C()],fu.prototype,`query`,void 0),D([C()],fu.prototype,`selectedTags`,void 0),D([C()],fu.prototype,`selectedIds`,void 0),D([C()],fu.prototype,`showSpecialized`,void 0),fu=D([x(`script-picker-dialog`)],fu);var pu=class extends R{get scripts(){let e=this.props.scripts||[];return e.length?e:J.getState().getScripts()}get selectedScript(){let e=this.getValue();if(!(e==null||e===``))return this.scripts.find(t=>t._id===e||t.id===e)}get options(){let e=this.props.options||[];return this.multiple||this.props.required||e.some(e=>e.value===``)?e:[{value:``,label:`No script`},...e]}get multiple(){return this.props.multiple===!0}get selectedLabels(){return(this.multiple?Array.isArray(this.getValue())?this.getValue():[]:[this.getValue()].filter(Boolean)).map(e=>{let t=this.options.find(t=>t.value===e);return t?t.label:this.scripts.find(t=>t._id===e||t.id===e)?.name||e})}async openPicker(){if(!(this.props.disabled||this.props.readonly))try{let e=await z.open({title:this.props.dialogTitle||`Select script`,width:`min(92vw, 58rem)`,height:`min(84vh, 46rem)`,maxWidth:`92vw`,maxHeight:`90vh`,closeOnBackdrop:!0,closeOnEscape:!0,content:v(uu||=lu([`
          <script-picker-dialog
            class="input-picker-dialog"
            .scripts=`,`
            .options=`,`
            .selectedValue=`,`
            .selectedScriptId=`,`
            .multiple=`,`
          ><\/script-picker-dialog>
        `]),this.scripts,this.options,this.getValue()||(this.multiple?[]:``),String(this.getValue()||``),this.multiple)});e!=null&&this.updateModel(e)}catch{}}clearValue(e){e.stopPropagation(),!(this.props.disabled||this.props.readonly)&&this.updateModel(this.multiple?[]:``)}renderField(){let e=this.getValue(),t=this.selectedScript,n=this.selectedLabels,r=this.multiple?Array.isArray(e)&&e.length>0:e!=null&&e!==``,i=r?this.options.find(t=>t.value===e):void 0,a=this.multiple&&n.length?n.join(`, `):t?.name||i?.label||this.props.placeholder||(this.multiple,``);return v`
      <button
        type="button"
        class="input-picker-control"
        ?disabled=${this.props.disabled}
        @click=${this.openPicker}
      >
        <span class="input-picker-value text-truncate ${r?``:`input-picker-placeholder`}">
          ${a}
        </span>
        <span class="input-picker-actions">
          ${n.length&&!this.props.required?v`
            <span
              class="input-picker-clear"
              role="button"
              tabindex="0"
              title="Clear"
              @click=${this.clearValue}
            >
              <app-icon .icon=${Gn} size="16"></app-icon>
            </span>
          `:``}
          <app-icon .icon=${cn} size="16"></app-icon>
        </span>
      </button>
    `}};pu=D([x(`input-script`)],pu);var mu=class extends b{constructor(...e){super(...e),this.cards=[],this.zones=[],this.options=[],this.selectedValue=``,this.multiple=!1,this.query=``,this.selectedTags=new Set,this.selectedZoneId=``,this.selectedIds=new Set}createRenderRoot(){return this}connectedCallback(){super.connectedCallback();let e=Array.isArray(this.selectedValue)?this.selectedValue:this.selectedValue?[this.selectedValue]:[];this.selectedIds=new Set(e)}get tags(){return[...new Set(this.cards.flatMap(e=>e.tags||[]))].filter(Boolean).sort((e,t)=>e.localeCompare(t))}get visibleZones(){return this.getChildren(this.selectedZoneId||null)}get filteredCards(){let e=this.query.trim().toLowerCase();return this.cards.filter(e=>!this.selectedZoneId||this.isZoneWithin(e.zone,this.selectedZoneId)).filter(e=>[...this.selectedTags].every(t=>(e.tags||[]).includes(t))).filter(t=>e?[this.getCardLabel(t),t.name,t._id,...t.tags||[]].some(t=>String(t||``).toLowerCase().includes(e)):!0).sort((e,t)=>this.getCardLabel(e).localeCompare(this.getCardLabel(t)))}getChildren(e){return this.zones.filter(t=>t.parent===e).sort((e,t)=>e.order-t.order||e.name.localeCompare(t.name))}getZonePath(e){let t=[],n=this.zones.find(t=>t.id===e);for(;n;)t.unshift(n),n=n.parent?this.zones.find(e=>e.id===n?.parent):void 0;return t}isZoneWithin(e,t){return this.getZonePath(e).some(e=>e.id===t)}getCardLabel(e){let t=this.getZonePath(e.zone),n=this.selectedZoneId?t.findIndex(e=>e.id===this.selectedZoneId):-1;return[...(n>=0?t.slice(n+1):t).map(e=>e.name),e.name].filter(Boolean).join(`: `)}toggleTag(e){let t=new Set(this.selectedTags);t.has(e)?t.delete(e):t.add(e),this.selectedTags=t}selectCard(e){if(!this.multiple){z.close(e);return}let t=new Set(this.selectedIds);t.has(e)?t.delete(e):t.add(e),this.selectedIds=t}confirmSelection(){z.close([...this.selectedIds])}renderZoneNavigation(){let e=this.selectedZoneId?this.getZonePath(this.selectedZoneId):[];return v`
      <div class="input-picker-navigation">
        ${e.length?v`
          <div class="input-picker-breadcrumbs">
            <button
              type="button"
              class="input-picker-breadcrumb"
              @click=${()=>{this.selectedZoneId=``}}
            >
              <app-icon .icon=${un} size="15"></app-icon>
              ${j(`All zones`)}
            </button>
            ${e.map((t,n)=>v`
              <app-icon class="text-muted" .icon=${dn} size="14"></app-icon>
              <button
                type="button"
                class="input-picker-breadcrumb ${n===e.length-1?`active`:``}"
                @click=${()=>{this.selectedZoneId=t.id}}
              >
                ${t.name}
              </button>
            `)}
          </div>
        `:``}

        ${this.visibleZones.length?v`
          <div class="input-picker-zones">
            ${this.visibleZones.map(e=>v`
              <button
                type="button"
                class="input-picker-zone"
                @click=${()=>{this.selectedZoneId=e.id}}
              >
                ${e.name}
                <app-icon .icon=${dn} size="14"></app-icon>
              </button>
            `)}
          </div>
        `:``}
      </div>
    `}render(){let e=this.filteredCards;return v`
      <div class="input-picker">
        <div class="input-picker-search">
          <app-icon
            class="input-picker-search-icon"
            .icon=${ea}
            size="18"
          ></app-icon>
          <input
            class="form-control input-picker-search-input"
            type="search"
            placeholder=${j(`Search cards`)}
            .value=${this.query}
            @input=${e=>{this.query=e.target.value}}
          />
        </div>

        ${this.tags.length?v`
          <div class="input-picker-filters">
            ${this.tags.map(e=>v`
                <button
                  type="button"
                  class="input-picker-filter ${this.selectedTags.has(e)?`active`:``}"
                  @click=${()=>this.toggleTag(e)}
                >
                  ${e}
                </button>
              `)}
          </div>
        `:``}

        ${this.renderZoneNavigation()}

        <div class="input-picker-meta">
          ${j(`{{visible}} of {{total}} cards`,{visible:e.length,total:this.cards.length})}
        </div>

        <div class="input-picker-list">
          ${this.options.map(e=>v`
              <button
                type="button"
                class="input-picker-item ${this.selectedIds.has(e.value)?`active`:``}"
                @click=${()=>this.selectCard(e.value)}
              >
                ${e.label}
              </button>
            `)}

          ${e.length?e.map(e=>{let t=this.selectedIds.has(e._id);return v`
              <button
                type="button"
                class="input-picker-item ${t?`active`:``}"
                @click=${()=>this.selectCard(e._id)}
              >
                <div class="input-picker-item-header align-items-center">
                  <span class="input-picker-item-title text-truncate">${this.getCardLabel(e)}</span>
                  ${t?v`<span class="input-picker-selected">${j(`Selected`)}</span>`:``}
                </div>
              </button>
            `}):v`
            <div class="input-picker-empty">
              ${j(`No cards match the selected filters.`)}
            </div>
          `}
        </div>

        ${this.multiple?v`
          <div class="input-picker-footer">
            <app-button
              background
              .label=${`${j(`Select cards`)} (${this.selectedIds.size})`}
              @click=${this.confirmSelection}
            ></app-button>
          </div>
        `:``}
      </div>
    `}};D([S({attribute:!1})],mu.prototype,`cards`,void 0),D([S({attribute:!1})],mu.prototype,`zones`,void 0),D([S({attribute:!1})],mu.prototype,`options`,void 0),D([S({attribute:!1})],mu.prototype,`selectedValue`,void 0),D([S({type:Boolean})],mu.prototype,`multiple`,void 0),D([C()],mu.prototype,`query`,void 0),D([C()],mu.prototype,`selectedTags`,void 0),D([S({type:String})],mu.prototype,`selectedZoneId`,void 0),D([C()],mu.prototype,`selectedIds`,void 0),mu=D([x(`cards-picker-dialog`)],mu);var hu=class extends R{constructor(...e){super(...e),this.draggedTagIndex=null,this.dragOverTagIndex=null}get cards(){let e=this.props.cards||[];return e.length?e:L.getState().devices}get options(){return this.props.options||[]}get multiple(){return this.props.multiple===!0}get defaultZoneId(){let e=this.props.defaultZoneId,t=typeof e==`function`?e(this.getValue(),this.model):e,n=typeof t==`string`?t:``;return I.getState().zones.some(e=>e.id===n)?n:``}get selectedValues(){return this.multiple?Array.isArray(this.getValue())?this.getValue():[]:[this.getValue()].filter(Boolean)}get selectedLabels(){return this.selectedValues.map(e=>{let t=this.options.find(t=>t.value===e);return t?t.label:this.cards.find(t=>t._id===e)?._fullName||e})}async openPicker(){if(!(this.props.disabled||this.props.readonly)){await Promise.all([L.getState().fetchDevices(),I.getState().initializeIfNeeded()]);try{let e=await z.open({title:j(this.props.dialogTitle||(this.multiple?`Select cards`:`Select card`)),width:`min(92vw, 62rem)`,height:`min(86vh, 50rem)`,maxWidth:`92vw`,maxHeight:`92vh`,closeOnBackdrop:!0,closeOnEscape:!0,content:v`
          <cards-picker-dialog
            class="input-picker-dialog"
            .cards=${this.cards}
            .zones=${I.getState().zones}
            .options=${this.options}
            .selectedValue=${this.getValue()||(this.multiple?[]:``)}
            .selectedZoneId=${this.defaultZoneId}
            .multiple=${this.multiple}
          ></cards-picker-dialog>
        `});e!==void 0&&this.updateModel(e)}catch{}}}clearValue(e){e.stopPropagation(),!(this.props.disabled||this.props.readonly)&&this.updateModel(this.multiple?[]:``)}removeSelected(e,t){t.stopPropagation(),!(this.props.disabled||this.props.readonly)&&this.updateModel(this.selectedValues.filter(t=>t!==e))}handleTagDragStart(e,t){t.stopPropagation(),this.draggedTagIndex=e,t.dataTransfer?.setData(`text/plain`,String(e)),t.dataTransfer&&(t.dataTransfer.effectAllowed=`move`)}handleTagDragOver(e,t){t.preventDefault(),t.stopPropagation(),this.dragOverTagIndex=e,t.dataTransfer&&(t.dataTransfer.dropEffect=`move`)}handleTagDrop(e,t){t.preventDefault(),t.stopPropagation();let n=Number(t.dataTransfer?.getData(`text/plain`)??this.draggedTagIndex),r=[...this.selectedValues];if(!Number.isInteger(n)||n<0||n>=r.length)return;let[i]=r.splice(n,1);r.splice(e,0,i),this.updateModel(r),this.handleTagDragEnd()}handleTagDragEnd(){this.draggedTagIndex=null,this.dragOverTagIndex=null}renderField(){let e=this.selectedLabels,t=this.selectedValues;return this.multiple?v`
        <div
          class="input-picker-multiple"
          @click=${this.openPicker}
        >
          <div class="d-flex w-100 align-items-center justify-content-between gap-2">
            <div class="input-picker-value">
              ${e.length?v`
                <div class="input-picker-selected-tags">
                  ${e.map((e,n)=>v`
                    <div
                      draggable="true"
                      class="input-picker-selected-tag ${this.dragOverTagIndex===n?`drop-target`:``} ${this.draggedTagIndex===n?`dragging`:``}"
                      @click=${e=>e.stopPropagation()}
                      @dragstart=${e=>this.handleTagDragStart(n,e)}
                      @dragover=${e=>this.handleTagDragOver(n,e)}
                      @drop=${e=>this.handleTagDrop(n,e)}
                      @dragend=${this.handleTagDragEnd}
                    >
                      <span class="input-picker-drag-handle">
                        ${Array.from({length:6}).map(()=>v`<span class="input-picker-drag-dot"></span>`)}
                      </span>
                      <span>${e}</span>
                      <button
                        type="button"
                        class="input-picker-tag-remove"
                        @click=${e=>this.removeSelected(t[n],e)}
                      >
                        <svg
                          fill="none"
                          stroke="currentColor"
                          viewBox="0 0 24 24"
                        >
                          <path
                            stroke-linecap="round"
                            stroke-linejoin="round"
                            stroke-width="2"
                            d="M6 18L18 6M6 6l12 12"
                          ></path>
                        </svg>
                      </button>
                    </div>
                  `)}
                </div>
              `:v`
                <span class="input-picker-placeholder">${j(this.props.placeholder||`Select cards`)}</span>
              `}
            </div>
            <app-icon class="flex-shrink-0 text-muted" .icon=${cn} size="16"></app-icon>
          </div>
        </div>
      `:v`
      <button
        type="button"
        class="input-picker-control"
        ?disabled=${this.props.disabled}
        @click=${this.openPicker}
      >
        <span class="input-picker-value ${e.length?``:`input-picker-placeholder`}">
          <span class="d-block text-truncate">${e[0]||j(this.props.placeholder||`Select card`)}</span>
        </span>
        <span class="input-picker-actions">
          ${e.length&&!this.multiple&&!this.props.required?v`
            <span
              class="input-picker-clear"
              role="button"
              tabindex="0"
              title=${j(`Clear`)}
              @click=${this.clearValue}
            >
              <app-icon .icon=${Gn} size="16"></app-icon>
            </span>
          `:``}
          <app-icon .icon=${cn} size="16"></app-icon>
        </span>
      </button>
    `}};D([C()],hu.prototype,`draggedTagIndex`,void 0),D([C()],hu.prototype,`dragOverTagIndex`,void 0),hu=D([x(`input-cards`)],hu);var gu=class extends R{get scripts(){let e=this.props.scripts||[];return e.length>0?e:J.getState().getScripts()}get definitions(){return this.props.fields||[]}getDefaultValue(e){return e.default===void 0?e.type===`object`?{}:e.type===`array`||e.type===`ids`?[]:e.type===`boolean`?!1:e.type===`number`?0:``:structuredClone(e.default)}getCardFields(e=[]){return e.flatMap(e=>[e,...this.getCardFields(e.fields||[])]).filter(e=>!!e.key)}createField(e){let t=e.relation?this.definitions.find(t=>t.key===e.relation&&t.subtype===`script`):void 0;if(e.type===`object`&&t)return{key:e.key,type:`card-script-params`,defaultValue:this.getDefaultValue(e),className:`ml-3 border-left pl-4`,hide:e=>!e[t.key],renderKey:e=>e[t.key],props:{scripts:this.scripts,scriptKey:t.key,includeValue:this.props.includeValue!==!1,label:e.label||e.key}};if(e.subtype===`script`)return{key:e.key,type:`input-script`,defaultValue:this.getDefaultValue(e),props:{label:e.label||e.key,required:e.required===!0,scripts:this.scripts,multiple:e.type===`ids`},hooks:{onModelChange:(t,n)=>{this.definitions.filter(t=>t.relation===e.key).forEach(e=>{n[e.key]=this.getDefaultValue(e)})}}};if(e.subtype===`card`||e.subtype===`cards`)return{key:e.key,type:`input-cards`,defaultValue:this.getDefaultValue(e),props:{label:e.label||e.key,required:e.required===!0,multiple:e.type===`ids`,cards:L.getState().devices,placeholder:e.type===`ids`?`Select cards`:`Select card`},hooks:{onModelChange:(t,n)=>{this.definitions.filter(t=>t.subtype===`card-field`&&t.relation===e.key).forEach(e=>{n[e.key]=this.getDefaultValue(e)})}}};if(e.subtype===`card-field`){let t=e.relation;return{key:e.key,type:`input-select`,defaultValue:this.getDefaultValue(e),props:{label:e.label||e.key,required:e.required===!0,placeholder:`Select card field`,options:(e,n)=>{let r=L.getState().devices.find(e=>e._id===n?.[t||``]);return this.getCardFields(r?.fields||[]).map(e=>({value:e.key,label:e.name?`${e.name} (${e.key})`:e.key}))}}}}let n=e.type===`number`&&e.subtype===`milliseconds`?`input-unit`:e.type===`number`?`input-number`:e.type===`boolean`?`input-toggle`:e.type===`enum`?`input-select`:`input-text`;return{key:e.key,type:n,defaultValue:this.getDefaultValue(e),props:{label:e.label||e.key,required:e.required===!0,options:e.options||[],min:e.type===`number`?0:void 0,type:e.subtype===`milliseconds`?`time`:void 0,defaultUnit:e.subtype===`milliseconds`?`s`:void 0}}}handleChange(e){e.stopPropagation(),this.value=e.detail.value,this.updateModel(e.detail.value)}renderField(){return v`
      <input-array
        .key=${this.key}
        .value=${this.getValue()||[]}
        .model=${this.model}
        .props=${{itemFields:this.definitions.map(e=>this.createField(e)),addLabel:this.props.addLabel}}
        @field-change=${this.handleChange}
      ></input-array>
    `}};gu=D([x(`repeat-field`)],gu);var _u=class extends Us{constructor(...e){super(...e),this.optionalIncludes={},this.activeFormKey=``}get formField(){return typeof this.props.getField==`function`?this.props.getField(this.model):this.props.field}syncForm(){let e=this.formField,t=String(e?.key||``);if(t===this.activeFormKey)return;this.activeFormKey=t;let n=this.getValue()||{};this.optionalIncludes=Object.fromEntries((e?.fields||[]).filter(e=>e.optional).map(e=>[e.key,Object.prototype.hasOwnProperty.call(n,e.key)]))}willUpdate(){this.syncForm()}getFieldConfig(e,t=!0){let n={label:t?e.name||e.key:``,placeholder:e.placeholder,required:e.required===!0};switch(e.type){case`boolean`:return{key:e.key,type:`input-toggle`,props:{required:e.required===!0,toggleLabel:t?e.name||e.key:``}};case`enum`:let r=e.options?.length?e.options:e.values;return{key:e.key,type:`input-select`,props:{...n,multiple:e.extra?.multiple===!0,placeholder:e.extra?.multiple===!0?e.placeholder||`Select values`:e.placeholder,options:(r||[]).map(e=>({value:typeof e==`string`?e:e.value??e.key??e.name,label:typeof e==`string`?e:e.name??e.label??String(e.value??e.key??``)}))}};case`number`:{let t=typeof e.extra?.min==`number`&&typeof e.extra?.max==`number`;return{key:e.key,type:t?`input-range`:`input-number`,props:{...n,min:e.extra?.min,max:e.extra?.max,step:e.extra?.step,suffix:e.extra?.suffix}}}case`color`:return{key:e.key,type:`input-color`,props:n};case`date`:return{key:e.key,type:`input-date`,props:n};case`array-string`:return{key:e.key,type:`input-array-text`,props:n};case`object`:return{key:e.key,type:`input-json`,props:{...n,rows:4}};default:return{key:e.key,type:`input-text`,props:n}}}getFormModel(){let e={...this.getValue()||{}};for(let t of this.formField?.fields||[]){if(t.extra?.multiple===!0&&e[t.key]!==void 0){e[t.key]=Array.isArray(e[t.key])?e[t.key]:e[t.key]===``||e[t.key]===null?[]:[e[t.key]];continue}e[t.key]===void 0&&(t.defaultValue===void 0?t.default===void 0?t.type===`boolean`&&(e[t.key]=!1):e[t.key]=t.default:e[t.key]=t.defaultValue)}return e}emitValue(e){let t={};for(let n of this.formField?.fields||[])n.optional&&!this.optionalIncludes[n.key]||e[n.key]!==void 0&&(t[n.key]=e[n.key]);this.value=t,this.updateModel(t),this.requestUpdate()}handleFieldChange(e,t){e.stopPropagation(),Hs(t,e.detail.key,e.detail.value),this.emitValue(t)}setOptionalIncluded(e,t,n){this.optionalIncludes={...this.optionalIncludes,[e.key]:t},this.emitValue(n)}renderField(){let e=this.formField;if(!e||e.type!==`form`)return``;let t=this.getFormModel();return v`
      <div class="space-y-3">
        ${(e.fields||[]).map(e=>{let n=this.getFieldConfig(e,!e.optional);if(!e.optional)return this.renderNestedField(n,t,e=>this.handleFieldChange(e,t));let r=this.optionalIncludes[e.key]===!0;return v`
            <div class="grid grid-cols-[auto_minmax(0,1fr)] gap-x-3 items-start">
              <div class="-mt-2 row-span-2 self-start">
                <input-checkbox
                  .key=${e.key}
                  .value=${r}
                  .props=${{}}
                  @field-change=${n=>{n.stopPropagation(),this.setOptionalIncluded(e,!!n.detail.value,t)}}
                ></input-checkbox>
              </div>
              <label class="block mb-2 text-sm font-medium text-gray-200 pt-0.5">
                ${e.name||e.key}
              </label>
              <div class="${r?``:`pointer-events-none opacity-50`}">
                ${this.renderNestedField(n,t,e=>this.handleFieldChange(e,t))}
              </div>
            </div>
          `})}
      </div>
    `}};D([C()],_u.prototype,`optionalIncludes`,void 0),_u=D([x(`device-form-value`)],_u);var vu=e=>Array.isArray(e)?e:e==null||e===``?[]:[e],yu=(e,t)=>e?.params?.[t]??e?.[t],bu=(e=[])=>e.flatMap(e=>[e,...bu(e.fields||[])]).filter(e=>!!e.key),xu=e=>{let t=e?.relation;return typeof t==`string`&&t.trim()?t.trim():void 0},Su=e=>(e.type===`id`||e.type===`ids`)&&(e.subtype===`card`||e.subtype===`cards`),Cu=(e,t)=>{let n=xu(t);return(n?e?.params?.find(e=>e.key===n&&Su(e)):void 0)||e?.params?.find(Su)},wu=(e,t)=>{let n=xu(t);return(n?e?.params?.find(e=>e.key===n&&e.subtype===`card-field`):void 0)||e?.params?.find(e=>e.subtype===`card-field`)},Tu=(e,t)=>{let n=xu(e);return!n||n===t},Eu=(e,t)=>{e.params?delete e.params[t]:delete e[t]},Du=(e=[])=>e.flatMap(e=>[...e.key?[e]:[],...Du(e.fields||[])]),Ou=(e,t)=>{let n=e?.translations?.[t];if(typeof n==`string`)return n;if(n?.key)return n.key},ku=(e,t,n)=>{let r=n.key;return r?e?.translations?.[r]?.key||Ou(t,r)||n.name||r:n.name},Au=(e,t=[])=>{if(!(typeof e!=`string`||!e.startsWith(`@`)))return t.find(t=>t.value===e)?.deviceId},ju=(e,t=[])=>{if(!(typeof e!=`string`||!e.startsWith(`@`)))return t.find(t=>t.value===e)?.cardId},Mu=e=>(e.type===`id`||e.type===`ids`)&&(e.subtype===`device`||e.subtype===`devices`),Nu=(e,t)=>{let n=xu(t);return(n?e?.params?.find(e=>e.key===n&&Mu(e)):void 0)||e?.params?.find(Mu)},Pu=(e,t)=>{let n=xu(t),r=t?.subtype===`device-state-value`?`device-state`:`device-field`;return(n?e?.params?.find(e=>e.key===n&&e.subtype===r):void 0)||e?.params?.find(e=>e.subtype===r)},Fu=(e,t)=>{let n=e?K.getState().getDefinitionById(e.definition):void 0,r=Du(n?.fields||[]).map(t=>({...t,name:ku(e,n,t)}));return t?.subtype===`device-state`||t?.subtype===`device-state-value`?Object.entries(e?.state||{}).map(([e,t])=>r.find(t=>t.key===e)||{key:e,name:e,type:typeof t==`number`?`number`:typeof t==`boolean`?`boolean`:`string`,control:!1}):r},Iu=(e,t)=>{if(e.length===0)return[];if(e.length===1)return Fu(e[0],t);let n=Fu(e[0],t),r=new Set(n.map(e=>e.key));return e.slice(1).forEach(e=>{let n=new Set(Fu(e,t).map(e=>e.key));Array.from(r).forEach(e=>{n.has(e)||r.delete(e)})}),n.filter(e=>r.has(e.key))},Lu=(e,t,n,r=[])=>{let i=Nu(e,n);return Iu(vu(i?.key?yu(t,i.key):void 0).map(e=>Au(e,r)||e).map(e=>q.getState().getDeviceById(e)).filter(Boolean),n)},Ru=(e,t,n,r=[])=>{let i=Nu(e,n),a=vu(i?.key?yu(t,i.key):void 0).map(e=>Au(e,r)||e).map(e=>q.getState().getDeviceById(e)).filter(Boolean),o=n?.subtype===`device-state`,s=a.map(e=>{if(o)return Object.entries(e?.state||{}).map(([e,t])=>({key:e,name:e,type:typeof t==`number`?`number`:typeof t==`boolean`?`boolean`:`string`}));let t=K.getState().getDefinitionById(e.definition);return(t?.fields||[]).filter(e=>!!e.key).map(n=>({...n,name:ku(e,t,n)}))});if(s.length===0)return[];let c=new Set(s[0].map(e=>e.key));return s.slice(1).forEach(e=>{let t=new Set(e.map(e=>e.key));Array.from(c).forEach(e=>{t.has(e)||c.delete(e)})}),s[0].filter(e=>c.has(e.key)).map(e=>({value:e.key,label:e.name&&e.name!==e.key?`${e.name} (${e.key})`:String(e.key)}))},zu=(e,t,n,r=[])=>{let i=Pu(e,n),a=i?.key?yu(t,i.key):void 0;return Lu(e,t,i||n,r).find(e=>e.key===a)},Bu=e=>{if(e?.type===`boolean`){let t=e.extra?.valueTrue!==void 0||e.extra?.valueFalse!==void 0,n=t?e.extra?.valueTrue:!0,r=t?e.extra?.valueFalse:!1;return[{value:n,label:String(n)},{value:r,label:String(r)}]}return e?.type===`enum`?(e.values||[]).map(e=>{if(typeof e==`string`)return{value:e,label:e};let t=e.value??e.key??e.name;return{value:t,label:e.name??e.label??String(t)}}):[]},Vu=(e,t,n,r=[])=>{let i=Cu(e,n);if(!i?.key)return[];let a=vu(yu(t,i.key)).map(e=>ju(e,r)||e),o=L.getState().devices;return a.map(e=>o.find(t=>t._id===e)).filter(Boolean)},Hu=(e,t,n,r=[])=>{let i=Vu(e,t,n,r);if(i.length===0)return[];let a=(i[0].fields||[]).filter(e=>!!e.key),o=new Set(a.map(e=>e.key));return i.slice(1).forEach(e=>{let t=new Set((e.fields||[]).filter(e=>!!e.key).map(e=>e.key));Array.from(o).forEach(e=>{t.has(e)||o.delete(e)})}),a.filter(e=>o.has(e.key)).map(e=>({value:e.key,label:e.name?`${e.name} (${e.key})`:e.key}))},Uu=(e,t,n,r=[])=>{let i=wu(e,n),[a]=Vu(e,t,i||n,r),o=i?.key?yu(t,i.key):void 0;if(!(!a||!o))return bu(a.fields||[]).find(e=>e.key===o)},Wu=(e,t,n,r=[])=>{let i=Uu(e,t,n,r);if(!i)return[];if(i.type===`boolean`){let e=i.extra?.boolean||{},t=e.valueTrue!==void 0||e.valueFalse!==void 0,n=t?e.valueTrue:!0,r=t?e.valueFalse:!1;return[{value:n,label:String(n)},{value:r,label:String(r)},{value:null,label:`Inverse`}]}return i.type===`enum`?((i.options?.length?i.options:i.values)||[]).map(e=>{if(typeof e==`string`)return{value:e,label:e};let t=e.value??e.key??e.name;return{value:t,label:e.name??e.label??String(t)}}):[]},Gu=(e,t,n)=>{let r=[],i=n?.includeValue??!0,a={value:`@value`,label:`@value`},o=(e=[])=>[...i?[a]:[],...e.filter(e=>(typeof e==`string`?e:e?.value)!==a.value)];return e&&e.params&&e.params.length>0&&e.params.forEach(t=>{let a=xu(t),s=a?e.params?.find(e=>e.key===a):e.params?.find(e=>e.subtype===`script`&&t.key===`${e.key}Params`),c={key:`params.${t.key}`,type:`input-text`,props:{label:t.label||t.key,description:t.description,required:t.required||!1}};if(t.type===`array`&&(t.subtype===`repeat`||Array.isArray(t.fields)&&t.fields.length>0)){c.type=`repeat-field`,c.props={...c.props,scripts:J.getState().getScripts(),fields:t.fields||[],addLabel:`Add ${t.label||t.key}`,includeValue:i},r.push(c);return}if(t.type===`object`&&s?.subtype===`script`){c.type=`card-script-params`,c.className=`ml-3 border-left pl-4`,c.hide=e=>!yu(e,s.key),c.renderKey=e=>yu(e,s.key)||`${s.key}-empty`,c.props={...c.props,scripts:J.getState().getScripts(),scriptKey:`params.${s.key}`,scriptParamKey:s.key,getScriptId:e=>yu(e,s.key),includeValue:i},r.push(c);return}if(t.subtype===`card-field`){c.type=`input-select`,c.props.placeholder=`Select card field`,c.props.options=(r,i)=>Hu(e,i,t,n?.cardOptions||[]),c.hooks={onModelChange:(n,r)=>{e.params?.filter(e=>e.subtype===`card-field-value`&&Tu(e,t.key)).forEach(e=>Eu(r,e.key))}},r.push(c);return}if(t.subtype===`device-field`||t.subtype===`device-state`){let i=t.subtype===`device-state`?`device-state-value`:`device-field-value`;c.type=`input-select`,c.props.placeholder=t.subtype===`device-state`?`Select device state`:`Select device field`,c.props.options=(r,i)=>Ru(e,i,t,n?.deviceOptions||[]),c.hooks={onModelChange:(n,r)=>{e.params?.filter(e=>e.subtype===i&&Tu(e,t.key)).forEach(e=>Eu(r,e.key))}},r.push(c);return}if(t.subtype===`device-field-value`||t.subtype===`device-state-value`){let i=r=>zu(e,r,t,n?.deviceOptions||[]),a=e=>Bu(i(e)),o=e=>a(e).length>0,s=e=>i(e)?.type===`number`,l=e=>i(e)?.type===`form`;r.push({...c,type:`device-form-value`,props:{...c.props,getField:e=>i(e)},hide:e=>!l(e)}),r.push({...c,type:`input-select`,props:{...c.props,placeholder:`Select value`,options:(e,t)=>a(t)},hide:e=>!o(e)}),r.push({...c,type:`input-number`,props:{...c.props,min:(e,t)=>i(t)?.extra?.min,max:(e,t)=>i(t)?.extra?.max,step:(e,t)=>i(t)?.extra?.step},hide:e=>!s(e)}),r.push({...c,type:`input-text`,hide:e=>o(e)||s(e)||l(e)});return}if(t.subtype===`card-field-value`){let i=r=>Uu(e,r,t,n?.cardOptions||[]),a=(r,i)=>Wu(e,i,t,n?.cardOptions||[]),o=e=>a(void 0,e).length>0,s=e=>i(e)?.type===`form`;r.push({...c,type:`device-form-value`,props:{...c.props,getField:e=>i(e)},hide:e=>!s(e)}),r.push({...c,type:`input-select`,props:{...c.props,placeholder:`Select value`,options:a},hide:e=>s(e)||!o(e)}),r.push({...c,type:`input-text`,props:{...c.props,placeholder:`Value`},hide:e=>s(e)||o(e)});return}switch(t.type){case`number`:t.subtype===`milliseconds`?(c.type=`input-unit`,c.props={...c.props,type:`time`,defaultUnit:`s`,min:0}):c.type=`input-number`;break;case`boolean`:c.type=`input-toggle`,c.props.toggleLabel=e=>e.params?.[t.key]?`True`:`False`;break;case`enum`:c.type=`input-select`,c.props.options=o(t.options||[]);break;case`object`:c.type=`input-object`;break;case`array`:c.type=`input-array-text`;break;case`id`:case`ids`:if(t.subtype===`script`)c.type=`input-script`,c.props.multiple=t.type===`ids`,c.props.scripts=J.getState().getScripts().filter(t=>t._id!==e._id),c.props.options=o([]),c.hooks={onModelChange:(n,r)=>{e.params?.filter(e=>xu(e)===t.key||e.key===`${t.key}Params`).forEach(e=>Eu(r,e.key))}};else if(t.subtype===`device`||t.subtype===`devices`){let r=q.getState().getDevices();c.type=`input-devices`,c.props.multiple=t.type===`ids`,c.props.placeholder=t.type===`ids`?`Select devices`:`Select device`,c.props.devices=r,c.props.options=o(n?.deviceOptions||[]),c.props.defaultZoneId=n?.defaultZoneId,c.hooks={onModelChange:(n,r)=>{e.params?.filter(e=>e.subtype===`device-field`||e.subtype===`device-state`).filter(e=>Tu(e,t.key)).forEach(t=>{Eu(r,t.key);let n=t.subtype===`device-state`?`device-state-value`:`device-field-value`;e.params?.filter(e=>e.subtype===n).filter(e=>Tu(e,t.key)).forEach(e=>Eu(r,e.key))})}}}else if(t.subtype===`card`||t.subtype===`cards`){let r=L.getState().devices;c.type=`input-cards`,c.props.multiple=t.type===`ids`,c.props.placeholder=t.type===`ids`?`Select cards`:`Select card`,c.props.cards=r,c.props.options=o(n?.cardOptions||[]),c.props.defaultZoneId=n?.defaultZoneId,c.hooks={onModelChange:(r,i)=>{e.params?.filter(e=>e.subtype===`card-field`).filter(e=>Tu(e,t.key)).forEach(t=>{let r=new Set(Hu(e,i,t,n?.cardOptions||[]).map(e=>e.value)),a=yu(i,t.key);!a||r.has(a)||(Eu(i,t.key),e.params?.filter(e=>e.subtype===`card-field-value`).filter(e=>Tu(e,t.key)).forEach(e=>Eu(i,e.key)))})}}}else c.type=`input-text`;break;default:c.type=`input-text`;break}r.push(c)}),[...r]},Ku=[{value:`inherit`,label:`Inherit`},{value:`string`,label:`String`},{value:`number`,label:`Number`},{value:`boolean`,label:`Boolean`},{value:`object`,label:`Object`}],qu=`__nq_undefined__`,Ju=class extends Us{constructor(...e){super(...e),this.valueTypeOverrides={}}get selectedScript(){let e=this.props.scripts||[],t=J.getState().getScripts(),n=e.length>0?e:t,r=this.props.scriptKey||`script`,i=this.props.scriptParamKey,a=(typeof this.props.getScriptId==`function`?this.props.getScriptId(this.model):void 0)??Vs(this.model,r)??(i?Vs(this.model,i):void 0)??(i?Vs(this.model,`params.${i}`):void 0);return n.find(e=>e._id===a||e.id===a)}getWatchedDeviceOptions(){return[{value:`@value`,label:`@value`},...((typeof this.props.getWatchedDevices==`function`?this.props.getWatchedDevices():[])||[]).filter(e=>e?.name).map(e=>({value:`@${e.name}._id`,label:`${e.name} (@${e.name}._id)`,deviceId:e.device}))]}getCardOptions(){let e=((typeof this.props.getCards==`function`?this.props.getCards():[])||[]).filter(e=>e?.name).map(e=>({value:`@${e.name}._id`,label:`${e.name} (@${e.name}._id)`,cardId:e.card}));return e.some(e=>e.value===`@card._id`)?e:[...e,{value:`@card._id`,label:`Current card (@card._id)`}]}getDynamicHelp(){let e=((typeof this.props.getWatchedDevices==`function`?this.props.getWatchedDevices():[])||[]).filter(e=>e?.name).map(e=>`@${e.name}`);return v`
      <div class="text-body mb-1">Dynamic values</div>
      <div>Use <code>@value</code> for value sent by UI, <code>@state</code> for current card state, and <code>@card</code> for the current card. Devices: ${e.length?e.join(`, `):`@device`}.</div>
      <div>Nested paths are supported, for example <code>@card._id</code>, <code>@device._id</code>, <code>@value.checked</code>, <code>@state.position_left</code>.</div>
    `}willUpdate(){this.props.help||(this.props.help=this.getDynamicHelp())}getFields(e){return Gu(e,{params:this.getValue()||{}},{deviceOptions:this.getWatchedDeviceOptions(),cardOptions:this.getCardOptions(),includeValue:this.props.includeValue!==!1,defaultZoneId:this.props.defaultZoneId})}getParamKey(e){return e.key?.startsWith(`params.`)?e.key.slice(7):void 0}isDynamicValue(e){return typeof e==`string`?e.trim().startsWith(`@`):Array.isArray(e)?e.some(e=>typeof e==`string`?e.trim().startsWith(`@`):this.isDynamicValue(e)):e&&typeof e==`object`?Object.values(e).some(e=>this.isDynamicValue(e)):!1}formatDynamicValue(e){return e==null?``:typeof e==`string`?e:Array.isArray(e)?`[${e.map(e=>typeof e==`string`?e:JSON.stringify(e)).join(`, `)}]`:typeof e==`object`?JSON.stringify(e):String(e)}getStaticDefault(e){if(e?.default!==void 0)return e.default;switch(e?.type){case`number`:return 0;case`boolean`:return!1;case`object`:return{};case`array`:case`ids`:return[];default:return``}}getValueType(e,t){return this.valueTypeOverrides[e.key]||(typeof t==`string`&&e.type!==`object`&&this.isDynamicValue(t)?`string`:`inherit`)}getValueForType(e,t,n){return t===`inherit`?this.getStaticDefault(e):t===`string`?this.formatDynamicValue(n):t===`number`?typeof n==`number`?n:0:t===`boolean`?n===!0||n===!1||n==null?n:!1:n&&typeof n==`object`&&!Array.isArray(n)?n:{}}handleValueTypeChange(e,t){let n=e.key,r=this.getActionModel(),i=Vs(r,`params.${n}`);this.valueTypeOverrides={...this.valueTypeOverrides,[n]:t},Hs(r,`params.${n}`,this.getValueForType(e,t,i)),this.value=r.params||{},this.updateModel(r.params||{}),this.requestUpdate()}renderValueTypeSelect(e,t){return this.renderNestedField({key:`valueType`,type:`input-select`,props:{label:`Dynamic`,help:v`<div>Use dynamic values when the action runs from a trigger.</div><div>Common examples: <code>@value</code>, <code>@state</code>, <code>@device._id</code>, <code>@card._id</code>, <code>@previousState</code>, <code>@changed</code>.</div><div>For watched devices in cards use their configured names, for example <code>@device1._id</code> or <code>@device1.state.key</code>.</div>`,options:Ku}},{valueType:t},t=>{t.stopPropagation(),this.handleValueTypeChange(e,t.detail.value)})}renderBooleanField(e,t,n,r){let i=r===void 0?qu:r;return this.renderNestedField({...e,type:`input-select`,hide:!1,props:{label:e.props?.label,description:e.props?.description,required:e.props?.required,placeholder:`Select value`,options:[{value:!0,label:`True`},{value:!1,label:`False`},{value:null,label:`Null`},{value:qu,label:`Undefined`}]}},{params:{...t.params,[n]:i}},e=>{e.detail.value===qu&&(e.detail.value=void 0),this.handleFieldChange(e)})}renderParamField(e,t,n){if(this.isFieldHidden(e,n))return v``;let r=this.getParamKey(e);if(!r)return this.renderNestedField(e,n,e=>this.handleFieldChange(e));let i=Vs(n,e.key),a=this.getValueType(t,i),o;return o=a===`inherit`?this.renderNestedField(e,n,e=>this.handleFieldChange(e)):a===`boolean`?this.renderBooleanField(e,n,r,i):this.renderNestedField({...e,type:a===`number`?`input-number`:a===`object`?`input-object`:`input-text`,hide:!1,props:{label:e.props?.label,description:e.props?.description,required:e.props?.required,placeholder:a===`string`?`@value.path`:e.props?.placeholder}},n,e=>this.handleFieldChange(e)),v`
      <div class="script-param-row">
        <div>${o}</div>
        <div>
          ${this.renderValueTypeSelect(t,a)}
        </div>
      </div>
    `}getActionModel(){return{params:{...this.getValue()||{}}}}handleFieldChange(e){e.stopPropagation();let t=this.getActionModel();Hs(t,e.detail.key,e.detail.value);let n=this.selectedScript;if(n){let r=e.detail.key?.startsWith(`params.`)?e.detail.key.slice(7):e.detail.key;n.params?.find(e=>e.key===r)?.subtype===`script`&&n.params?.filter(e=>e.relation===r||e.key===`${r}Params`).forEach(e=>{delete t.params[e.key]}),this.triggerFieldHooks(this.getFields(n),e.detail.key,e.detail.value,t)}this.value=t.params||{},this.updateModel(t.params||{}),this.requestUpdate()}renderField(){let e=this.selectedScript;if(!e)return``;let t=this.getFields(e),n=this.getActionModel();return[...t.map(t=>{if(this.isFieldHidden(t,n))return v``;t.key&&Vs(n,t.key)===void 0&&t.defaultValue!==void 0&&Hs(n,t.key,t.defaultValue);let r=this.getParamKey(t),i=r?e.params?.find(e=>e.key===r):void 0;return i?this.renderParamField(t,i,n):this.renderNestedField(t,n,e=>this.handleFieldChange(e))})]}};D([C()],Ju.prototype,`valueTypeOverrides`,void 0),Ju=D([x(`card-script-params`)],Ju);function Yu(e,t=[]){return!!(e&&t.some(t=>(t._id===e||t.id===e)&&t.waitForCompletion===!0))}function Xu(e,t=[]){e.waitForCompletion=Yu(e?.script,t)}function Zu(e=[],t=[]){return(e||[]).map(e=>({...e,...e.waitForCompletion===void 0&&Yu(e?.script,t)?{waitForCompletion:!0}:{}}))}function Qu(e=[],t=[],n=e=>e){return(e||[]).filter(e=>e?.script).map(e=>({script:e.script,params:n(e.params||{}),...e.waitForCompletion===!0?{waitForCompletion:!0}:{}}))}var $u=class extends R{get scripts(){let e=this.props.scripts||[],t=J.getState().getScripts();return e.length>0?e:t}getItemFields(){let e=this.scripts;return[{key:`script`,type:`input-script`,props:{label:`Script`,required:!0,scripts:e},hooks:{onModelChange:(t,n)=>Xu(n,e)}},{key:`params`,type:`card-script-params`,hide:e=>!e.script,props:{scripts:e,getWatchedDevices:this.props.getWatchedDevices,getCards:this.props.getCards,scriptKey:`script`,includeValue:this.props.includeValue!==!1,defaultZoneId:this.props.defaultZoneId}},{key:`waitForCompletion`,type:`input-toggle`,defaultValue:!1,props:{toggleLabel:`Wait for completion`,help:`Wait before starting the next script until this script finishes.`}}]}handleChange(e){e.stopPropagation(),this.value=e.detail.value,this.updateModel(e.detail.value)}renderField(){return v`
      <input-array
        .key=${this.key}
        .value=${Zu(this.getValue()||[],this.scripts)}
        .model=${this.model}
        .props=${{required:this.props.required,addLabel:this.props.addLabel||`Add Script`,itemFields:this.getItemFields()}}
        @field-change=${this.handleChange}
      ></input-array>
    `}};$u=D([x(`input-script-actions`)],$u);var ed=[{value:`string`,label:`String`},{value:`number`,label:`Number`},{value:`boolean`,label:`Boolean`},{value:`enum`,label:`Enum`},{value:`list`,label:`List`},{value:`image`,label:`Image`},{value:`button`,label:`Button`},{value:`form`,label:`Form`},{value:`chart`,label:`Chart`}],td=[{value:`string`,label:`String`},{value:`number`,label:`Number`},{value:`boolean`,label:`Boolean`},{value:`enum`,label:`Enum`},{value:`image`,label:`Image`},{value:`icon`,label:`Icon`},{value:`color`,label:`Color`},{value:`date`,label:`Date`},{value:`time`,label:`Time`},{value:`datetime`,label:`Date & time`},{value:`list`,label:`List`},{value:`form`,label:`Form`},{value:`object`,label:`Object`},{value:`array-object`,label:`Array object`},{value:`array-string`,label:`Array string`}],nd=new Set([`enum`]),rd=new Set([`object`,`array-object`,`form`]),id=new Set([`string`,`number`,`enum`,`color`,`date`,`time`,`datetime`,`array-string`]),ad=(e,t)=>{e===`form`||e===`button`?t.control=!0:e===`image`&&(t.control=!1)},od=(e,t)=>(t.options||[]).filter(e=>e?.name&&e?.value).map(e=>({value:e.value,label:e.name})),sd=(e=0)=>[{fieldGroupClassName:`d-grid grid-columns-1 grid-columns-md-4 gap-4 align-items-end`,fieldGroup:[{key:`key`,type:`input-text`,props:{label:`Key`,required:!0}},{key:`name`,type:`input-text`,props:{label:`Name`,required:!0}},{key:`type`,type:`input-select`,defaultValue:`string`,props:{label:`Type`,options:td},hooks:{onModelChange:(e,t)=>{e===`form`&&(t.control=!0)}}},{key:`extra.hideName`,type:`input-toggle`,props:{toggleLabel:`Hide name`}}]},{fieldGroupClassName:`d-grid grid-columns-1 grid-columns-md-2 gap-4`,fieldGroup:[{key:`placeholder`,type:`input-text`,hide:e=>!id.has(e.type),props:{label:`Placeholder`}},{key:`defaultValue`,type:`input-text`,hide:e=>e.type!==`string`&&e.type!==`color`&&e.type!==`date`&&e.type!==`time`&&e.type!==`datetime`,props:{label:`Default value`}},{key:`defaultValue`,type:`input-number`,hide:e=>e.type!==`number`,props:{label:`Default value`}},{key:`defaultValue`,type:`input-toggle`,hide:e=>e.type!==`boolean`,props:{toggleLabel:`Default value`}},{key:`defaultValue`,type:`input-select`,hide:e=>e.type!==`enum`,props:{label:`Default value`,placeholder:`None`,options:od}}]},{fieldGroupClassName:`d-grid grid-columns-1 grid-columns-md-3 gap-4`,hide:e=>e.type!==`number`,fieldGroup:[{key:`extra.suffix`,type:`input-text`,props:{label:`Suffix`}},{key:`extra.min`,type:`input-number`,props:{label:`Min`}},{key:`extra.max`,type:`input-number`,props:{label:`Max`}}]},{fieldGroupClassName:`d-grid grid-columns-1 grid-columns-md-2 gap-4`,hide:e=>e.type!==`boolean`,fieldGroup:[{key:`extra.valueTrue`,type:`input-text`,props:{label:`True value`,help:`Optional value mapping, for example ON.`}},{key:`extra.valueFalse`,type:`input-text`,props:{label:`False value`,help:`Optional value mapping, for example OFF.`}}]},{key:`options`,type:`input-array`,hide:e=>!nd.has(e.type),props:{label:`Options`},fieldArray:[{fieldGroupClassName:`d-grid grid-columns-1 grid-columns-md-2 gap-4`,fieldGroup:[{key:`name`,type:`input-text`,props:{label:`Name`,placeholder:`Otwarte`,required:!0}},{key:`value`,type:`input-text`,props:{label:`Value`,placeholder:`OPEN`,required:!0}}]}]},{hide:e=>e.type!==`list`,fieldGroupClassName:`d-grid grid-columns-1 gap-4`,fieldGroup:[{fieldGroupClassName:`d-grid grid-columns-1 grid-columns-md-3 gap-4`,fieldGroup:[{key:`list.item.id`,type:`input-text`,props:{label:`ID field`,placeholder:`id`}},{key:`list.item.title`,type:`input-text`,props:{label:`Title field`,placeholder:`title`}},{key:`list.item.description`,type:`input-text`,props:{label:`Description field`,placeholder:`description`}},{key:`list.item.badge`,type:`input-text`,props:{label:`Badge field`,placeholder:`badge`}}]},{key:`list.check.enabled`,type:`input-toggle`,props:{toggleLabel:`Check action`}},{key:`list.check.checkedKey`,type:`input-text`,hide:e=>!e.list?.check?.enabled,props:{label:`Checked key`,placeholder:`completed`}},{key:`list.delete.enabled`,type:`input-toggle`,props:{toggleLabel:`Delete action`}}]},{key:`fields`,type:`input-array`,hide:e=>!rd.has(e.type),props:{label:`Nested fields`},fieldArray:e<6?sd(e+1):[]}],cd=[{value:`normal`,label:`Normal`},{value:`jumbo`,label:`Jumbo`},{value:`date`,label:`Date`},{value:`datetime`,label:`Date & Time`},{value:`time`,label:`Time`}],ld=[{value:`normal`,label:`Normal`},{value:`jumbo`,label:`Jumbo`},{value:`chart`,label:`Chart`},{value:`date`,label:`Date`},{value:`datetime`,label:`Date & Time`},{value:`time`,label:`Time`}],ud=[{value:`normal`,label:`Normal`},{value:`jumbo`,label:`Jumbo`},{value:`icon-value`,label:`Icon & value`},{value:`icon`,label:`Icon`},{value:`icon-large`,label:`Large icon`},{value:`icon-value-bottom`,label:`Icon with value below`},{value:`icon-as-value`,label:`Icon as value`}],dd=[{value:`buttons-inline`,label:`Buttons inline`},{value:`buttons-1`,label:`Buttons — 1 per row`},{value:`buttons-2`,label:`Buttons — 2 per row`},{value:`buttons-3`,label:`Buttons — 3 per row`},{value:`radio-inline`,label:`Radio inline`},{value:`radio-1`,label:`Radio — 1 per row`}],fd=Array.from({length:12},(e,t)=>{let n=t+1;return{value:n,label:`${n}/12`}}),pd=[{value:`line`,label:`Line`}],md=[{value:`value`,label:`Value`},{value:`counter-delta`,label:`Counter delta`},{value:`consumption`,label:`Consumption`}],hd=[{value:`blue`,label:`Blue`},{value:`green`,label:`Green`},{value:`red`,label:`Red`},{value:`yellow`,label:`Yellow`},{value:`orange`,label:`Orange`},{value:`purple`,label:`Purple`},{value:`pink`,label:`Pink`},{value:`white`,label:`White`},{value:`gray`,label:`Gray`}],gd=()=>Zt().map(({name:e,icon:t})=>({value:e,icon:t})),_d=(e,t)=>t.control?[{value:`toggle`,label:`Toggle`},{value:`enum`,label:`Enum`},{value:`jumbo`,label:`Jumbo`},{value:`icon`,label:`Icon`}]:[{value:`normal`,label:`Normal`},{value:`checkbox`,label:`Checkbox`,disabled:!0},{value:`toggle`,label:`Toggle`,disabled:!0},{value:`jumbo`,label:`Jumbo`},{value:`icon`,label:`Icon`}],vd=(e=[])=>e.filter(e=>!!e.key).map(e=>{let t={key:e.key,name:e.name||e.key,type:e.type||`string`};return e.placeholder&&(t.placeholder=e.placeholder),e.defaultValue!==void 0&&(t.defaultValue=e.defaultValue),e.extra&&(t.extra=structuredClone(e.extra)),e.type===`enum`&&e.values?.length&&(t.options=e.values.map(e=>typeof e==`string`?{name:e,value:e}:{name:e.name,value:e.value})),[`form`,`object`,`array-object`].includes(e.type||``)&&e.fields?.length&&(t.fields=vd(e.fields)),t}),yd=(e=[])=>e.map(e=>{if(typeof e==`string`)return{name:e,value:e};let t=e?.value??e?.key??e?.name;return t==null||t===``?null:{name:e?.name??e?.label??String(t),value:t}}).filter(Boolean),bd=(e,t)=>{if(!t){e.control=!1;return}if(e.control=t.control===!0,t.type===`boolean`){let n=t.extra?.boolean||{},r=n.trueLabel??t.extra?.valueTrue,i=n.falseLabel??t.extra?.valueFalse;e.extra||={},e.extra.boolean||={},r!=null&&r!==``&&(e.extra.boolean.trueLabel=String(r)),i!=null&&i!==``&&(e.extra.boolean.falseLabel=String(i))}t.type===`enum`&&(e.options=yd(t.values||[])),t.type===`list`&&(e.list=t.list?structuredClone(t.list):{})};function xd(e,t){let n=()=>t().filter(e=>e.name&&e.device).map(e=>({value:e.name,label:e.name})),r=(e,t,n)=>{let r=n.key,i=r,a=e?.translations?.[r],o=t?.translations?.[r],s=typeof a==`string`?a:a?.key||(typeof o==`string`?o:o?.key);return s?`${s} (${i})`:i},i=e=>{let n=t().find(t=>t.name===e);if(!n?.device)return[];let i=q.getState().getDeviceById(n.device);if(!i?.definition)return[];let a=K.getState().getDefinitionById(i.definition);return Sd(a?.fields||[]).map(e=>({value:e.key,label:r(i,a,e)}))},a=e=>{if(!e)return[];let t=q.getState().getDeviceById(e);return t?.definition?Sd(K.getState().getDefinitionById(t.definition)?.fields||[]).map(e=>({value:e.key,label:e.name&&e.name!==e.key?`${e.name} (${e.key})`:e.key})):[]},o=e=>{let n=t().find(t=>t.name===e.bindingDevice);if(!n?.device||!e.bindingKey)return;let r=q.getState().getDeviceById(n.device);return Cd((r?.definition?K.getState().getDefinitionById(r.definition):void 0)?.fields||[],e.bindingKey)},s=(e,t)=>e.binding&&o(e)?.type===t||e.type===t;return[{key:`fields`,type:`input-array`,props:{label:`Fields`},fieldArray:[{key:`name`,type:`input-accordion`,props:{label:`Name`,placeholder:`Field name`,required:!0,border:!1},fieldArray:[{fieldGroupClassName:`d-grid grid-columns-1 grid-columns-md-4 gap-4 align-items-end`,fieldGroup:[{key:`key`,type:`input-text`,props:{label:`Key`,required:!0}},{key:`binding`,type:`input-toggle`,defaultValue:!1,props:{toggleLabel:`Binding`}},{key:`type`,type:`input-select`,hide:e=>!!e.binding,defaultValue:`string`,props:{label:`Type`,options:ed},hooks:{onModelChange:(e,t)=>{ad(e,t)}}},{key:`bindingDevice`,type:`input-select`,hide:e=>!e.binding,props:{label:`Device`,required:!0,help:`Shows devices added in the General tab as watched devices.`,options:n()},hooks:{onModelChange:(e,t)=>{t.bindingKey=``,t.control=!1}}},{key:`bindingKey`,type:`input-select`,hide:e=>!e.binding,props:{label:`State field`,required:!0,options:(e,t)=>i(t.bindingDevice)},hooks:{onModelChange:(e,t)=>{let n=o(t);n?.type&&(t.type=n.type),bd(t,n),[`form`,`object`,`array-object`].includes(n?.type||``)?t.fields=vd(n.fields):delete t.fields}}},{key:`control`,type:`input-toggle`,hide:e=>!!e.binding||[`form`,`button`,`image`,`list`,`chart`].some(t=>s(e,t)),props:{toggleLabel:`Control`}}]},{key:`value`,type:`input-text`,hide:e=>!!e.binding,props:{label:`Value expression`,help:`Example: device1.state.position_left + device2.state.position_left`}},{hide:e=>!s(e,`string`),fieldGroupClassName:`d-grid grid-columns-1 gap-4`,fieldGroup:[{key:`extra.display`,type:`input-select`,defaultValue:`normal`,props:{label:`Display`,options:cd}}]},{fieldGroupClassName:`d-grid grid-columns-1 grid-columns-md-4 gap-4`,hide:e=>!s(e,`number`),fieldGroup:[{key:`extra.display`,type:`input-select`,defaultValue:`normal`,props:{label:`Display`,options:ld}},{key:`extra.suffix`,type:`input-text`,hide:e=>!!e.binding,props:{label:`Suffix`}},{key:`extra.min`,type:`input-number`,hide:e=>!!e.binding,props:{label:`Min`}},{key:`extra.max`,type:`input-number`,hide:e=>!!e.binding,props:{label:`Max`}}]},{hide:e=>!s(e,`boolean`),fieldGroupClassName:`d-grid grid-columns-1 grid-columns-md-5 gap-4`,fieldGroup:[{key:`extra.display`,type:`input-select`,props:{label:`Display`,options:_d,placeholder:`Default`}},{key:`extra.boolean.trueLabel`,type:`input-text`,props:{label:`True label`,placeholder:`Yes`}},{key:`extra.boolean.falseLabel`,type:`input-text`,props:{label:`False label`,placeholder:`No`}},{key:`extra.boolean.trueIcon`,type:`input-icon`,props:{label:`True icon`,options:gd(),allowCustomSvg:!0}},{key:`extra.boolean.falseIcon`,type:`input-icon`,props:{label:`False icon`,options:gd(),allowCustomSvg:!0}}]},{hide:e=>!s(e,`enum`),fieldGroupClassName:`d-grid grid-columns-1 gap-4`,fieldGroup:[{key:`extra.display`,type:`input-select`,props:{label:`Display`,placeholder:`Default`,options:(e,t)=>t.control?t.extra?.display===`buttons`?[{value:`buttons`,label:`Buttons inline`},...dd]:dd:ud}}]},{key:`options`,type:`input-array`,hide:e=>!s(e,`enum`),props:{label:`Options`},fieldArray:[{fieldGroupClassName:`d-grid grid-columns-1 grid-columns-md-4 gap-4`,fieldGroup:[{key:`name`,type:`input-text`,props:{label:`Name`,placeholder:`Otwarte`,required:!0}},{key:`value`,type:`input-text`,props:{label:`Value`,placeholder:`OPEN`,required:!0}},{key:`width`,type:`input-select`,props:{label:`Width`,placeholder:`Fit`,options:fd}},{key:`icon`,type:`input-icon`,props:{label:`Icon`,options:gd(),allowCustomSvg:!0}}]}]},{hide:e=>!s(e,`chart`),fieldGroupClassName:`d-grid grid-columns-1 gap-4`,fieldGroup:[{key:`extra.chart.sources`,type:`input-array`,defaultValue:[],props:{label:`Sources`},fieldArray:[{fieldGroupClassName:`d-grid grid-columns-1 gap-4`,fieldGroup:[{key:`device`,type:`input-devices`,props:{label:`Device`,required:!0,devices:q.getState().getDevices()},hooks:{onModelChange:(e,t)=>{t.key=``}}},{fieldGroupClassName:`d-grid grid-columns-1 grid-columns-md-3 gap-4`,fieldGroup:[{key:`name`,type:`input-text`,props:{label:`Name`,placeholder:`Kitchen`,required:!0}},{key:`key`,type:`input-select`,props:{label:`History field`,required:!0,options:(e,t)=>a(t.device)}},{key:`color`,type:`input-select`,props:{label:`Color`,placeholder:`Auto`,options:hd}}]}]}]},{fieldGroupClassName:`d-grid grid-columns-1 grid-columns-md-2 gap-4`,fieldGroup:[{key:`extra.chart.display`,type:`input-select`,defaultValue:`line`,props:{label:`Display`,options:pd}},{key:`extra.chart.mode`,type:`input-select`,defaultValue:`value`,props:{label:`Mode`,options:md}},{key:`extra.chart.showTotal`,type:`input-toggle`,props:{toggleLabel:`Show total`}}]},{fieldGroupClassName:`d-grid grid-columns-1 grid-columns-md-2 gap-4`,fieldGroup:[{key:`extra.chart.range`,type:`input-unit`,props:{label:`Range`,type:`time`,defaultUnit:`h`,min:0,help:`Chart history range. The API stores this value in milliseconds.`}},{key:`extra.chart.bucket`,type:`input-unit`,props:{label:`Bucket`,type:`time`,defaultUnit:`h`,min:0,help:`Chart aggregation bucket. The API stores this value in milliseconds.`}}]}]},{hide:e=>!s(e,`list`),fieldGroupClassName:`d-grid grid-columns-1 gap-4`,fieldGroup:[{fieldGroupClassName:`d-grid grid-columns-1 grid-columns-md-3 gap-4`,hide:e=>!!e.binding,fieldGroup:[{key:`list.item.id`,type:`input-text`,props:{label:`ID field`,placeholder:`id`}},{key:`list.item.title`,type:`input-text`,props:{label:`Title field`,placeholder:`title`}},{key:`list.item.description`,type:`input-text`,props:{label:`Description field`,placeholder:`description`}},{key:`list.item.badge`,type:`input-text`,props:{label:`Badge field`,placeholder:`badge`}}]},{key:`list.item.templateExpression`,type:`input-textarea`,hide:e=>!!e.binding,props:{label:`Template Expression`}},{key:`list.check.enabled`,type:`input-toggle`,props:{toggleLabel:`Check action`}},{fieldGroupClassName:`d-grid grid-columns-1 grid-columns-md-2 gap-4`,hide:e=>!!e.binding||!e.list?.check?.enabled,fieldGroup:[{key:`list.check.checkedKey`,type:`input-text`,props:{label:`Checked key`,placeholder:`completed`}},{key:`list.check.script`,type:`input-script`,props:{label:`Script`,scripts:e}}]},{key:`list.check.params`,type:`card-script-params`,hide:e=>!!e.binding||!e.list?.check?.enabled||!e.list?.check?.script,props:{scripts:e,getWatchedDevices:t,scriptKey:`list.check.script`}},{key:`list.delete.enabled`,type:`input-toggle`,props:{toggleLabel:`Delete action`}},{key:`list.delete.script`,type:`input-script`,hide:e=>!!e.binding||!e.list?.delete?.enabled,props:{label:`Script`,scripts:e}},{key:`list.delete.params`,type:`card-script-params`,hide:e=>!!e.binding||!e.list?.delete?.enabled||!e.list?.delete?.script,props:{scripts:e,getWatchedDevices:t,scriptKey:`list.delete.script`}}]},{key:`extra.form.submitLabel`,type:`input-text`,hide:e=>!s(e,`form`),props:{label:`Submit label`,placeholder:`Submit`}},{key:`fields`,type:`input-array`,hide:e=>!s(e,`form`),props:{label:`Form fields`},fieldArray:sd()},{key:`commands`,type:`input-array`,hide:e=>!!e.binding||e.type!==`form`&&!e.control,props:{label:`Commands`},fieldArray:[{key:`script`,type:`input-script`,props:{label:`Script`,scripts:e},hooks:{onModelChange:(t,n)=>Xu(n,e)}},{key:`params`,type:`card-script-params`,defaultValue:{},hide:e=>!e.script,props:{scripts:e,getWatchedDevices:t,scriptKey:`script`}},{key:`waitForCompletion`,type:`input-toggle`,defaultValue:!1,props:{toggleLabel:`Wait for completion`,help:`Wait before starting the next script until this script finishes.`}}]},{fieldGroupClassName:`d-grid grid-columns-1 grid-columns-md-2 gap-4 mt-0 align-items-end`,hide:e=>s(e,`list`)||s(e,`chart`)||!e.control,fieldGroup:[{key:`cooldownMs`,type:`input-unit`,props:{label:`Cooldown`,type:`time`,defaultUnit:`s`,min:0,help:`Wait time before the next command can be executed`}},{key:`extra.confirm`,type:`input-toggle`,props:{toggleLabel:`Request confirmation`,help:`Ask for confirmation before executing the command`}}]}]}]}]}function Sd(e=[],t=``){let n=[];for(let r of e){let e=r?.key?`${t}${r.key}`:``;e&&n.push({key:e,name:r.name}),Array.isArray(r?.fields)&&n.push(...Sd(r.fields,e?`${e}.`:t))}return n}function Cd(e=[],t,n=``){for(let r of e){let e=r?.key?`${n}${r.key}`:``;if(e===t)return r;if(Array.isArray(r?.fields)){let i=Cd(r.fields,t,e?`${e}.`:n);if(i)return i}}}var wd=()=>Zt().map(({name:e,icon:t})=>({value:e,icon:t})),Td=Array.from({length:12},(e,t)=>{let n=t+1;return{value:n,label:`${n}/12`}}),Ed=Array.from({length:6},(e,t)=>{let n=t+1;return{value:n,label:String(n)}}),Dd=[{value:`white`,label:`White`},{value:`red`,label:`Red`},{value:`blue`,label:`Blue`},{value:`green`,label:`Green`},{value:`yellow`,label:`Yellow`}],Od=[{value:`left`,label:`Left`},{value:`right`,label:`Right`},{value:`top`,label:`Top`},{value:`bottom`,label:`Bottom`}],kd=v`
  <div class="space-y-2">
    <div>${j(`Space-separated CSS classes applied to the card or field.`)}</div>
    <div>
      ${j(`Guaranteed colors:`)}
      <code>text-danger</code>, <code>text-warning</code>, <code>text-success</code>,
      <code>text-info</code>, <code>text-primary</code>, <code>text-muted</code>,
      <code>text-light</code>, <code>text-dark</code>. ${j(`Use the same variants with`)}
      <code>border-</code> and <code>bg-</code>.
    </div>
    <div>
      ${j(`Utility examples:`)} <code>hidden</code>, <code>rounded</code>,
      <code>p-3</code>, <code>opacity-50</code>, or <code>fw-bold</code>.
    </div>
  </div>
`,Ad=v`
  <div class="space-y-2">
    <div>${j(`Safe expression that returns a class string. Available variables:`)} <code>state</code> ${j(`and`)} <code>value</code>. ${j(`Function calls and JavaScript code are not allowed.`)}</div>
    <div>
      ${j(`Example:`)}
      <code>state?.alarm ? 'border-success text-success' : 'hidden'</code>
    </div>
  </div>
`;function jd(e){let t=[{fieldGroupClassName:`d-grid grid-columns-1 grid-columns-md-2 gap-4`,fieldGroup:[{key:`className`,type:`input-text`,props:{label:`ClassName`,help:kd}},{key:`icon`,type:`input-icon`,props:{label:`Icon`,options:wd(),allowCustomSvg:!0}}]},{key:`classNameExpression`,type:`input-text`,props:{label:`ClassName Expression`,help:Ad}},{template:v`<div class="text-sm mb-2">${j(`Fields`)}</div>`}];return(e.fields||[]).forEach((e,n)=>{let r=e.name||`Field ${n+1}`;t.push({type:`input-accordion`,className:`mb-1`,props:{title:r},fieldArray:[{fieldGroupClassName:`d-grid grid-columns-1 d-md-flex gap-2 gap-md-8 justify-content-md-start`,fieldGroup:[{key:`fields.${n}.extra.hideField`,type:`input-toggle`,props:{toggleLabel:`Hide field`}},{key:`fields.${n}.extra.hideName`,type:`input-toggle`,props:{toggleLabel:`Hide name`}}]},{fieldGroupClassName:`d-grid grid-columns-1 grid-columns-md-3 gap-4`,fieldGroup:[{key:`fields.${n}.extra.width`,type:`input-select`,props:{label:`Width`,placeholder:`Full width`,options:Td}},{key:`fields.${n}.extra.height`,type:`input-select`,hooks:{onModelChange:(e,t)=>{let r=t.fields?.[n];r&&(r.extra=r.extra||{},r.extra.width||(r.extra.width=12))}},props:{label:`Height`,placeholder:`Auto`,options:Ed}},{key:`fields.${n}.extra.icon`,type:`input-icon`,props:{label:`Icon`,options:wd(),allowCustomSvg:!0}}]},{hide:e=>e.fields?.[n]?.type!==`button`,fieldGroupClassName:`d-grid grid-columns-1 grid-columns-md-3 gap-4 align-items-end`,fieldGroup:[{key:`fields.${n}.button.color`,type:`input-select`,defaultValue:`white`,props:{label:`Color`,options:Dd}},{key:`fields.${n}.button.outline`,type:`input-toggle`,props:{toggleLabel:`Outline`}},{key:`fields.${n}.button.iconPosition`,type:`input-select`,defaultValue:`left`,props:{label:`Icon position`,options:Od}}]},{key:`fields.${n}.className`,type:`input-text`,props:{label:`ClassName`,help:kd}},{key:`fields.${n}.classNameExpression`,type:`input-text`,props:{label:`ClassName Expression`,help:Ad}},{key:`fields.${n}.list.item.className`,type:`input-text`,hide:e=>e.fields?.[n]?.type!==`list`,props:{label:`List item ClassName`,help:kd}},{key:`fields.${n}.list.item.classNameExpression`,type:`input-text`,hide:e=>e.fields?.[n]?.type!==`list`,props:{label:`List item ClassName Expression`,help:v`
              <div class="space-y-2">
                ${Ad}
                <div>${j(`Example:`)} <code>option.completed ? 'opacity-50' : ''</code></div>
              </div>
            `}}]})}),t}function Md(){return[{key:`state`,type:`input-json`,props:{label:`State`,rows:18}}]}var Nd=[{value:`$eq`,label:`=`},{value:`$ne`,label:`!=`},{value:`$gt`,label:`>`},{value:`$gte`,label:`>=`},{value:`$lt`,label:`<`},{value:`$lte`,label:`<=`},{value:`$in`,label:`in`},{value:`$nin`,label:`not in`},{value:`$exists`,label:`exists`}],Pd=[{value:!0,label:`True`},{value:!1,label:`False`},{value:null,label:`Null`},{value:void 0,label:`Undefined`}],Fd=[{value:`field-current`,label:`Current fields`},{value:`field-card`,label:`Other card fields`},{value:`field-device`,label:`Other device fields`},{value:`expression-current`,label:`Current expression`},{value:`expression-card`,label:`Other card expression`},{value:`expression-device`,label:`Other device expression`}];function Id(e=[]){return e.filter(e=>e?.key).map(e=>({value:e.key,label:e.name&&e.name!==e.key?`${e.name} (${e.key})`:e.key}))}function Ld(e=[],t){return e.find(e=>e.key===t)}function Rd(e,t){return Ld(e,t?.key)?.type||`string`}function zd(e,t){let n=Ld(e,t?.key);return(n?.options?.length?n.options:n?.values||[]).map(e=>{if(typeof e==`string`)return{value:e,label:e};let t=e?.value??e?.key??e?.name??String(e);return{value:t,label:e?.name??e?.label??String(t)}})}function Bd(e){return!e?.key||e?.operator===`$exists`}function Vd(e){return e?._useExternalCard===!0||!!e?.card}function Hd(e){return e?._useExternalDevice===!0||!!e?.device}function Ud(e){let t=e?._expressionMode===!0||!!e?.expression?.trim(),n=Vd(e),r=Hd(e);return t&&r?`expression-device`:t&&n?`expression-card`:t?`expression-current`:r?`field-device`:n?`field-card`:`field-current`}function Wd(e,t){let n=e.startsWith(`expression-`),r=e===`field-card`||e===`expression-card`,i=e===`field-device`||e===`expression-device`;t._expressionMode=n,t._useExternalCard=r,t._useExternalDevice=i,r||delete t.card,i||delete t.device,n?(delete t.key,delete t.operator,delete t.value):delete t.expression}function Gd(e,t,n){let r=e.fields||[],i=()=>L.getState().devices||[],a=e=>{let t=q.getState().getDeviceById(e?.device);return t?.definition&&K.getState().getDefinitionById(t.definition)?.fields||[]},o=e=>Hd(e)?a(e):Vd(e)?i().find(t=>t._id===e?.card)?.fields||[]:r,s=e=>Rd(o(e),e),c=e=>zd(o(e),e);return(e.triggers||[]).forEach(e=>{(e.conditions||[]).forEach(e=>{e._expressionMode=!!e.expression?.trim(),e._useExternalCard=!!e.card,e._useExternalDevice=!!e.device,e._conditionMode=Ud(e)})}),[{key:`triggers`,type:`input-array`,props:{label:`Triggers`,addLabel:`Add Trigger`},fieldArray:[{key:`name`,type:`input-accordion`,props:{placeholder:`Trigger name`,border:!1},fieldArray:[{key:`conditions`,type:`input-array`,props:{label:`Conditions`,required:!0},fieldArray:[{fieldGroupClassName:`d-flex flex-wrap align-items-end gap-4`,fieldGroup:[{key:`_conditionMode`,type:`input-select`,defaultValue:`field-current`,className:`w-100 max-w-15rem`,props:{label:`Condition type`,options:Fd,help:`Choose whether this condition uses fields or an expression, and whether it reads the current item, another card, or another device.`},hooks:{onModelChange:(e,t)=>{Wd(e,t)}}},{key:`card`,type:`input-cards`,hide:e=>!Vd(e),props:{label:`Card`,required:!0,placeholder:`Select card`,cards:i(),defaultZoneId:()=>e.zone},hooks:{onModelChange:(e,t)=>{delete t.key,delete t.operator,delete t.value}}},{key:`device`,type:`input-devices`,hide:e=>!Hd(e),props:{label:`Device`,required:!0,defaultZoneId:()=>e.zone},hooks:{onModelChange:(e,t)=>{delete t.key,delete t.operator,delete t.value}}}]},{fieldGroupClassName:`d-grid grid-columns-1 grid-columns-md-3 gap-4 align-items-end`,hide:e=>e?._expressionMode===!0||Vd(e)&&!e?.card||Hd(e)&&!e?.device,fieldGroup:[{key:`key`,type:`input-select`,props:{label:`Field`,options:(e,t)=>Id(o(t))}},{key:`operator`,type:`input-select`,defaultValue:`$eq`,hide:e=>!e?.key,props:{label:`Operator`,options:Nd}},{key:`value`,type:`input-text`,hide:e=>Bd(e)||![`string`,`image`,`button`,`form`,`list`,`chart`].includes(s(e)),props:{label:`Value`}},{key:`value`,type:`input-number`,hide:e=>Bd(e)||s(e)!==`number`,props:{label:`Value`}},{key:`value`,type:`input-select`,hide:e=>Bd(e)||s(e)!==`boolean`,props:{label:`Value`,options:Pd}},{key:`value`,type:`input-select`,hide:e=>Bd(e)||s(e)!==`enum`,props:{label:`Value`,options:(e,t)=>c(t)}}]},{key:`expression`,type:`input-code`,hide:e=>e?._expressionMode!==!0||Vd(e)&&!e?.card||Hd(e)&&!e?.device,props:{rows:2,help:`Use state to read fields from the condition source. Example: state.closed === false && state.mode === 'AUTO'`}}]},{key:`actions`,type:`input-script-actions`,props:{label:`Scripts`,required:!0,addLabel:`Add Script`,scripts:t,getWatchedDevices:n,getCards:()=>e._id?[{name:`card`,card:e._id}]:[],defaultZoneId:()=>e.zone}}]}]}]}var Kd=new Set([`string`,`number`,`boolean`,`enum`]),qd=(e,t)=>{let n=e?.name||e?.key||t;return t?`${n} (${t})`:n},Jd=(e=[],t=`fields`,n=``)=>e.flatMap((e,r)=>{if(!e?.key)return[];let i=`${t}.${r}`,a=n?`${n}.${e.key}`:e.key,o=Kd.has(e.type)?[{key:`${i}.history`,type:`input-toggle`,className:`mb-1`,props:{toggleLabel:qd(e,a)}}]:[];return Array.isArray(e.fields)&&o.push(...Jd(e.fields,`${i}.fields`,a)),o}),Yd=e=>{let t=Jd(e.fields||[]);return[{key:`history.enabled`,type:`input-toggle`,props:{label:`History`,toggleLabel:`Enabled`}},{fieldGroupClassName:`d-flex flex-wrap align-items-start gap-4`,fieldGroup:[{key:`history.retentionMs`,type:`input-unit`,className:`w-100 w-lg-25`,hide:e=>!e.history?.enabled,props:{label:`Retention`,placeholder:`Default 60 days`,type:`time`,defaultUnit:`d`,min:0}},{key:`history.throttleMs`,type:`input-unit`,className:`w-100 w-lg-25`,hide:e=>!e.history?.enabled,props:{label:`Throttle`,placeholder:`Disabled`,type:`time`,defaultUnit:`m`,min:0}}]},{type:`template`,hide:e=>!e.history?.enabled,template:v`
        <div class="mt-4 mb-2">
          <div class="fw-semibold">${j(`Fields`)}</div>
          <div class="form-text">${j(`Choose which card fields should be saved to history.`)}</div>
        </div>
      `},...t.map(e=>({...e,hide:e=>!e.history?.enabled}))]},Xd=[{id:`general`,label:`General`},{id:`fields`,label:`Fields`},{id:`styling`,label:`Styling`},{id:`triggers`,label:`Triggers`},{id:`state`,label:`State`},{id:`history`,label:`History`}],Zd=new Set([`string`,`number`,`boolean`,`enum`]);function Qd(e,t=!1){let n={};for(let[r,i]of Object.entries(e||{}))if(!(i===void 0||i===``||i===null&&!t)){if(i===null){n[r]=null;continue}if(typeof i==`object`&&!Array.isArray(i)){let e=Qd(i,t);e&&Object.keys(e).length>0&&(n[r]=e);continue}n[r]=i}return Object.keys(n).length>0?n:void 0}function $d(e=[]){return e.filter(e=>e?.key).map(ef)}function ef(e){let t={key:e.key};if(e.name&&(t.name=e.name),e.placeholder&&(t.placeholder=e.placeholder),e.defaultValue!==void 0&&e.defaultValue!==``&&(t.defaultValue=e.defaultValue),e.binding&&(t.binding=!0,e.bindingDevice&&e.bindingKey&&(t.value=`${e.bindingDevice}.state.${e.bindingKey}`)),e.type&&(t.type=e.type),!e.binding&&e.value&&(t.value=e.value),e.options&&Array.isArray(e.options)){let n=e.options.filter(e=>e?.name&&e?.value).map(e=>{let t={name:e.name,value:e.value};return e.icon&&(t.icon=e.icon),typeof e.width==`number`&&(t.width=e.width),t});n.length>0&&(t.options=n)}let n=e.type===`form`||e.type===`button`?!0:e.type===`image`?!1:e.control===!0;n&&(t.control=!0),e.history===!0&&Zd.has(e.type)&&(t.history=!0);let r=Qd(e.list||{},!0);r&&(t.list=r);let i=Qd(e.button||{});i&&(t.button=i),Object.prototype.hasOwnProperty.call(e,`className`)&&(t.className=e.className||``),Object.prototype.hasOwnProperty.call(e,`classNameExpression`)&&(t.classNameExpression=e.classNameExpression||``),typeof e.cooldownMs==`number`&&(t.cooldownMs=e.cooldownMs);let a=Qd(e.extra||{});a&&(t.extra=a);let o=$d(e.fields||[]);[`form`,`object`,`array-object`].includes(e.type)&&(t.fields=o);let s=(e.commands||[]).filter(e=>e?.script).map(e=>Qd(e,!0)).filter(Boolean);return!e.binding&&n&&s.length>0&&(t.commands=s),t}function tf(e=[],t,n=``){for(let r of e){let e=r?.key?`${n}${r.key}`:``;if(e===t)return r;if(Array.isArray(r?.fields)){let i=tf(r.fields,t,e?`${e}.`:n);if(i)return i}}}function nf(e=[],t=[]){return e.map(e=>{let n={...e};if(e.binding&&e.value){let r=rf(e.value);if(r){n.bindingDevice=r.device,n.bindingKey=r.key;let e=t.find(e=>e.name===r.device),i=e?.device?q.getState().getDeviceById(e.device):void 0,a=tf((i?.definition?K.getState().getDefinitionById(i.definition):void 0)?.fields||[],r.key);a?.type&&(n.type=a.type,n.control=a.control===!0)}}return!n.binding&&(n.type===`form`||n.type===`button`)?n.control=!0:!n.binding&&n.type===`image`&&(n.control=!1),n})}function rf(e){let t=e.split(`.`).filter(Boolean),n=t.indexOf(`state`);return n!==1||t.length<3?null:{device:t[0],key:t.slice(n+1).join(`.`)}}function af(e=[]){return e.filter(e=>e?.name&&e?.device).map(e=>({name:e.name,device:e.device}))}function of(e=[],t=[]){return e.map(e=>({...e.name?{name:e.name}:{},conditions:(e.conditions||[]).filter(e=>e?._expressionMode===!0?e?.expression?.trim()&&(!e?._useExternalCard||e?.card)&&(!e?._useExternalDevice||e?.device):e?.key&&(!e?._useExternalCard||e?.card)&&(!e?._useExternalDevice||e?.device)).map(e=>e._expressionMode===!0?{...e._useExternalCard||e.card?{card:e.card}:{},...e._useExternalDevice||e.device?{device:e.device}:{},expression:e.expression.trim()}:{...e._useExternalCard||e.card?{card:e.card}:{},...e._useExternalDevice||e.device?{device:e.device}:{},key:e.key,operator:e.operator||`$eq`,...e.operator===`$exists`?{}:{value:e.value}}),actions:Qu(e.actions||[],t,e=>Qd(e||{},!0)||{})})).filter(e=>e.conditions.length>0&&e.actions.length>0)}function sf(e=[],t=[]){return e.map(e=>{let n=e?.sequentialActions===!0,{sequentialActions:r,...i}=e||{};return{...i,actions:Zu((e?.actions||[]).map(e=>({...e,...n?{waitForCompletion:!0}:{}})),t)}})}async function cf(e){let t=e?.edit??!1,n=e?.data;e?.zoneId&&n?._id,await Promise.all([q.getState().fetchDevices(!0),L.getState().fetchDevices(),J.getState().fetchScripts()]);let r=I.getState().getFlatZonesWithParents(),i=q.getState().getDevices(),a=J.getState().getScripts(),o=r.map(e=>({value:e.id,label:e.fullPath})),s=i.map(e=>({value:e._id,label:e._fullName||e.name})),c={_id:n?._id,_tab:`general`,name:n?.name||``,zone:n?.zone||e?.zoneId||``,watchedDevices:n?.watchedDevices||[],fields:nf(n?.fields||[],n?.watchedDevices||[]),triggers:sf(n?.triggers||[],a),state:n?.state||{},history:n?.history||{enabled:!1},tags:n?.tags||[],order:n?.order||0,className:n?.className||``,classNameExpression:n?.classNameExpression||``,icon:n?.icon||``,onlineVisible:n?.onlineVisible??!1},l=null,u=()=>{let e=f(),t=l;if(t?.refreshForm){t.refreshForm(e,c);return}l&&(l.fields=e,l.requestUpdate())},d=e=>{c._tab=e.detail.tabId,u()},f=()=>[{type:`template`,template:v`
      <div class="mb-4">
        <app-button-tabs
          .tabs=${Xd}
          .activeTab=${c._tab}
          @tab-change=${d}
        ></app-button-tabs>
      </div>
      `},...cu(s,o,()=>c.watchedDevices||[],()=>c.zone).map(e=>({...e,hide:c._tab===`general`?e.hide:!0})),...xd(a,()=>c.watchedDevices||[]).map(e=>({...e,hide:c._tab===`fields`?e.hide:!0})),...jd(c).map(e=>({...e,hide:c._tab===`styling`?e.hide:!0})),...Gd(c,a,()=>c.watchedDevices||[]).map(e=>({...e,hide:c._tab===`triggers`?e.hide:!0})),...Md().map(e=>({...e,hide:c._tab===`state`?e.hide:!0})),...Yd(c).map(e=>({...e,hide:c._tab===`history`?e.hide:!0}))],p=e=>({name:e.name,zone:e.zone,watchedDevices:af(e.watchedDevices),fields:$d(e.fields),triggers:of(e.triggers,a),state:e.state||{},history:{enabled:e.history?.enabled===!0,...Number.isFinite(e.history?.retentionMs)?{retentionMs:e.history.retentionMs}:{},...Number.isFinite(e.history?.throttleMs)?{throttleMs:e.history.throttleMs}:{}},tags:Array.isArray(e.tags)?e.tags:[],order:e.order||void 0,className:e.className??``,classNameExpression:e.classNameExpression??``,icon:e.icon??``,onlineVisible:e.onlineVisible??!1}),m=await G({title:t?`Edit ${n?.name}`:`Add New Card`,width:`60rem`,fields:f(),advancedEditor:f,model:c,onFormReady:e=>{l=e},onAfterSubmit:async t=>{e?.onSubmit&&await e.onSubmit(p(t))}});return m?p(m):null}var lf=[{value:15e3,label:`15s`},{value:3e4,label:`30s`},{value:6e4,label:`60s`},{value:2*6e4,label:`2m`},{value:5*6e4,label:`5m`},{value:10*6e4,label:`10m`},{value:15*6e4,label:`15m`},{value:30*6e4,label:`30m`},{value:45*6e4,label:`45m`},{value:60*6e4,label:`1h`},{value:120*6e4,label:`2h`},{value:240*6e4,label:`4h`},{value:480*6e4,label:`8h`},{value:720*6e4,label:`12h`},{value:1440*6e4,label:`24h`}];async function uf(e){let{cardId:t,fieldKey:n,value:r,field:i}=e,a={mode:`now`,delayMs:5*6e4,runAt:ff()},o=await G({title:`Confirm: ${i.name||i.key}`,submitLabel:`Confirm`,width:`28rem`,model:a,fields:[{key:`mode`,type:`input-radio`,props:{label:`Action`,inline:!1,options:[{value:`now`,label:`Execute now`},{value:`delay`,label:`Execute after`},{value:`time`,label:`Execute at time`}]}},{key:`delayMs`,type:`input-range`,hide:e=>e.mode!==`delay`,props:{label:`Delay`,steps:lf,required:!0}},{key:`runAt`,type:`input-date`,hide:e=>e.mode!==`time`,props:{label:`Date and time`,placeholder:`YYYY-MM-DD HH:mm`,withTime:!0,futureOnly:!0,required:!0},validators:[{validate:e=>{let t=mf(String(e||``));return t&&t.getTime()>Date.now()?!0:`Select a future date and time.`}}]}]});if(!o)return!1;if(o.mode===`now`)return!0;let s=o.mode===`delay`?df(Number(o.delayMs)||5*6e4):mf(String(o.runAt||``));return s&&await L.getState().sendCommand(t,{key:n,...r===void 0?{}:{value:r},runAt:s.toISOString()}),!1}function df(e){let t=Math.max(1e3,e);return new Date(Date.now()+t)}function ff(){let e=new Date;return e.setHours(e.getHours()+1,0,0,0),pf(e)}function pf(e){return`${e.getFullYear()}-${String(e.getMonth()+1).padStart(2,`0`)}-${String(e.getDate()).padStart(2,`0`)} ${String(e.getHours()).padStart(2,`0`)}:${String(e.getMinutes()).padStart(2,`0`)}`}function mf(e){let t=e.trim().match(/^(\d{4})-(\d{2})-(\d{2}) (\d{2}):(\d{2})$/);if(!t)return null;let n=Number(t[1]),r=Number(t[2]),i=Number(t[3]),a=Number(t[4]),o=Number(t[5]),s=new Date(n,r-1,i,a,o,0,0);return s.getFullYear()!==n||s.getMonth()!==r-1||s.getDate()!==i||s.getHours()!==a||s.getMinutes()!==o?null:s}var hf=`nq-selected-zone-path`,gf=`nq-cards-home`,_f=320,vf=16,yf=4,bf=new Set([`button`,`form`,`enum`,`number`,`boolean`]),xf=class extends w{constructor(...e){super(...e),this.selectedPath=[],this.includeSubzones=!1,this.masonryLayouts={},this.masonryHeight=0,this.editMode=!1,this.onlineOnly=!1,this.commandCooldowns={},this.zoneEventSource=null,this.masonryRaf=0,this.commandCooldownTimers=new Map,this.handleVisibilityChange=()=>{document.hidden?this.unsubscribeFromZoneChanges():this.subscribeToZoneChanges()},this.handleCardsHome=e=>{let t=e.detail?.path;this.selectedPath=Array.isArray(t)?t:[],this.includeSubzones=!1,this.editMode=!1,this.onlineOnly=!1,this.masonryLayouts={},this.masonryHeight=0;for(let e of this.commandCooldownTimers.values())window.clearTimeout(e);this.commandCooldownTimers.clear(),this.commandCooldowns={},this.saveToStorage(),this.subscribeToZoneChanges(),window.scrollTo({top:0})}}connectedCallback(){super.connectedCallback(),this.loadFromStorage(),this.subscribeToZoneChanges(),document.addEventListener(`visibilitychange`,this.handleVisibilityChange),window.addEventListener(gf,this.handleCardsHome),this.resizeObserver=new ResizeObserver(()=>this.scheduleMasonryLayout())}disconnectedCallback(){super.disconnectedCallback(),this.unsubscribeFromZoneChanges(),document.removeEventListener(`visibilitychange`,this.handleVisibilityChange),window.removeEventListener(gf,this.handleCardsHome),this.resizeObserver?.disconnect(),this.masonryRaf&&cancelAnimationFrame(this.masonryRaf);for(let e of this.commandCooldownTimers.values())window.clearTimeout(e);this.commandCooldownTimers.clear()}updated(){this.cardsMasonry&&this.resizeObserver&&(this.resizeObserver.observe(this.cardsMasonry),this.cardsMasonry.querySelectorAll(`[data-card-id]`).forEach(e=>{this.resizeObserver?.observe(e)})),this.scheduleMasonryLayout()}subscribeToZoneChanges(){if(this.unsubscribeFromZoneChanges(),document.hidden||this.selectedPath.length===0)return;let e=this.selectedPath[this.selectedPath.length-1],t=window.APP_CONFIG?.apiUrl||``,n=Eo(),r=`${t}/api/zones/${e}/cards/changes`;this.zoneEventSource=new go(r,{headers:n?{Authorization:`Bearer ${n}`}:{}}),this.zoneEventSource.addEventListener(`connected`,e=>{try{let t=JSON.parse(e.data);if(console.log(`Connected to zone SSE:`,t),t.cards&&Array.isArray(t.cards))for(let e of t.cards)L.getState().updateDeviceState(e.cardId,e.state)}catch(e){console.error(`Failed to parse zone connected event:`,e)}}),this.zoneEventSource.addEventListener(`state-change`,e=>{try{let t=JSON.parse(e.data);console.log(`Zone card state change:`,t),t.type===`card-added`?L.getState().fetchDevices():t.cardId&&L.getState().updateDeviceState(t.cardId,t.state)}catch(e){console.error(`Failed to parse zone state change event:`,e)}}),this.zoneEventSource.onerror=t=>{console.error(`SSE error for zone ${e}:`,t)}}unsubscribeFromZoneChanges(){this.zoneEventSource&&=(this.zoneEventSource.close(),null)}loadFromStorage(){try{let e=localStorage.getItem(hf);if(e){let t=JSON.parse(e);Array.isArray(t)?(this.selectedPath=t,this.includeSubzones=!1):(this.selectedPath=Array.isArray(t?.path)?t.path:[],this.includeSubzones=!!t?.includeSubzones);return}let t=localStorage.getItem(`nq-cards-selected-zone`),n=localStorage.getItem(`nq-cards-selected-subzone`);t&&(this.selectedPath=n?[t,n]:[t],localStorage.removeItem(`nq-cards-selected-zone`),localStorage.removeItem(`nq-cards-selected-subzone`),this.saveToStorage())}catch(e){console.error(`Failed to load zone path from storage:`,e)}}saveToStorage(){try{localStorage.setItem(hf,JSON.stringify({path:this.selectedPath,includeSubzones:this.includeSubzones}))}catch(e){console.error(`Failed to save zone path to storage:`,e)}}getChildren(e){return this.zones?this.zones.filter(t=>t.parent===e).sort((e,t)=>e.order-t.order):[]}getAllDescendantIds(e){let t=[e],n=this.getChildren(e);for(let e of n)t.push(...this.getAllDescendantIds(e.id));return t}getCurrentCards(){if(this.selectedPath.length===0||!this.cards)return[];let e=this.selectedPath[this.selectedPath.length-1],t=this.includeSubzones?this.getAllDescendantIds(e):[e];return this.cards.filter(e=>t.includes(e.zone)).filter(e=>!this.onlineOnly||e.onlineVisible).sort((e,t)=>{let n=typeof e.order==`number`?e.order:2**53-1,r=typeof t.order==`number`?t.order:2**53-1;return n===r?(e.name||``).localeCompare(t.name||``,void 0,{sensitivity:`base`}):n-r})}getCurrentZoneIds(){if(this.selectedPath.length===0)return[];let e=this.selectedPath[this.selectedPath.length-1];return this.includeSubzones?this.getAllDescendantIds(e):[e]}getCardsForZone(e){return(this.cards||[]).filter(t=>t.zone===e).filter(e=>!this.onlineOnly||e.onlineVisible).sort((e,t)=>{let n=typeof e.order==`number`?e.order:2**53-1,r=typeof t.order==`number`?t.order:2**53-1;return n===r?(e.name||``).localeCompare(t.name||``,void 0,{sensitivity:`base`}):n-r})}isAllSubzonesView(){if(this.selectedPath.length===0)return!1;let e=this.selectedPath[this.selectedPath.length-1];return this.includeSubzones&&this.getChildren(e).length>0}handleMobileZoneChange(e){this.selectedPath=e.detail.path||[],this.includeSubzones=!!e.detail.includeSubzones,this.saveToStorage(),this.subscribeToZoneChanges()}async handleFieldChange(e){let{cardId:t,fieldKey:n,value:r,field:i,option:a,forceConfirm:o}=e.detail;console.log(`Field change:`,{cardId:t,fieldKey:n,value:r}),console.log(`Field definition:`,i);try{let e=i.type===`list`&&r&&typeof r==`object`&&!Array.isArray(r)&&(r.action===`check`||r.action===`delete`||Object.prototype.hasOwnProperty.call(r,`checked`)||r.delete===!0);if(i.control||i.commands?.length||e){if((i.extra?.confirm||o)&&!await uf({card:this.cards.find(e=>e._id===t),cardId:t,fieldKey:n,value:r,field:i,option:a}))return;let e=this.shouldUseFieldCooldown(i);e&&this.setCommandCooldown(t,n,this.getFieldCooldownMs(i));let s=r===void 0?{key:n}:{key:n,value:r};await L.getState().sendCommand(t,s),e&&this.setCommandCooldown(t,n,this.getFieldCooldownMs(i)),console.log(`Sent card command to card ${t}:`,{key:n,value:r})}else{let e={[n]:r};await L.getState().setDeviceState(t,e)}}catch(e){this.applyCommandCooldownFromError(t,n,i,e),console.error(`Failed to handle field change:`,e)}}applyCommandCooldownFromError(e,t,n,r){if(!this.shouldUseFieldCooldown(n))return;let i=r?.details,a=typeof i?.retryAfterMs==`number`?i.retryAfterMs:0;if(a>0){this.setCommandCooldown(e,t,a);return}this.clearCommandCooldown(e,t)}setCommandCooldown(e,t,n){let r=`${e}:${t}`,i=this.commandCooldownTimers.get(r);if(i&&(window.clearTimeout(i),this.commandCooldownTimers.delete(r)),n<=0){this.clearCommandCooldown(e,t);return}let a=window.setTimeout(()=>{this.commandCooldownTimers.delete(r),this.clearCommandCooldown(e,t)},n);this.commandCooldownTimers.set(r,a),this.commandCooldowns={...this.commandCooldowns,[r]:Date.now()+n}}clearCommandCooldown(e,t){let n=`${e}:${t}`,r=this.commandCooldownTimers.get(n);r&&(window.clearTimeout(r),this.commandCooldownTimers.delete(n));let{[n]:i,...a}=this.commandCooldowns;this.commandCooldowns=a}getFieldCooldownMs(e){return typeof e?.cooldownMs==`number`&&Number.isFinite(e.cooldownMs)?Math.max(0,e.cooldownMs):1e3}shouldUseFieldCooldown(e){return bf.has(e?.type||``)}getSelectedZoneId(){return this.selectedPath[this.selectedPath.length-1]}get isAdmin(){return this.userRole===`admin`}openChangeOrderDialog(){let e=this.getSelectedZoneId();e&&nu({zoneId:e})}async openCreateCardDialog(){let e=this.getSelectedZoneId();e&&await cf({zoneId:e,onSubmit:e=>L.getState().addDevice(e)})}async handleEditCard(e){let t=e.detail.card;t&&await cf({data:t,edit:!0,onSubmit:e=>L.getState().updateDevice(t._id,e)})}async handleRemoveCard(e){let t=e.detail.card;if(t)try{await z.open({title:j(`Remove card`),content:j(`Are you sure you want to delete "{{name}}"?`,{name:t.name}),buttons:[{label:j(`Cancel`),variant:`ghost`,action:()=>z.cancel()},{label:j(`Confirm`),variant:`danger`,action:()=>z.close(!0)}]}),await L.getState().deleteDevice(t._id)}catch{}}renderCard(e){return v`
			<nq-card
				.card=${e}
				.editMode=${this.editMode}
				.externalCommandCooldowns=${this.getCardCommandCooldowns(e._id)}
				@field-change=${this.handleFieldChange}
				@edit-card=${this.handleEditCard}
				@remove-card=${this.handleRemoveCard}
			></nq-card>
		`}getCardCommandCooldowns(e){let t=`${e}:`,n={};for(let[e,r]of Object.entries(this.commandCooldowns))e.startsWith(t)&&(n[e.slice(t.length)]=r);return n}renderZoneGroups(){let e=this.getCurrentZoneIds().map(e=>this.zones?.find(t=>t.id===e)).filter(e=>!!e).map(e=>({zone:e,cards:this.getCardsForZone(e.id)})).filter(e=>e.cards.length>0);return e.length===0?v`
				<div class="empty-state" style="min-height: 16rem;">
					<div class="text-center">
						<div class="fs-5 text-muted mb-2">${j(`No devices in this area`)}</div>
						<div class="text-secondary">Add devices to see them here</div>
					</div>
				</div>
			`:v`
			<div class="form-stack gap-8">
				${e.map(e=>v`
					<section>
						<div class="d-flex align-items-center gap-3 mb-3">
							<h2 class="fs-5 fw-semibold text-body m-0">${e.zone.name}</h2>
							<span class="text-muted">${e.cards.length}</span>
						</div>
						<div class="d-grid gap-4" style="grid-template-columns: repeat(auto-fill, minmax(min(100%, ${_f}px), 1fr));">
							${e.cards.map(e=>this.renderCard(e))}
						</div>
					</section>
				`)}
			</div>
		`}getMasonryColumnCount(e){return Math.max(1,Math.min(yf,Math.floor((e+vf)/336)))}snapMasonryTop(e,t){return t.filter(t=>t>=e&&t-e<=36).sort((e,t)=>e-t)[0]??e}snapMasonryHeight(e,t){return t.filter(t=>t>=e&&t-e<=28).sort((e,t)=>e-t)[0]??e}scheduleMasonryLayout(){this.masonryRaf||=requestAnimationFrame(()=>{this.masonryRaf=0,this.updateMasonryLayout()})}updateMasonryLayout(){let e=this.cardsMasonry;if(!e)return;let t=this.getCurrentCards(),n=e.clientWidth;if(!t.length||n<=0){this.masonryLayouts={},this.masonryHeight=0;return}let r=vf,i=this.getMasonryColumnCount(n),a=(n-r*(i-1))/i,o=Array(i).fill(0),s={};for(let n of t){let t=e.querySelector(`[data-card-id="${n._id}"]`),c=a*1+r*0;t&&(t.style.width=`${c}px`);let l=t?.offsetHeight||0,u=0,d=1/0;for(let e=0;e<=i-1;e+=1){let t=Math.max(...o.slice(e,e+1));t<d&&(d=t,u=e)}let f=this.snapMasonryTop(Number.isFinite(d)?d:0,o),p=u*(a+r),m=this.snapMasonryHeight(f+l+r,o);for(let e=u;e<u+1;e+=1)o[e]=m;s[n._id]={left:p,top:f,width:c}}let c=Math.max(0,...o)-r;this.hasMasonryLayoutChanged(s,c)&&(this.masonryLayouts=s,this.masonryHeight=c)}hasMasonryLayoutChanged(e,t){if(Math.abs(this.masonryHeight-t)>.5)return!0;let n=Object.keys(this.masonryLayouts),r=Object.keys(e);return n.length===r.length?r.some(t=>{let n=this.masonryLayouts[t],r=e[t];return!n||Math.abs(n.left-r.left)>.5||Math.abs(n.top-r.top)>.5||Math.abs(n.width-r.width)>.5}):!0}renderZoneActions(){return this.isAdmin?v`
			<app-dropdown
				align="right"
				.showIndicator=${!1}
				.trigger=${{variant:`ghost`,icon:ra,className:`p-1`,label:``}}
				.menu=${v`
					<app-dropdown-item
						label=${j(`Add card`)}
						.icon=${O}
						?disabled=${this.selectedPath.length===0}
						@item-click=${()=>this.openCreateCardDialog()}
					></app-dropdown-item>
					<app-dropdown-item
						label=${j(this.editMode?`Disable edit`:`Enable edit`)}
						.icon=${this.editMode?Nr:A}
						?disabled=${this.selectedPath.length===0}
						@item-click=${()=>{this.editMode=!this.editMode}}
					></app-dropdown-item>
					<app-dropdown-item
						label=${j(this.onlineOnly?`Show all cards`:`Show online cards`)}
						.icon=${this.onlineOnly?lo:co}
						?disabled=${this.selectedPath.length===0}
						@item-click=${()=>{this.onlineOnly=!this.onlineOnly}}
					></app-dropdown-item>
					<app-dropdown-item separator></app-dropdown-item>
					<app-dropdown-item
						label=${j(`Change order`)}
						.icon=${ha}
						?disabled=${this.selectedPath.length===0}
						@item-click=${()=>this.openChangeOrderDialog()}
					></app-dropdown-item>
				`}
			></app-dropdown>
		`:null}render(){let e=this.getCurrentCards(),t=this.isAllSubzonesView();return v`
			<div>
				<select-zone
					.selectedPath=${this.selectedPath}
					.includeSubzones=${this.includeSubzones}
					.desktopActions=${this.isAdmin?this.renderZoneActions():null}
					@zone-change=${this.handleMobileZoneChange}
				></select-zone>

				${this.selectedPath.length===0?v`
					<div class="empty-state" style="min-height: 16rem;">
						<div class="text-center">
							<div class="fs-5 text-muted mb-2">Select a zone to view devices</div>
							<div class="text-secondary">Choose a zone from the tabs above</div>
						</div>
					</div>
				`:t?v`
					${this.renderZoneGroups()}
				`:e.length===0?v`
					<div class="empty-state" style="min-height: 16rem;">
						<div class="text-center">
							<div class="fs-5 text-muted mb-2">${j(`No devices in this area`)}</div>
							<div class="text-secondary">Add devices to see them here</div>
						</div>
					</div>
				`:v`
					<div id="cards-masonry" class="card-masonry" style=${`height: ${this.masonryHeight}px; min-height: ${this.masonryHeight?this.masonryHeight:1}px;`}>
						${e.map(e=>v`
							<div
								data-card-id=${e._id}
								class="card-masonry-item"
								style=${`
									left: ${this.masonryLayouts[e._id]?.left||0}px;
									top: ${this.masonryLayouts[e._id]?.top||0}px;
									width: ${this.masonryLayouts[e._id]?.width||_f}px;
								`}
							>
								${this.renderCard(e)}
							</div>
						`)}
					</div>
				`}
			</div>
		`}};D([Qe(`#cards-masonry`)],xf.prototype,`cardsMasonry`,void 0),D([H(I,e=>e.zones)],xf.prototype,`zones`,void 0),D([H(L,e=>e.devices)],xf.prototype,`cards`,void 0),D([H(F,e=>e.user?.role)],xf.prototype,`userRole`,void 0),D([C()],xf.prototype,`selectedPath`,void 0),D([C()],xf.prototype,`includeSubzones`,void 0),D([C()],xf.prototype,`masonryLayouts`,void 0),D([C()],xf.prototype,`masonryHeight`,void 0),D([C()],xf.prototype,`editMode`,void 0),D([C()],xf.prototype,`onlineOnly`,void 0),D([C()],xf.prototype,`commandCooldowns`,void 0),xf=D([x(`cards-grid-view`)],xf);var Sf=`provider-saved-commands`,Cf=()=>{try{let e=localStorage.getItem(Sf);return e?JSON.parse(e):{}}catch{return{}}},wf=e=>{localStorage.setItem(Sf,JSON.stringify(e))},Tf=(e,t)=>{let n=e.findIndex(e=>e._id===t._id);if(n===-1)return[...e,t];let r={...e[n],...t};return e.map((e,t)=>t===n?r:e).filter((e,r)=>e._id!==t._id||r===n)},Y=po()((e,t)=>({providers:[],definitions:{},devices:{},savedCommands:Cf(),loading:!1,getProviders:()=>t().providers,fetchProviders:async(n=!1)=>{t().providers.length>0&&!n||(e({loading:!0}),e({providers:await N.get(`/providers`),loading:!1}))},addProvider:async n=>{let r=await N.post(`/providers`,n);e({providers:Tf(t().providers,r)})},removeProvider:async n=>{await N.delete(`/providers/${n}`),e({providers:t().providers.filter(e=>e._id!==n)})},updateProvider:async(n,r)=>{let i=await N.put(`/providers/${n}`,r);e({providers:t().providers.map(e=>e._id===n?i:e)})},disableProvider:async n=>{let r=await N.post(`/providers/${n}/disable`,{});e({providers:t().providers.map(e=>e._id===n?r:e)})},enableProvider:async n=>{let r=await N.post(`/providers/${n}/enable`,{});e({providers:t().providers.map(e=>e._id===n?r:e)})},reconnectProvider:async n=>{let r=await N.post(`/providers/${n}/reconnect`,{});e({providers:t().providers.map(e=>e._id===n?r:e)})},getProviderById:e=>t().providers.find(t=>t._id===e),updateProviderStatus:n=>{e({providers:Tf(t().providers,n)})},fetchDefinitions:async(n,r=!1)=>{if(t().definitions[n]?.length>0&&!r)return;e({loading:!0});let i=await N.get(`/providers/${n}/definitions`);e({definitions:{...t().definitions,[n]:i},loading:!1})},fetchDevices:async(n,r=!1)=>{if(t().devices[n]?.length>0&&!r)return;e({loading:!0});let i=await N.get(`/providers/${n}/devices`);e({devices:{...t().devices,[n]:i},loading:!1})},getDefinitions:e=>t().definitions[e]||[],getDefinitionById:async(e,n)=>(t().definitions[e]||await t().fetchDefinitions(e),(t().definitions[e]||[]).find(e=>e.id===n)),getProviderDevices:e=>t().devices[e]||[],updateDevice:(n,r,i)=>{let a=(t().devices[n]||[]).map(e=>e.externalId===r?{...e,...i}:e);e({devices:{...t().devices,[n]:a}})},getSavedCommands:e=>t().savedCommands[e]||[],addSavedCommand:(n,r,i)=>{let a={...t().savedCommands};a[n]=[...a[n]||[],{id:yo(),topic:r,payload:i}],e({savedCommands:a}),wf(a)},removeSavedCommand:(n,r)=>{let i={...t().savedCommands};i[n]=(i[n]||[]).filter(e=>e.id!==r),e({savedCommands:i}),wf(i)},updateSavedCommand:(n,r,i,a)=>{let o={...t().savedCommands};o[n]=(o[n]||[]).map(e=>e.id===r?{...e,topic:i,payload:a}:e),e({savedCommands:o}),wf(o)}})),Ef=[{id:`general`,label:`General`},{id:`state`,label:`State`},{id:`translations`,label:`Translations`},{id:`triggers`,label:`Triggers`}],Df=[{value:`$eq`,label:`=`},{value:`$ne`,label:`!=`},{value:`$gt`,label:`>`},{value:`$gte`,label:`>=`},{value:`$lt`,label:`<`},{value:`$lte`,label:`<=`},{value:`$in`,label:`in`},{value:`$nin`,label:`not in`},{value:`$exists`,label:`exists`}],Of=[{value:!0,label:`True`},{value:!1,label:`False`},{value:null,label:`Null`},{value:void 0,label:`Undefined`}],kf=[{value:`field-current`,label:`Current fields`},{value:`field-card`,label:`Other card fields`},{value:`field-device`,label:`Other device fields`},{value:`expression-current`,label:`Current expression`},{value:`expression-card`,label:`Other card expression`},{value:`expression-device`,label:`Other device expression`}];function Af(e,t=!1){let n={};for(let[r,i]of Object.entries(e||{}))if(!(i===void 0||i===``||i===null&&!t)){if(i===null){n[r]=null;continue}if(typeof i==`object`&&!Array.isArray(i)){let e=Af(i,t);e&&Object.keys(e).length>0&&(n[r]=e);continue}n[r]=i}return Object.keys(n).length>0?n:void 0}function jf(e=[],t=[]){return e.map(e=>({...e.name?{name:e.name}:{},conditions:(e.conditions||[]).filter(e=>e?._expressionMode===!0?e?.expression?.trim()&&(!e?._useExternalCard||e?.card)&&(!e?._useExternalDevice||e?.device):e?.key&&(!e?._useExternalCard||e?.card)&&(!e?._useExternalDevice||e?.device)).map(e=>e._expressionMode===!0?{...e._useExternalCard||e.card?{card:e.card}:{},...e._useExternalDevice||e.device?{device:e.device}:{},expression:e.expression.trim()}:{...e._useExternalCard||e.card?{card:e.card}:{},...e._useExternalDevice||e.device?{device:e.device}:{},key:e.key,operator:e.operator||`$eq`,...e.operator===`$exists`?{}:{value:e.value}}),actions:Qu(e.actions||[],t,e=>Af(e||{},!0)||{})})).filter(e=>e.actions.length>0)}function Mf(e=[],t=[]){return e.map(e=>{let n=e?.sequentialActions===!0,{sequentialActions:r,...i}=e||{};return{...i,actions:Zu((e?.actions||[]).map(e=>({...e,...n?{waitForCompletion:!0}:{}})),t)}})}function Nf(e){let t=e;return t.type===`boolean`?[t.extra?.valueTrue??`true`,t.extra?.valueFalse??`false`].map(String):t.type===`enum`&&Array.isArray(t.values)?t.values.map(e=>String(typeof e==`string`?e:e.value)):[]}function Pf(e){return e.type===`boolean`?Nf(e).map((e,t)=>({key:e,label:`${t===0?`True`:`False`} (${e})`,placeholder:e})):(e.type,Nf(e).map(e=>({key:e,label:e,placeholder:e})))}function Ff(e=[]){return e.flatMap(e=>e.type===`form`?[]:e.key?[e]:[])}function If(e={}){let t={};for(let[n,r]of Object.entries(e||{})){let e=typeof r?.key==`string`?r.key.trim():``,i={};for(let[e,t]of Object.entries(r?.value||{}))typeof t==`string`&&t.trim()&&(i[e]=t.trim());(e||Object.keys(i).length>0)&&(t[n]={...e?{key:e}:{},...Object.keys(i).length>0?{value:i}:{}})}return t}function Lf(){return[{fieldGroupClassName:`d-grid grid-columns-1 grid-columns-md-2 gap-4`,fieldGroup:[{key:`name`,type:`input-text`,props:{label:`Name`,placeholder:`Enter device name`,required:!0}},{key:`definition`,type:`input-select`,props:{label:`Definition`,required:!0,options:K.getState().getDefinitions().map(e=>({label:e.name,value:e._id}))}}]},{key:`zone`,type:`input-select`,props:{label:`Zone`,required:!0,options:I.getState().getFlatZonesWithParents().map(e=>({label:e.fullPath,value:e.id}))}},{fieldGroupClassName:`d-grid grid-columns-1 grid-columns-md-2 gap-4`,fieldGroup:[{key:`provider`,type:`input-select`,props:{label:`Provider`,required:!0,options:Y.getState().getProviders().map(e=>({label:e.name,value:e._id}))}},{key:`externalId`,type:`input-text`,props:{label:`External ID`,required:!0}}]},{key:`tags`,type:`input-array-text`,props:{label:`Tags`,type:`string`,options:()=>q.getState().getTags()}}]}function Rf(){return[{key:`state`,type:`input-json`,defaultValue:{},props:{rows:12}}]}function zf(e,t,n){let r=e=>e?._useExternalCard===!0||!!e?.card,i=e=>e?._useExternalDevice===!0||!!e?.device,a=e=>{let t=e?._expressionMode===!0||!!e?.expression?.trim(),n=r(e),a=i(e);return t&&a?`expression-device`:t&&n?`expression-card`:t?`expression-current`:a?`field-device`:n?`field-card`:`field-current`},o=(e,t)=>{let n=e.startsWith(`expression-`),r=e===`field-card`||e===`expression-card`,i=e===`field-device`||e===`expression-device`;t._expressionMode=n,t._useExternalCard=r,t._useExternalDevice=i,r||delete t.card,i||delete t.device,n?(delete t.key,delete t.operator,delete t.value):delete t.expression},s=()=>L.getState().devices||[],c=e=>s().find(t=>t._id===e?.card)?.fields||[],l=e=>{let t=q.getState().getDeviceById(e?.device);return t?.definition&&K.getState().getDefinitionById(t.definition)?.fields||[]},u=e=>i(e)?l(e):r(e)?c(e):n,d=e=>u(e).find(t=>t.key===e?.key),f=e=>d(e)?.type||`string`,p=e=>!e?.key||e?.operator===`$exists`,m=e=>{let t=d(e);return(t?.options?.length?t.options:t?.values||[]).map(e=>typeof e==`string`?{value:e,label:e}:{value:e?.value??e?.key??e?.name??String(e),label:e?.name??e?.label??e?.value??String(e)})};return(e.triggers||[]).forEach(e=>{(e.conditions||[]).forEach(e=>{e._expressionMode=!!e.expression?.trim(),e._useExternalCard=!!e.card,e._useExternalDevice=!!e.device,e._conditionMode=a(e)})}),[{key:`triggers`,type:`input-array`,props:{addLabel:`Add Trigger`},fieldArray:[{key:`name`,type:`input-accordion`,props:{placeholder:`Trigger name`,border:!1},fieldArray:[{key:`conditions`,type:`input-array`,props:{label:`Conditions`},fieldArray:[{fieldGroupClassName:`d-flex flex-wrap align-items-end gap-4`,fieldGroup:[{key:`_conditionMode`,type:`input-select`,defaultValue:`field-current`,className:`w-100 max-w-15rem`,props:{label:`Condition type`,options:kf,help:`Choose whether this condition uses fields or an expression, and whether it reads the current item, another card, or another device.`},hooks:{onModelChange:(e,t)=>{o(e,t)}}},{key:`card`,type:`input-cards`,hide:e=>!r(e),props:{label:`Card`,required:!0,placeholder:`Select card`,cards:s(),defaultZoneId:()=>e.zone},hooks:{onModelChange:(e,t)=>{delete t.key,delete t.operator,delete t.value}}},{key:`device`,type:`input-devices`,hide:e=>!i(e),props:{label:`Device`,required:!0,defaultZoneId:()=>e.zone},hooks:{onModelChange:(e,t)=>{delete t.key,delete t.operator,delete t.value}}}]},{fieldGroupClassName:`d-grid grid-columns-1 grid-columns-md-3 gap-4 align-items-end`,hide:e=>e?._expressionMode===!0||r(e)&&!e?.card||i(e)&&!e?.device,fieldGroup:[{key:`key`,type:`input-select`,props:{label:`Field`,options:(e,t)=>u(t).map(e=>({value:e.key,label:e.name||e.key}))}},{key:`operator`,type:`input-select`,defaultValue:`$eq`,hide:e=>!e?.key,props:{label:`Operator`,options:Df}},{key:`value`,type:`input-text`,hide:e=>p(e)||![`string`,`image`,`button`,`object`,`array`,`form`,`list`,`chart`].includes(f(e)),props:{label:`Value`}},{key:`value`,type:`input-number`,hide:e=>p(e)||f(e)!==`number`,props:{label:`Value`}},{key:`value`,type:`input-select`,hide:e=>p(e)||f(e)!==`boolean`,props:{label:`Value`,options:Of}},{key:`value`,type:`input-select`,hide:e=>p(e)||f(e)!==`enum`,props:{label:`Value`,options:(e,t)=>m(t)}}]},{key:`expression`,type:`input-code`,hide:e=>e?._expressionMode!==!0||r(e)&&!e?.card||i(e)&&!e?.device,props:{rows:2,help:`Use state to read fields from the condition source. Example: state.closed === false && state.mode === 'AUTO'`}}]},{key:`actions`,type:`input-script-actions`,props:{label:`Scripts`,required:!0,addLabel:`Add Script`,scripts:t,getWatchedDevices:()=>e._id?[{name:`device`,device:e._id}]:[],includeValue:!1,defaultZoneId:()=>e.zone}}]}]}]}function Bf(e){let t=Ff(e);return t.length===0?[{type:`template`,template:v`<div class="text-sm text-midnight-400">${j(`No definition fields available.`)}</div>`}]:[...t.map(e=>{let t=Pf(e),n=e.name||e.key,r=`${n} (${e.key})`,i=[{key:`translations.${e.key}.key`,type:`input-text`,className:`grid-column-md-span-4`,props:{label:r,placeholder:n}}];return t.forEach(t=>{i.push({key:`translations.${e.key}.value.${t.key}`,type:`input-text`,className:`grid-column-md-span-2`,props:{label:t.label,placeholder:t.placeholder}})}),{fieldGroupClassName:`d-grid grid-columns-1 grid-columns-md-12 gap-4 border rounded mb-2 p-4`,fieldGroup:i}})]}async function Vf(e){let{device:t}=e||{};if(!t)return null;await Promise.all([K.getState().fetchDefinitions(),Y.getState().fetchProviders(),q.getState().fetchDevices(),L.getState().fetchDevices(),J.getState().fetchScripts()]);let n=J.getState().getScripts(),r={...t,_tab:`general`,state:t.state||{},triggers:Mf(t.triggers||[],n),translations:t.translations||{},tags:t.tags||[]},i=null,a=()=>K.getState().getDefinitionById(r.definition||t.definition)?.fields||[],o=()=>[{type:`template`,template:v`
        <app-button-tabs
          .tabs=${Ef}
          .activeTab=${r._tab}
          class="d-block mb-4"
          @tab-change=${e=>{r._tab=e.detail.tabId;let t=o(),n=i;if(n?.refreshForm){n.refreshForm(t,r);return}i&&(i.fields=t,i.requestUpdate())}}
        ></app-button-tabs>
      `},...Lf().map(e=>({...e,hide:r._tab===`general`?e.hide:!0})),...Rf().map(e=>({...e,hide:r._tab===`state`?e.hide:!0})),...Bf(a()).map(e=>({...e,hide:r._tab===`translations`?e.hide:!0})),...zf(r,n,a()).map(e=>({...e,hide:r._tab===`triggers`?e.hide:!0}))];return await G({title:`Device: ${t.name}`,width:`60rem`,fields:o(),advancedEditor:o,model:r,onFormReady:e=>{i=e},onBeforeSubmit:async()=>(await q.getState().updateDevice(r._id,{name:r.name,zone:r.zone,externalId:r.externalId,provider:r.provider,tags:r.tags||[],metadata:r.metadata||{},state:r.state||{},definition:r.definition,translations:If(r.translations||{}),triggers:jf(r.triggers||[],n)}),!0)})}var Hf=class extends w{constructor(...e){super(...e),this.items=[],this.config={},this.label=``}getValue(e,t,n=``){return!t||!e||typeof e!=`object`?n:t.split(`.`).reduce((e,t)=>e?.[t],e)??n}emitAction(e,t,n,r){let i=this.config.item?.id||`id`;this.dispatchEvent(new CustomEvent(`list-${e}`,{detail:{index:n,id:this.getValue(t,i,n),item:t,...r===void 0?{}:{checked:r}},bubbles:!0,composed:!0}))}render(){let e=Array.isArray(this.items)?this.items:[],t=this.config.item?.title||`title`,n=this.config.item?.description||`description`,r=this.config.item?.badge,i=this.config.check?.checkedKey||`completed`;return v`
      <div>
        ${this.label?v`
          <div class="d-flex align-items-center justify-content-between gap-3 mb-2">
            <div class="field-label">${this.label}</div>
            <div class="small text-muted">${e.length}</div>
          </div>
        `:``}
        ${e.length===0?v`
          <div class="empty-state">
            ${j(`No items`)}
          </div>
        `:v`
          <div class="list-group">
            ${e.map((e,a)=>{let o=typeof e==`object`&&!!e&&!Array.isArray(e),s=o?this.getValue(e,t,e.name||e.id||`Item ${a+1}`):e,c=o?this.getValue(e,n):``,l=o?this.getValue(e,r):``,u=this.config.check?.enabled===!0&&o,d=u&&!!this.getValue(e,i,!1);return v`
                <div class="list-group-item">
                  ${u?v`
                    <button
                      type="button"
                      class="form-check-mark ${d?`is-checked`:``}"
                      title=${d?`Uncheck`:`Check`}
                      @click=${()=>this.emitAction(`check`,e,a,!d)}
                    >
                      ${d?v`
                        <svg class="form-check-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M5 13l4 4L19 7"></path>
                        </svg>
                      `:``}
                    </button>
                  `:``}
                  <div class="min-w-0 flex-grow-1">
                    <div class="d-flex align-items-start gap-2">
                      <div class="min-w-0 flex-grow-1 text-break field-value">${s}</div>
                      ${l?v`
                        <span class="badge badge-sm">
                          ${l}
                        </span>
                      `:``}
                    </div>
                    ${c?v`
                      <div class="small text-muted text-break">${c}</div>
                    `:``}
                  </div>
                  ${this.config.delete?.enabled?v`
                    <button
                      type="button"
                      class="btn btn-plain btn-danger btn-square"
                      title="Delete"
                      @click=${()=>this.emitAction(`delete`,e,a)}
                    >
                      <app-icon .icon=${_r} size="16"></app-icon>
                    </button>
                  `:``}
                </div>
              `})}
          </div>
        `}
      </div>
    `}};D([S({type:Array})],Hf.prototype,`items`,void 0),D([S({type:Object})],Hf.prototype,`config`,void 0),D([S({type:String})],Hf.prototype,`label`,void 0),Hf=D([x(`nq-device-list`)],Hf);var Uf=class extends w{constructor(...e){super(...e),this.fields=[],this.editable=!1,this.showStateAsJson=!1}isStructuredValue(e){return typeof e==`object`&&!!e}getNestedFieldLabel(e){return e.name||e.key}formatPrimitiveValue(e,t){if(t==null||t===``)return t;if(typeof t==`boolean`)return j(t?`True`:`False`);if(e.type===`date`){let e=new Date(`${t}T00:00:00`);return Number.isNaN(e.getTime())?t:e.toLocaleDateString()}if(e.type===`datetime`){let e=new Date(t);return Number.isNaN(e.getTime())?t:e.toLocaleString()}return e.type===`time`?String(t).slice(0,5):t}renderStateValue(e){return this.renderNestedValue(e.field||e,e.value,e.suffix)}renderStateField(e){return this.isStructuredValue(e.value)?v`
        <div class="py-2 border-bottom border-subtle">
          <div class="field-label mb-1">${e.name}</div>
          <div class="min-w-0 w-100">${this.renderStateValue(e)}</div>
        </div>
      `:v`
      <div class="field-row">
        <span class="field-label">${e.name}:</span>
        <div class="d-flex align-items-center justify-content-end gap-2 min-w-0 text-right">
          <div class="field-value min-w-0 text-break">${this.renderStateValue(e)}</div>
          ${this.editable?v`
            <app-button
              variant="ghost"
              size="sm"
              .className=${`field-row-action`}
              .icon=${A}
              @click=${()=>this.emitEditField(e)}
            ></app-button>
          `:``}
        </div>
      </div>
    `}renderNestedValue(e,t,n){if(t==null)return v`<span class="text-muted">-</span>`;if(e.type===`color`&&this.isStructuredValue(t)&&`x`in t&&`y`in t)return v`<div class="border rounded" style="width: 1.5rem; height: 1.5rem; background-color: ${Uc(t.x,t.y)}"></div>`;if(e.type===`image`){let n=String(t||``);return n?v`
        <auth-image
          src=${n}
          alt=${this.getNestedFieldLabel(e)}
          imageClass="w-100 rounded border border-subtle bg-body-secondary object-fit-contain"
          loading="lazy"
        ></auth-image>
      `:v`<span class="text-muted">-</span>`}if(e.type===`icon`){let e=String(t||``);return e?v`<app-icon .name=${e} size="32" class="text-body"></app-icon>`:v`<span class="text-muted">-</span>`}if(e.type===`list`)return v`
        <nq-device-list
          .items=${Array.isArray(t)?t:[]}
          .config=${e.list||{}}
          @list-check=${t=>this.emitListAction(`check`,e,t.detail)}
          @list-delete=${t=>this.emitListAction(`delete`,e,t.detail)}
        ></nq-device-list>
      `;if(Array.isArray(t)){if(t.length===0)return v`<span class="text-muted">[]</span>`;let n=Array.isArray(e.fields)?e.fields:[];return v`
        <div class="d-flex flex-column gap-2 text-left">
          ${t.map((e,t)=>v`
            <div class="border border-subtle rounded p-3 bg-body-secondary">
              <div class="mb-2 small fw-semibold text-uppercase text-muted">#${t+1}</div>
              ${n.length&&this.isStructuredValue(e)?this.renderNestedFields(n,e):this.renderFallbackJson(e)}
            </div>
          `)}
        </div>
      `}if(this.isStructuredValue(t)){let n=Array.isArray(e.fields)?e.fields:[];return n.length?v`<div class="w-100 border border-subtle rounded p-3 bg-body-secondary text-left">${this.renderNestedFields(n,t)}</div>`:this.renderFallbackJson(t)}return v`
      <span class="field-value text-break">
        ${this.formatPrimitiveValue(e,t)}${n?` `+n:``}
      </span>
    `}renderNestedFields(e,t){let n=new Set(e.map(e=>e.key)),r=Object.keys(t||{}).filter(e=>!n.has(e));return v`
      <div class="d-flex flex-column gap-1">
        ${e.filter(e=>t?.[e.key]!==void 0&&t?.[e.key]!==null).map(e=>v`
            <div class="d-flex justify-content-between gap-3 py-1">
              <span class="text-muted">${this.getNestedFieldLabel(e)}:</span>
              <div class="min-w-0 text-right text-break">${this.renderNestedValue(e,t[e.key],e.extra?.suffix)}</div>
            </div>
          `)}
        ${r.map(e=>v`
          <div class="d-flex justify-content-between gap-3 py-1">
            <span class="text-muted">${e}:</span>
            <div class="min-w-0 text-right text-break">${this.renderNestedValue({key:e,name:e,type:this.isStructuredValue(t[e])?`object`:`string`},t[e])}</div>
          </div>
        `)}
      </div>
    `}renderFallbackJson(e){return v`
      <pre class="overflow-auto text-break rounded bg-body-secondary p-3 small text-muted font-monospace" style="max-height: 16rem; white-space: pre-wrap;">${JSON.stringify(e,null,2)}</pre>
    `}emitEditField(e){this.dispatchEvent(new CustomEvent(`edit-field`,{detail:{fieldKey:e.key,field:e.field},bubbles:!0,composed:!0}))}emitListAction(e,t,n){this.dispatchEvent(new CustomEvent(`list-action`,{detail:{action:e,field:t,...n},bubbles:!0,composed:!0}))}render(){return this.stateValue?v`
      <div class="d-flex flex-column min-h-0">
        <div class="d-flex align-items-center justify-content-between">
          <h4 class="mt-0">${j(`Current State`)}</h4>
          <input-toggle
            .key=${`showStateAsJson`}
            .value=${this.showStateAsJson}
            .model=${{showStateAsJson:this.showStateAsJson}}
            class="mt-n4"
            .props=${{toggleLabel:`Show as JSON`}}
            @field-change=${e=>{this.showStateAsJson=e.detail.value}}
          ></input-toggle>
        </div>
        <div class="card p-3 flex-grow-1 min-h-0 overflow-auto" style="max-height: calc(100vh - 24rem);">
          ${this.showStateAsJson?v`
            <pre class="overflow-auto text-break rounded bg-body-secondary p-3 small text-muted font-monospace" style="max-height: 24rem; white-space: pre-wrap;">${JSON.stringify(this.stateValue,null,2)}</pre>
          `:v`
            <div class="card-content">
              ${this.fields.map(e=>this.renderStateField(e))}
            </div>
          `}
        </div>
      </div>
    `:``}};D([S({type:Object})],Uf.prototype,`stateValue`,void 0),D([S({type:Array})],Uf.prototype,`fields`,void 0),D([S({type:Boolean})],Uf.prototype,`editable`,void 0),D([C()],Uf.prototype,`showStateAsJson`,void 0),Uf=D([x(`nq-current-state`)],Uf);var Wf=class extends w{constructor(...e){super(...e),this.loading=!1,this.items=[],this.total=0,this.error=null}async load(e){if(this.device?._id){this.loading=!0,this.error=null;try{let t=await q.getState().getDeviceHistory(this.device._id,e);this.items=t.items||[],this.total=t.total||0}catch(e){this.error=e?.message||`Failed to load device history`}finally{this.loading=!1}}}get columns(){let e=this.definition?.history?.fields||[];return e.length>0?[{key:`timestamp`,label:`Time`,sortable:!0,type:`date`},...e.map(e=>{let t=e.name;return{key:`state.${t}`,label:t,sortable:!0,type:`text`,renderCell:e=>v`<span class="small text-body">${Gf(e)}</span>`}})]:[{key:`timestamp`,label:`Time`,sortable:!0,type:`date`},{key:`state`,label:`State`,sortable:!1,renderCell:(e,t)=>{let n=Object.entries(t.state||{});return n.length===0?v`<span class="text-muted">${j(`Empty`)}</span>`:v`
						<div class="d-flex flex-column gap-1 small">
							${n.slice(0,20).map(([e,t])=>v`
								<div class="d-flex gap-2">
									<span class="text-muted">${e}:</span>
									<span class="text-body">${Gf(t)}</span>
								</div>
							`)}
							${n.length>20?v`<div class="text-muted">...and ${n.length-20} more</div>`:``}
						</div>
					`}}]}render(){if(!this.device)return v``;let e={id:`device-history-${this.device._id}`,mode:`api`,total:this.total,loading:this.loading,sort:`-timestamp`,saveState:!0,onParamsChange:e=>{this.load(e)}};return v`
			<div>
				${this.error?v`
					<div class="p-3 mb-3 bg-surface-subtle rounded text-danger small">${this.error}</div>
				`:``}

				<nq-table
					.data=${this.items}
					.columns=${this.columns}
					.options=${e}
				></nq-table>
			</div>
		`}};D([S({type:Object})],Wf.prototype,`device`,void 0),D([S({type:Object})],Wf.prototype,`definition`,void 0),D([C()],Wf.prototype,`loading`,void 0),D([C()],Wf.prototype,`items`,void 0),D([C()],Wf.prototype,`total`,void 0),D([C()],Wf.prototype,`error`,void 0),Wf=D([x(`content-history-device`)],Wf);function Gf(e){if(e===void 0)return`undefined`;if(e===null)return`null`;if(typeof e==`string`)return e;if(typeof e==`number`||typeof e==`boolean`)return String(e);try{let t=JSON.stringify(e);return t.length>80?t.slice(0,77)+`...`:t}catch{return`[unserializable]`}}function Kf(e){return e.type===`boolean`?[e.extra?.valueTrue||`true`,e.extra?.valueFalse||`false`]:e.type===`enum`&&e.values?e.values.map(e=>typeof e==`string`?e:e.value):[]}async function qf(e){let{deviceId:t,fieldKey:n,fieldName:r,translation:i,field:a,currentTranslations:o}=e,s=Kf(a),c={keyName:i.key||r,...Object.fromEntries(s.map(e=>[`value_${e}`,i.value?.[e]||``]))},l=[{key:`keyName`,type:`input-text`,props:{label:`Field Label`,placeholder:r,helperText:`Original: ${r}`}}];if(s.length>0&&s.forEach(e=>{l.push({key:`value_${e}`,type:`input-text`,props:{label:`Value: ${e}`,placeholder:e}})}),await G({title:`Edit Translation: ${n}`,model:c,fields:l,width:`30rem`,onBeforeSubmit:async()=>{let e={};s.forEach(t=>{let n=c[`value_${t}`];n&&n.trim()&&(e[t]=n.trim())});let i={key:c.keyName===r?void 0:c.keyName,value:Object.keys(e).length>0?e:void 0},a={...o};i.key||i.value?a[n]=i:delete a[n];try{return await N.patch(`/devices/${t}/translations`,{translations:a}),await q.getState().fetchDevices(!0),!0}catch(e){return console.error(`Failed to update translations:`,e),alert(`Failed to update translations: `+(e.message||`Unknown error`)),!1}}})){let e={};return s.forEach(t=>{let n=c[`value_${t}`];n&&n.trim()&&(e[t]=n.trim())}),{key:c.keyName===r?void 0:c.keyName,value:Object.keys(e).length>0?e:void 0}}return null}var Jf=[{id:`general`,label:`General`},{id:`history`,label:`History`}],Yf=[{value:`string`,label:`String`},{value:`number`,label:`Number`},{value:`boolean`,label:`Boolean`},{value:`enum`,label:`Enum`},{value:`button`,label:`Button`},{value:`image`,label:`Image`},{value:`icon`,label:`Icon`},{value:`color`,label:`Color`},{value:`date`,label:`Date`},{value:`time`,label:`Time`},{value:`datetime`,label:`Date & time`},{value:`list`,label:`List`},{value:`form`,label:`Form`},{value:`object`,label:`Object`},{value:`array-object`,label:`Array object`},{value:`array-string`,label:`Array string`}],Xf=new Set([`enum`]),Zf=new Set([`object`,`array-object`,`form`]),Qf=new Set([`string`,`number`,`boolean`,`enum`,`image`,`icon`,`color`,`date`,`datetime`,`time`,`form`]),$f=new Set([`string`,`number`,`boolean`,`enum`,`color`,`date`,`datetime`,`time`]),ep=new Set([`string`,`number`,`boolean`,`enum`,`image`,`icon`,`color`,`date`,`datetime`,`time`]),tp=new Set([`string`,`number`,`boolean`,`enum`,`image`,`icon`,`color`,`date`,`datetime`,`time`]);function np(e){return e==null?``:typeof e==`string`?e:JSON.stringify(e)}function rp(e){if(typeof e!=`string`)return e;let t=e.trim();if(t)try{return JSON.parse(t)}catch{return t}}function ip(e=0){return[{fieldGroupClassName:`d-grid grid-columns-1 grid-columns-md-2 gap-2`,fieldGroup:[{key:`name`,type:`input-text`,props:{label:`Name`,required:!0}},{key:`key`,type:`input-text`,props:{label:`Key`,required:!0}}]},{type:`input-accordion`,props:{title:`Options`},fieldArray:[{key:`type`,type:`input-select`,defaultValue:`string`,props:{label:`Type`,placeholder:`Select type`,required:!0,options:Yf},hooks:{onModelChange:(e,t)=>{(e===`form`||e===`button`)&&(t.control=!0)}}},{fieldGroupClassName:`d-flex flex-wrap align-items-end gap-4`,hide:t=>e>0||!Qf.has(t.type),fieldGroup:[{key:`control`,type:`input-toggle`,defaultValue:!1,className:`flex-shrink-0`,hide:e=>!$f.has(e.type),props:{toggleLabel:`Control`,help:`This field can be controlled from the UI.`}},{key:`listen`,type:`input-toggle`,defaultValue:!1,className:`flex-shrink-0`,hide:e=>!ep.has(e.type),props:{toggleLabel:`Listen`,help:`If at least one field in the definition has Listen enabled, triggers will run when this field changes in the device state.`}},{key:`reportEveryTime`,type:`input-toggle`,defaultValue:!1,className:`flex-shrink-0`,hide:e=>!ep.has(e.type)||!e.listen,props:{toggleLabel:`Report every time`,help:`Emit updates even when the incoming value is the same as the previous one.`}},{key:`throttleMs`,type:`input-unit`,className:`w-100 w-lg-25`,hide:e=>!ep.has(e.type)||!e.listen,props:{placeholder:`Throttle`,help:`Limit how often this field reports updates. Use 0 or leave empty to disable.`,type:`time`,defaultUnit:`s`,min:0}}]},{key:`values`,type:`input-array-text`,defaultValue:[],hide:e=>!Xf.has(e.type),props:{label:`Values`,placeholder:`Add value`,separator:`,`}},{key:`fields`,type:`input-array`,defaultValue:[],hide:e=>!Zf.has(e.type),props:{label:`Nested fields`},fieldArray:e<6?ip(e+1):[]},{fieldGroupClassName:`form-stack`,hide:e=>e.type!==`list`,fieldGroup:[{fieldGroupClassName:`d-grid grid-columns-1 grid-columns-md-2 gap-2`,fieldGroup:[{key:`list.item.id`,type:`input-text`,props:{label:`ID key`,placeholder:`id`}},{key:`list.item.title`,type:`input-text`,props:{label:`Title key`,placeholder:`title`}},{key:`list.item.description`,type:`input-text`,props:{label:`Description key`,placeholder:`description`}},{key:`list.item.badge`,type:`input-text`,props:{label:`Badge key`,placeholder:`badge`}}]},{fieldGroupClassName:`d-grid grid-columns-1 grid-columns-md-2 gap-2`,fieldGroup:[{key:`list.check.enabled`,type:`input-toggle`,defaultValue:!1,props:{toggleLabel:`Allow checking`}},{key:`list.check.checkedKey`,type:`input-text`,hide:e=>!e.list?.check?.enabled,props:{label:`Checked key`,placeholder:`completed`}},{key:`list.delete.enabled`,type:`input-toggle`,defaultValue:!1,props:{toggleLabel:`Allow deletion`}}]}]},{fieldGroupClassName:`form-stack form-stack-lg`,fieldGroup:[{fieldGroupClassName:`d-grid grid-columns-1 grid-columns-md-3 gap-2`,hide:e=>e.type!==`number`,fieldGroup:[{key:`extra.min`,type:`input-number`,props:{label:`Min`}},{key:`extra.max`,type:`input-number`,props:{label:`Max`}},{key:`extra.suffix`,type:`input-text`,props:{label:`Suffix`}}]},{fieldGroupClassName:`d-grid grid-columns-1 grid-columns-md-2 gap-2`,hide:e=>e.type!==`boolean`,fieldGroup:[{key:`extra.valueTrue`,type:`input-text`,props:{label:`Value true`,help:`Map a raw value to boolean true. Example: ON.`}},{key:`extra.valueFalse`,type:`input-text`,props:{label:`Value false`,help:`Map a raw value to boolean false. Example: OFF.`}}]},{key:`expression`,type:`input-text`,defaultValue:``,hide:t=>e>0||!tp.has(t.type),props:{label:`Expression`,help:`JavaScript expression used to transform the incoming state value. Example: state.state === 'ON' ? 'On' : 'Off'.`}}]}]}]}function ap(e,t){let n=e?.name||e?.key||t;return t?`${n} (${t})`:n}function op(e=[],t=`fields`,n=``){return e.flatMap((e,r)=>{let i=`${t}.${r}`,a=e?.key?`${n}${e.key}`:`${n}${r+1}`,o=[];return ep.has(e?.type)&&o.push({key:`${i}.history`,type:`input-toggle`,defaultValue:!1,props:{toggleLabel:ap(e,a)}}),Zf.has(e?.type)&&Array.isArray(e.fields)&&o.push(...op(e.fields,`${i}.fields`,`${a}.`)),o})}function sp(e=[]){return e.map(e=>({...e,control:e.type===`form`||e.type===`button`?!0:e.control,values:Array.isArray(e.values)?e.values.map(e=>String(e)):typeof e.values==`string`&&e.values.trim()?e.values.split(`,`).map(e=>e.trim()).filter(Boolean):[],extra:e.extra&&typeof e.extra==`object`?{...e.extra,valueTrue:np(e.extra.valueTrue),valueFalse:np(e.extra.valueFalse)}:{},fields:Array.isArray(e.fields)?sp(e.fields):[],list:e.list&&typeof e.list==`object`?e.list:{}}))}function cp(e=[]){return e.map(e=>{let t={...e};if(Array.isArray(t.values)&&(t.values=t.values.map(e=>String(e).trim()).filter(e=>e),t.values.length===0&&delete t.values),Xf.has(t.type)||delete t.values,t.type===`number`){t.extra=t.extra&&typeof t.extra==`object`?t.extra:{};for(let e of[`min`,`max`])t.extra[e]===``||t.extra[e]===void 0||t.extra[e]===null?delete t.extra[e]:t.extra[e]=Number(t.extra[e]);typeof t.extra.suffix==`string`&&(t.extra.suffix=t.extra.suffix.trim()),t.extra.suffix||delete t.extra.suffix}else t.extra&&typeof t.extra==`object`&&(delete t.extra.min,delete t.extra.max,delete t.extra.suffix);if(t.type===`boolean`){t.extra=t.extra&&typeof t.extra==`object`?t.extra:{};let e=rp(t.extra.valueTrue),n=rp(t.extra.valueFalse);e===void 0?delete t.extra.valueTrue:t.extra.valueTrue=e,n===void 0?delete t.extra.valueFalse:t.extra.valueFalse=n}else t.extra&&typeof t.extra==`object`&&(delete t.extra.valueTrue,delete t.extra.valueFalse);return t.type===`form`||t.type===`button`?(t.control=!0,delete t.listen,delete t.history,delete t.reportEveryTime):Qf.has(t.type)?($f.has(t.type)||delete t.control,ep.has(t.type)||(delete t.listen,delete t.throttleMs,delete t.history,delete t.reportEveryTime)):(delete t.control,delete t.listen,delete t.throttleMs,delete t.history,delete t.reportEveryTime),ep.has(t.type)||(delete t.listen,delete t.throttleMs,delete t.history,delete t.reportEveryTime),(!t.listen||!t.throttleMs)&&delete t.throttleMs,(!t.listen||!t.reportEveryTime)&&delete t.reportEveryTime,Zf.has(t.type)?t.fields=cp(t.fields||[]):delete t.fields,t.type===`list`?(t.list===void 0||t.list===null||typeof t.list==`object`&&Object.keys(t.list).length===0)&&delete t.list:delete t.list,(t.extra===void 0||t.extra===null||typeof t.extra==`object`&&Object.keys(t.extra).length===0)&&delete t.extra,(!tp.has(t.type)||typeof t.expression==`string`&&!t.expression.trim())&&delete t.expression,t})}async function lp(e){let{definition:t}=e||{},n=e?.edit??!!t?._id,r=t?{...t,_tab:`general`,_id:n?``:t._id||``,tags:t.tags||[],fields:sp(t.fields||[])}:{_tab:`general`,name:``,_id:``,setIdManually:!1,tags:[],fields:[],history:{enabled:!1},translations:{},metadata:{}},i=null,a=()=>[{fieldGroupClassName:`d-grid grid-columns-1 grid-columns-md-2 gap-2`,fieldGroup:[{key:`name`,type:`input-text`,props:{label:`Name`,required:!0}},{key:`_id`,type:`input-text`,hide:()=>n,props:{label:`ID`,placeholder:`Auto`,required:!1}}]},{key:`tags`,type:`input-array-text`,props:{label:`Tags`,type:`string`,options:()=>K.getState().getTags()}},{key:`fields`,type:`input-array`,props:{label:`Fields`},fieldArray:[...ip()]}],o=()=>{let e=op(r.fields||[]);return[{key:`history.enabled`,type:`input-toggle`,className:`flex-shrink-0`,props:{label:`History`,toggleLabel:`Enabled`}},{fieldGroupClassName:`d-flex flex-wrap align-items-start gap-4`,fieldGroup:[{key:`history.retentionMs`,type:`input-unit`,className:`w-100 w-lg-25`,hide:e=>!e.history?.enabled,props:{label:`Retention`,placeholder:`Default 60 days`,help:`How long history entries should be kept. The API stores this value in milliseconds.`,type:`time`,defaultUnit:`d`,min:0}},{key:`history.throttleMs`,type:`input-unit`,className:`w-100 w-lg-25`,hide:e=>!e.history?.enabled,props:{label:`Throttle`,help:`Save history at most once every selected time interval. The API stores this value in milliseconds.`,placeholder:`Disabled`,type:`time`,defaultUnit:`m`,min:0}}]},{type:`template`,hide:e=>!e.history?.enabled,template:v`
          <div class="mt-4 mb-2">
            <div class="fw-semibold">${j(`Fields`)}</div>
            <div class="form-text">${j(`Choose which definition fields should be saved to history.`)}</div>
          </div>
        `},...e.length?e.map(e=>({...e,className:`mb-1`,hide:t=>!t.history?.enabled||(typeof e.hide==`function`?e.hide(t):e.hide===!0)})):[]]},s=()=>{let e=l(),t=i;if(t?.refreshForm){t.refreshForm(e,r);return}i&&(i.fields=e,i.requestUpdate())},c=e=>{r._tab=e.detail.tabId,s()},l=()=>[{type:`template`,template:v`
        <div class="mb-4">
          <app-button-tabs
            .tabs=${Jf}
            .activeTab=${r._tab}
            @tab-change=${c}
          ></app-button-tabs>
        </div>
      `},...a().map(e=>({...e,hide:r._tab===`general`?e.hide:!0})),...o().map(e=>({...e,hide:r._tab===`history`?e.hide:!0}))];return await G({title:n?`Edit: ${t?.name}`:`Add Definition`,width:`60rem`,model:r,fields:l(),advancedEditor:l,onFormReady:e=>{i=e},onBeforeSubmit:async()=>{let e=cp(r.fields||[]);return n&&t?._id?await K.getState().updateDefinition(t._id,{name:r.name,tags:r.tags||[],fields:e,history:r.history,translations:r.translations,metadata:r.metadata}):await K.getState().addDefinition({_id:typeof r._id==`string`&&r._id.trim()?r._id.trim():void 0,name:r.name,tags:r.tags||[],fields:e,history:r.history,translations:r.translations,metadata:r.metadata}),!0}})}function up(e,t){return t.split(`.`).reduce((e,t)=>e?.[t],e)}var dp=class extends w{constructor(...e){super(...e),this.activeTab=`device`,this.providerDefinition=null,this.providerDevice=null,this.formControlModels=new Map,this.formOptionalIncludes=new Map}connectedCallback(){super.connectedCallback();let e=q.getState().devices.find(e=>e._id===this.device._id)||this.device;this.currentDeviceSource=e,this.currentDevice={...e,state:e.state?{...e.state}:void 0},this.unsubscribe=q.subscribe(e=>{let t=e.devices.find(e=>e._id===this.device._id);if(t){if(t===this.currentDeviceSource)return;this.currentDeviceSource=t,this.currentDevice={...t,state:t.state?{...t.state}:void 0},this.providerDevice&&={...this.providerDevice,state:t.state?{...t.state}:void 0},this.requestUpdate()}}),this.unsubscribeDefinition=K.subscribe(e=>{let t=e.getDefinitionById(this.device.definition);t&&t!==this.definition&&(this.definition=t)}),this.connectDeviceChanges()}disconnectedCallback(){super.disconnectedCallback(),this.unsubscribe?.(),this.unsubscribeDefinition?.(),this.eventSource?.close(),this.eventSource=void 0}connectDeviceChanges(){this.eventSource?.close(),this.eventSource=N.sse(`/devices/changes`),this.eventSource.onmessage=e=>{if(e.type!==`message`||!e.payload)return;let{_id:t,state:n,lastSeenAt:r}=e.payload;t&&q.getState().updateDeviceState(t,{state:n,lastSeenAt:r})}}async loadProviderDataLazy(){if(!(!this.device.provider||this.providerDefinition))try{await Y.getState().fetchDevices(this.device.provider);let e=Y.getState().getProviderDevices(this.device.provider).find(e=>e.externalId===this.device.externalId);if(e){this.providerDevice=e;let t=await Y.getState().getDefinitionById(this.device.provider,e.definitionId);t&&(this.providerDefinition=t)}}catch(e){console.error(`Failed to load provider data:`,e)}}async openEditDefinition(){let e=K.getState().getDefinitionById(this.device.definition)||this.definition;e&&await lp({definition:e})}getFieldLabel(e,t){let n=this.currentDevice.translations?.[t];return n?.key?n.key:this.definition.translations?.[t]||e.name}getTranslatedValue(e,t){let n=this.currentDevice.translations?.[e];return n?.value&&n.value[t]?n.value[t]:t}async openEditTranslation(e,t){let n=this.currentDevice.translations?.[e]||{key:t.name,value:{}};await qf({deviceId:this.currentDevice._id,fieldKey:e,fieldName:t.name,translation:n,field:t,currentTranslations:this.currentDevice.translations||{}})&&this.requestUpdate()}isStructuredValue(e){return typeof e==`object`&&!!e}getDisplayValue(e,t){if(e.type===`boolean`){let n=e.extra?.valueTrue||e.extra?.valueFalse?t===e.extra?.valueTrue||t===!0?e.extra?.valueTrue:e.extra?.valueFalse:t;return this.activeTab===`provider`?n:this.getTranslatedValue(e.key,n)}return e.type===`color`&&this.isStructuredValue(t)&&`x`in t&&`y`in t||this.isStructuredValue(t)?t:(e.type,this.activeTab===`provider`?t:this.getTranslatedValue(e.key,t))}transformControlValue(e,t){return e.type===`boolean`&&(e.extra?.valueTrue!==void 0||e.extra?.valueFalse!==void 0)?t?e.extra?.valueTrue:e.extra?.valueFalse:t}async sendControlCommand(e){this.activeTab===`provider`?await N.post(`/providers/${this.currentDevice.provider}/commands`,{externalId:this.currentDevice.externalId,command:e}):await N.post(`/devices/${this.currentDevice._id}/state`,{state:e})}async handleListAction(e){let{action:t,field:n,index:r,id:i,checked:a}=e.detail;n?.key&&await this.sendControlCommand({[n.key]:{action:t,index:r,id:i,...a===void 0?{}:{checked:a}}})}cleanCommandPayload(e){let t={};for(let[n,r]of Object.entries(e||{}))r!==void 0&&r!==``&&(t[n]=r);return t}isEmptyControlValue(e){return e==null||e===``}isFormControlField(e){return e?.type===`form`}getControlStateFields(e){let t=[];for(let n of e||[])this.isFormControlField(n)||t.push(n);return t}getDefinitionModelKey(e){return`${this.activeTab}:${e?.id||e?._id||``}`}getGroupKey(e){return e.key||e.name}getFormControlModel(e,t){let n=`${this.getDefinitionModelKey(e)}:${this.getGroupKey(t)}`,r=this.formControlModels.get(n);if(r)return r;let i=this.createEmptyFormControlModel(t);return this.formControlModels.set(n,i),i}createEmptyFormControlModel(e){let t={};for(let n of e.fields||[])n.default===void 0?n.defaultValue===void 0?n.type===`boolean`&&(t[n.key]=!1):t[n.key]=n.defaultValue:t[n.key]=n.default;return t}resetFormControlModel(e,t){let n=`${this.getDefinitionModelKey(e)}:${this.getGroupKey(t)}`;this.formControlModels.set(n,this.createEmptyFormControlModel(t));for(let n of t.fields||[])this.formOptionalIncludes.delete(this.getFormOptionalFieldKey(e,t,n));this.requestUpdate()}getFormOptionalFieldKey(e,t,n){return`${this.getDefinitionModelKey(e)}:${this.getGroupKey(t)}:${n.key}`}isFormOptionalFieldIncluded(e,t,n){return this.formOptionalIncludes.get(this.getFormOptionalFieldKey(e,t,n))===!0}setFormOptionalFieldIncluded(e,t,n,r){this.formOptionalIncludes.set(this.getFormOptionalFieldKey(e,t,n),r),this.requestUpdate()}createFormCommand(e,t,n){let r={};for(let i of t.fields||[]){let a=this.transformControlValue(i,n[i.key]),o=this.isEmptyControlValue(a);if(i.required&&o)return null;if(i.optional){this.isFormOptionalFieldIncluded(e,t,i)&&(r[i.key]=a);continue}(i.required||!o||i.type===`boolean`)&&(r[i.key]=a)}let i=this.cleanCommandPayload(r);return Object.keys(i).length===0?(t.fields||[]).length>0&&(t.fields||[]).every(e=>e.optional)?{}:null:i}createFormCommandPayload(e,t){return e.key?{[e.key]:t}:t}createFormField(e,t,n){let r={key:e.key,hooks:n},i={label:t,required:e.required};switch(e.type){case`boolean`:return{...r,type:`input-toggle`,props:{required:e.required,toggleLabel:t,helperText:e.extra?.min===void 0?void 0:`Range: ${e.extra.min} - ${e.extra.max}`}};case`enum`:return{...r,type:`input-select`,props:{...i,multiple:e.extra?.multiple===!0,options:e.values?.map(e=>({value:typeof e==`string`?e:e.value,label:typeof e==`string`?e:e.name}))||[]}};case`number`:{let t=e.extra?.min!==void 0&&e.extra?.max!==void 0;return{...r,type:t?`input-range`:`input-number`,props:{...i,min:e.extra?.min,max:e.extra?.max,suffix:e.extra?.suffix,helperText:!t&&e.extra?.min!==void 0?`Range: ${e.extra.min} - ${e.extra.max}`:void 0}}}case`color`:return{...r,type:`input-color`,props:i};case`date`:return{...r,type:`input-date`,props:i};case`datetime`:return{...r,type:`input-text`,props:{...i,placeholder:`YYYY-MM-DDTHH:mm:ss.sssZ`}};case`time`:return{...r,type:`input-text`,props:{...i,placeholder:`HH:mm`}};case`array-string`:return{...r,type:`input-array-text`,props:i};case`array-object`:return{...r,type:`input-array`,props:i,fieldArray:(e.fields||[]).map(e=>this.createFormField(e,e.name))};case`object`:if(e.fields?.length){let r=(t,r)=>{n?.onModelChange?.(up(r,e.key),r)};return{fieldGroupClassName:`border border-subtle rounded p-3 d-grid grid-columns-1 gap-3`,fieldGroup:[...t?[{template:v`<div class="field-label">${t}</div>`}]:[],...(e.fields||[]).map(t=>this.createFormField({...t,key:`${e.key}.${t.key}`},t.name||t.key,{onModelChange:r}))]}}return{...r,type:`input-json`,props:{...i,rows:4}};case`form`:return{fieldGroupClassName:`d-grid grid-columns-1 gap-3`,fieldGroup:(e.fields||[]).map(e=>this.createFormField(e,e.name||e.key))};default:return{...r,type:`input-text`,props:{...i,placeholder:e.placeholder}}}}renderActionControlButton(e,t){return v`
      <app-button
        label=${t}
        variant="primary"
        background
        @click=${async()=>{let t={[e.key]:!0};try{await this.sendControlCommand(t),console.log(`Command sent successfully:`,t)}catch(e){console.error(`Failed to send control command:`,e),alert(`Failed to send command: `+(e.message||`Unknown error`))}}}
      ></app-button>
    `}renderFormControlGroup(e,t,n){let r=this.getFormControlModel(e,t),i=this.createFormCommand(e,t,r)!==null;return v`
      <div class="card p-3 form-stack mb-3">
        <div class="fw-semibold">${n}</div>
        <div class="form-stack">
          ${(t.fields||[]).map(n=>{let i=this.createFormField(n,n.optional?``:n.name,{onModelChange:e=>{r[n.key]=e,this.requestUpdate()}}),a={[n.key]:r[n.key]};return n.optional?v`
              <div class="d-flex gap-3 align-items-start">
                <div class="mt-n2 flex-shrink-0">
                  <input-checkbox
                    .key=${this.getFormOptionalFieldKey(e,t,n)}
                    .value=${this.isFormOptionalFieldIncluded(e,t,n)}
                    .props=${{}}
                    @field-change=${r=>this.setFormOptionalFieldIncluded(e,t,n,r.detail.value)}
                  ></input-checkbox>
                </div>
                <div class="min-w-0 flex-grow-1">
                  <label class="form-label mb-2">
                    ${n.name}
                  </label>
                  <div class="${this.isFormOptionalFieldIncluded(e,t,n)?``:`pointer-events-none opacity-50`}">
                    <app-form-fields
                      .fields=${[i]}
                      .model=${a}
                    ></app-form-fields>
                  </div>
                </div>
              </div>
            `:v`
                <app-form-fields
                  .fields=${[i]}
                  .model=${a}
                ></app-form-fields>
              `})}
        </div>
        <div class="d-flex justify-content-end">
          <app-button
            label=${t.extra?.form?.submitLabel||`Submit`}
            variant="primary"
            background
            .disabled=${!i}
            @click=${async()=>{let n=this.createFormCommand(e,t,r);if(!n)return;let i=this.createFormCommandPayload(t,n);try{await this.sendControlCommand(i),this.resetFormControlModel(e,t),console.log(`Command sent successfully:`,i)}catch(e){console.error(`Failed to send control command:`,e),alert(`Failed to send command: `+(e.message||`Unknown error`))}}}
          ></app-button>
        </div>
      </div>
    `}render(){if(this.activeTab===`history`)return v`
        <div class="form-stack form-stack-lg">
          ${this.renderStateTabs()}
          <content-history-device
            .device=${this.currentDevice}
            .definition=${this.definition}
          ></content-history-device>
        </div>
      `;let e=this.activeTab===`provider`&&this.providerDefinition?this.providerDefinition:this.definition,t=e?.fields.filter(e=>e.control||e.type===`form`||e.type===`button`)||[],n=e?.fields.filter(e=>!e.control&&e.type!==`form`&&e.type!==`button`)||[],r=this.getControlStateFields(t),i={...this.currentDevice};for(let e of t){if(this.isFormControlField(e))continue;let t=this.currentDevice.state?.[e.key];t!=null&&(i[e.key]=e.type===`boolean`?t===e.extra?.valueTrue||t===!0:t)}let a=[];for(let n of t){let t=this.activeTab===`provider`?n.name:this.getFieldLabel(n,n.key);if(this.isFormControlField(n)){a.push({template:this.renderFormControlGroup(e,n,t)});continue}if(n.type===`button`){a.push({template:this.renderActionControlButton(n,t)});continue}a.push(this.createFormField(n,t,{onModelChange:async e=>{let t={[n.key]:this.transformControlValue(n,e)};try{await this.sendControlCommand(t),console.log(`Command sent successfully:`,t)}catch(e){console.error(`Failed to send control command:`,e),alert(`Failed to send command: `+(e.message||`Unknown error`))}}}))}let o=[];for(let e of[...r,...n]){let t=this.currentDevice.state?.[e.key];t!=null&&o.push({key:e.key,name:this.activeTab===`provider`?e.name:this.getFieldLabel(e,e.key),value:this.getDisplayValue(e,t),rawValue:t,suffix:e.extra?.suffix,type:e.type,field:e})}return v`
      <div>

        ${this.renderStateTabs()}

        ${a.length>0||o.length>0?v`
          <div class="mt-4 d-grid grid-columns-1 ${a.length>0&&o.length>0?`grid-columns-lg-2`:``} gap-3">
            <!-- Left: Control Fields -->
            ${a.length>0?v`
              <div>
                <h4 class="mt-0">${j(`Control Fields`)}</h4>
                <div class="card p-3">
                  <app-form-fields
                    .fields=${a}
                    .model=${i}
                  ></app-form-fields>
                </div>
              </div>
            `:``}
            ${o.length>0?v`
              <nq-current-state
                .stateValue=${this.currentDevice.state}
                .fields=${o}
                .editable=${this.activeTab===`device`}
                @list-action=${e=>void this.handleListAction(e)}
                @edit-field=${e=>this.openEditTranslation(e.detail.fieldKey,e.detail.field)}
              ></nq-current-state>
            `:``}
          </div>
        `:``}

        ${this.activeTab===`device`?v`
          <div class="mt-3 d-flex justify-content-end">
            <app-button
              label="Edit definition"
              variant="ghost"
              size="sm"
              .icon=${A}
              @click=${()=>void this.openEditDefinition()}
            ></app-button>
          </div>
        `:``}
      </div>
    `}renderStateTabs(){return v`
      <app-button-tabs
        .tabs=${[{id:`device`,label:`Device Definition`},{id:`provider`,label:`Provider Definition`},{id:`history`,label:`History`}]}
        .activeTab=${this.activeTab}
        @tab-change=${e=>{this.activeTab=e.detail.tabId,e.detail.tabId===`provider`&&!this.providerDefinition&&this.loadProviderDataLazy()}}
      ></app-button-tabs>
    `}};D([S({type:Object})],dp.prototype,`device`,void 0),D([S({type:Object})],dp.prototype,`definition`,void 0),D([C()],dp.prototype,`currentDevice`,void 0),D([C()],dp.prototype,`activeTab`,void 0),D([C()],dp.prototype,`providerDefinition`,void 0),D([C()],dp.prototype,`providerDevice`,void 0),dp=D([x(`content-control-device`)],dp);async function fp(e){let{device:t}=e||{};if(!t)return null;await K.getState().fetchDefinitions(),await q.getState().fetchDevices(!0);let n=await K.getState().getDefinitionById(t.definition);if(!n)return alert(`Definition not found for this device`),null;let r=v`
    <content-control-device
      .device=${t}
      .definition=${n}
    ></content-control-device>
  `;return await z.open({title:`State: ${t.name}`,content:r,width:`50rem`,closeOnBackdrop:!0,closeOnEscape:!0,buttons:[{label:`OK`,variant:`primary`,action:()=>z.cancel()}]}).catch(()=>null)}var pp=`nq-selected-zone-path`;function mp(e,t){return t.split(`.`).reduce((e,t)=>e?.[t],e)}var hp=class extends w{constructor(...e){super(...e),this.selectedPath=[],this.includeSubzones=!1,this.debounceTimers=new Map,this.formControlModels=new Map,this.formOptionalIncludes=new Map}getCardToggleProps(e){return{toggleLabel:e,layout:`between`}}connectedCallback(){super.connectedCallback(),this.loadFromStorage(),setTimeout(async()=>{await I.getState().fetchZones(),await K.getState().fetchDefinitions(),await q.getState().fetchDevices(),this.connectDeviceChanges()})}disconnectedCallback(){super.disconnectedCallback(),this.eventSource?.close(),this.eventSource=void 0;for(let e of this.debounceTimers.values())window.clearTimeout(e);this.debounceTimers.clear()}connectDeviceChanges(){this.eventSource?.close(),this.eventSource=N.sse(`/devices/changes`),this.eventSource.onmessage=e=>{if(e.type!==`message`||!e.payload)return;let{_id:t,state:n,lastSeenAt:r}=e.payload;t&&q.getState().updateDeviceState(t,{state:n,lastSeenAt:r})}}loadFromStorage(){try{let e=localStorage.getItem(pp);if(e){let t=JSON.parse(e);Array.isArray(t)?(this.selectedPath=t,this.includeSubzones=!1):(this.selectedPath=Array.isArray(t?.path)?t.path:[],this.includeSubzones=!!t?.includeSubzones)}}catch(e){console.error(`Failed to load devices zone path:`,e)}}saveToStorage(){try{localStorage.setItem(pp,JSON.stringify({path:this.selectedPath,includeSubzones:this.includeSubzones}))}catch(e){console.error(`Failed to save devices zone path:`,e)}}getChildren(e){return(this.zones||[]).filter(t=>t.parent===e).sort((e,t)=>e.order-t.order)}getAllDescendantIds(e){let t=[e];for(let n of this.getChildren(e))t.push(...this.getAllDescendantIds(n.id));return t}handleZoneChange(e){this.selectedPath=e.detail.path||[],this.includeSubzones=!!e.detail.includeSubzones,this.saveToStorage()}getCurrentZoneIds(){if(this.selectedPath.length===0)return[];let e=this.selectedPath[this.selectedPath.length-1];return this.includeSubzones?this.getAllDescendantIds(e):[e]}getDevicesForZone(e){return(this.devices||[]).filter(t=>t.zone===e).sort((e,t)=>(e.name||``).localeCompare(t.name||``,void 0,{sensitivity:`base`}))}isAllSubzonesView(){if(this.selectedPath.length===0)return!1;let e=this.selectedPath[this.selectedPath.length-1];return this.includeSubzones&&this.getChildren(e).length>0}getDefinition(e){return this.definitions?.find(t=>t._id===e.definition)}getDeviceLabel(e,t,n){let r=e.translations?.[n.key];if(r?.key)return r.key;let i=t?.translations?.[n.key];return typeof i==`string`?i:n.name||n.key}getFieldValue(e,t){return e.state?.[t.key]}getCommandValue(e,t){return e.type===`boolean`&&(e.extra?.valueTrue!==void 0||e.extra?.valueFalse!==void 0)?t?e.extra.valueTrue:e.extra.valueFalse:t}getCommandPayload(e,t){let n=this.getCommandValue(e,t);return{[e.key]:n}}async sendCommand(e,t,n,r=!1){if(!e._id)return;let i=async()=>{let r=this.getCommandPayload(t,n);await N.post(`/devices/${e._id}/state`,{state:r})};if(!r){await i();return}let a=`${e._id}:${t.key}`,o=this.debounceTimers.get(a);o&&window.clearTimeout(o);let s=window.setTimeout(()=>{this.debounceTimers.delete(a),i()},500);this.debounceTimers.set(a,s)}async openEditDevice(e){await Vf({device:e})}async openEditDefinition(e){e&&await lp({definition:e})}async openDeviceState(e){await fp({device:e})}flattenFields(e=[]){return e.filter(e=>!!e.key)}getFieldDisplayValue(e,t,n){if(t.type===`date`&&n!=null&&n!==``){let e=new Date(`${n}T00:00:00`);return Number.isNaN(e.getTime())?String(n):e.toLocaleDateString()}if(t.type===`datetime`&&n!=null&&n!==``){let e=new Date(n);return Number.isNaN(e.getTime())?String(n):e.toLocaleString()}if(t.type===`time`&&n!=null&&n!==``)return String(n).slice(0,5);if(n==null||n===``)return`—`;if(t.type===`boolean`){if(t.extra?.valueTrue!==void 0||t.extra?.valueFalse!==void 0){let e=n===t.extra?.valueTrue||n===!0;return String(e?t.extra?.valueTrue??!0:t.extra?.valueFalse??!1)}return j(n?`True`:`False`)}return typeof n==`object`?JSON.stringify(n):`${n}${t.extra?.suffix?` ${t.extra.suffix}`:``}`}isStructuredValue(e){return typeof e==`object`&&!!e}renderFallbackJson(e){return v`
      <pre class="overflow-auto text-break rounded bg-body-secondary p-3 small text-muted font-monospace" style="max-height: 16rem; white-space: pre-wrap;">${JSON.stringify(e,null,2)}</pre>
    `}renderNestedDeviceValue(e,t,n,r){if(r==null)return v`<span class="text-muted">-</span>`;if(Array.isArray(r)){if(!r.length)return v`<span class="text-muted">[]</span>`;let i=n.fields||[];return v`
        <div class="d-flex flex-column gap-2 text-left">
          ${r.map((n,r)=>v`
            <div class="border border-subtle rounded p-3 bg-body-secondary">
              <div class="mb-2 small fw-semibold text-uppercase text-muted">#${r+1}</div>
              ${i.length&&this.isStructuredValue(n)?this.renderNestedDeviceFields(e,t,i,n):this.renderFallbackJson(n)}
            </div>
          `)}
        </div>
      `}if(this.isStructuredValue(r)){let i=n.fields||[];return i.length?v`<div class="w-100 border border-subtle rounded p-3 bg-body-secondary text-left">${this.renderNestedDeviceFields(e,t,i,r)}</div>`:this.renderFallbackJson(r)}return v`
      <span class="field-value text-break">
        ${this.getFieldDisplayValue(e,n,r)}
      </span>
    `}renderNestedDeviceFields(e,t,n,r){let i=new Set(n.map(e=>e.key)),a=Object.keys(r||{}).filter(e=>!i.has(e));return v`
      <div class="d-flex flex-column gap-1">
        ${n.filter(e=>r?.[e.key]!==void 0&&r?.[e.key]!==null).map(n=>v`
            <div class="d-flex justify-content-between gap-3 py-1">
              <span class="text-muted">${this.getDeviceLabel(e,t,n)}:</span>
              <div class="min-w-0 text-right text-break">${this.renderNestedDeviceValue(e,t,n,r[n.key])}</div>
            </div>
          `)}
        ${a.map(n=>v`
          <div class="d-flex justify-content-between gap-3 py-1">
            <span class="text-muted">${n}:</span>
            <div class="min-w-0 text-right text-break">${this.renderNestedDeviceValue(e,t,{key:n,name:n,type:this.isStructuredValue(r[n])?`object`:`string`},r[n])}</div>
          </div>
        `)}
      </div>
    `}renderObjectField(e,t,n,r,i){return r==null?v``:v`
      <div class="py-2">
        ${i?v`<div class="field-label mb-1">${i}</div>`:``}
        ${n.fields?.length&&this.isStructuredValue(r)?this.renderNestedDeviceValue(e,t,n,r):this.renderFallbackJson(r)}
      </div>
    `}renderBooleanControl(e,t,n,r){let i=t.extra?.valueTrue===void 0?!!n:n===t.extra.valueTrue||n===!0;return v`
      <input-toggle
        .key=${t.key}
        .value=${i}
        .props=${this.getCardToggleProps(r)}
        @field-change=${n=>{n.stopPropagation(),this.sendCommand(e,t,!!n.detail.value)}}
      ></input-toggle>
    `}renderEnumControl(e,t,n,r){let i=(t.values||[]).map(e=>typeof e==`string`?{value:e,label:e}:{value:e.value,label:e.name||e.value});return v`
      <input-select
        .key=${t.key}
        .value=${n}
        .props=${{label:r,placeholder:t.placeholder||`Select`,options:i}}
        @field-change=${n=>{n.stopPropagation(),this.sendCommand(e,t,n.detail.value)}}
      ></input-select>
    `}renderNumberControl(e,t,n,r){let i=t.extra?.min!==void 0&&t.extra?.max!==void 0,a=n??t.extra?.min??0;return i?v`
        <div class="py-1">
          <input-range
            .key=${t.key}
            .value=${Number(a)}
            .props=${{label:r,min:t.extra?.min,max:t.extra?.max,suffix:t.extra?.suffix}}
            @field-change=${n=>{n.stopPropagation(),this.sendCommand(e,t,n.detail.value,!0)}}
          ></input-range>
        </div>
      `:v`
      <input-number
        .key=${t.key}
        .value=${a}
        .props=${{label:r,placeholder:t.placeholder,min:t.extra?.min,max:t.extra?.max,suffix:t.extra?.suffix}}
        @field-change=${n=>{n.stopPropagation(),this.sendCommand(e,t,n.detail.value,!0)}}
      ></input-number>
    `}renderButtonControl(e,t,n){return v`
      <app-button
        label=${n}
        variant="ghost"
        size="md"
        className="w-100"
        @click=${()=>this.sendCommand(e,t,!0)}
      ></app-button>
    `}renderTextControl(e,t,n,r){return v`
      <input-text
        .key=${t.key}
        .value=${String(n??``)}
        .props=${{label:r,placeholder:t.placeholder}}
        @field-change=${n=>{n.stopPropagation(),this.sendCommand(e,t,n.detail.value,!0)}}
      ></input-text>
    `}renderColorControl(e,t,n,r){return v`
      <input-color
        .key=${t.key}
        .value=${n}
        .props=${{label:r}}
        @field-change=${n=>{n.stopPropagation(),this.sendCommand(e,t,n.detail.value)}}
      ></input-color>
    `}async sendListAction(e,t,n,r){await this.sendCommand(e,t,{action:n,index:r.index,id:r.id,...r.checked===void 0?{}:{checked:r.checked}})}renderListField(e,t,n,r){return v`
      <nq-device-list
        .items=${Array.isArray(n)?n:[]}
        .config=${t.list||{}}
        .label=${r}
        @list-check=${n=>{n.stopPropagation(),this.sendListAction(e,t,`check`,n.detail)}}
        @list-delete=${n=>{n.stopPropagation(),this.sendListAction(e,t,`delete`,n.detail)}}
      ></nq-device-list>
    `}getFormControlModel(e,t){let n=`${e._id}:${t.key}`,r=this.formControlModels.get(n);if(r)return r;r={};for(let e of t.fields||[])e.extra?.defaultValue===void 0?e.defaultValue===void 0?e.default===void 0?e.type===`boolean`&&(r[e.key]=!1):r[e.key]=e.default:r[e.key]=e.defaultValue:r[e.key]=e.extra.defaultValue;return this.formControlModels.set(n,r),r}updateFormControlModel(e,t,n,r){let i=this.getFormControlModel(e,t);i[n.key]=r,this.requestUpdate()}createFormFieldConfig(e,t,n){let r={key:e.key,hooks:n},i={label:t,required:e.required,placeholder:e.placeholder};switch(e.type){case`boolean`:return{...r,type:`input-toggle`,props:{required:e.required,toggleLabel:t}};case`enum`:return{...r,type:`input-select`,props:{...i,multiple:e.extra?.multiple===!0,options:(e.values||[]).map(e=>({value:typeof e==`string`?e:e.value,label:typeof e==`string`?e:e.name||e.value}))}};case`number`:{let t=e.extra?.min!==void 0&&e.extra?.max!==void 0;return{...r,type:t?`input-range`:`input-number`,props:{...i,min:e.extra?.min,max:e.extra?.max,suffix:e.extra?.suffix}}}case`color`:return{...r,type:`input-color`,props:i};case`date`:return{...r,type:`input-date`,props:i};case`array-string`:return{...r,type:`input-array-text`,props:i};case`array-object`:return{...r,type:`input-array`,props:i,fieldArray:(e.fields||[]).map(e=>this.createFormFieldConfig(e,e.name||e.key))};case`object`:if(e.fields?.length){let r=(t,r)=>{n?.onModelChange?.(mp(r,e.key),r)};return{fieldGroupClassName:`border border-subtle rounded p-3 d-grid grid-columns-1 gap-3`,fieldGroup:[...t?[{template:v`<div class="field-label">${t}</div>`}]:[],...(e.fields||[]).map(t=>this.createFormFieldConfig({...t,key:`${e.key}.${t.key}`},t.name||t.key,{onModelChange:r}))]}}return{...r,type:`input-json`,props:{...i,rows:4}};case`datetime`:return{...r,type:`input-text`,props:{...i,placeholder:e.placeholder||`YYYY-MM-DDTHH:mm:ss.sssZ`}};case`time`:return{...r,type:`input-text`,props:{...i,placeholder:e.placeholder||`HH:mm`}};default:return{...r,type:`input-text`,props:i}}}getDefaultFormFieldValue(e){return e.extra?.defaultValue===void 0?e.defaultValue===void 0?e.default===void 0?e.type===`boolean`?!1:e.type===`array-string`||e.type===`array-object`?[]:e.type===`object`?{}:``:e.default:e.defaultValue:e.extra.defaultValue}renderDynamicControl(e,t,n,r,i=!0){let a=this.createFormFieldConfig(t,r),o={[t.key]:n??this.getDefaultFormFieldValue(t)};return v`
      <app-form-fields
        .fields=${[a]}
        .model=${o}
        @model-change=${n=>{n.stopPropagation(),this.sendCommand(e,t,n.detail.model?.[t.key],i)}}
      ></app-form-fields>
    `}getFormOptionalKey(e,t,n){return`${e._id}:${t.key}:${n.key}`}isFormOptionalIncluded(e,t,n){return this.formOptionalIncludes.get(this.getFormOptionalKey(e,t,n))===!0}setFormOptionalIncluded(e,t,n,r){this.formOptionalIncludes.set(this.getFormOptionalKey(e,t,n),r),this.requestUpdate()}createFormCommand(e,t,n){let r={};for(let i of t.fields||[]){let a=this.getCommandValue(i,n[i.key]),o=a==null||a===``;if(i.required&&o)return null;if(i.optional){this.isFormOptionalIncluded(e,t,i)&&(r[i.key]=a);continue}(!o||i.type===`boolean`)&&(r[i.key]=a)}let i=!!t.fields?.length&&t.fields.every(e=>!!e.optional);return Object.keys(r).length>0||i?r:null}resetFormControlModel(e,t){this.formControlModels.delete(`${e._id}:${t.key}`);for(let n of t.fields||[])this.formOptionalIncludes.delete(this.getFormOptionalKey(e,t,n));this.requestUpdate()}renderFormInput(e,t,n,r,i){let a=n.name||n.key,o=r[n.key],s=this.createFormFieldConfig(n,a,{onModelChange:r=>{this.updateFormControlModel(e,t,n,r)}}),c={[n.key]:o??this.getDefaultFormFieldValue(n)};return v`
      <app-form-fields
        .fields=${[s]}
        .model=${c}
        @model-change=${r=>{r.stopPropagation(),this.updateFormControlModel(e,t,n,r.detail.model?.[n.key])}}
        @keydown=${i}
      ></app-form-fields>
    `}renderFormControl(e,t,n){let r=this.getDeviceLabel(e,t,n),i=this.getFormControlModel(e,n),a=this.createFormCommand(e,n,i),o=async()=>{let t=this.createFormCommand(e,n,i);t&&(await this.sendCommand(e,n,t),this.resetFormControlModel(e,n))},s=e=>{e.key!==`Enter`||e.isComposing||e.composedPath()[0]instanceof HTMLInputElement&&(e.preventDefault(),e.stopPropagation(),o())};return v`
      <div class="border border-subtle rounded p-3">
        <div class="field-value fw-semibold mb-3">${r}</div>
        <div class="form-stack gap-3">
          ${(n.fields||[]).map(t=>{if(!t.optional)return this.renderFormInput(e,n,t,i,s);let r=this.isFormOptionalIncluded(e,n,t);return v`
              <div class="d-grid align-items-start gap-3" style="grid-template-columns: auto minmax(0, 1fr);">
                <div class="mt-n2 align-self-start">
                  <input-checkbox
                    .key=${this.getFormOptionalKey(e,n,t)}
                    .value=${r}
                    .props=${{}}
                    @field-change=${r=>{r.stopPropagation(),this.setFormOptionalIncluded(e,n,t,!!r.detail.value)}}
                  ></input-checkbox>
                </div>
                <div class="${r?``:`pointer-events-none opacity-50`}">
                  ${this.renderFormInput(e,n,t,i,s)}
                </div>
              </div>
            `})}
        </div>
        <div class="mt-3 d-flex justify-content-end">
          <app-button
            label=${n.extra?.form?.submitLabel||`Submit`}
            variant="primary"
            size="md"
            background
            .disabled=${a===null}
            @click=${o}
          ></app-button>
        </div>
      </div>
    `}renderField(e,t,n){let r=this.getDeviceLabel(e,t,n),i=this.getFieldValue(e,n);if(n.type===`form`)return this.renderFormControl(e,t,n);if(n.type===`list`)return this.renderListField(e,n,i,r);if(n.type===`object`||n.type===`array-object`)return this.renderObjectField(e,t,n,i,r);if(n.type===`button`)return this.renderButtonControl(e,n,r);if(n.control){if(n.type===`boolean`)return this.renderBooleanControl(e,n,i,r);if(n.type===`enum`)return this.renderEnumControl(e,n,i,r);if(n.type===`number`)return this.renderNumberControl(e,n,i,r);if(n.type===`color`)return this.renderColorControl(e,n,i,r);if(n.type===`string`)return this.renderTextControl(e,n,i,r);if([`date`,`time`,`datetime`,`array-string`,`array-object`,`object`].includes(n.type||``))return this.renderDynamicControl(e,n,i,r)}if(n.type===`image`){let e=i?.toString();return e?v`
        <div class="py-2">
          <div class="mb-1 small text-muted">${r}</div>
          <auth-image
            src=${e}
            alt=${r}
            imageClass="img-thumbnail object-fit-contain"
            loading="lazy"
            .preview=${!0}
          ></auth-image>
        </div>
      `:v``}if(n.type===`icon`){let e=i?.toString();return e?v`
        <div class="field-row">
          <div class="field-label">
            ${r?v`<span class="text-truncate">${r}</span>`:``}
          </div>
          <app-icon .name=${e} size="32" class="flex-shrink-0 text-body"></app-icon>
        </div>
      `:v``}return i==null?v``:v`
      <div class="field-row">
        ${r?v`
          <div class="field-label">
            <span class="text-truncate">${r}</span>
          </div>
        `:``}
        <div class="field-value text-end text-break">
          ${this.getFieldDisplayValue(e,n,i)}
        </div>
      </div>
    `}renderDeviceCard(e){let t=this.getDefinition(e),n=this.flattenFields(t?.fields||[]),r=e.lastSeenAt?new Date(e.lastSeenAt):null,i=r?r.getTime()>Date.now()-1440*60*1e3:!1,a={variant:`ghost`,className:`p-0`,icon:ji,label:``};return v`
      <div class="card">
        <div class="card-body">
          <div class="card-header">
            <div class="card-icon">
              <span class="circle ${i?`circle-success`:`circle-secondary`}"></span>
            </div>
            <div class="min-w-0 flex-grow-1">
              <h3 class="card-title">${e.name}</h3>
              <div class="card-subtitle text-muted small text-truncate">${t?.name||e.definition}</div>
            </div>
            <app-dropdown
              align="right"
              .showIndicator=${!1}
              .fixedMenu=${!0}
              .trigger=${a}
              .menu=${v`
                <app-dropdown-item
                  label="Edit device"
                  .icon=${A}
                  @item-click=${()=>this.openEditDevice(e)}
                ></app-dropdown-item>
                <app-dropdown-item
                  label="Edit definition"
                  .icon=${gr}
                  ?disabled=${!t}
                  @item-click=${()=>this.openEditDefinition(t)}
                ></app-dropdown-item>
                <app-dropdown-item
                  label="State"
                  .icon=${ia}
                  @item-click=${()=>this.openDeviceState(e)}
                ></app-dropdown-item>
                <app-dropdown-item
                  label="Remove"
                  .icon=${k}
                  @item-click=${()=>this.confirmRemoveDevice(e)}
                ></app-dropdown-item>
              `}
            ></app-dropdown>
          </div>

          <div class="card-content">
            ${n.map(n=>this.renderField(e,t,n))}
          </div>

          ${e.lastSeenAt?v`
            <div class="mt-3 border-top border-subtle pt-3 small text-muted">
              ${j(`Last seen:`)} ${new Date(e.lastSeenAt).toLocaleString()}
            </div>
          `:``}
        </div>
      </div>
    `}async confirmRemoveDevice(e){try{await z.open({title:j(`Remove device`),content:j(`Are you sure you want to delete "{{name}}"?`,{name:e.name}),buttons:[{label:j(`Cancel`),variant:`ghost`,action:()=>z.cancel()},{label:j(`Confirm`),variant:`danger`,action:()=>z.close(!0)}]}),await q.getState().removeDevice(e._id)}catch{}}renderDeviceMasonry(e){return v`
      <div class="card-columns">
        ${e.map(e=>v`
          <div>
            ${this.renderDeviceCard(e)}
          </div>
        `)}
      </div>
    `}render(){let e=this.isAllSubzonesView(),t=this.getCurrentZoneIds().map(e=>this.zones?.find(t=>t.id===e)).filter(e=>!!e).map(e=>({zone:e,devices:this.getDevicesForZone(e.id)})).filter(e=>e.devices.length>0);return v`
      <div>
        <select-zone
          .selectedPath=${this.selectedPath}
          .includeSubzones=${this.includeSubzones}
          @zone-change=${this.handleZoneChange}
        ></select-zone>

        ${this.selectedPath.length===0?v`
          <div class="empty-state" style="min-height: 16rem;">
            <div class="text-center">
              <div class="mb-2 fs-5 text-muted">Select a zone to view devices</div>
              <div class="text-secondary">Choose a zone from the tabs above</div>
            </div>
          </div>
        `:t.length===0?v`
          <div class="empty-state" style="min-height: 16rem;">
            <div class="text-center">
              <div class="mb-2 fs-5 text-muted">${j(`No devices in this area`)}</div>
              <div class="text-secondary">Linked devices will appear here</div>
            </div>
          </div>
        `:e?v`
          <div class="form-stack gap-8">
            ${t.map(e=>v`
              <section>
                <div class="mb-3 d-flex align-items-center gap-3">
                  <h2 class="fs-5 fw-semibold text-body m-0">${e.zone.name}</h2>
                  <span class="text-muted">${e.devices.length}</span>
                </div>
                ${this.renderDeviceMasonry(e.devices)}
              </section>
            `)}
          </div>
        `:v`
          ${this.renderDeviceMasonry(t.flatMap(e=>e.devices))}
        `}
      </div>
    `}};D([H(I,e=>e.zones)],hp.prototype,`zones`,void 0),D([H(q,e=>e.devices)],hp.prototype,`devices`,void 0),D([H(K,e=>e.definitions)],hp.prototype,`definitions`,void 0),D([C()],hp.prototype,`selectedPath`,void 0),D([C()],hp.prototype,`includeSubzones`,void 0),hp=D([x(`devices-grid-view`)],hp);function gp(e){let t=e.trim().split(/\s+/);if(t.length<5)return`Invalid`;let[n,r,i,a,o,s]=t;return r===`*`&&i===`*`&&a===`*`&&o===`*`&&s===`*`?`Every Minute`:r!==`*`&&i===`*`&&a===`*`&&o===`*`&&s===`*`?`Hourly`:i!==`*`&&r!==`*`&&a===`*`&&o===`*`&&s===`*`?`Daily`:s!==`*`&&s!==`?`&&a===`*`?`Weekly`:a!==`*`&&o===`*`&&(s===`*`||s===`?`)?`Monthly`:o!==`*`&&a!==`*`?`Yearly`:`Custom`}function _p(e){return{...e,_type:gp(e.cron)}}var vp=po()((e,t)=>({crons:[],loading:!1,getCrons(){return t().crons},getTags(){let e=new Set;return t().crons.forEach(t=>{(t.tags||[]).forEach(t=>{let n=String(t||``).trim();n&&e.add(n)})}),Array.from(e).sort((e,t)=>e.localeCompare(t))},fetchCrons:async(n=!1)=>{t().crons.length>0&&!n||(e({loading:!0}),e({crons:(await N.get(`/cron`)).map(_p),loading:!1}))},addCron:async n=>{let r=_p(await N.post(`/cron`,n));return e({crons:[...t().crons,r]}),r},updateCron:async(n,r)=>{let i=_p(await N.put(`/cron/${n}`,r));e({crons:t().crons.map(e=>e._id===n?i:e)})},removeCron:async n=>{await N.delete(`/cron/${n}`),e({crons:t().crons.filter(e=>e._id!==n)})},removeAutoRemoveCron:async n=>{await N.delete(`/cron/${n}/auto-remove`),e({crons:t().crons.filter(e=>e._id!==n)})},getCronById:e=>t().crons.find(t=>t._id===e),toggleCronEnabled:async n=>{let r=t().getCronById(n);if(!r)return;let i=_p(await N.put(`/cron/${n}/enabled`,{enabled:!r.enabled}));e({crons:t().crons.map(e=>e._id===n?i:e)})}}));function yp(e){let t=e.trim().split(/\s+/);if(t.length<5)return`Invalid cron expression`;let n,r,i,a,o;t.length===6?[,n,r,i,a,o]=t:[n,r,i,a,o]=t;let s=[`January`,`February`,`March`,`April`,`May`,`June`,`July`,`August`,`September`,`October`,`November`,`December`],c=[`Sunday`,`Monday`,`Tuesday`,`Wednesday`,`Thursday`,`Friday`,`Saturday`],l=e=>parseInt(e,10),u=e=>{if(e===`*`)return``;if(e.includes(`/`)){let[,t]=e.split(`/`);return t===`1`?`every minute`:`every ${t} minutes`}return e.includes(`,`)?`at minute ${e.split(`,`).map(e=>e.padStart(2,`0`)).join(`, `)}`:e.includes(`-`)?`at minute ${e}`:`at minute ${e.padStart(2,`0`)}`},d=e=>{if(e===`*`)return``;if(e.includes(`/`)){let[,t]=e.split(`/`);return`every ${t} hours`}if(e.includes(`,`))return`at ${e.split(`,`).map(e=>`${e.padStart(2,`0`)}:00`).join(`, `)}`;if(e.includes(`-`)){let[t,n]=e.split(`-`);return`between ${t.padStart(2,`0`)}:00 and ${n.padStart(2,`0`)}:00`}return`at ${e.padStart(2,`0`)}:00`},f=e=>{if(e===`*`||e===`?`)return``;if(e.includes(`/`)){let[,t]=e.split(`/`);return`every ${t} days`}return e.includes(`,`)||e.includes(`-`),`on day-of-month ${e}`},p=e=>{if(e===`*`)return``;if(e.includes(`,`))return`in ${e.split(`,`).map(e=>s[l(e)-1]).join(`, `)}`;if(e.includes(`-`)){let[t,n]=e.split(`-`);return`in ${s[l(t)-1]} through ${s[l(n)-1]}`}return`in ${s[l(e)-1]}`},m=e=>{if(e===`*`||e===`?`)return``;if(e.includes(`/`))return`every ${e.split(`/`)[1]} days of the week`;if(e.includes(`,`))return`on ${e.split(`,`).map(e=>c[l(e)]).join(`, `)}`;if(e.includes(`-`)){let[t,n]=e.split(`-`);return`on ${c[l(t)]} through ${c[l(n)]}`}let t=l(e);return`on ${c[t===7?0:t]}`},h=[];if(n===`*`&&r===`*`&&i===`*`&&a===`*`&&o===`*`)return`Every minute`;let g=u(n),_=d(r);if(_&&g)if(!_.includes(`every`)&&!g.includes(`every`)){let e=r.includes(`,`)?r.split(`,`)[0]:r,t=n.includes(`,`)?n.split(`,`)[0]:n;h.push(`At ${e.padStart(2,`0`)}:${t.padStart(2,`0`)}`)}else g&&h.push(g),_&&h.push(_);else _?h.push(`At ${_.replace(`at `,``)}`):g&&h.push(g.charAt(0).toUpperCase()+g.slice(1));let ee=f(i),te=m(o);ee&&te?h.push(`${ee} and ${te}`):ee?h.push(ee):te&&h.push(te);let ne=p(a);ne&&h.push(ne);let re=h.join(` `);return re&&=re.charAt(0).toUpperCase()+re.slice(1),re&&!re.endsWith(`.`)&&(re+=`.`),re||`Invalid cron expression`}function bp(e=[]){return Qu(e,J.getState().getScripts())}var xp=[{value:`$eq`,label:`=`},{value:`$ne`,label:`!=`},{value:`$gt`,label:`>`},{value:`$gte`,label:`>=`},{value:`$lt`,label:`<`},{value:`$lte`,label:`<=`},{value:`$in`,label:`in`},{value:`$nin`,label:`not in`},{value:`$exists`,label:`exists`}],Sp=[{value:!0,label:`True`},{value:!1,label:`False`},{value:null,label:`Null`},{value:void 0,label:`Undefined`}],Cp=[{value:`field-card`,label:`Card`},{value:`field-device`,label:`Device`},{value:`expression-card`,label:`Card Expression`},{value:`expression-device`,label:`Device Expression`}];function wp(e=[]){return e.map(e=>({...e,_conditionMode:e.device?e.expression?.trim()?`expression-device`:`field-device`:e.expression?.trim()?`expression-card`:`field-card`}))}function Tp(e=[]){return e.filter(e=>(e?._conditionMode?.endsWith(`-device`)?e?.device:e?.card)&&(e?._conditionMode?.startsWith(`expression-`)?e?.expression?.trim():e?.key)).map(e=>e?._conditionMode?.startsWith(`expression-`)?{...e._conditionMode.endsWith(`-device`)?{device:e.device}:{card:e.card},expression:e.expression.trim()}:{...e._conditionMode.endsWith(`-device`)?{device:e.device}:{card:e.card},key:e.key,operator:e.operator||`$eq`,...e.operator===`$exists`?{}:{value:e.value}})}function Ep(e){return(e?.options?.length?e.options:e?.values||[]).map(e=>{if(typeof e==`string`)return{value:e,label:e};let t=e?.value??e?.key??e?.name??String(e);return{value:t,label:e?.name??e?.label??String(t)}})}async function Dp(e){let{cron:t}=e||{},n=e?.edit??!!t?._id;await Promise.all([J.getState().fetchScripts(),L.getState().fetchDevices(),q.getState().fetchDevices()]);let r=J.getState().getScripts(),i=t?{...t}:{name:``,tags:[],cron:``,modificators:void 0,enabled:!0,description:``,actions:[],conditions:[],remmoveAfterExecution:!1};i.tags=i.tags||[],i.actions=Zu(i.actions||[],r),i.conditions=wp(i.conditions||[]),i._tab=`general`;let a=[{id:`general`,label:`General`},{id:`commands`,label:`Commands`}],o=null,s=()=>{let e=c(),t=o;if(t?.refreshForm){t.refreshForm(e,i);return}o&&(o.fields=e,o.model=i,o.requestUpdate())},c=()=>{let e=()=>L.getState().devices||[],t=t=>e().find(e=>e._id===t?.card)?.fields||[],n=e=>{let t=q.getState().getDeviceById(e?.device);return t?.definition&&K.getState().getDefinitionById(t.definition)?.fields||[]},o=e=>e?._conditionMode?.endsWith(`-device`),c=e=>e?._conditionMode?.startsWith(`expression-`),l=e=>o(e)?n(e):t(e),u=e=>l(e).find(t=>t.key===e?.key),d=e=>u(e)?.type||`string`,f=e=>!e?.key||e?.operator===`$exists`,p=e=>o(e)?!!e?.device:!!e?.card;return[{type:`template`,template:v`
				<div class="mb-4">
					<app-button-tabs
						.tabs=${a}
						.activeTab=${i._tab}
						@tab-change=${e=>{i._tab=e.detail.tabId,s()}}
					></app-button-tabs>
				</div>
			`},{key:`name`,type:`input-text`,hide:()=>i._tab!==`general`,props:{label:`Name`,required:!0}},{key:`cron`,type:`input-cron`,hide:()=>i._tab!==`general`,props:{label:`Schedule`,required:!0,placeholder:`* * * * *`}},{key:`tags`,type:`input-array-text`,hide:()=>i._tab!==`general`,props:{label:`Tags`,type:`string`,options:()=>vp.getState().getTags()}},{key:`enabled`,type:`input-toggle`,defaultValue:!0,hide:()=>i._tab!==`general`,props:{toggleLabel:`Enabled`}},{key:`remmoveAfterExecution`,type:`input-toggle`,defaultValue:!1,hide:()=>i._tab!==`general`,props:{toggleLabel:`Remove after execution`}},{key:`conditions`,type:`input-array`,hide:()=>i._tab!==`commands`,props:{label:`Conditions`,addLabel:`Add Condition`,help:`Optional. All conditions must match before commands are executed.`},fieldArray:[{fieldGroupClassName:`d-flex flex-wrap align-items-end gap-4`,fieldGroup:[{key:`_conditionMode`,type:`input-select`,defaultValue:`field-card`,className:`w-100 max-w-15rem`,props:{label:`Condition type`,options:Cp,help:`Choose a card or device field comparison, or evaluate an expression using the selected source state.`},hooks:{onModelChange:(e,t)=>{e.endsWith(`-device`)?delete t.card:delete t.device,e.startsWith(`expression-`)?(delete t.key,delete t.operator,delete t.value):delete t.expression}}},{key:`card`,type:`input-cards`,hide:e=>o(e),props:{label:`Card`,required:!0,placeholder:`Select card`,cards:e()},hooks:{onModelChange:(e,t)=>{delete t.key,delete t.operator,delete t.value}}},{key:`device`,type:`input-devices`,hide:e=>!o(e),props:{label:`Device`,required:!0},hooks:{onModelChange:(e,t)=>{delete t.key,delete t.operator,delete t.value}}}]},{fieldGroupClassName:`d-grid grid-columns-1 grid-columns-md-3 gap-4 align-items-end`,hide:e=>c(e)||!p(e),fieldGroup:[{key:`key`,type:`input-select`,props:{label:`Field`,options:(e,t)=>l(t).map(e=>({value:e.key,label:e.name&&e.name!==e.key?`${e.name} (${e.key})`:e.key}))}},{key:`operator`,type:`input-select`,defaultValue:`$eq`,hide:e=>!e?.key,props:{label:`Operator`,options:xp}},{key:`value`,type:`input-text`,hide:e=>f(e)||![`string`,`image`,`button`,`object`,`array`,`form`,`list`,`chart`].includes(d(e)),props:{label:`Value`}},{key:`value`,type:`input-number`,hide:e=>f(e)||d(e)!==`number`,props:{label:`Value`}},{key:`value`,type:`input-select`,hide:e=>f(e)||d(e)!==`boolean`,props:{label:`Value`,options:Sp}},{key:`value`,type:`input-select`,hide:e=>f(e)||d(e)!==`enum`,props:{label:`Value`,options:(e,t)=>Ep(u(t))}}]},{key:`expression`,type:`input-code`,hide:e=>!c(e)||!p(e),props:{label:`Expression`,rows:2,help:`Use state to read fields from the condition source. Example: state.closed === false && state.mode === 'AUTO'`}}]},{key:`actions`,type:`input-script-actions`,hide:()=>i._tab!==`commands`,props:{addLabel:`Add Command`,scripts:r,includeValue:!1}}]};return await G({title:n?`Edit Schedule: ${t?.name||``}`:`Add Schedule`,model:i,fields:c(),advancedEditor:c,onFormReady:e=>{o=e},onBeforeSubmit:async()=>{let e={name:i.name,tags:i.tags||[],cron:i.cron,modificators:i.modificators,enabled:i.enabled,description:i.description,actions:bp(i.actions||[]),conditions:Tp(i.conditions||[]),remmoveAfterExecution:i.remmoveAfterExecution,lastRunAt:i.lastRunAt};return t?._id?await vp.getState().updateCron(t._id,e):await vp.getState().addCron(e),!0}})}var Op=class extends w{constructor(...e){super(...e),this.crons=[],this.selectedTag=`__all`}connectedCallback(){super.connectedCallback(),setTimeout(()=>{vp.getState().fetchCrons(!0)})}get tags(){return vp.getState().getTags()}get filteredCrons(){let e=[...this.crons||[]].sort((e,t)=>{let n=(e.name||``).localeCompare(t.name||``,void 0,{sensitivity:`base`});return n===0?String(e._id||``).localeCompare(String(t._id||``)):n});if(this.selectedTag===`__all`)return e;if(this.selectedTag===`__one_time`)return e.filter(e=>e.remmoveAfterExecution);if(this.selectedTag===`__enabled`)return e.filter(e=>e.enabled!==!1);if(this.selectedTag===`__disabled`)return e.filter(e=>e.enabled===!1);if(this.selectedTag.startsWith(`tag:`)){let t=this.selectedTag.slice(4);return e.filter(e=>(e.tags||[]).includes(t))}return e}get tagTabs(){return[{id:`__all`,label:`All`,icon:ka},{id:`__one_time`,label:`One time`},{id:`__enabled`,label:`Enabled`},{id:`__disabled`,label:`Disabled`},...this.tags.map(e=>({id:`tag:${e}`,label:e}))]}handleTagChange(e){this.selectedTag=e.detail.id||`__all`}async toggleEnabled(e){e._id&&await vp.getState().toggleCronEnabled(e._id)}async removeAutoRemove(e){e._id&&await vp.getState().removeAutoRemoveCron(e._id)}async confirmRemove(e){try{await z.open({title:`Remove Schedule`,content:`Are you sure you want to remove schedule "${e.name}"?`,buttons:[{label:`Cancel`,variant:`ghost`,action:()=>z.cancel()},{label:`Confirm`,variant:`danger`,action:()=>z.close(!0)}]}),this.isAdmin?await this.removeCron(e):await this.removeAutoRemove(e)}catch{}}async removeCron(e){e._id&&await vp.getState().removeCron(e._id)}get isAdmin(){return this.userRole===`admin`}renderMeta(e,t){let n=e.tags||[];return v`
      <div class="d-flex flex-wrap gap-1 border-top pt-2 mt-2">
        <app-badge .variant=${t?`success`:`danger`} .content=${j(t?`Enabled`:`Disabled`)}></app-badge>
        ${e.remmoveAfterExecution?v`
          <app-badge variant="info" .content=${j(`One time`)}></app-badge>
        `:y}
        ${n.map(e=>v`<app-badge variant="neutral" .content=${e}></app-badge>`)}
      </div>
    `}renderSchedule(e){let t=e.enabled!==!1,n=e.description||yp(e.cron),r=this.renderActions(e,t);return v`
      <article class="card card-body h-100">
        <div class="card-header align-items-start">
          <div class="card-icon">
            <app-icon .icon=${Bn} size="22"></app-icon>
          </div>
          <div class="flex-grow-1 min-w-0">
            <h3 class="card-title text-truncate">${e.name}</h3>
            <div class="card-subtitle text-muted">${j(e._type||`Schedule`)}</div>
          </div>
          ${r}
        </div>

        <div class="card-content">
          <div class="field-row">
            <span class="text-muted">${j(`Next run`)}</span>
            <span class="fw-semibold">${e.nextRunAt?zl(e.nextRunAt,`standard`):`-`}</span>
          </div>
          <div class="field-row">
            <span class="text-muted">${j(`Last run`)}</span>
            <span class="fw-semibold">${e.lastRunAt?zl(e.lastRunAt,`standard`):`-`}</span>
          </div>
          <div class="d-flex align-items-start gap-2 text-muted">
            <app-icon .icon=${La} size="18"></app-icon>
            <span class="text-break">${n}</span>
          </div>
          ${this.renderMeta(e,t)}
        </div>
      </article>
    `}renderActions(e,t){return v`
      <app-dropdown
        align="right"
        .showIndicator=${!1}
        .fixedMenu=${!0}
        .trigger=${{variant:`ghost`,className:`p-0`,icon:ji,label:``}}
        .menu=${v`
          ${!e.remmoveAfterExecution||this.isAdmin?v`
            <app-dropdown-item
              label=${t?`Disable`:`Enable`}
              .icon=${t?Ba:Va}
              @item-click=${()=>this.toggleEnabled(e)}
            ></app-dropdown-item>
          `:y}
          ${this.isAdmin?v`
            <app-dropdown-item
              label="Edit"
              .icon=${A}
              @item-click=${()=>Dp({cron:e})}
            ></app-dropdown-item>
          `:y}
          ${this.isAdmin||e.remmoveAfterExecution?v`
            <app-dropdown-item
              label="Remove"
              .icon=${k}
              @item-click=${()=>this.confirmRemove(e)}
            ></app-dropdown-item>
          `:y}
        `}
      ></app-dropdown>
    `}render(){let e=this.filteredCrons;return v`
      <div class="form-stack gap-5">
        ${this.tags.length?v`
          <app-tabs
            .items=${this.tagTabs}
            .activeId=${this.selectedTag}
            ariaLabel="Schedule tags"
            @tab-change=${this.handleTagChange}
          ></app-tabs>
        `:y}

        ${e.length?v`
          <div class="card-grid gap-4" style="grid-template-columns: repeat(auto-fill, minmax(min(100%, 22rem), 1fr)); grid-auto-rows: auto;">
            ${e.map(e=>this.renderSchedule(e))}
          </div>
        `:v`
          <div class="empty-state" style="min-height: 16rem;">
            <div class="text-center">
              <div class="fs-5 text-muted mb-2">No schedules found</div>
              <div class="text-secondary">${this.selectedTag===`__all`?`There are no schedules yet.`:`No schedules for selected filter.`}</div>
            </div>
          </div>
        `}
      </div>
    `}};D([C(),H(vp,e=>e.crons)],Op.prototype,`crons`,void 0),D([H(F,e=>e.user?.role)],Op.prototype,`userRole`,void 0),D([C()],Op.prototype,`selectedTag`,void 0),Op=D([x(`schedules-view`)],Op);var kp=po()((e,t)=>({todos:[],loading:!1,error:null,fetchTodos:async()=>{e({loading:!0,error:null});try{e({todos:await N.get(`/todos`),loading:!1})}catch(t){e({error:t.message,loading:!1})}},setTodos:t=>e({todos:t}),addTodo:async t=>{e({loading:!0,error:null});try{let n=await N.post(`/todos`,t);e(e=>({todos:[...e.todos,n],loading:!1}))}catch(t){e({error:t.message,loading:!1})}},updateTodo:async(t,n)=>{e({loading:!0,error:null});try{let r=await N.put(`/todos/${t}`,n);e(e=>({todos:e.todos.map(e=>e.id===t?r:e),loading:!1}))}catch(t){e({error:t.message,loading:!1})}},toggleTodo:async t=>{e({loading:!0,error:null});try{let n=await N.patch(`/todos/${t}/toggle`);e(e=>({todos:e.todos.map(e=>e.id===t?n:e),loading:!1}))}catch(t){e({error:t.message,loading:!1})}},removeTodo:async t=>{e({loading:!0,error:null});try{await N.delete(`/todos/${t}`),e(e=>({todos:e.todos.filter(e=>e.id!==t),loading:!1}))}catch(t){e({error:t.message,loading:!1})}},clearTodos:()=>e({todos:[]})})),Ap=!1,jp=kp.getState;kp.getState=()=>{let e=jp();return!Ap&&typeof window<`u`&&(Ap=!0,e.todos.length===0&&!e.loading&&e.fetchTodos()),e};var Mp=class extends w{constructor(...e){super(...e),this.todos=[],this.loading=!1,this.newTodoText=``}get detailFallback(){return v`
      <div class="bg-white rounded-lg shadow-md p-6 text-center text-gray-500">
        Wybierz zadanie z listy, aby zobaczyć szczegóły.
      </div>
    `}addTodo(){this.newTodoText.trim()&&(kp.getState().addTodo({text:this.newTodoText.trim(),completed:!1,description:``}),this.newTodoText=``)}toggleTodo(e){kp.getState().toggleTodo(e)}deleteTodo(e){kp.getState().removeTodo(e);let t=at();t.length>=2&&t[0]===`todos`&&t[1]===String(e)&&T(`todos`,{replace:!0})}render(){return v`
      <div class="max-w-5xl mx-auto p-6 min-h-screen">
        <div class="mb-8 pb-4 border-b-2 border-purple-600">
          <h1 class="text-3xl font-bold text-gray-800">Lista TODO</h1>
        </div>

        <div class="grid gap-8 lg:grid-cols-[1.1fr_0.9fr]">
          <div class="bg-white rounded-lg shadow-md">
            <div class="flex gap-2 p-4 border-b border-gray-200">
              <input
                type="text"
                placeholder="Dodaj nowe zadanie..."
                .value=${this.newTodoText}
                @input=${e=>this.newTodoText=e.target.value}
                @keypress=${e=>e.key===`Enter`&&this.addTodo()}
                class="flex-1 px-4 py-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-500"
                ?disabled=${this.loading}
              />
              <button
                @click=${this.addTodo}
                ?disabled=${this.loading}
                class="px-6 py-3 bg-purple-600 text-white rounded-md hover:bg-purple-700 transition-colors duration-300 font-semibold disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Dodaj
              </button>
            </div>

            ${this.loading&&this.todos.length===0?v`
                  <div class="flex items-center justify-center py-12">
                    <div class="flex flex-col align-items-center gap-3">
                      <div class="w-12 h-12 border-4 border-purple-200 border-t-purple-600 rounded-full animate-spin"></div>
                      <p class="text-gray-500">Ładowanie zadań...</p>
                    </div>
                  </div>
                `:this.todos.length===0?v`<div class="text-center py-8 text-gray-400">Brak zadań. Dodaj pierwsze zadanie!</div>`:this.todos.map(e=>v`
                <div
                  class="flex items-center p-4 ${Et(`bg-purple-50`,`hover:bg-gray-50`,`todos/${e.id}`)}"
                >
                  <input
                    type="checkbox"
                    .checked=${e.completed}
                    @change=${()=>this.toggleTodo(e.id)}
                    class="w-5 h-5 mr-4 cursor-pointer"
                  />
                  <span class="flex-1 text-gray-800 ${e.completed?`line-through text-gray-400`:``}">
                    ${e.text}
                  </span>
                  <div class="flex gap-2">
                    <button
                      routerLink=${`todos/${e.id}`}
                      ?disabled=${Tt()}
                    >
                      Szczegóły
                    </button>
                    <button
                      @click=${()=>this.deleteTodo(e.id)}
                      class="px-4 py-2 bg-red-500 text-white rounded-md hover:bg-red-600 transition-colors duration-300 disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      Usuń
                    </button>
                  </div>
                </div>
              `)}
          </div>

          <div>
            <router-outlet .fallback=${this.detailFallback}></router-outlet>
          </div>
        </div>
      </div>
    `}};D([C(),H(kp,e=>e.todos)],Mp.prototype,`todos`,void 0),D([C(),H(kp,e=>e.loading)],Mp.prototype,`loading`,void 0),D([C()],Mp.prototype,`newTodoText`,void 0),Mp=D([x(`todo-view`)],Mp);var Np=class extends w{constructor(...e){super(...e),this.routeParams={},this.todo=null}render(){if(!this.todo)return v`
				<div class="max-w-xl mx-auto p-6">
					<div class="text-center py-12 bg-white rounded-lg shadow-md">
						<h2 class="text-xl font-semibold text-gray-700 mb-2">
							Nie znaleziono zadania
						</h2>
						<p class="text-gray-500">
							Sprawdź, czy zadanie nadal istnieje na liście.
						</p>
					</div>
				</div>
			`;let{text:e,completed:t,description:n,_createdAt:r}=this.todo;return v`
			<div class="max-w-xl mx-auto p-6">
				<div class="bg-white rounded-lg shadow-md p-6 space-y-4">
					<div class="flex items-center justify-between">
						<h2 class="text-2xl font-bold text-gray-800">Szczegóły zadania</h2>
						<span
							class="px-3 py-1 rounded-full text-sm font-medium ${t?`bg-green-100 text-green-700`:`bg-yellow-100 text-yellow-700`}"
						>
							${t?`Zakończone`:`W toku`}
						</span>
					</div>

					<div>
						<h3 class="text-lg font-semibold text-gray-700">Tytuł</h3>
						<p class="text-gray-800">${e}</p>
					</div>

					<div>
						<h3 class="text-lg font-semibold text-gray-700">Opis</h3>
						<p class="text-gray-600">${n||`Brak dodatkowego opisu.`}</p>
					</div>

					<div>
						<h3 class="text-lg font-semibold text-gray-700">Utworzono</h3>
						<p class="text-gray-600">
							${r?new Date(r).toLocaleString():`Brak informacji o dacie.`}
						</p>
					</div>
				</div>
			</div>
		`}};D([S({attribute:!1})],Np.prototype,`routeParams`,void 0),D([C(),H(kp,(e,t)=>e.todos.find(e=>e.id===t)??null,e=>Number(e.routeParams?.id))],Np.prototype,`todo`,void 0),Np=D([x(`todo-detail-view`)],Np);var Pp=class extends w{constructor(...e){super(...e),this.index=0,this.level=0,this.isFirst=!1,this.isLast=!1,this.expanded=!0,this.dropZone=null}toggleExpand(){this.expanded=!this.expanded}handleDragStart(e){e.stopPropagation(),e.dataTransfer.effectAllowed=`move`,e.dataTransfer.setData(`text/plain`,this.node.id)}handleDragOver(e){e.preventDefault(),e.stopPropagation(),e.dataTransfer.dropEffect=`move`;let t=e.currentTarget.getBoundingClientRect(),n=e.clientY-t.top,r=t.height;n<r*.25?this.dropZone=`before`:n>r*.75?this.dropZone=`after`:this.dropZone=`inside`}handleDragLeave(e){let t=e.relatedTarget;(!t||!e.currentTarget.contains(t))&&(this.dropZone=null)}handleDrop(e){e.preventDefault(),e.stopPropagation();let t=e.dataTransfer.getData(`text/plain`);if(!t||t===this.node.id){this.dropZone=null;return}let n,r;this.dropZone===`before`?(n=this.parent?.id??null,r=this.index):this.dropZone===`after`?(n=this.parent?.id??null,r=this.index+1):(n=this.node.id,r=this.node.children?.length??0,this.expanded=!0),this.dropZone=null,this.dispatchEvent(new CustomEvent(`tree-drop`,{detail:{nodeId:t,targetParentId:n,targetIndex:r},bubbles:!0,composed:!0}))}handleDragEnd(){this.dropZone=null}handleAdd(e){e.stopPropagation(),this.dispatchEvent(new CustomEvent(`tree-add`,{detail:{node:this.node,parentNode:this.parent,index:this.index},bubbles:!0,composed:!0}))}handleEdit(e){e.stopPropagation(),this.dispatchEvent(new CustomEvent(`tree-edit`,{detail:{node:this.node,parentNode:this.parent,index:this.index},bubbles:!0,composed:!0}))}handleDelete(e){e.stopPropagation(),this.dispatchEvent(new CustomEvent(`tree-delete`,{detail:{node:this.node,parentNode:this.parent,index:this.index},bubbles:!0,composed:!0}))}handleMoveUp(e){e.stopPropagation(),this.dispatchEvent(new CustomEvent(`tree-move`,{detail:{node:this.node,parentNode:this.parent,index:this.index,direction:`up`},bubbles:!0,composed:!0}))}handleMoveDown(e){e.stopPropagation(),this.dispatchEvent(new CustomEvent(`tree-move`,{detail:{node:this.node,parentNode:this.parent,index:this.index,direction:`down`},bubbles:!0,composed:!0}))}get dropIndicatorClass(){return this.dropZone?this.dropZone===`before`?`tree-drop-before`:this.dropZone===`after`?`tree-drop-after`:`tree-drop-inside`:``}renderNodeIcon(){let e=this.node.data?.icon;return e?typeof e==`string`&&(e.trim().startsWith(`<svg`)||e.endsWith(`Icon`))?v`<app-icon .name=${e}></app-icon>`:v`<span class="small lh-1">${e}</span>`:v`<app-icon .icon=${wr}></app-icon>`}render(){let e=this.node.children&&this.node.children.length>0;return v`
      <div class="tree-node">
        <div
          class="tree-node-row ${this.isLast&&this.level===0?`tree-node-row-last`:``} ${this.dropIndicatorClass}"
          draggable="true"
          @dragstart=${this.handleDragStart}
          @dragover=${this.handleDragOver}
          @dragleave=${this.handleDragLeave}
          @drop=${this.handleDrop}
          @dragend=${this.handleDragEnd}
        >
          <button
            class="tree-node-toggle ${this.expanded?`expanded`:``}"
            @click=${this.toggleExpand}
            ?disabled=${!e}
          >
            ${e?v`<app-icon .icon=${dn}></app-icon>`:v`<svg width="6" height="6" viewBox="0 0 6 6" fill="currentColor"><circle cx="3" cy="3" r="2.5"/></svg>`}
          </button>

          <span class="tree-node-icon">${this.renderNodeIcon()}</span>
          <span class="tree-node-label text-truncate">${this.node.label}</span>

          <div class="tree-node-actions">
            <app-button
              variant="primary"
              size="sm"
              .icon=${fn}
              outline
              ?disabled=${this.isFirst}
              ${V(j(`Move up`))}
              @click=${e=>this.handleMoveUp(e)}
            ></app-button>

            <app-button
              variant="primary"
              size="sm"
              .icon=${cn}
              outline
              ?disabled=${this.isLast}
              ${V(j(`Move down`))}
              @click=${e=>this.handleMoveDown(e)}
            ></app-button>

            <app-button
              variant="primary"
              size="sm"
              .icon=${O}
              outline
              ${V(`Add child`)}
              @click=${e=>this.handleAdd(e)}
            ></app-button>

            <app-button
              variant="primary"
              size="sm"
              .icon=${A}
              outline
              ${V(`Edit`)}
              @click=${e=>this.handleEdit(e)}
            ></app-button>

            <app-button
              variant="danger"
              size="sm"
              .icon=${k}
              outline
              ${V(`Delete`)}
              @click=${e=>this.handleDelete(e)}
              ${B({})}
            ></app-button>
          </div>
        </div>

        ${e?v`
              <div class="tree-children ${this.expanded?``:`collapsed`}">
                ${this.node.children.map((e,t)=>v`
                    <tree-node-item
                      .node=${e}
                      .parent=${this.node}
                      .index=${t}
                      .level=${this.level+1}
                      .isFirst=${t===0}
                      .isLast=${t===this.node.children.length-1}
                    ></tree-node-item>
                  `)}
              </div>
            `:``}
      </div>
    `}};D([S({type:Object}),E(`design:type`,Object)],Pp.prototype,`node`,void 0),D([S({type:Object}),E(`design:type`,Object)],Pp.prototype,`parent`,void 0),D([S({type:Number}),E(`design:type`,Number)],Pp.prototype,`index`,void 0),D([S({type:Number}),E(`design:type`,Number)],Pp.prototype,`level`,void 0),D([S({type:Boolean}),E(`design:type`,Boolean)],Pp.prototype,`isFirst`,void 0),D([S({type:Boolean}),E(`design:type`,Boolean)],Pp.prototype,`isLast`,void 0),D([S({type:Boolean}),E(`design:type`,Boolean)],Pp.prototype,`expanded`,void 0),D([C(),E(`design:type`,Object)],Pp.prototype,`dropZone`,void 0),Pp=D([x(`tree-node-item`)],Pp);var Fp=class extends w{constructor(...e){super(...e),this.data=[]}handleAdd(e){this.dispatchEvent(new CustomEvent(`add`,{detail:e.detail,bubbles:!0,composed:!0}))}handleEdit(e){this.dispatchEvent(new CustomEvent(`edit`,{detail:e.detail,bubbles:!0,composed:!0}))}handleDelete(e){this.dispatchEvent(new CustomEvent(`delete`,{detail:e.detail,bubbles:!0,composed:!0}))}handleMove(e){this.dispatchEvent(new CustomEvent(`move`,{detail:e.detail,bubbles:!0,composed:!0}))}handleDrop(e){this.dispatchEvent(new CustomEvent(`drop`,{detail:e.detail,bubbles:!0,composed:!0}))}handleAddRoot(){this.dispatchEvent(new CustomEvent(`add`,{bubbles:!0,composed:!0}))}render(){let e=!this.data||this.data.length===0;return v`
      <div class="tree">
        <div
          @tree-add=${this.handleAdd}
          @tree-edit=${this.handleEdit}
          @tree-delete=${this.handleDelete}
          @tree-move=${this.handleMove}
          @tree-drop=${this.handleDrop}
        >
          ${e?v`
                <button class="tree-empty" @click=${this.handleAddRoot}>
                  <app-icon .icon=${O} size="48" class="mb-4 opacity-50"></app-icon>
                  <span>No items yet. Click to add the first one.</span>
                </button>
              `:v`
                ${this.data.map((e,t)=>v`
                    <tree-node-item
                      .node=${e}
                      .index=${t}
                      .level=${0}
                      .isFirst=${t===0}
                      .isLast=${t===this.data.length-1}
                    ></tree-node-item>
                  `)}
                <div class="mt-4 d-flex justify-content-start">
                  <app-button variant="ghost" background .icon=${O} label="Add" @click=${this.handleAddRoot}></app-button>
                </div>
                `}
        </div>
      </div>
    `}};D([S({type:Array}),E(`design:type`,Array)],Fp.prototype,`data`,void 0),Fp=D([x(`app-tree`)],Fp);async function Ip(e){let t=e?.edit??!1,n=e?.data;return G({title:t?j(`Edit {{name}}`,{name:n?.label||``}):!n&&!t?j(`Add New Zone`):j(`Add Subzone to {{name}}`,{name:n?.label||j(`Parent`)}),fields:[{key:`label`,type:`input-text`,props:{label:`Name`,required:!0}},{key:`icon`,type:`input-icon`,props:{label:`Icon`,options:Zt().map(({name:e,icon:t})=>({value:e,icon:t})),allowCustomSvg:!0}},{key:`onlineVisible`,type:`input-toggle`,props:{toggleLabel:`Visible Online`,help:`Controls whether this zone can be exposed in online views.`}}],model:{label:t?n?.label??``:``,icon:t?n?.data?.icon??``:``,onlineVisible:t?n?.data?.onlineVisible??!1:!1}})}var Lp=class extends w{constructor(...e){super(...e),this.zones=[],this.loading=!1,this.error=null}connectedCallback(){super.connectedCallback(),Q.getState().setPageMeta({title:`Zones & Subzones`,description:`Manage the physical areas of your home`,action:v`
        <app-button
          variant="primary"
          background
          label="Add Zone"
          .icon=${O}
          @click=${()=>this.handleAdd()}
        ></app-button>
      `}),I.getState().initializeIfNeeded()}disconnectedCallback(){Q.getState().setPageMeta(null),super.disconnectedCallback()}async handleAdd(e){let t=e?.detail?.node,n=await Ip({data:t});if(n)try{await I.getState().addZone(t?.id,n.label,n.icon,n.onlineVisible)}catch(e){console.error(`Failed to add zone:`,e)}}async handleEdit(e){let{node:t}=e.detail,n=await Ip({data:t,edit:!0});if(n)try{await I.getState().updateZone(t.id,n.label,n.icon,n.onlineVisible)}catch(e){console.error(`Failed to update zone:`,e)}}async handleDelete(e){let{node:t}=e.detail;try{await I.getState().deleteZone(t.id)}catch(e){console.error(`Failed to delete zone:`,e)}}async handleMove(e){let{node:t,parentNode:n,index:r,direction:i}=e.detail,a=i===`up`?r-1:r+1;try{await I.getState().moveZoneTo(t.id,n?.id??null,a)}catch(e){console.error(`Failed to move zone:`,e)}}async handleDrop(e){let{nodeId:t,targetParentId:n,targetIndex:r}=e.detail;try{await I.getState().moveZoneTo(t,n,r)}catch(e){console.error(`Failed to move zone:`,e)}}render(){return this.loading?v`
        <div class="d-flex align-items-center justify-content-center p-8">
          <div class="text-muted">${j(`Loading...`)}</div>
        </div>
      `:this.error?v`
        <div class="p-8">
          <div class="alert alert-danger">
            ${this.error}
          </div>
          <app-button
            @click=${()=>I.getState().fetchZones()}
            className="mt-4"
            label="Try Again"
            background
          ></app-button>
        </div>
      `:v`
      <div>
        <app-tree
          .data=${this.zones}
          @add=${this.handleAdd}
          @edit=${this.handleEdit}
          @delete=${this.handleDelete}
          @move=${this.handleMove}
          @drop=${this.handleDrop}
        ></app-tree>
      </div>
    `}};D([C(),H(I,e=>e.getTree())],Lp.prototype,`zones`,void 0),D([C(),H(I,e=>e.loading)],Lp.prototype,`loading`,void 0),D([C(),H(I,e=>e.error)],Lp.prototype,`error`,void 0),Lp=D([x(`zones-and-subzones-view`)],Lp);var Rp=class extends w{constructor(...e){super(...e),this.columnKey=`_zone.fullName`,this.operator=`startsWith`,this.zones=[]}connectedCallback(){super.connectedCallback(),I.getState().initializeIfNeeded()}getZonePath(e){let t=[],n=this.zones.find(t=>t.id===e);for(;n;)t.unshift(n.name),n=n.parent?this.zones.find(e=>e.id===n?.parent):void 0;return t.join(`: `)}setZoneFilter(e){let t={columnKey:this.columnKey,operator:this.operator,value:this.getZonePath(e.id)};this.dispatchEvent(new CustomEvent(`table-filter-set`,{detail:{filter:t,replaceColumnKey:this.columnKey},bubbles:!0,composed:!0}))}clearZoneFilter(){this.dispatchEvent(new CustomEvent(`table-filter-clear`,{detail:{columnKey:this.columnKey},bubbles:!0,composed:!0}))}renderZoneFilterItem(e){let t=this.zones.filter(t=>t.parent===e.id).sort((e,t)=>e.order-t.order);return t.length===0?v`
        <app-dropdown-item
          label=${e.name}
          @click=${()=>this.setZoneFilter(e)}
        ></app-dropdown-item>
      `:v`
      <app-dropdown-item
        label=${e.name}
        .submenu=${v`
          <app-dropdown-item
            label=${e.name}
            @click=${()=>this.setZoneFilter(e)}
          ></app-dropdown-item>
          <app-dropdown-item separator></app-dropdown-item>
          ${t.map(e=>this.renderZoneFilterItem(e))}
        `}
      ></app-dropdown-item>
    `}renderZoneFilterMenu(){let e=this.zones.filter(e=>e.parent===null).sort((e,t)=>e.order-t.order);return e.length===0?v`
        <app-dropdown-item label="No zones" disabled></app-dropdown-item>
      `:v`
      <app-dropdown-item
        label="All zones"
        @click=${()=>this.clearZoneFilter()}
      ></app-dropdown-item>
      <app-dropdown-item separator></app-dropdown-item>
      ${e.map(e=>this.renderZoneFilterItem(e))}
    `}render(){return v`
      <app-dropdown
        .trigger=${{variant:`primary`,outline:!0,icon:ri,label:`Zone`}}
        .menu=${this.renderZoneFilterMenu()}
      ></app-dropdown>
    `}};D([S({type:String})],Rp.prototype,`columnKey`,void 0),D([S({type:String})],Rp.prototype,`operator`,void 0),D([C(),H(I,e=>e.zones)],Rp.prototype,`zones`,void 0),Rp=D([x(`zone-filter`)],Rp);var zp=class extends w{constructor(...e){super(...e),this.columnKey=`tags`,this.operator=`$eq`,this.tags=[]}setTagFilter(e){let t={columnKey:this.columnKey,operator:this.operator,value:e};this.dispatchEvent(new CustomEvent(`table-filter-set`,{detail:{filter:t,replaceColumnKey:this.columnKey},bubbles:!0,composed:!0}))}clearTagFilter(){this.dispatchEvent(new CustomEvent(`table-filter-clear`,{detail:{columnKey:this.columnKey},bubbles:!0,composed:!0}))}renderTagFilterMenu(){return this.tags.length===0?v`<app-dropdown-item label="No tags" disabled></app-dropdown-item>`:v`
      <app-dropdown-item
        label="All tags"
        @click=${()=>this.clearTagFilter()}
      ></app-dropdown-item>
      <app-dropdown-item separator></app-dropdown-item>
      ${this.tags.map(e=>v`
        <app-dropdown-item
          label=${e}
          @click=${()=>this.setTagFilter(e)}
        ></app-dropdown-item>
      `)}
    `}render(){return v`
      <app-dropdown
        .trigger=${{variant:`primary`,outline:!0,icon:ka,label:`Tag`}}
        .menu=${this.renderTagFilterMenu()}
      ></app-dropdown>
    `}};D([S({type:String})],zp.prototype,`columnKey`,void 0),D([S({type:String})],zp.prototype,`operator`,void 0),D([S({type:Array})],zp.prototype,`tags`,void 0),zp=D([x(`tag-filter`)],zp);var Bp=class extends w{constructor(...e){super(...e),this.cards=[],this.currentPath=``}get isOnSubRoute(){let e=this.currentPath.split(`cards/`)?.[1];return!!e&&e.length>0}connectedCallback(){super.connectedCallback(),Q.getState().setPageMeta({title:`Cards`,description:`View and control virtual entities grouped from physical devices`,action:v`
        <app-button
          variant="primary"
          background
          label="Add Card"
          .icon=${O}
          @click=${()=>this.handleAdd()}
        >
        </app-button>
      `}),setTimeout(async()=>{await I.getState().fetchZones(),await L.getState().fetchDevices()})}disconnectedCallback(){Q.getState().setPageMeta(null),super.disconnectedCallback()}get columns(){return[{key:`name`,label:`Name`,sortable:!0,filterable:!0,searchable:!0},{key:`_zone.fullName`,label:`Zone`,sortable:!0,filterable:!0,searchable:!0},{key:`order`,label:`Order`,type:`number`,sortable:!0,filterable:!0},{key:`onlineVisible`,label:`Visible Online`,sortable:!0,filterable:!0},{key:`tags`,label:`Tags`,sortable:!1,filterable:!0,searchable:!0,type:`array`,filterFn:(e,t)=>(Array.isArray(e.tags)?e.tags:[]).some(e=>String(e)===String(t.value))}]}render(){if(this.isOnSubRoute&&this.routes)return v`<router-outlet .routes=${this.routes}></router-outlet>`;let e={id:`cards`,mode:`ui`,pagination:!0,limit:25,limitOptions:[5,10,25,50],sortable:!0,filterable:!0,striped:!0,hoverable:!0,emptyMessage:`No cards found`,filtersExtra:v`
      <zone-filter columnKey="_zone.fullName"></zone-filter>
      <tag-filter
        columnKey="tags"
        .tags=${L.getState().getTags()}
      ></tag-filter>
    `,actions:(e,t)=>v`
        <div>
          <app-button
            variant="ghost"
            label="Edit"
            .icon=${A}
            @click=${()=>this.handleEdit(e)}
          >
          </app-button>
          <app-button
            variant="ghost"
            className="text-danger"
            label="Delete"
            ${B({title:`Delete Card`,message:`Are you sure you want to delete "${e.name}"?`,variant:`danger`})}
            .icon=${k}
            @click=${()=>this.handleRemove(e)}
          >
          </app-button>
        </div>
      `};return v`
      <nq-table
        .data=${this.cards.map(e=>({...e,_zone:I.getState().getZoneById(e.zone)}))}
        .columns=${this.columns}
        .options=${e}
      ></nq-table>
    `}async handleAdd(){await cf({onSubmit:e=>L.getState().addDevice(e)})}async handleEdit(e){await cf({data:e,edit:!0,onSubmit:t=>L.getState().updateDevice(e._id,t)})}handleRemove(e){L.getState().deleteDevice(e._id)}};D([S({attribute:!1})],Bp.prototype,`routes`,void 0),D([C(),H(L,e=>e.devices)],Bp.prototype,`cards`,void 0),D([C(),zt()],Bp.prototype,`currentPath`,void 0),Bp=D([x(`cards-view`)],Bp);function Vp(e,t){!t||!t.configFields?.length||(e.config=e.config||{},t.configFields.forEach(t=>{e.config[t.key]===void 0&&t.default!==void 0&&(e.config[t.key]=t.default)}))}function Hp(e){return!e||!e.configFields?.length?[]:e.configFields.map(e=>{let t={key:`config.${e.key}`,type:`input-text`,props:{label:e.label,required:e.required||!1}};switch(e.type){case`number`:t.type=`input-number`;break;case`boolean`:t.type=`input-toggle`,t.props={toggleLabel:e.label,required:e.required||!1};break;case`password`:t.type=`input-password`;break;default:t.type=`input-text`;break}return t})}function Up(e,t){if(!(!t||t===`custom`))return e.find(e=>e.filename===t)}function Wp(e,t){return typeof t?.requiresMqtt==`boolean`?t.requiresMqtt:typeof e.mqttConnection==`boolean`?e.mqttConnection:!1}function Gp(e,t){typeof t?.requiresMqtt==`boolean`?e.mqttConnection=t.requiresMqtt:typeof e.mqttConnection!=`boolean`&&(e.mqttConnection=!0),e.mqttConnection?e.mqtt={server:``,topic:``,username:``,password:``,...e.mqtt||{}}:e.mqtt={}}var Kp=[{id:`general`,label:`General`},{id:`heartbeat`,label:`Heartbeat`}];function qp(e){let t=e.heartbeat;if(t){if(typeof t.timeoutMs==`number`)return t.timeoutMs;if(typeof t.timeout==`number`)return t.timeout*1e3}}function Jp(e=[]){return Qu(e,J.getState().getScripts())}async function Yp(e){let t=e?.provider||{},n=!!t._id,[r]=await Promise.all([N.get(`/providers/integrations`),J.getState().fetchScripts()]),i=J.getState().getScripts(),a=t.integration?Up(r,t.integration):void 0,o={_tab:`general`,_selectedIntegration:t.integration?t.integration:``,...t,mqttConnection:Wp(t,a),mqtt:{server:``,topic:``,username:``,password:``,...t.mqtt},heartbeat:{timeoutMs:qp(t),actions:t.heartbeat?.actions||(t.heartbeat?.script?[{script:t.heartbeat.script,params:{}}]:[])}};o.heartbeat.actions=Zu(o.heartbeat.actions||[],i),Gp(o,a);let s=[];t.integration&&(s=Hp(Up(r,t.integration)));let c=[...r.map(e=>({value:e.filename,label:e.name})),{value:`custom`,label:`Custom`}],l=e=>e.mqttConnection!==!0,u=e=>typeof Up(r,e._selectedIntegration)?.requiresMqtt==`boolean`,d=[],f=null,p=()=>{d=ee();let e=f;if(e?.refreshForm){e.refreshForm(d,o);return}f&&(f.fields=d,f.requestUpdate())},m=e=>{o._tab=e.detail.tabId,p()},h=e=>{let t=d.find(e=>e.key===`mqttConnection`);t&&(t.props={...t.props||{},disabled:u(e)})},g=()=>[{fieldGroupClassName:`d-grid grid-columns-1 grid-columns-md-2 gap-4`,fieldGroup:[{key:`name`,type:`input-text`,props:{label:`Name`,required:!0}},{key:`_selectedIntegration`,type:`input-select`,props:{label:`Integration`,required:!0,options:c},hooks:{onModelChange:(e,t)=>{if(e===`custom`)t.integration=void 0,t.config={},t.icon=void 0,s=[],Gp(t,void 0),h(t),queueMicrotask(p);else{t.integration=e,t.logic=void 0;let n=Up(r,e);t.config={},t.icon=n?.icon,Vp(t,n),s=Hp(n),Gp(t,n),h(t),queueMicrotask(p)}}}}]},{key:`mqttConnection`,type:`input-toggle`,props:{toggleLabel:`MQTT Connection`,disabled:u(o)},hooks:{onModelChange:(e,t)=>{e?t.mqtt={server:``,topic:``,username:``,password:``,...t.mqtt||{}}:t.mqtt={}}}},{hide:l,fieldGroupClassName:`d-grid grid-columns-1 grid-columns-md-2 gap-4`,fieldGroup:[{hide:l,fieldGroupClassName:`d-flex flex-column gap-4`,fieldGroup:[{key:`mqtt.server`,type:`input-text`,hide:l,props:{label:`MQTT Server`,required:!0}},{key:`mqtt.topic`,type:`input-text`,hide:l,props:{label:`MQTT Topic`,required:!0}}]},{hide:l,fieldGroupClassName:`d-flex flex-column gap-4`,fieldGroup:[{key:`mqtt.username`,type:`input-text`,hide:l,props:{label:`MQTT Username`}},{key:`mqtt.password`,type:`input-password`,hide:l,props:{label:`MQTT Password`}}]}]},{key:`logic`,type:`input-code`,hide:e=>e._selectedIntegration!==`custom`,props:{label:`Provider Logic`,required:!0}},{key:`_integrationConfig`,hide:e=>e._selectedIntegration===`custom`,fieldGroup:s}],_=()=>[{key:`heartbeat.timeoutMs`,type:`input-unit`,className:`w-lg-25`,props:{label:`Timeout`,type:`time`,defaultUnit:`s`,min:0,help:`If the provider has no activity for this time, heartbeat actions will run. The API stores this value in milliseconds. Use 0 or leave empty to disable heartbeat.`}},{key:`heartbeat.actions`,type:`input-script-actions`,props:{label:`Scripts`,addLabel:`Add Script`,scripts:i,includeValue:!1}}],ee=()=>[{type:`template`,template:v`
        <div class="mb-4">
          <app-button-tabs
            .tabs=${Kp}
            .activeTab=${o._tab}
            @tab-change=${m}
          ></app-button-tabs>
        </div>
      `},...g().map(e=>({...e,hide:o._tab===`general`?e.hide:!0})),..._().map(e=>({...e,hide:o._tab===`heartbeat`?e.hide:!0}))];return d=ee(),await G({title:n?`Edit ${t?.name}`:`Register New Provider`,model:o,fields:d,advancedEditor:ee,onFormReady:e=>{f=e},onBeforeSubmit:async()=>{try{return delete o._tab,o.mqttConnection!==!0&&(o.mqtt={}),o.heartbeat&&(delete o.heartbeat._action,delete o.heartbeat.timeout,(o.heartbeat.timeoutMs===null||o.heartbeat.timeoutMs===``)&&delete o.heartbeat.timeoutMs,o.heartbeat.actions=Jp(o.heartbeat.actions||[])),n?await Y.getState().updateProvider(t._id,o):await Y.getState().addProvider(o),!0}catch{return!1}}})}var Xp=class extends w{constructor(...e){super(...e),this.params={},this.providers=[]}connectedCallback(){super.connectedCallback(),this.setListPageMeta(),Y.getState().fetchProviders(),this.connectProviderStatusSse()}disconnectedCallback(){super.disconnectedCallback(),this.eventSource?.close(),this.eventSource=void 0,Q.getState().setPageMeta(null)}setListPageMeta(){Q.getState().setPageMeta({title:`Providers`,description:`Add and manage providers from various integrations`,action:v`
        <app-button
          variant="primary"
          background
          .icon=${qi}
          label="Register Provider"
          @click=${Yp}
        ></app-button>
      `})}connectProviderStatusSse(){this.eventSource?.close(),this.eventSource=N.sse(`/providers/changes`),this.eventSource.onmessage=e=>{if(e.type!==`message`||!e.payload)return;let t=e.payload,n=Y.getState().getProviderById(t._id)?.status;Y.getState().updateProviderStatus(t),n&&n!==t.status&&this.showProviderStatusNotification(t,n)}}showProviderStatusNotification(e,t){let n=e.status||`disconnected`,r=n===`connected`?`connected`:n===`error`?`error`:n===`disabled`?`disabled`:`disconnected`;M.show({variant:n===`connected`?`success`:n===`error`?`error`:`warning`,message:`Provider ${e.name} is ${r}`,details:e.error||`Previous status: ${t}`})}render(){let e=this.params.providerId;if(this.providers.length===0)return v`
        <div class="empty-state" style="min-height: 16rem;">
          <div class="text-center">
            <div class="mb-2 fs-5 text-muted">${j(`No providers registered yet`)}</div>
            <div class="text-secondary">${j(`Registered providers will appear here`)}</div>
          </div>
        </div>
      `;if(e)return v`<router-outlet></router-outlet>`;{let e=this.providers.filter(e=>e.status===`connected`).length,t=this.providers.length,n=t-e;return v`
        <div class="d-flex flex-column gap-6">
          <div class="d-grid grid-columns-1 grid-columns-md-3 gap-4">
            <div class="card">
              <div class="card-body d-flex align-items-center gap-4">
                <span class="card-icon">
                  <app-icon .icon=${qi}></app-icon>
                </span>
                <div>
                  <div class="fw-semibold">${j(`Total Providers`)}</div>
                  <div class="fs-4 fw-bold lh-1 mt-2">${t}</div>
                </div>
              </div>
            </div>
            <div class="card">
              <div class="card-body d-flex align-items-center gap-4">
                <span class="card-icon">
                  <app-icon .icon=${ar}></app-icon>
                </span>
                <div>
                  <div class="fw-semibold">${j(`Online`)}</div>
                  <div class="fs-4 fw-bold lh-1 mt-2">${e}</div>
                </div>
              </div>
            </div>
            <div class="card">
              <div class="card-body d-flex align-items-center gap-4">
                <span class="card-icon">
                  <app-icon .icon=${nn}></app-icon>
                </span>
                <div>
                  <div class="fw-semibold">${j(`Offline`)}</div>
                  <div class="fs-4 fw-bold lh-1 mt-2">${n}</div>
                </div>
              </div>
            </div>
          </div>

          <div class="d-grid grid-columns-1 grid-columns-md-2 gap-4">
            ${this.providers.map(e=>{let t=e.status||`disconnected`,n=t===`error`,r=t===`disabled`,i=t===`connected`,a=i?`text-success`:n?`text-danger`:r?`text-secondary`:`text-warning`,o=i?`circle-success`:n?`circle-danger`:r?`circle-secondary`:`circle-warning`,s=i?`Connected`:n?`Error`:r?`Disabled`:`Disconnected`;return v`
                <div class="btn-card-wrap">
                  <button
                    routerLink=${`/settings/providers/${e._id}/devices`}
                    class="btn btn-card ${n?`btn-card-danger`:``}"
                  >
                    <span class="card-icon">
                      ${e.icon?v`<app-icon .icon=${Ms(e.icon)}></app-icon>`:``}
                    </span>
                    <div class="flex-grow-1 min-w-0">
                      <h4 class="card-title mb-2">${e.name}</h4>
                      <div class="${a} fw-semibold">
                        <span class="circle ${o} mr-2"></span>
                        ${j(s)}
                      </div>
                      ${n&&e.error?v`<div class="text-danger mt-1 text-break">${e.error}</div>`:``}
                      <div class="text-muted mt-1">
                        ${j(`Integration:`)} ${e.integration||`custom`}
                      </div>
                    </div>
                  </button>
                  <div class="btn-card-actions">
                    ${r?v`
                        <app-button
                          .outline=${!0}
                          size="sm"
                          .icon=${Gi}
                          ${V(`Start`)}
                          @click=${()=>Y.getState().enableProvider(e._id)}
                        ></app-button>`:i?``:v`
                          <app-button
                            .outline=${!0}
                            size="sm"
                            .icon=${Yi}
                            ${V(`Reconnect`)}
                            @click=${()=>Y.getState().reconnectProvider(e._id)}
                          ></app-button>`}
                    ${r?``:v`
                        <app-button
                          .outline=${!0}
                          size="sm"
                          .icon=${Vi}
                          ${V(`Stop`)}
                          @click=${()=>Y.getState().disableProvider(e._id)}
                        ></app-button>`}
                    <app-button
                      .outline=${!0}
                      size="sm"
                      .icon=${Mr}
                      ${V(`Edit`)}
                      @click=${()=>Yp({provider:e})}
                    ></app-button>
                    <app-button
                      variant="danger"
                      .outline=${!0}
                      size="sm"
                      ${B({title:`Delete Provider`,message:`Are you sure you want to delete "${e.name}"?`,variant:`danger`})}
                      .icon=${k}
                      ${V(`Delete`)}
                      @click=${()=>Y.getState().removeProvider(e._id)}
                    ></app-button>
                  </div>
                </div>
              `})}
          </div>
        </div>
      `}}};D([C(),Vt()],Xp.prototype,`params`,void 0),D([C(),H(Y,e=>e.providers)],Xp.prototype,`providers`,void 0),Xp=D([x(`providers-view`)],Xp);var Zp=class extends w{constructor(...e){super(...e),this.params={},this.currentPath=``,this.providers=[]}connectedCallback(){super.connectedCallback(),setTimeout(()=>this.updatePageMeta())}disconnectedCallback(){super.disconnectedCallback(),Q.getState().setPageMeta(null)}updated(e){super.updated(e),(e.has(`providers`)||e.has(`params`))&&this.updatePageMeta(),(e.has(`providers`)||e.has(`params`)||e.has(`currentPath`))&&this.redirectFromUnavailableConsole()}get currentProvider(){return this.providers.find(e=>e._id===this.params.providerId)}hasMqttConsole(e){return e?.mqttConnection!==!1&&!!e?.mqtt?.server}redirectFromUnavailableConsole(){let e=this.params.providerId;!e||!this.currentPath.includes(`/console`)||this.hasMqttConsole(this.currentProvider)||T(`/settings/providers/${e}/devices`,{replace:!0})}updatePageMeta(){let e=this.currentProvider;if(e){let t=[];e._id&&t.push(`ID: ${e._id}`),e.mqtt?.server&&t.push(`Server: ${e.mqtt.server}`),e.mqtt?.topic&&t.push(`Topic: ${e.mqtt.topic}`),Q.getState().setPageMeta({title:e.name,description:t.join(` · `)||void 0})}}render(){let e=this.params.providerId,t=this.currentPath.includes(`/console`),n=this.hasMqttConsole(this.currentProvider);return v`
      <div class="space-y-6">
        <app-tabs
          .items=${[{id:`devices`,label:`Devices`,icon:mr,routerLink:`/settings/providers/${e}/devices`},...n?[{id:`console`,label:`Console`,icon:rr,routerLink:`/settings/providers/${e}/console`}]:[]]}
          .activeId=${t?`console`:`devices`}
          ariaLabel="Provider sections"
        ></app-tabs>

        <div class="mt-2">
          <router-outlet></router-outlet>
        </div>
      </div>
    `}};D([C(),Vt()],Zp.prototype,`params`,void 0),D([C(),zt()],Zp.prototype,`currentPath`,void 0),D([C(),H(Y,e=>e.providers)],Zp.prototype,`providers`,void 0),Zp=D([x(`provider-detail-view`)],Zp);function Qp(e,t=[]){if(!(!e?.vendor||!e?.model))return t.find(t=>t.externalId!==e?.externalId&&t.definition&&t.vendor===e.vendor&&t.model===e.model)?.definition}function $p(e){return String(e||``).trim().normalize(`NFD`).replace(/[\u0300-\u036f]/g,``).toLowerCase().replace(/[^a-z0-9]+/g,`-`).replace(/^-+|-+$/g,``)}function em(e){let t=String(e?.definitionId||``).trim(),n=String(e?.vendor||``).trim(),r=String(e?.model||``).trim();if(!t)return``;if(!n||!r)return t.replace(/-/g,` `).toUpperCase();let i=[$p(n),$p(r)].filter(Boolean).join(`-`),a=$p(t);if(!i||!a.endsWith(i))return t.replace(/-/g,` `).toUpperCase();let o=a.slice(0,a.length-i.length).replace(/-+$/g,``);return`${o?`${o.replace(/-/g,` `).toUpperCase()} `:``}${n.toUpperCase()} ${r.toUpperCase()}`.trim()}function tm(e,t,n=[]){let r=Y.getState().getProviderById(e),i=n.find(e=>e.filename===r?.integration),a=em(t),o=i?.name||r?.name||r?.integration?.replace(/\.js$/,``)||e,s=(a?[a]:[o]).map($p).filter(Boolean).join(`-`),c=a||o;return{id:s||t?.definitionId||``,name:c||t?.definitionId||t?.model||t?.name||`Definition`}}function nm(e,t,n,r=[]){let i=tm(e,t,r);return{_id:i.id,name:i.name,fields:sp(n?.fields||[]),history:n?.history||{enabled:!1},metadata:{}}}async function rm(e){let{providerId:t,device:n,devices:r}=e||{};await K.getState().fetchDefinitions();let i=await N.get(`/providers/integrations`),a=!n?._id&&n?.definitionId?await Y.getState().getDefinitionById(t,n.definitionId):void 0,o=JSON.parse(JSON.stringify(n||{}));o.definition?._id&&(o.definition=o.definition._id),o.providerDefinition=nm(t,n,a,i);let s=o._id?void 0:Qp(n,r);return!o._id&&s&&(o._setDefinition=!0,o.definition=s),o._stateJson=JSON.stringify(o.state||{},null,2),await G({title:`Link: ${n?.name}`,model:o,fields:[{type:`input-html`,hide:!0,props:{subscribe:e=>Y.subscribe(r=>{let i=(r.devices[t]||[]).find(e=>e.externalId===n.externalId);i&&i.lastSeenAt!==o.lastSeenAt&&e()}),html:e=>{let r=(Y.getState().devices[t]||[]).find(e=>e.externalId===n.externalId)||e;return v`
              <div class="p-4 bg-gray-800 rounded-lg">
                <div class="flex gap-4 text-sm text-gray-400 mt-1">
                  <span>${r.externalId}</span>
                  <span>•</span>
                  <span>${r.vendor}</span>
                  <span>•</span>
                  <span>${r.model}</span>
                  ${r.lastSeenAt?v`
                    <span>•</span>
                    <span>Last seen: ${new Date(r.lastSeenAt).toLocaleString()}</span>
                  `:``}
                </div>
              </div>
          `}}},{type:`input-html`,props:{html:()=>v`
            <div class="d-grid grid-columns-1 grid-columns-md-2 gap-3">
              <div>
                <div class="field-label">${j(`External ID`)}</div>
                <div class="form-control d-flex align-items-center">
                  ${n?.externalId||o.externalId||`-`}
                </div>
              </div>
              ${n?.lastSeenAt?v`
                <div>
                  <div class="field-label">${j(`Last seen`)}</div>
                  <div class="form-control d-flex align-items-center">
                    ${zl(n.lastSeenAt,`full`)}
                  </div>
                </div>
              `:``}
            </div>
          `}},{key:`name`,type:`input-text`,props:{label:`Device Name`,required:!0}},{key:`zone`,type:`input-select`,props:{label:`Zone`,required:!0,options:I.getState().getFlatZonesWithParents().map(e=>({label:e.fullPath,value:e.id}))}},{key:`_stateJson`,type:`input-json`,props:{label:`State`,rows:8,readonly:!0,maxHeight:`120px`}},{key:`_setDefinition`,type:`input-radio`,hide:e=>!!e._id,defaultValue:o._setDefinition??!!o.zone,props:{label:`Device Definition`,options:[{label:`Use from provider`,value:!1},{label:`Use exiting`,value:!0}]}},{key:`definition`,type:`input-select`,hide:e=>e._setDefinition!==!0,props:{label:`Definition`,required:!0,options:K.getState().getDefinitions().map(e=>({label:e.name,value:e._id}))}},{type:`input-accordion`,hide:e=>e._id||e._setDefinition===!0,props:{title:`Definition from provider`,initExpand:!1},fieldArray:[{fieldGroupClassName:`d-grid grid-columns-1 grid-columns-md-2 gap-3`,fieldGroup:[{key:`providerDefinition.name`,type:`input-text`,props:{label:`Definition name`,required:!0}},{key:`providerDefinition._id`,type:`input-text`,props:{label:`Definition ID`,placeholder:`auto`,help:`Optional. Leave empty to let the API generate the definition ID.`}}]},{key:`providerDefinition.fields`,type:`input-array`,props:{label:`Fields`},fieldArray:[...ip()]}]}],onBeforeSubmit:async e=>{if(Object.assign(o,e||{}),o._id)return await q.getState().updateDevice(o._id,{name:o.name,zone:o.zone,definition:o.definition}),!0;if(!o._setDefinition){let e=o.providerDefinition||nm(t,n,a,i),r=typeof e._id==`string`&&e._id.trim()?e._id.trim():void 0,s=e.name?.trim()||n.definitionId,c=(await K.getState().getDefinitions()).find(e=>r&&e._id===r||e.name===s);c?o.definition=c._id:o.definition=(await K.getState().addDefinition({_id:r,name:s,fields:cp(e.fields||[]),history:e.history,metadata:e.metadata||{}}))._id}return await q.getState().addDevice({name:o.name,provider:t,externalId:n.externalId,zone:o.zone,definition:o.definition}),!0}})}var im=class extends w{constructor(...e){super(...e),this.formControlModels=new Map,this.formOptionalIncludes=new Map}connectedCallback(){super.connectedCallback();let e=Y.getState().getProviderDevices(this.providerId).find(e=>e.externalId===this.device.externalId)||this.device;this.currentDeviceSource=e,this.currentDevice={...e,state:e.state?{...e.state}:void 0},this.unsubscribe=Y.subscribe(e=>{let t=(e.devices[this.providerId]||[]).find(e=>e.externalId===this.device.externalId);if(t){if(t===this.currentDeviceSource)return;this.currentDeviceSource=t,this.currentDevice={...t,state:t.state?{...t.state}:void 0},this.requestUpdate()}}),this.connectProviderChanges()}disconnectedCallback(){super.disconnectedCallback(),this.unsubscribe?.(),this.eventSource?.close(),this.eventSource=void 0}connectProviderChanges(){this.providerId&&(this.eventSource?.close(),this.eventSource=N.sse(`/providers/${this.providerId}/changes`),this.eventSource.onmessage=e=>{if(e.type!==`message`||!e.payload)return;let{externalId:t,state:n,lastSeenAt:r,available:i}=e.payload;t&&Y.getState().updateDevice(this.providerId,t,{state:n,lastSeenAt:r,available:i})})}isStructuredValue(e){return typeof e==`object`&&!!e}getDisplayValue(e,t){return e.type===`boolean`?e.extra?.valueTrue||e.extra?.valueFalse?t===e.extra?.valueTrue||t===!0?e.extra?.valueTrue:e.extra?.valueFalse:t:(e.type===`color`&&this.isStructuredValue(t)&&`x`in t&&`y`in t,t)}transformControlValue(e,t){return e.type===`boolean`&&(e.extra?.valueTrue!==void 0||e.extra?.valueFalse!==void 0)?t?e.extra?.valueTrue:e.extra?.valueFalse:t}async sendControlCommand(e){await N.post(`/providers/${this.providerId}/commands`,{externalId:this.currentDevice.externalId,command:e})}async handleListAction(e){let{action:t,field:n,index:r,id:i,checked:a}=e.detail;n?.key&&await this.sendControlCommand({[n.key]:{action:t,index:r,id:i,...a===void 0?{}:{checked:a}}})}cleanCommandPayload(e){let t={};for(let[n,r]of Object.entries(e||{}))r!==void 0&&r!==``&&(t[n]=r);return t}isEmptyControlValue(e){return e==null||e===``}isFormControlField(e){return e?.type===`form`}getControlStateFields(e){let t=[];for(let n of e||[])this.isFormControlField(n)||t.push(n);return t}getFormControlModel(e){let t=this.getGroupKey(e),n=this.formControlModels.get(t);if(n)return n;let r=this.createEmptyFormControlModel(e);return this.formControlModels.set(t,r),r}getGroupKey(e){return e.key||e.name}createEmptyFormControlModel(e){let t={};for(let n of e.fields||[])n.default===void 0?n.defaultValue===void 0?n.type===`boolean`&&(t[n.key]=!1):t[n.key]=n.defaultValue:t[n.key]=n.default;return t}resetFormControlModel(e){this.formControlModels.set(this.getGroupKey(e),this.createEmptyFormControlModel(e));for(let t of e.fields||[])this.formOptionalIncludes.delete(this.getFormOptionalFieldKey(e,t));this.requestUpdate()}getFormOptionalFieldKey(e,t){return`${this.getGroupKey(e)}:${t.key}`}isFormOptionalFieldIncluded(e,t){return this.formOptionalIncludes.get(this.getFormOptionalFieldKey(e,t))===!0}setFormOptionalFieldIncluded(e,t,n){this.formOptionalIncludes.set(this.getFormOptionalFieldKey(e,t),n),this.requestUpdate()}createFormCommand(e,t){let n={};for(let r of e.fields||[]){let i=this.transformControlValue(r,t[r.key]),a=this.isEmptyControlValue(i);if(r.required&&a)return null;if(r.optional){this.isFormOptionalFieldIncluded(e,r)&&(n[r.key]=i);continue}(r.required||!a||r.type===`boolean`)&&(n[r.key]=i)}let r=this.cleanCommandPayload(n);return Object.keys(r).length===0?(e.fields||[]).length>0&&(e.fields||[]).every(e=>e.optional)?{}:null:r}createFormCommandPayload(e,t){return e.key?{[e.key]:t}:t}createFormField(e,t,n){let r={key:e.key,hooks:n},i={label:t,required:e.required};switch(e.type){case`boolean`:return{...r,type:`input-toggle`,props:{required:e.required,toggleLabel:t,helperText:e.extra?.min===void 0?void 0:`Range: ${e.extra.min} - ${e.extra.max}`}};case`enum`:return{...r,type:`input-select`,props:{...i,multiple:e.extra?.multiple===!0,options:e.values?.map(e=>({value:typeof e==`string`?e:e.value,label:typeof e==`string`?e:e.name}))||[]}};case`number`:{let t=e.extra?.min!==void 0&&e.extra?.max!==void 0;return{...r,type:t?`input-range`:`input-number`,props:{...i,min:e.extra?.min,max:e.extra?.max,suffix:e.extra?.suffix,helperText:!t&&e.extra?.min!==void 0?`Range: ${e.extra.min} - ${e.extra.max}`:void 0}}}case`color`:return{...r,type:`input-color`,props:i};case`date`:return{...r,type:`input-date`,props:i};case`datetime`:return{...r,type:`input-text`,props:{...i,placeholder:`YYYY-MM-DDTHH:mm:ss.sssZ`}};case`time`:return{...r,type:`input-text`,props:{...i,placeholder:`HH:mm`}};case`array-string`:return{...r,type:`input-array-text`,props:i};case`array-object`:return{...r,type:`input-array`,props:i,fieldArray:(e.fields||[]).map(e=>this.createFormField(e,e.name))};case`object`:return{...r,type:`input-json`,props:{...i,rows:4}};default:return{...r,type:`input-text`,props:{...i,placeholder:e.placeholder}}}}renderActionControlButton(e,t){return v`
      <app-button
        label=${t}
        variant="primary"
        background
        @click=${async()=>{let t={[e.key]:!0};try{await this.sendControlCommand(t),console.log(`Command sent successfully:`,t)}catch(e){console.error(`Failed to send control command:`,e),alert(`Failed to send command: `+(e.message||`Unknown error`))}}}
      ></app-button>
    `}renderFormControlGroup(e){let t=this.getFormControlModel(e),n=this.createFormCommand(e,t)!==null;return v`
      <div class="card p-3 form-stack mb-3">
        <div class="fw-semibold">${e.name}</div>
        <div class="form-stack">
          ${(e.fields||[]).map(n=>{let r=this.createFormField(n,n.optional?``:n.name,{onModelChange:e=>{t[n.key]=e,this.requestUpdate()}}),i={[n.key]:t[n.key]};return n.optional?v`
              <div class="d-flex gap-3 align-items-start">
                <div class="mt-n2 flex-shrink-0">
                  <input-checkbox
                    .key=${this.getFormOptionalFieldKey(e,n)}
                    .value=${this.isFormOptionalFieldIncluded(e,n)}
                    .props=${{}}
                    @field-change=${t=>this.setFormOptionalFieldIncluded(e,n,t.detail.value)}
                  ></input-checkbox>
                </div>
                <div class="min-w-0 flex-grow-1">
                  <label class="form-label mb-2">
                    ${n.name}
                  </label>
                  <div class="${this.isFormOptionalFieldIncluded(e,n)?``:`pointer-events-none opacity-50`}">
                    <app-form-fields
                      .fields=${[r]}
                      .model=${i}
                    ></app-form-fields>
                  </div>
                </div>
              </div>
            `:v`
                <app-form-fields
                  .fields=${[r]}
                  .model=${i}
                ></app-form-fields>
              `})}
        </div>
        <div class="d-flex justify-content-end">
          <app-button
            label=${e.extra?.form?.submitLabel||`Submit`}
            variant="primary"
            background
            .disabled=${!n}
            @click=${async()=>{let n=this.createFormCommand(e,t);if(!n)return;let r=this.createFormCommandPayload(e,n);try{await this.sendControlCommand(r),this.resetFormControlModel(e),console.log(`Command sent successfully:`,r)}catch(e){console.error(`Failed to send control command:`,e),alert(`Failed to send command: `+(e.message||`Unknown error`))}}}
          ></app-button>
        </div>
      </div>
    `}getInfoBarItems(){let e=this.definition?.metadata||{};return[this.currentDevice?.externalId,e.vendor,e.model,e.type,this.currentDevice?.lastSeenAt?`Last seen: ${new Date(this.currentDevice.lastSeenAt).toLocaleString()}`:void 0].filter(e=>e!=null&&String(e).trim()!==``).map(e=>String(e))}render(){let e=this.definition.fields.filter(e=>e.control||e.type===`form`||e.type===`button`),t=this.definition.fields.filter(e=>!e.control&&e.type!==`form`&&e.type!==`button`),n=this.getControlStateFields(e),r=this.getInfoBarItems(),i={...this.currentDevice};for(let t of e){if(this.isFormControlField(t))continue;let e=this.currentDevice.state?.[t.key];e!=null&&(i[t.key]=t.type===`boolean`?e===t.extra?.valueTrue||e===!0:e)}let a=[];for(let t of e){if(this.isFormControlField(t)){a.push({template:this.renderFormControlGroup(t)});continue}if(t.type===`button`){a.push({template:this.renderActionControlButton(t,t.name)});continue}a.push(this.createFormField(t,t.name,{onModelChange:async e=>{let n={[t.key]:this.transformControlValue(t,e)};try{await this.sendControlCommand(n),console.log(`Command sent successfully:`,n)}catch(e){console.error(`Failed to send control command:`,e),alert(`Failed to send command: `+(e.message||`Unknown error`))}}}))}let o=[];for(let e of[...n,...t]){let t=this.currentDevice.state?.[e.key];t!=null&&o.push({key:e.key,name:e.name,value:this.getDisplayValue(e,t),suffix:e.extra?.suffix,type:e.type,field:e})}return v`
      <div>
        ${r.length?v`
          <div class="card p-3 mb-4">
            <div class="d-flex flex-wrap align-items-center gap-2 small text-muted">
              ${r.map((e,t)=>v`
                ${t>0?v`<span class="text-muted">&bull;</span>`:``}
                <span>${e}</span>
              `)}
            </div>
          </div>
        `:``}

        ${a.length>0||o.length>0?v`
          <div class="d-grid grid-columns-1 ${a.length>0&&o.length>0?`grid-columns-lg-2`:``} gap-3">
          <!-- Left: Control Fields -->
          ${a.length>0?v`
            <div>
              <h4 class="mt-0">${j(`Control Fields`)}</h4>
              <div class="card p-3">
                <app-form-fields
                  .fields=${a}
                  .model=${i}
                ></app-form-fields>
              </div>
            </div>
          `:``}

          ${o.length>0?v`
            <nq-current-state
              .stateValue=${this.currentDevice.state}
              .fields=${o}
              @list-action=${e=>void this.handleListAction(e)}
            ></nq-current-state>
          `:``}
          </div>
        `:``}
      </div>
    `}};D([S({type:String})],im.prototype,`providerId`,void 0),D([S({type:Object})],im.prototype,`device`,void 0),D([S({type:Object})],im.prototype,`definition`,void 0),D([C()],im.prototype,`currentDevice`,void 0),im=D([x(`content-control-provider-device`)],im);async function am(e){let{providerId:t,device:n}=e||{};if(!t)return null;await Y.getState().fetchDevices(t,!0);let r=v`
    <content-control-provider-device
      .providerId=${t}
      .device=${n}
      .definition=${await Y.getState().getDefinitionById(t,n.definitionId)}
    ></content-control-provider-device>
  `;return await z.open({title:`State: ${n.name}`,content:r,width:`50rem`,closeOnBackdrop:!0,closeOnEscape:!0,buttons:[{label:`OK`,variant:`primary`,action:()=>z.cancel()}]}).catch(()=>null)}var om=class extends w{constructor(...e){super(...e),this.params={},this.devices=[],this.linkedDevices=[],this.isPaused=!1}getLinkedDeviceName(e,t){let n=e?.friendlyName===e.externalId?`${e.vendor}: ${e.model}`:e.friendlyName;return t&&([K.getState().getDefinitionById(t.definition)?.name,t.name].filter(Boolean).join(`: `)||t.name)||n}get columns(){return[{key:`name`,label:`Name`,sortable:!0,filterable:!0,searchable:!0},{key:`externalId`,label:`External ID`,sortable:!0,filterable:!0,searchable:!0},{key:`zoneName`,label:`Zone`,sortable:!0,filterable:!0,searchable:!0},{key:`vendor`,label:`Vendor`,sortable:!0,filterable:!0,searchable:!0,hidden:!0},{key:`model`,label:`Model`,sortable:!0,filterable:!0,searchable:!0,hidden:!0},{key:`lastSeenAt`,label:`Last Seen`,sortable:!0,filterable:!0,type:`date`}]}connectedCallback(){super.connectedCallback(),setTimeout(async()=>{await q.getState().fetchDevices(),await K.getState().fetchDefinitions();let e=this.params.providerId;Y.getState().fetchDevices(e),this.eventSource=N.sse(`/providers/`+e+`/changes`),this.eventSource.onmessage=t=>{if(t.type===`message`&&t.payload){let{externalId:n,state:r,lastSeenAt:i}=t.payload;n&&!this.isPaused&&Y.getState().updateDevice(e,n,{state:r,lastSeenAt:i})}}})}disconnectedCallback(){super.disconnectedCallback(),this.eventSource&&=(this.eventSource.close(),void 0)}render(){let e=this.devices.map(e=>{let t=this.linkedDevices.find(t=>t.externalId===e.externalId&&t.provider===this.params.providerId),n;return t?.zone&&(n=I.getState().getZoneById(t.zone)),{...e,name:this.getLinkedDeviceName(e,t),_id:t?._id,_linkedDevice:t,zone:n?.id,definition:t?.definition,zoneName:n?.fullName}}),t={id:`provider-devices`,mode:`ui`,sort:`-lastSeenAt`,saveState:!0,actions:(t,n)=>{let r=t._linkedDevice;return v`
          <div>
            ${r?v`
              <app-button
                variant="ghost"
                label="Edit"
                .icon=${A}
                @click=${()=>Vf({device:r})}
              >
              </app-button>
            `:v`
              <app-button
                variant="ghost"
                label="Link"
                .icon=${yi}
                @click=${()=>rm({device:t,providerId:this.params.providerId,devices:e})}
              >
              </app-button>
            `}
          <app-button
            variant="ghost"
            label="State"
            .icon=${Kr}
            @click=${()=>r?fp({device:r}):am({device:t,providerId:this.params.providerId})}
          >
          </app-button>
          </div>
        `},extra:v`
        <div>
          <input-toggle
            .props=${{toggleLabel:`Autorefresh`}}
            .value=${!this.isPaused}
            @field-change=${e=>{this.isPaused=!e.detail.value,this.isPaused||Y.getState().fetchDevices(this.params.providerId,!0)}}
          ></input-toggle>
        </div>
      `};return v`
      <nq-table
        .data=${e}
        .columns=${this.columns}
        .options=${t}
      ></nq-table>
    `}};D([C(),Vt()],om.prototype,`params`,void 0),D([C(),H(Y,(e,t)=>t?e.devices[t]??[]:[],e=>e.params?.providerId??null)],om.prototype,`devices`,void 0),D([C(),H(q,e=>e.devices)],om.prototype,`linkedDevices`,void 0),D([C()],om.prototype,`isPaused`,void 0),om=D([x(`provider-devices-view`)],om);var sm=500,cm=class extends w{constructor(...e){super(...e),this.params={},this.providers=[],this.allCommands={},this.messages=[],this.formModel={},this.isPaused=!1}get currentProvider(){return this.providers.find(e=>e._id===this.params.providerId)}get savedCommands(){let e=this.params.providerId;return e&&this.allCommands[e]||[]}get baseTopic(){return(this.currentProvider?.mqtt?.topic||``).replace(/\/(#|\+)$/,``)+`/`}connectedCallback(){super.connectedCallback(),Y.getState().fetchProviders(),setTimeout(()=>{this.formModel={topic:this.baseTopic},this.connectSSE()})}disconnectedCallback(){super.disconnectedCallback(),this.disconnectSSE()}connectSSE(){this.disconnectSSE();let e=this.params.providerId;e&&(this.eventSource=N.sse(`/providers/${e}/mqtt`),this.eventSource.onmessage=e=>{let t=e.payload;!t?.topic||this.isPaused||this.addMessage({topic:t.topic,payload:t.payload,timestamp:t.timestamp})},this.eventSource.onerror=()=>{console.warn(`[Provider MQTT] SSE connection lost`)})}disconnectSSE(){this.eventSource&&=(this.eventSource.close(),void 0)}addMessage(e){let t=[...this.messages,e];t.length>sm&&t.splice(0,t.length-sm),this.messages=t}updated(e){super.updated(e),e.has(`messages`)&&this.scrollMessagesToBottom()}scrollMessagesToBottom(){requestAnimationFrame(()=>{let e=this.querySelector(`#provider-mqtt-log`);e&&(e.scrollTop=e.scrollHeight)})}async handlePublish(e){e.preventDefault(),e.stopPropagation();let t=this.params.providerId,{topic:n,payload:r}=this.formModel;if(!(!t||!n||!r))try{await N.post(`/providers/${t}/mqtt`,{topic:n,payload:r})}catch(e){console.error(`Publish error:`,e)}}handleSave(){let e=this.params.providerId,{topic:t,payload:n}=this.formModel;!e||!t||!n||Y.getState().addSavedCommand(e,t,n)}async handleQuickSend(e){let t=this.params.providerId;if(t)try{await N.post(`/providers/${t}/mqtt`,{topic:e.topic,payload:e.payload})}catch(e){console.error(`Publish error:`,e)}}handleDeleteCommand(e){let t=this.params.providerId;t&&Y.getState().removeSavedCommand(t,e.id)}formatTimestamp(e){try{return new Date(e).toLocaleTimeString()}catch{return e}}formatPayload(e){if(typeof e==`string`)return e;try{return JSON.stringify(e,null,2)}catch{return String(e)}}render(){return v`
      <div class="console-layout">
        <div class="console-main">
          ${this.renderMessageLog()}
        </div>
        <div class="console-sidebar">
          ${this.renderPublishPanel()}
          ${this.savedCommands.length>0?this.renderSavedCommands():``}
        </div>
      </div>
    `}renderSavedCommands(){return v`
      <div class="card">
        <div class="card-body">
          <h3 class="card-title mb-3">${j(`Saved Commands`)}</h3>
          <div class="console-saved-list">
          ${this.savedCommands.map(e=>v`
              <div class="console-saved-item">
                <div class="flex-grow-1 min-w-0">
                  <span class="d-block small font-monospace text-warning console-saved-text">${e.topic}</span>
                  <span class="d-block small font-monospace text-muted console-saved-text">${e.payload}</span>
                </div>
                <div class="console-saved-actions">
                  <app-button
                    size="sm"
                    variant="ghost"
                    .outline=${!0}
                    .icon=${na}
                    ${V(`Send`)}
                    @click=${()=>this.handleQuickSend(e)}
                  ></app-button>
                  <app-button
                    size="sm"
                    variant="ghost"
                    .outline=${!0}
                    ${V(`Delete`)}
                    className="text-danger"
                    .icon=${k}
                    @click=${()=>this.handleDeleteCommand(e)}
                  ></app-button>
                </div>
              </div>
            `)}
          </div>
        </div>
      </div>
    `}get formFields(){return[{key:`topic`,type:`input-text`,props:{label:`Topic`,required:!0}},{key:`payload`,type:`input-textarea`,props:{label:`Payload`,placeholder:`{"state": "ON"}`,required:!0,rows:4}}]}renderPublishPanel(){return v`
      <div class="card">
        <div class="card-body">
          <h3 class="card-title mb-4">${j(`Send Message`)}</h3>
        <form @submit=${this.handlePublish} class="form-stack gap-5">
          <app-form-fields
            .fields=${this.formFields}
            .model=${this.formModel}
          ></app-form-fields>
          <div class="d-flex align-items-center gap-2 justify-content-end">
            <app-button
              label="Save"
              variant="ghost"
              .icon=${Ur}
              type="button"
              @click=${()=>this.handleSave()}
            ></app-button>
            <app-button
              label="Send"
              background
              .icon=${na}
              type="submit"
            ></app-button>
          </div>
        </form>
        </div>
      </div>
    `}renderMessageLog(){return v`
      <div class="card h-100 min-h-0">
        <div class="card-body h-100 min-h-0 d-flex flex-column">
        <div class="d-flex align-items-center justify-content-between mb-3">
          <h3 class="card-title">
            Messages
            <span class="small text-muted ml-2">(${this.messages.length})</span>
          </h3>
          <div class="d-flex align-items-center gap-2">
            <app-button
              label=${this.isPaused?`Resume`:`Pause`}
              size="sm"
              variant="ghost"
              .icon=${this.isPaused?Gi:Vi}
              @click=${()=>{this.isPaused=!this.isPaused}}
            ></app-button>
            <app-button
              label="Clear"
              size="sm"
              variant="ghost"
              .icon=${sr}
              @click=${()=>{this.messages=[]}}
            ></app-button>
          </div>
        </div>

        <div
          id="provider-mqtt-log"
          class="console-log"
        >
          ${this.messages.length===0?v`
                <div class="empty-state h-100">
                  Waiting for MQTT messages...
                </div>
              `:this.messages.map(e=>v`
                  <div class="console-message">
                    <div class="d-flex align-items-center justify-content-between gap-2">
                      <span class="console-message-topic" title=${e.topic}>${e.topic}</span>
                      <span class="small text-muted flex-shrink-0">${this.formatTimestamp(e.timestamp)}</span>
                    </div>
                    <div class="console-message-payload">${this.formatPayload(e.payload)}</div>
                  </div>
                `)}
        </div>
        </div>
      </div>
    `}};D([C(),Vt()],cm.prototype,`params`,void 0),D([C(),H(Y,e=>e.providers)],cm.prototype,`providers`,void 0),D([C(),H(Y,e=>e.savedCommands)],cm.prototype,`allCommands`,void 0),D([C()],cm.prototype,`messages`,void 0),D([C()],cm.prototype,`formModel`,void 0),D([C()],cm.prototype,`isPaused`,void 0),cm=D([x(`provider-mqtt-console`)],cm);var lm=class extends w{constructor(...e){super(...e),this.devices=[],this.isPaused=!1}get columns(){return[{key:`_definition.name`,label:`Definition`,sortable:!0,filterable:!0,searchable:!0},{key:`name`,label:`Name`,sortable:!0,filterable:!0,searchable:!0,type:`double`,key2:`externalId`,renderCell:(e,t)=>v`
          <div>
            <div>${e}</div>
            <div class="table-secondary">${t.externalId}</div>
          </div>
        `},{key:`_provider.name`,label:`Provider`,sortable:!0,hidden:!0,filterable:!0,searchable:!0},{key:`_zone.fullName`,label:`Zone`,sortable:!0,filterable:!0,searchable:!0},{key:`tags`,label:`Tags`,sortable:!0,filterable:!0,searchable:!0,type:`array`,filterFn:(e,t)=>(Array.isArray(e.tags)?e.tags:[]).some(e=>String(e)===String(t.value))},{key:`lastSeenAt`,label:`Last Seen`,sortable:!0,filterable:!0,type:`date`,renderCell:e=>v`
            <span class="text-${new Date(e)<new Date(Date.now()-1440*60*1e3)?`danger`:``}">${zl(e,`full`)}</span>
          `}]}renderFilters(){return v`
      <zone-filter columnKey="_zone.fullName"></zone-filter>
      <tag-filter
        columnKey="tags"
        .tags=${q.getState().getTags()}
      ></tag-filter>
    `}connectedCallback(){super.connectedCallback(),setTimeout(async()=>{await K.getState().fetchDefinitions(),await q.getState().fetchDevices(),await Y.getState().fetchProviders(),await I.getState().fetchZones(),this.eventSource=N.sse(`/devices/changes`),this.eventSource.onmessage=e=>{if(e.type===`message`&&e.payload&&!this.isPaused){let{_id:t,state:n,lastSeenAt:r}=e.payload;t&&q.getState().updateDeviceState(t,{state:n,lastSeenAt:r})}}})}disconnectedCallback(){super.disconnectedCallback(),this.eventSource&&=(this.eventSource.close(),void 0)}render(){let e={id:`devices`,mode:`ui`,sort:`name`,filtersExtra:this.renderFilters(),actions:(e,t)=>v`
        <div>
          <app-button
            variant="ghost"
            label="Edit"
            .icon=${A}
            @click=${()=>Vf({device:e})}
          >
          </app-button>
          <app-button
            variant="ghost"
            label="State"
            .icon=${Kr}
            @click=${()=>fp({device:e})}
          >
          </app-button>
          <app-button
            variant="ghost"
            className="text-danger"
            label="Delete"
            ${B({title:`Delete Device`,message:`Are you sure you want to delete "${e.name}"?`,variant:`danger`})}
            .icon=${k}
            @click=${()=>q.getState().removeDevice(e._id)}
          ></app-button>
        </div>
      `,extra:v`
        <div>
          <input-toggle
            .props=${{toggleLabel:`Autorefresh`}}
            .value=${!this.isPaused}
            @field-change=${e=>{this.isPaused=!e.detail.value,this.isPaused||q.getState().fetchDevices(!0)}}
          ></input-toggle>
        </div>
      `};return v`
      <nq-table
        .data=${this.devices.map(e=>({...e,_provider:Y.getState().getProviderById(e.provider),_zone:I.getState().getZoneById(e.zone),_definition:K.getState().getDefinitionById(e.definition)}))}
        .columns=${this.columns}
        .options=${e}
      ></nq-table>
    `}};D([C(),H(q,e=>e.devices)],lm.prototype,`devices`,void 0),D([C()],lm.prototype,`isPaused`,void 0),lm=D([x(`devices-view`)],lm);var um=class extends w{constructor(...e){super(...e),this.definitions=[]}get columns(){return[{key:`name`,label:`Name`,sortable:!0,filterable:!0,searchable:!0},{key:`fields`,label:`Fields`,sortable:!1,filterable:!1,renderCell:e=>v`
            <app-badge .content=${`${(e||[]).length} fields`}></app-badge>
          `},{key:`tags`,label:`Tags`,sortable:!1,filterable:!0,searchable:!0,type:`array`,filterFn:(e,t)=>(Array.isArray(e.tags)?e.tags:[]).some(e=>String(e)===String(t.value)),renderCell:e=>!e||e.length===0?v`<span class="text-muted">${j(`No tags`)}</span>`:v`
            <div class="d-flex gap-1 flex-wrap">
              ${e.map(e=>v`
                <app-badge .variant=${`neutral`} .content=${e}></app-badge>
              `)}
            </div>
          `},{key:`history.enabled`,label:`History`,type:`enum`,sortable:!0,filterable:!0,options:[{value:!0,label:`Enabled`},{value:!1,label:`Disabled`}]}]}connectedCallback(){super.connectedCallback(),Q.getState().setPageMeta({title:`Definitions`,description:`Manage data definitions and schemas`,action:v`
        <app-button
          variant="primary"
          background
          label="Add Definition"
          .icon=${O}
          @click=${()=>lp()}
        ></app-button>
      `}),setTimeout(async()=>{await K.getState().fetchDefinitions()})}disconnectedCallback(){Q.getState().setPageMeta(null),super.disconnectedCallback()}async openReassignDialog(e){let t=this.definitions.filter(t=>t._id&&t._id!==e._id),n={targetDefinition:``};await G({title:`Reassign devices: ${e.name}`,model:n,width:`32rem`,submitLabel:`Reassign`,fields:[{type:`template`,template:v`
            <div class="rounded border border-midnight-700 bg-midnight-900 p-3 text-sm text-midnight-300">
              All devices currently using "${e.name}" will be changed to the selected definition.
            </div>
          `},{key:`targetDefinition`,type:`input-select`,props:{label:`New definition`,required:!0,options:t.map(e=>({value:e._id,label:e.name}))}}],onBeforeSubmit:async()=>{let t=await K.getState().reassignDevices(e._id,n.targetDefinition);return M.show({message:`Reassigned ${t.count} device${t.count===1?``:`s`}`,variant:`success`}),!0}})}showDevices(e){let t={devices:{filters:[{columnKey:`_definition.name`,operator:`$eq`,value:e.name}]}};T(`settings/devices?${new URLSearchParams({filter:JSON.stringify(t)}).toString()}`)}render(){let e={id:`definitions`,mode:`ui`,sort:`name`,filtersExtra:v`
        <tag-filter
          columnKey="tags"
          .tags=${K.getState().getTags()}
        ></tag-filter>
      `,actions:(e,t)=>v`
        <div>
          <app-button
            label="Edit"
            variant="ghost"
            .icon=${A}
            @click=${()=>lp({definition:e})}
          >
          </app-button>
          <app-button
            label="Show devices"
            variant="ghost"
            .icon=${Qa}
            @click=${()=>this.showDevices(e)}
          ></app-button>
          <app-button
            label="Reassign"
            variant="ghost"
            .icon=${Jr}
            @click=${()=>this.openReassignDialog(e)}
          ></app-button>
          <app-button
            variant="ghost"
            className="text-danger"
            label="Delete"
            ${B({title:`Delete Definition`,message:`Are you sure you want to delete "${e.name}"?`,variant:`danger`})}
            .icon=${k}
            @click=${()=>K.getState().removeDefinition(e._id)}
          ></app-button>
        </div>
      `};return v`
      <nq-table
        .data=${this.definitions}
        .columns=${this.columns}
        .options=${e}
      ></nq-table>
    `}};D([C(),H(K,e=>e.definitions)],um.prototype,`definitions`,void 0),um=D([x(`definitions-view`)],um);var dm={id:[{value:`device`,label:`Device`},{value:`card`,label:`Card`},{value:`script`,label:`Script`}],ids:[{value:`devices`,label:`Devices`},{value:`cards`,label:`Cards`}],string:[{value:`device-field`,label:`Device field`},{value:`device-field-value`,label:`Device field value`},{value:`device-state`,label:`Device state`},{value:`device-state-value`,label:`Device state value`},{value:`card-field`,label:`Card field`},{value:`card-field-value`,label:`Card field value`}],number:[{value:`milliseconds`,label:`Milliseconds`}]},fm=e=>[{value:``,label:`None`},...dm[e||``]||[]],pm=(e,t)=>t?fm(e).some(e=>e.value===t):!0,mm=[{value:`string`,label:`String`},{value:`number`,label:`Number`},{value:`boolean`,label:`Boolean`},{value:`enum`,label:`Enum`},{value:`object`,label:`Object`},{value:`array`,label:`Array`},{value:`id`,label:`ID`},{value:`ids`,label:`IDs`},{value:`any`,label:`Any`}],hm=[`device-field`,`device-field-value`,`device-state`,`device-state-value`,`card-field`,`card-field-value`],gm=()=>[{fieldGroupClassName:`d-grid grid-columns-1 grid-columns-md-5 gap-4 align-items-end`,fieldGroup:[{key:`label`,type:`input-text`,props:{label:`Label`}},{key:`key`,type:`input-text`,props:{label:`Key`,required:!0}},{key:`type`,type:`input-select`,defaultValue:`string`,props:{label:`Type`,required:!0,options:mm}},{key:`subtype`,type:`input-select`,defaultValue:``,props:{label:`Subtype`,options:(e,t)=>fm(t.type)},hide:e=>fm(e.type).length<=1},{key:`required`,type:`input-toggle`,defaultValue:!1,props:{toggleLabel:`Required`}}]},{key:`description`,type:`input-text`,props:{label:`Description`}},{key:`relation`,type:`input-text`,props:{label:`Relation`},hide:e=>!hm.includes(e.subtype)},{key:`options`,type:`input-array-text`,props:{label:`Options`},hide:e=>e.type!==`enum`},{key:`default`,type:`input-text`,props:{label:`Default Value (String)`},hide:e=>e.type!==`string`&&e.type!==`enum`},{key:`default`,type:`input-number`,props:{label:`Default Value (Number)`},hide:e=>e.type!==`number`},{key:`default`,type:`input-toggle`,props:{toggleLabel:e=>e.default?`Default: True`:`Default: False`},hide:e=>e.type!==`boolean`}],_m=()=>gm(),vm=()=>[...gm(),{type:`input-accordion`,props:{title:`Fields`},hide:e=>e.type!==`array`,fieldArray:[{key:`fields`,type:`input-array`,props:{addLabel:`Add Field`},fieldArray:_m()}]}],ym=(e=[])=>e.map(e=>{let t={...e};return e.type!==`enum`&&`options`in t&&delete t.options,!pm(e.type,e.subtype)&&`subtype`in t&&delete t.subtype,t.subtype===``&&delete t.subtype,!hm.includes(e.subtype)&&`relation`in t&&delete t.relation,e.type===`array`?t.fields=ym(t.fields||[]):`fields`in t&&delete t.fields,Object.keys(t).forEach(e=>{Array.isArray(t[e])&&t[e].length===0&&delete t[e]}),t});async function bm(e){let{script:t}=e||{},n=e?.edit??!!t?._id,r=t?{...t}:{_id:``,name:``,description:``,specialized:!1,params:[],function:``};r._tab=`general`;let i=[{id:`general`,label:`General`},{id:`script`,label:`Script`}],a=null,o=()=>{let e=s();if(a?.refreshForm){a.refreshForm(e,r);return}a&&(a.fields=e,a.model=r,a.requestUpdate())},s=()=>[{type:`template`,template:v`
        <div class="mb-4">
          <app-button-tabs
            .tabs=${i}
            .activeTab=${r._tab}
            @tab-change=${e=>{r._tab=e.detail.tabId,o()}}
          ></app-button-tabs>
        </div>
      `},{fieldGroupClassName:`d-grid grid-columns-1 grid-columns-md-2 gap-4`,hide:()=>r._tab!==`general`,fieldGroup:[{key:`name`,type:`input-text`,props:{label:`Name`,required:!0}},{key:`_id`,type:`input-text`,props:{label:`ID`,disabled:n,placeholder:`Auto`,help:`Optional. Lowercase letters, numbers, underscores and hyphens only`},validators:[{validate:e=>!e||/^[a-z0-9_-]+$/.test(String(e)),message:`Use only lowercase letters, numbers, _ and -`}]}]},{key:`description`,type:`input-textarea`,hide:()=>r._tab!==`general`,props:{label:`Description`,rows:3}},{key:`waitForCompletion`,type:`input-toggle`,defaultValue:!1,hide:()=>r._tab!==`general`,props:{toggleLabel:`Wait for completion by default`,help:`When this script is selected in an action list, the action will wait for it and the action toggle will be hidden.`}},{key:`specialized`,type:`input-toggle`,defaultValue:!1,hide:()=>r._tab!==`general`,props:{toggleLabel:`Specialized script`,help:`Hide this specialized script from script selectors by default. It remains available after enabling Show specialized.`}},{key:`tags`,type:`input-array-text`,hide:()=>r._tab!==`general`,props:{label:`Tags`,options:()=>J.getState().getTags()}},{type:`input-accordion`,hide:()=>r._tab!==`script`,props:{title:`Parameters`},fieldArray:[{key:`params`,type:`input-array`,props:{},fieldArray:vm()}]},{key:`function`,type:`input-code`,className:`mt-4`,hide:()=>r._tab!==`script`,props:{required:!0}}];return await G({title:n?`Edit: ${t?.name}`:`Add Script`,size:`lg`,model:r,fields:s(),advancedEditor:s,onFormReady:e=>{a=e},onBeforeSubmit:async()=>{if(r.params&&=ym(r.params),n&&t?._id){let{_id:e,...n}=r;await J.getState().updateScript(t._id,n)}else r._id||delete r._id,await J.getState().addScript(r);return!0}})}var xm=(e,t)=>typeof e==`function`?e(t):e,Sm=e=>e?.response||e?.message||e;function Cm(e,t){let n=!1,r=t.pendingDelay??2e3,i=t.pendingMessage,a=i?window.setTimeout(()=>{n||M.show({message:i,variant:`info`,duration:t.pendingDuration??3e3})},r):void 0;return e.then(e=>{if(n=!0,a!==void 0&&window.clearTimeout(a),t.showSuccess===!1)return;let r=xm(t.successMessage,e);if(!r)return;let i={message:r,details:t.successDetails?t.successDetails(e):e,variant:`success`};t.successDuration!==void 0&&(i.duration=t.successDuration),M.show(i)}).catch(e=>{if(n=!0,a!==void 0&&window.clearTimeout(a),t.showError===!1)return;let r={message:xm(t.errorMessage,e)||`Request failed`,details:t.errorDetails?t.errorDetails(e):Sm(e),variant:`error`};t.errorDuration!==void 0&&(r.duration=t.errorDuration),M.show(r)}),e}var wm=(e,t)=>{Cm(t,{pendingMessage:`Script "${e.name}" command sent`,successMessage:`Script "${e.name}" executed`,errorMessage:`Script "${e.name}" failed`})};async function Tm(e){let t=Array.isArray(e.params)?e.params.filter(e=>!!e?.key):[];if(!(t.length>0))return await G({title:`Execute: ${e.name}`,model:{},fields:[{template:v`
            <div class="alert mb-0">
              This script has no additional parameters.
            </div>
          `}],submitLabel:`Execute`,onBeforeSubmit:async()=>(wm(e,J.getState().executeScript(e._id,void 0,{notify:!1})),!0)});await Promise.all([q.getState().fetchDevices(),L.getState().fetchDevices()]);let n={},r=[],i=e=>{let t=e?.relation;return typeof t==`string`&&t.trim()?t.trim():void 0},a=e=>(e.type===`id`||e.type===`ids`)&&(e.subtype===`card`||e.subtype===`cards`),o=e=>{let n=i(e);return(n?t.find(e=>e.key===n&&a(e)):void 0)||t.find(a)},s=e=>{let n=i(e);return(n?t.find(e=>e.key===n&&e.subtype===`card-field`):void 0)||t.find(e=>e.subtype===`card-field`)},c=(e,t)=>{let n=i(e);return!n||n===t},l=(e=[])=>e.flatMap(e=>[...e.key?[e]:[],...l(e.fields||[])]),u=(e,t)=>{let n=e?.translations?.[t];if(typeof n==`string`)return n;if(n?.key)return n.key},d=(e,t,n)=>{let r=n.key;return r?e?.translations?.[r]?.key||u(t,r)||n.name||r:n.name},f=e=>(e.type===`id`||e.type===`ids`)&&(e.subtype===`device`||e.subtype===`devices`),p=e=>{let n=i(e);return(n?t.find(e=>e.key===n&&f(e)):void 0)||t.find(f)},m=e=>{let n=i(e),r=e?.subtype===`device-state-value`?`device-state`:`device-field`;return(n?t.find(e=>e.key===n&&e.subtype===r):void 0)||t.find(e=>e.subtype===r)},h=(e,t)=>{let n=e?K.getState().getDefinitionById(e.definition):void 0,r=l(n?.fields||[]).map(t=>({...t,name:d(e,n,t)}));return t?.subtype===`device-state`||t?.subtype===`device-state-value`?Object.entries(e?.state||{}).map(([e,t])=>r.find(t=>t.key===e)||{key:e,name:e,type:typeof t==`number`?`number`:typeof t==`boolean`?`boolean`:`string`,control:!1}):r},g=(e,t)=>{if(e.length===0)return[];if(e.length===1)return h(e[0],t);let n=h(e[0],t),r=new Set(n.map(e=>e.key));return e.slice(1).forEach(e=>{let n=new Set(h(e,t).map(e=>e.key));Array.from(r).forEach(e=>{n.has(e)||r.delete(e)})}),n.filter(e=>r.has(e.key))},_=(e,t)=>{let n=p(t);return g((n?.key?re(e[n.key]):[]).map(e=>q.getState().getDeviceById(e)).filter(Boolean),t)},ee=(e,t,n)=>_(t,n).map(e=>({value:e.key,label:e.name&&e.name!==e.key?`${e.name} (${e.key})`:String(e.key)})),te=(e,t)=>{let n=m(t),r=n?.key?e[n.key]:void 0;return _(e,n||t).find(e=>e.key===r)},ne=(e,t,n)=>{let r=te(t,n);if(r?.type===`boolean`){let e=r.extra?.valueTrue!==void 0||r.extra?.valueFalse!==void 0,t=e?r.extra?.valueTrue:!0,n=e?r.extra?.valueFalse:!1;return[{value:t,label:String(t)},{value:n,label:String(n)}]}return r?.type===`enum`?(r.values||[]).map(e=>{if(typeof e==`string`)return{value:e,label:e};let t=e.value??e.key??e.name;return{value:t,label:e.name??e.label??String(t)}}):[]},re=e=>Array.isArray(e)?e:e==null||e===``?[]:[e],ie=(e,t)=>{let n=o(t);if(!n?.key)return[];let r=re(e[n.key]),i=L.getState().devices;return r.map(e=>i.find(t=>t._id===e)).filter(Boolean)},ae=e=>{let t=(e=[])=>e.flatMap(e=>[e,...t(e.fields||[])]);return t(e?.fields||[]).filter(e=>!!e.key)},oe=(e,t,n)=>{let r=ie(t,n);if(r.length===0)return[];let i=ae(r[0]),a=new Set(i.map(e=>e.key));return r.slice(1).forEach(e=>{let t=new Set(ae(e).map(e=>e.key));Array.from(a).forEach(e=>{t.has(e)||a.delete(e)})}),i.filter(e=>a.has(e.key)).map(e=>({value:e.key,label:e.name?`${e.name} (${e.key})`:e.key}))},se=(e,t)=>{let n=s(t),[r]=ie(e,n||t),i=n?.key?e[n.key]:void 0;if(!(!r||!i))return ae(r).find(e=>e.key===i)},ce=(e,t,n)=>{let r=se(t,n);return r?.type===`enum`?((r.options?.length?r.options:r.values)||[]).map(e=>{if(typeof e==`string`)return{value:e,label:e};let t=e.value??e.key??e.name;return{value:t,label:e.name??e.label??String(t)}}):[]},le=(e,t)=>ce(void 0,e,t).length>0,ue=(e,t,n)=>{let r=se(t,n);if(r?.type!==`boolean`)return[];let i=r.extra?.boolean||{},a=i.valueTrue!==void 0||i.valueFalse!==void 0,o=a?i.valueTrue:!0,s=a?i.valueFalse:!1;return[{value:o,label:String(o)},{value:s,label:String(s)},{value:null,label:`Inverse`}]},de=(e,t)=>ue(void 0,e,t).length>0,fe=(e,t)=>le(e,t)||de(e,t),pe=(e,t,n)=>ce(e,t,n).length>0?ce(e,t,n):ue(e,t,n),me=e=>e.default===void 0||e.default===null||e.default===``?!1:e.type===`boolean`||e.default!==!1;return t.forEach(o=>{me(o)&&(n[o.key]=o.default);let s={key:o.key,props:{label:o.label||o.key,description:o.description,required:o.required===!0}},l=i(o),u=l?t.find(e=>e.key===l):t.find(e=>e.subtype===`script`&&o.key===`${e.key}Params`);if(o.type===`array`){s.type=`repeat-field`,s.props={...s.props,scripts:J.getState().getScripts(),fields:o.fields||[],addLabel:`Add ${o.label||o.key}`,includeValue:!1},r.push(s);return}if(o.type===`object`&&u?.subtype===`script`){s.type=`card-script-params`,s.className=`ml-3 border-left pl-4`,s.hide=e=>!e?.[u.key],s.renderKey=e=>e?.[u.key]||`${u.key}-empty`,s.props={...s.props,scripts:J.getState().getScripts(),scriptKey:u.key,scriptParamKey:u.key,getScriptId:e=>e?.[u.key],includeValue:!1},r.push(s);return}if(o.subtype===`card-field`){s.type=`input-select`,s.props.placeholder=`Select card field`,s.props.options=(e,t)=>oe(e,t,o),s.hooks={onModelChange:(e,n)=>{t.filter(e=>e.subtype===`card-field-value`&&c(e,o.key)).forEach(e=>delete n[e.key])}},r.push(s);return}if(o.subtype===`device-field`||o.subtype===`device-state`){let e=o.subtype===`device-state`?`device-state-value`:`device-field-value`;s.type=`input-select`,s.props.placeholder=o.subtype===`device-state`?`Select device state`:`Select device field`,s.props.options=(e,t)=>ee(e,t,o),s.hooks={onModelChange:(n,r)=>{t.filter(t=>t.subtype===e&&c(t,o.key)).forEach(e=>delete r[e.key])}},r.push(s);return}if(o.subtype===`device-field-value`||o.subtype===`device-state-value`){let e=(e,t)=>ne(e,t,o),t=t=>e(void 0,t).length>0,n=e=>te(e,o)?.type===`number`,i=e=>te(e,o)?.type===`form`;r.push({...s,type:`device-form-value`,props:{...s.props,getField:e=>te(e,o)},hide:e=>!i(e)}),r.push({...s,type:`input-select`,props:{...s.props,placeholder:`Select value`,options:e},hide:e=>!t(e)}),r.push({...s,type:`input-number`,props:{...s.props,min:(e,t)=>te(t,o)?.extra?.min,max:(e,t)=>te(t,o)?.extra?.max,step:(e,t)=>te(t,o)?.extra?.step},hide:e=>!n(e)}),r.push({...s,type:`input-text`,hide:e=>t(e)||n(e)||i(e)});return}if(o.subtype===`card-field-value`){let e={...s,type:`input-select`,props:{...s.props,placeholder:`Select value`,options:(e,t)=>pe(e,t,o)},hide:e=>!fe(e,o)};r.push({...e});let t={...s,hide:e=>fe(e,o)};switch(o.type){case`number`:o.subtype===`milliseconds`?(t.type=`input-unit`,t.props={...t.props,type:`time`,defaultUnit:`s`,min:0}):t.type=`input-number`;break;case`boolean`:t.type=`input-toggle`,t.props.toggleLabel=e=>e[o.key]?`True`:`False`;break;case`object`:t.type=`input-object`;break;case`array`:t.type=`input-array-text`;break;default:t.type=`input-text`;break}r.push(t);return}switch(o.type){case`number`:o.subtype===`milliseconds`?(s.type=`input-unit`,s.props={...s.props,type:`time`,defaultUnit:`s`,min:0}):s.type=`input-number`;break;case`boolean`:s.type=`input-toggle`,s.props.toggleLabel=e=>e[o.key]?`True`:`False`;break;case`enum`:s.type=`input-select`,s.props.options=o.options||[];break;case`object`:s.type=`input-object`;break;case`array`:s.type=`input-array-text`;break;case`any`:s.type=`input-text`;break;case`id`:case`ids`:if(o.subtype===`script`)s.type=`input-script`,s.props.multiple=o.type===`ids`,s.props.scripts=J.getState().getScripts().filter(t=>t._id!==e._id),s.hooks={onModelChange:(e,n)=>{t.filter(e=>i(e)===o.key||e.key===`${o.key}Params`).forEach(e=>delete n[e.key])}};else if(o.subtype===`device`||o.subtype===`devices`){let e=q.getState().getDevices();s.type=`input-devices`,s.props.multiple=o.type===`ids`,s.props.placeholder=o.type===`ids`?`Select devices`:`Select device`,s.props.devices=e,s.hooks={onModelChange:(e,n)=>{t.filter(e=>e.subtype===`device-field`||e.subtype===`device-state`).filter(e=>c(e,o.key)).forEach(e=>{delete n[e.key];let r=e.subtype===`device-state`?`device-state-value`:`device-field-value`;t.filter(e=>e.subtype===r).filter(t=>c(t,e.key)).forEach(e=>delete n[e.key])})}}}else if(o.subtype===`card`||o.subtype===`cards`){let e=L.getState().devices;s.type=`input-cards`,s.props.multiple=o.type===`ids`,s.props.placeholder=o.type===`ids`?`Select cards`:`Select card`,s.props.cards=e,a(o)&&(s.hooks={onModelChange:(e,n)=>{t.filter(e=>e.subtype===`card-field`).filter(e=>c(e,o.key)).forEach(e=>{let r=new Set(oe(void 0,n,e).map(e=>e.value)),i=n[e.key];!i||r.has(i)||(delete n[e.key],t.filter(e=>e.subtype===`card-field-value`).filter(t=>c(t,e.key)).forEach(e=>delete n[e.key]))})}})}else s.type=`input-text`;break;default:s.type=`input-text`;break}r.push(s)}),await G({title:`Execute: ${e.name}`,model:n,fields:r,submitLabel:`Execute`,onBeforeSubmit:async()=>(wm(e,J.getState().executeScript(e._id,n,{notify:!1})),!0)})}var Em=class extends w{constructor(...e){super(...e),this.scripts=[]}get columns(){return[{key:`name`,label:`Name`,sortable:!0,filterable:!0,searchable:!0},{key:`description`,label:`Description`,sortable:!1,filterable:!0,searchable:!0},{key:`params`,label:`Parameters`,sortable:!1,filterable:!1,renderCell:e=>v`
            <app-badge .content=${`${(e||[]).length} params`}></app-badge>
          `},{key:`tags`,label:`Tags`,sortable:!1,filterable:!0,searchable:!0,type:`array`,filterFn:(e,t)=>(Array.isArray(e.tags)?e.tags:[]).some(e=>String(e)===String(t.value)),renderCell:e=>!e||e.length===0?v`<span class="text-muted">${j(`No tags`)}</span>`:v`
            <div class="d-flex gap-1 flex-wrap">
              ${e.map(e=>v`
                <app-badge .variant=${`neutral`} .content=${e}></app-badge>
              `)}
            </div>
          `}]}connectedCallback(){super.connectedCallback(),Q.getState().setPageMeta({title:`Scripts`,description:`Create and manage scripts for advanced logic`,action:v`
        <app-button
          variant="primary"
          background
          label="Add Script"
          .icon=${O}
          @click=${()=>bm()}
        ></app-button>
      `}),setTimeout(async()=>{await J.getState().fetchScripts()})}disconnectedCallback(){Q.getState().setPageMeta(null),super.disconnectedCallback()}async handleExecute(e){try{await Tm(e)}catch(e){console.error(`Error executing script:`,e)}}render(){let e={id:`scripts`,mode:`ui`,sort:`name`,filtersExtra:v`
        <tag-filter
          columnKey="tags"
          .tags=${J.getState().getTags()}
        ></tag-filter>
      `,actions:(e,t)=>v`
        <div>
          <app-button
            label="Execute"
            variant="ghost"
            .icon=${Gi}
            @click=${()=>this.handleExecute(e)}
          >
          </app-button>
          <app-button
            variant="ghost"
            label="Edit"
            .icon=${A}
            @click=${()=>bm({script:e})}
          >
          </app-button>
          <app-button
            variant="ghost"
            className="text-danger"
            label="Delete"
            ${B({title:`Delete Script`,message:`Are you sure you want to delete "${e.name}"?`,variant:`danger`})}
            .icon=${k}
            @click=${()=>J.getState().removeScript(e._id)}
          ></app-button>
        </div>
      `};return v`
      <nq-table
        .data=${this.scripts}
        .columns=${this.columns}
        .options=${e}
      ></nq-table>
    `}};D([C(),H(J,e=>e.scripts)],Em.prototype,`scripts`,void 0),Em=D([x(`scripts-view`)],Em);var Dm=class extends w{constructor(...e){super(...e),this.crons=[]}get columns(){return[{key:`name`,label:`Name`,sortable:!0,filterable:!0,searchable:!0,renderCell:(e,t)=>v`
					${e}
					${t.remmoveAfterExecution?v`<app-badge class='ml-2' .size=${`sm`} .content=${`Auto Remove`}></app-badge>`:``}
				`},{key:`_type`,label:`Type`,sortable:!0,filterable:!0,searchable:!0,renderCell:(e,t)=>v`
					<app-popover
						.trigger=${e}
						.content=${v`
							<div class="max-w-md">
								<code class="text-gray-300">${yp(t.cron)} [${t.cron}]</code>
							</div>
						`}
					></app-popover>
				`},{key:`tags`,label:`Tags`,sortable:!1,filterable:!0,searchable:!0,type:`array`,filterFn:(e,t)=>(Array.isArray(e.tags)?e.tags:[]).some(e=>String(e)===String(t.value)),renderCell:e=>!e||e.length===0?v`<span class="text-muted">${j(`No tags`)}</span>`:v`
						<div class="d-flex gap-1 flex-wrap">
							${e.map(e=>v`
								<app-badge .variant=${`neutral`} .content=${e}></app-badge>
							`)}
						</div>
					`},{key:`enabled`,label:`Enabled`,sortable:!0,renderCell:(e,t)=>v`
					<app-button
						variant="primary"
						size="sm"
						className="w-100 max-w-4rem"
						.label=${e?`ON`:`OFF`}
						.outline=${!e}
						@click=${()=>vp.getState().toggleCronEnabled(t._id)}  
					></app-button>
				`},{key:`lastRunAt`,label:`Last run`,type:`date`,sortable:!0},{key:`nextRunAt`,label:`Next run`,type:`date`,sortable:!0},{key:`remmoveAfterExecution`,label:`Auto Remove`,sortable:!0,hidden:!0,type:`boolean`}]}connectedCallback(){super.connectedCallback(),Q.getState().setPageMeta({title:`Schedules`,description:`Automate routines using time-based schedules and timers`,action:v`
				<app-button
					variant="primary"
					background
					label="Add Schedule"
					.icon=${O}
					@click=${()=>Dp()}
				></app-button>
			`}),setTimeout(async()=>{await vp.getState().fetchCrons()})}disconnectedCallback(){Q.getState().setPageMeta(null),super.disconnectedCallback()}render(){let e={id:`crons`,mode:`ui`,sort:`name`,filtersExtra:v`
				<tag-filter
					columnKey="tags"
					.tags=${vp.getState().getTags()}
				></tag-filter>
			`,actions:e=>v`
				<div>
					<app-button
						variant="ghost"
						label="Edit"
						.icon=${A}
						@click=${()=>Dp({cron:e})}
					></app-button>
					<app-button
						variant="ghost"
						className="text-danger"
						label="Delete"
						${B({title:`Delete Cron`,message:`Are you sure you want to delete schedule "${e.name}"?`,variant:`danger`})}
						.icon=${k}
						@click=${()=>vp.getState().removeCron(e._id)}
					></app-button>
				</div>
			`};return v`
			<nq-table
				.data=${this.crons}
				.columns=${this.columns}
				.options=${e}
			></nq-table>
		`}};D([C(),H(vp,e=>e.crons)],Dm.prototype,`crons`,void 0),Dm=D([x(`crons-view`)],Dm);var Om=po()((e,t)=>({users:[],loading:!1,getUsers(){return t().users},fetchUsers:async(n=!1)=>{t().users.length>0&&!n||(e({loading:!0}),e({users:await N.get(`/users`),loading:!1}))},getUserById:e=>t().users.find(t=>t._id===e),addUser:async n=>{let r=await N.post(`/users`,n);return e({users:[...t().users,r]}),r},updateUser:async(n,r)=>{let i=await N.put(`/users/${n}`,r);e({users:t().users.map(e=>e._id===n?i:e)})},removeUser:async n=>{await N.delete(`/users/${n}`),e({users:t().users.filter(e=>e._id!==n)})}}));async function km(e){await Promise.all([I.getState().initializeIfNeeded(),L.getState().fetchDevices()]);let{user:t}=e||{},n=t?{...t,language:t.language||`en`}:{name:``,email:``,language:`en`,role:`user`,zoneIds:[],cardIds:[],active:!0},r=[{key:`name`,type:`input-text`,props:{label:`Name`,placeholder:`Enter user name`,required:!0}},{key:`email`,type:`input-text`,props:{label:`Email`,placeholder:`Enter email address`,required:!0}},{key:`password`,type:`input-password`,props:{label:`Password`,placeholder:`Enter password`,autogenerate:!0,required:!t?._id}},{key:`role`,type:`input-select`,props:{label:`Role`,required:!0,placeholder:`Select role`,options:[{value:`admin`,label:`Admin`},{value:`user`,label:`User`},{value:`scoped`,label:`Scoped User`}]}},{key:`language`,type:`input-select`,props:{label:`Language`,required:!0,options:[{value:`en`,label:`English`},{value:`pl`,label:`Polski`}]}},{key:`zoneIds`,type:`input-select`,hide:e=>e.role!==`scoped`,props:{label:`Zones`,multiple:!0,required:!0,placeholder:`Select zones`,options:I.getState().getFlatZonesWithParents().map(({zone:e,fullPath:t})=>({value:e.id,label:t}))}},{key:`cardIds`,type:`input-select`,hide:e=>e.role!==`scoped`,props:{label:`Cards`,multiple:!0,required:!0,placeholder:`Select cards`,options:()=>{let e=new Set(Array.isArray(n.zoneIds)?n.zoneIds:[]);return L.getState().devices.filter(t=>e.has(t.zone)).map(e=>({value:e._id,label:e._fullName||e.name}))}}},{key:`active`,type:`input-toggle`,props:{toggleLabel:`Active`}}];return await G({title:t?`Edit: ${t.name}`:`Add User`,model:n,fields:r,onBeforeSubmit:async()=>{if(t?._id){let e={...n};e.password?.trim()||delete e.password,await Om.getState().updateUser(t._id,e)}else await Om.getState().addUser(n);return!0}})}var Am=class extends w{constructor(...e){super(...e),this.users=[]}get columns(){return[{key:`name`,label:`Name`,searchable:!0,sortable:!0,filterable:!0},{key:`email`,label:`Email`,searchable:!0,sortable:!0,filterable:!0},{key:`role`,label:`Role`,searchable:!0,sortable:!0,filterable:!0,renderCell:e=>v`<app-badge .variant=${e===`admin`?`warning`:`neutral`} .content=${e}></app-badge>`},{key:`active`,label:`Status`,sortable:!0,filterable:!0,renderCell:e=>{let t=e!==!1;return v`<app-badge
            .variant=${t?`success`:`neutral`}
            .content=${j(t?`Active`:`Disabled`)}
          ></app-badge>`}}]}connectedCallback(){super.connectedCallback(),Q.getState().setPageMeta({title:`Users`,description:`Manage user accounts and permissions`,action:v`
        <app-button
          variant="primary"
          background
          label="Add User"
          .icon=${O}
          @click=${()=>km()}
        ></app-button>
      `}),setTimeout(async()=>{await Om.getState().fetchUsers()})}disconnectedCallback(){Q.getState().setPageMeta(null),super.disconnectedCallback()}render(){return v`
      <nq-table
        .data=${this.users}
        .columns=${this.columns}
        .options=${{id:`users`,mode:`ui`,sort:`name`,actions:e=>v`
        <div>
          <app-button
            variant="ghost"
            label="Edit"
            .icon=${A}
            @click=${()=>km({user:e})}
          >
          </app-button>
          <app-button
            variant="ghost"
            className="text-danger"
            label="Delete"
            ${B({title:`Delete User`,message:`Are you sure you want to delete "${e.name}"?`,variant:`danger`})}
            .icon=${k}
            @click=${()=>Om.getState().removeUser(e._id)}
          ></app-button>
        </div>
      `}}
      ></nq-table>
    `}};D([C(),H(Om,e=>e.users)],Am.prototype,`users`,void 0),Am=D([x(`users-view`)],Am);var X=po()((e,t)=>({status:null,sessions:[],guests:[],loading:!1,setStatus:t=>e({status:t}),setSessions:t=>e({sessions:t}),setGuests:t=>e({guests:t}),fetchStatus:async(n=!1)=>{t().status&&!n||(e({loading:!0}),e({status:await N.get(`/online/status`),loading:!1}))},fetchSessions:async()=>{e({sessions:await N.get(`/online/sessions`)})},fetchGuests:async()=>{e({guests:await N.get(`/online/guests`)})},fetchAll:async(e=!1)=>{await Promise.all([t().fetchStatus(e),t().fetchSessions(),t().fetchGuests()])},connect:async()=>{e({status:await N.post(`/online/connect`,{}),sessions:await N.get(`/online/sessions`)})},disconnect:async()=>{e({status:await N.post(`/online/disconnect`,{}),sessions:await N.get(`/online/sessions`)})},resume:async()=>{e({status:await N.post(`/online/resume`,{}),sessions:await N.get(`/online/sessions`)})},updateConfig:async t=>{e({status:await N.put(`/online/config`,t)})},updateReconnect:async t=>{e({status:await N.put(`/online/reconnect`,{enabled:t})})},terminateSession:async e=>{await N.post(`/online/sessions/terminate`,{connectionId:e}),await t().fetchSessions()},addGuest:async n=>{let r=await N.post(`/online/guests`,n);return e({guests:[...t().guests,r].sort((e,t)=>e.name.localeCompare(t.name))}),r},updateGuest:async(n,r)=>{let i=await N.put(`/online/guests/${n}`,r);return e({guests:t().guests.map(e=>e._id===n?i:e).sort((e,t)=>e.name.localeCompare(t.name))}),i},removeGuest:async n=>{await N.delete(`/online/guests/${n}`),e({guests:t().guests.filter(e=>e._id!==n)})}})),jm=class extends w{constructor(...e){super(...e),this.status=null,this.tokenInput=``,this.tokenSaving=!1,this.tokenError=``}formatDate(e){if(!e)return`-`;let t=new Date(e);return Number.isNaN(t.getTime())?`-`:t.toLocaleString()}formatMegabytes(e){return e==null?`-`:`${(e/(1024*1024)).toFixed(2)} MB`}formatHoursFromMilliseconds(e){return e==null||!Number.isFinite(e)?`-`:`${(e/36e5).toFixed(2)} h`}isExpired(e){if(!e)return!1;let t=new Date(e).getTime();return Number.isFinite(t)&&t<Date.now()}isTrafficExceeded(e,t){return typeof t!=`number`||t<=0||typeof e!=`number`?!1:e>=t}isMillisecondsExceeded(e,t){return typeof t!=`number`||t<=0||typeof e!=`number`?!1:e>=t}async saveInitialToken(e){e.preventDefault();let t=this.tokenInput.trim();if(!(!t||this.tokenSaving)){this.tokenSaving=!0,this.tokenError=``;try{await X.getState().updateConfig({token:t})}catch(e){this.tokenError=e instanceof Error?e.message:j(`Cannot save token.`)}finally{this.tokenSaving=!1}}}async openConfigDialog(){let e=this.status,t={token:e?.token||``};await G({title:`Online Configuration`,model:t,fields:[{template:v`<div class="small text-muted mb-2">${j(`Server URL:`)} <span class="text-body">${e?.server||`-`}</span></div>`},{key:`token`,type:`input-text`,props:{label:`Token`,placeholder:`Paste access token`}}],onBeforeSubmit:async()=>{let e={token:String(t.token||``).trim()};return await X.getState().updateConfig(e),!0}})}render(){let e=this.status;if(e&&!e.tokenConfigured)return v`
        <div class="card">
          <div class="card-body">
            <form class="form-stack gap-4" @submit=${this.saveInitialToken}>
              <div>
                <h2 class="fs-4 mt-0 mb-2">${j(`Connect NQ2 Local to NQ2 Home`)}</h2>
                <p class="text-muted m-0">
                  ${j(`Generate a Home token at`)}
                  <a class="text-primary text-decoration-underline" href="https://portal.nq2.io" target="_blank" rel="noreferrer">portal.nq2.io</a>
                  ${j(`and paste it below.`)}
                </p>
              </div>
              <div>
                <label class="form-label" for="online-token">${j(`Token`)} <span class="text-danger">*</span></label>
                <input
                  id="online-token"
                  class="form-control"
                  type="text"
                  autocomplete="off"
                  .value=${this.tokenInput}
                  placeholder=${j(`Paste access token`)}
                  @input=${e=>{this.tokenInput=e.target.value}}
                />
              </div>
              ${this.tokenError?v`<div class="alert alert-danger">${this.tokenError}</div>`:``}
              <div><app-button type="submit" .label=${this.tokenSaving?j(`Saving...`):j(`Save`)} .disabled=${this.tokenSaving||!this.tokenInput.trim()} @click=${this.saveInitialToken}></app-button></div>
            </form>
          </div>
        </div>
      `;let t=this.isExpired(e?.expirationAt),n=this.isTrafficExceeded(e?.trafficBytes,e?.limitBytes),r=this.isMillisecondsExceeded(e?.trafficMilliseconds,e?.limitMilliseconds);return v`
      <div class="form-stack gap-4">
        <div class="d-grid grid-columns-1 grid-columns-md-2 gap-4">
          <div class="card">
            <div class="card-body">
              <div class="card-content">
                <div class="small text-uppercase text-muted fw-semibold">${j(`Connection`)}</div>
                <div class="field-row">
                  <span class="field-label">${j(`Status`)}</span>
                  ${e?.connected?v`
                      <app-button
                        variant="success"
                        size="sm"
                        label="Connected"
                        @click=${()=>X.getState().disconnect()}
                      ></app-button>
                    `:v`
                      <app-button
                        variant="danger"
                        size="sm"
                        label="Disconnected"
                        @click=${()=>X.getState().resume()}
                      ></app-button>
                    `}
                </div>
                <div class="field-row">
                  <span class="field-label">${j(`Server`)}</span>
                  <span class="field-value text-end text-break">${e?.server||`-`}</span>
                </div>
                <div class="field-row">
                  <span class="field-label">${j(`Reconnect`)}</span>
                  <app-button
                    size="sm"
                    .variant=${e?.reconnect?`success`:`ghost`}
                    .label=${e?.reconnect?`Enabled`:`Disabled`}
                    @click=${()=>X.getState().updateReconnect(!e?.reconnect)}
                  ></app-button>
                </div>
                <div class="field-row">
                  <span class="field-label">${j(`Token`)}</span>
                  ${e?.token&&e.token.trim().length>0?v`
                      <app-button
                        size="sm"
                        variant="ghost"
                        label="********"
                        @click=${()=>this.openConfigDialog()}
                      ></app-button>
                    `:v`<span class="field-value">${j(`Not set`)}</span>`}
                </div>
                <div class="field-row">
                  <span class="field-label">${j(`Last connected`)}</span>
                  <span class="field-value text-end text-break">${this.formatDate(e?.lastConnectedAt)}</span>
                </div>
                ${e?.lastError?v`<div class="alert alert-danger text-break">${j(`Error:`)} ${e.lastError}</div>`:``}
              </div>
            </div>
          </div>

          <div class="card">
            <div class="card-body">
              <div class="card-content">
                <div class="small text-uppercase text-muted fw-semibold">${j(`License & Usage`)}</div>
                <div class="field-row">
                  <span class="field-label">${j(`Plan`)}</span>
                  <span class="field-value">${e?.plan?.trim()?e.plan:j(`Free`)}</span>
                </div>
                <div class="field-row">
                  <span class="field-label">${j(`Home ID`)}</span>
                  <span class="field-value text-end text-break">${e?.homeId?.trim()?e.homeId:`-`}</span>
                </div>
                <div class="field-row">
                  <span class="field-label">${j(`Expiration`)}</span>
                  <span class="field-value ${t?`text-danger`:``}">${this.formatDate(e?.expirationAt)}</span>
                </div>
                <div class="field-row">
                  <span class="field-label">${j(`Traffic`)}</span>
                  <span class="field-value ${n?`text-danger`:``}">
                    ${this.formatMegabytes(e?.trafficBytes)} / ${this.formatMegabytes(e?.limitBytes)}
                  </span>
                </div>
                <div class="field-row">
                  <span class="field-label">${j(`Hours`)}</span>
                  <span class="field-value ${r?`text-danger`:``}">
                    ${this.formatHoursFromMilliseconds(e?.trafficMilliseconds)} / ${this.formatHoursFromMilliseconds(e?.limitMilliseconds)}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    `}};D([C(),H(X,e=>e.status)],jm.prototype,`status`,void 0),D([C()],jm.prototype,`tokenInput`,void 0),D([C()],jm.prototype,`tokenSaving`,void 0),D([C()],jm.prototype,`tokenError`,void 0),jm=D([x(`online-overview-view`)],jm);var Mm=class extends w{constructor(...e){super(...e),this.sessions=[],this.loading=!1}formatDate(e){if(!e)return`-`;let t=new Date(e);return Number.isNaN(t.getTime())?`-`:t.toLocaleString()}formatBytes(e){return e==null?`-`:e<1024?`${e} B`:e<1024*1024?`${(e/1024).toFixed(1)} KB`:e<1024*1024*1024?`${(e/(1024*1024)).toFixed(1)} MB`:`${(e/(1024*1024*1024)).toFixed(1)} GB`}formatMinutes(e){return e==null||!Number.isFinite(e)?`-`:`${e.toFixed(2)} min`}async terminateSession(e){let t=String(e.connectionId||``).trim();t&&await X.getState().terminateSession(t)}get columns(){return[{key:`active`,label:`Status`,sortable:!0,renderCell:e=>v`<span class="small ${e?`text-success`:`text-muted`}">${e?`Active`:`Ended`}</span>`},{key:`email`,label:`Email`,sortable:!0,filterable:!0,searchable:!0},{key:`connectedAt`,label:`Connected At`,sortable:!0,renderCell:e=>v`${this.formatDate(e)}`},{key:`disconnectedAt`,label:`Disconnected At`,sortable:!0,renderCell:e=>v`${this.formatDate(e)}`},{key:`trafficBytes`,label:`Traffic`,sortable:!0,renderCell:e=>v`${this.formatBytes(e)}`},{key:`trafficMinutes`,label:`Minutes`,sortable:!0,renderCell:e=>v`${this.formatMinutes(e)}`},{key:`connectionId`,label:`Connection ID`,sortable:!1,filterable:!0,searchable:!0}]}render(){let e={id:`online-connections`,mode:`ui`,sort:`connectedAt`,actions:e=>!e.active||!e.connectionId?v``:v`
          <div>
            <app-button
              variant="ghost"
              className="text-danger"
              label="Terminate"
              .icon=${k}
              @click=${()=>this.terminateSession(e)}
            ></app-button>
          </div>
        `,extra:v`
        <div class="small text-muted">
          ${j(`Active connections and connections ended in the last 24 hours.`)}
        </div>
      `};return this.loading?v`<div class="small text-muted">${j(`Loading...`)}</div>`:v`
      <div class="form-stack gap-4">
        <nq-table
          .data=${this.sessions||[]}
          .columns=${this.columns}
          .options=${e}
        ></nq-table>
      </div>
    `}};D([C(),H(X,e=>e.sessions)],Mm.prototype,`sessions`,void 0),D([C(),H(X,e=>e.loading)],Mm.prototype,`loading`,void 0),Mm=D([x(`online-connections-view`)],Mm);var Nm=class extends w{constructor(...e){super(...e),this.guests=[],this.cards=[],this.status=null,this.syncGuestLink=(e,t)=>{t.link=this.buildGuestLink(t)}}connectedCallback(){super.connectedCallback(),setTimeout(async()=>{await Promise.all([X.getState().fetchGuests(),L.getState().fetchDevices()])})}getCardLabel(e){return this.cards.find(t=>t._id===e)?._fullName||e}getServerLink(e){let t=String(e||``).trim();if(!t)return null;try{return t.startsWith(`ws://`)?new URL(`http://${t.slice(5)}`).toString():t.startsWith(`wss://`)?new URL(`https://${t.slice(6)}`).toString():t.startsWith(`http://`)||t.startsWith(`https://`)?new URL(t).toString():new URL(`http://${t}`).toString()}catch{return null}}encodeAuth(e,t){return btoa(unescape(encodeURIComponent(`${e}:${t}`)))}buildGuestLink(e){let t=this.getServerLink(this.status?.server),n=String(this.status?.homeId||``).trim(),r=String(e.name||``).trim(),i=String(e.password||``);if(!t||!n||!r||!i)return``;let a=new URL(t);return a.hash=`guest/${n}?auth=${encodeURIComponent(this.encodeAuth(r,i))}`,a.toString()}async openGuestDialog(e){let t=e?{name:e.name,password:e.password||``,active:e.active!==!1,cards:[...e.cards||[]],link:``}:{name:``,password:``,active:!0,cards:[],link:``};t.link=this.buildGuestLink(t);let n=[{key:`name`,type:`input-text`,props:{label:`Name`,required:!0,placeholder:`Guest name`},hooks:{onModelChange:this.syncGuestLink}},{key:`password`,type:`input-password`,props:{label:`Password`,autoComplete:`new-password`,autogenerate:!0,required:!0},hooks:{onModelChange:this.syncGuestLink}},{key:`link`,type:`input-text`,props:{label:`Link`,readonly:!0,placeholder:`Server and Home ID are required`,help:`Generated from server URL, Home ID and guest credentials.`}},{key:`active`,type:`input-toggle`,props:{toggleLabel:`Active`}},{key:`cards`,type:`input-cards`,props:{label:`Cards`,multiple:!0,placeholder:`Select cards`}}];await G({title:e?`Edit Guest: ${e.name}`:`Add Guest`,model:t,fields:n,onBeforeSubmit:async()=>{let n={name:String(t.name||``).trim(),password:String(t.password||``),active:t.active!==!1,cards:Array.isArray(t.cards)?t.cards:[]};return e&&!n.password&&delete n.password,e?await X.getState().updateGuest(e._id,n):await X.getState().addGuest(n),!0}})}get columns(){return[{key:`name`,label:`Name`,sortable:!0,searchable:!0,filterable:!0},{key:`active`,label:`Status`,type:`enum`,sortable:!0,filterable:!0,options:[{value:!0,label:`Active`},{value:!1,label:`Disabled`}],renderCell:(e,t)=>{let n=e!==!1;return v`
            <app-button
              variant="primary"
              size="sm"
              className="w-100 max-w-6rem"
              .label=${n?`Active`:`Disabled`}
              .outline=${!n}
              @click=${()=>X.getState().updateGuest(t._id,{active:!n})}
            ></app-button>
          `}},{key:`cards`,label:`Cards`,renderCell:e=>{let t=Array.isArray(e)?e:[];return t.length?v`
            <div class="d-flex flex-wrap gap-2">
              ${t.slice(0,3).map(e=>v`
                <app-badge variant="neutral" .content=${this.getCardLabel(e)}></app-badge>
              `)}
              ${t.length>3?v`<app-badge variant="primary" .content=${`+${t.length-3}`}></app-badge>`:``}
            </div>
          `:v`<span class="text-muted">${j(`No cards selected`)}</span>`}},{key:`lastUsage`,label:`Last usage`,type:`date`,sortable:!0,dateFormat:`full`,renderCell:e=>e?v`${zl(e,`full`)}`:v`<span class="text-muted">${j(`Never`)}</span>`}]}render(){let e={id:`online-guests`,mode:`ui`,sort:`name`,extra:v`
        <app-button
          variant="primary"
          background
          label="Add Guest"
          .icon=${O}
          @click=${()=>this.openGuestDialog()}
        ></app-button>
      `,actions:e=>v`
        <div>
          <app-button
            variant="ghost"
            label="Edit"
            .icon=${A}
            @click=${()=>this.openGuestDialog(e)}
          ></app-button>
          <app-button
            variant="ghost"
            className="text-danger"
            label="Delete"
            .icon=${k}
            ${B({title:`Delete Guest`,message:`Are you sure you want to delete "${e.name}"?`,variant:`danger`})}
            @click=${()=>X.getState().removeGuest(e._id)}
          ></app-button>
        </div>
      `};return v`
      <nq-table
        .data=${this.guests||[]}
        .columns=${this.columns}
        .options=${e}
      ></nq-table>
    `}};D([C(),H(X,e=>e.guests)],Nm.prototype,`guests`,void 0),D([C(),H(L,e=>e.devices)],Nm.prototype,`cards`,void 0),D([C(),H(X,e=>e.status)],Nm.prototype,`status`,void 0),Nm=D([x(`online-guests-view`)],Nm);var Pm=class extends w{constructor(...e){super(...e),this.activeTab=`overview`,this.statusSse=null}connectedCallback(){super.connectedCallback(),setTimeout(async()=>{await X.getState().fetchAll(!0),this.subscribeToStatusChanges()})}disconnectedCallback(){super.disconnectedCallback(),this.unsubscribeFromStatusChanges()}subscribeToStatusChanges(){this.unsubscribeFromStatusChanges(),this.statusSse=N.sse(`/online/changes`),this.statusSse.onmessage=e=>{if(e.type===`status`){let t=e.payload;t&&typeof t==`object`&&X.getState().setStatus(t)}if(e.type===`sessions`){let t=e.payload;Array.isArray(t)&&X.getState().setSessions(t)}if(e.type===`connected`){let t=e.payload;t?.status&&X.getState().setStatus(t.status),Array.isArray(t?.sessions)&&X.getState().setSessions(t.sessions)}},this.statusSse.onerror=()=>{}}unsubscribeFromStatusChanges(){this.statusSse&&=(this.statusSse.close(),null)}render(){return v`
      <div class="form-stack gap-4">
        <app-button-tabs
          .tabs=${[{id:`overview`,label:`Overview`},{id:`connections`,label:`Connections`},{id:`guests`,label:`Guests`}]}
          .activeTab=${this.activeTab}
          @tab-change=${e=>{this.activeTab=e.detail.tabId}}
        ></app-button-tabs>

        ${this.activeTab===`overview`?v`<online-overview-view></online-overview-view>`:this.activeTab===`connections`?v`<online-connections-view></online-connections-view>`:v`<online-guests-view></online-guests-view>`}
      </div>
    `}};D([C()],Pm.prototype,`activeTab`,void 0),Pm=D([x(`online-view`)],Pm);var Fm=class extends w{constructor(...e){super(...e),this.currentPath=``}render(){let e=this.currentPath.includes(`/history`);return v`
      <div class="space-y-6">
        <app-tabs
          .items=${[{id:`history`,label:`History`,icon:cr,routerLink:`/settings/logs/history`},{id:`triggers`,label:`Triggers`,icon:Wi,routerLink:`/settings/logs/triggers`}]}
          .activeId=${e?`history`:`triggers`}
          ariaLabel="Logs sections"
        ></app-tabs>

        <div class="mt-4">
          <router-outlet></router-outlet>
        </div>
      </div>
    `}};D([C(),zt()],Fm.prototype,`currentPath`,void 0),Fm=D([x(`logs-view`)],Fm);var Im=(e,t)=>e?.actions?.length?Zu(e.actions,t):e?.scriptId?Zu([{script:e.scriptId,params:e.params||{},waitForCompletion:!0}],t):[];async function Lm({scripts:e,trigger:t}){await q.getState().fetchDevices();let n={name:t?.name||``,event:t?.event||``,actions:Im(t,e)},r=[{key:`name`,type:`input-text`,props:{label:`Name`,required:!0}},{key:`event`,type:`input-text`,props:{label:`Event`,required:!0}},{key:`actions`,type:`input-script-actions`,props:{label:`Commands`,addLabel:`Add Command`,scripts:e,includeValue:!1,required:!0}}],i=await G({title:t?`Edit Trigger: ${t.name}`:`Add Log Trigger`,model:n,fields:r});return i?{...i,actions:Qu(i.actions||[],e)}:null}var Rm=class extends w{constructor(...e){super(...e),this.scripts=[],this.triggersLoading=!1,this.triggers=[],this.triggersError=null}connectedCallback(){super.connectedCallback(),Q.getState().setPageMeta({title:`Logs`,description:`Browse system and websocket audit logs`,action:v`
        <app-button
          variant="primary"
          background
          label="Add Trigger"
          .icon=${O}
          @click=${()=>this.openTriggerDialog()}
        ></app-button>
      `}),this.initialize()}disconnectedCallback(){Q.getState().setPageMeta(null),super.disconnectedCallback()}async initialize(){await J.getState().fetchScripts(),this.scripts=J.getState().getScripts(),await this.loadTriggers()}get columns(){return[{key:`name`,label:`Name`,sortable:!0,filterable:!0,searchable:!0},{key:`event`,label:`Event`,sortable:!0,filterable:!0,searchable:!0},{key:`actions`,label:`Commands`,sortable:!1,filterable:!1,renderCell:(e,t)=>{let n=e?.length?e:t.scriptId?[{script:t.scriptId}]:[];return n.length?v`
            <div class="d-flex flex-wrap gap-1">
              ${n.map(e=>v`<app-badge .content=${this.scripts.find(t=>t._id===e.script||t.id===e.script)?.name||e.script||`Unknown`}></app-badge>`)}
            </div>
          `:v`<span class="text-muted">${j(`No commands`)}</span>`}}]}async loadTriggers(){this.triggersLoading=!0,this.triggersError=null;try{this.triggers=await N.get(`/logs/triggers`)}catch(e){this.triggersError=e?.message||`Failed to load log triggers`,this.triggers=[]}finally{this.triggersLoading=!1}}async openTriggerDialog(e){this.scripts.length||(await J.getState().fetchScripts(!0),this.scripts=J.getState().getScripts());let t=await Lm({scripts:this.scripts,trigger:e});if(!t)return;let n={name:t.name,event:t.event?.trim()||void 0,actions:t.actions||[]};e?._id?await N.put(`/logs/triggers/${e._id}`,n):await N.post(`/logs/triggers`,n),await this.loadTriggers()}async deleteTrigger(e){await N.delete(`/logs/triggers/${e._id}`),await this.loadTriggers()}render(){let e={id:`log-triggers`,mode:`ui`,sort:`name`,loading:this.triggersLoading,actions:e=>v`
        <div>
          <app-button
            variant="ghost"
            label="Edit"
            .icon=${A}
            @click=${()=>this.openTriggerDialog(e)}
          ></app-button>
          <app-button
            variant="ghost"
            className="text-danger"
            label="Delete"
            .icon=${k}
            ${B({title:`Delete Log Trigger`,message:`Are you sure you want to delete "${e.name}"?`,variant:`danger`})}
            @click=${()=>this.deleteTrigger(e)}
          ></app-button>
        </div>
      `};return v`
      ${this.triggersError?v`<div class="mb-4 p-3 rounded bg-red-900/30 text-red-300 text-sm">${this.triggersError}</div>`:``}
      <nq-table
        .data=${this.triggers}
        .columns=${this.columns}
        .options=${e}
      ></nq-table>
    `}};D([C()],Rm.prototype,`scripts`,void 0),D([C()],Rm.prototype,`triggersLoading`,void 0),D([C()],Rm.prototype,`triggers`,void 0),D([C()],Rm.prototype,`triggersError`,void 0),Rm=D([x(`logs-triggers-view`)],Rm);var zm=()=>{let e=new Date;return`${e.getFullYear()}-${`${e.getMonth()+1}`.padStart(2,`0`)}-${`${e.getDate()}`.padStart(2,`0`)}`},Bm=class extends w{constructor(...e){super(...e),this.loading=!1,this.items=[],this.total=0,this.error=null,this.selectedDate=zm(),this.lastLogsQuery={}}connectedCallback(){super.connectedCallback(),Q.getState().setPageMeta({title:`Logs`,description:`Browse system and websocket audit logs`,action:v`
        <app-button
          label="Refresh"
          .icon=${Yi}
          @click=${()=>this.handleRefresh()}
        ></app-button>
      `})}disconnectedCallback(){Q.getState().setPageMeta(null),super.disconnectedCallback()}async load(e){this.lastLogsQuery=e||{},this.loading=!0,this.error=null;try{let t=await N.get(`/logs`,{...e||{},date:this.selectedDate});this.items=t.items||[],this.total=t.total||0}catch(e){this.error=e?.message||`Failed to load logs`,this.items=[],this.total=0}finally{this.loading=!1}}openLogDetailsDialog(e){z.open({title:`Log Details`,maxWidth:`900px`,content:v`
        <pre class="overflow-auto rounded bg-body-secondary border p-4 small text-body font-monospace" style="max-height: 70vh; white-space: pre-wrap;">${JSON.stringify(e,null,2)}</pre>
      `,buttons:[{label:`Close`,variant:`primary`,action:()=>z.close()}]})}formatContext(e){if(!e||Object.keys(e).length===0)return``;let t=JSON.stringify(e);return t.length>120?`${t.slice(0,120)}...`:t}get columns(){return[{key:`timestamp`,label:`Time`,sortable:!0,filterable:!0,type:`date`,renderCell:e=>v`${new Date(e).toLocaleString()}`},{key:`level`,label:`Level`,sortable:!0,filterable:!0,renderCell:e=>v`<app-badge .variant=${e===`error`?`danger`:e===`warn`?`warning`:e===`info`?`success`:`neutral`} .content=${e}></app-badge>`},{key:`event`,label:`Event`,sortable:!0,filterable:!0,searchable:!0},{key:`message`,label:`Message`,sortable:!0,filterable:!0,searchable:!0},{key:`context`,label:`Context`,sortable:!1,filterable:!1,hidden:!0,renderCell:e=>{if(!e||typeof e!=`object`)return v`<span class="text-muted">-</span>`;let t=JSON.stringify(e),n=t.length>120,r=n?`${t.slice(0,117)}...`:t;return n?v`
                <span class="small text-muted" title=${t}>${r}</span>`:v`<span class="small text-muted">${r}</span>`}},{key:`source`,label:`Source`,sortable:!0,filterable:!0,searchable:!0}]}handleDateChange(e){let t=e.detail?.value||``;this.selectedDate=t||zm(),this.load(this.lastLogsQuery)}handleRefresh(){this.load(this.lastLogsQuery)}render(){let e={id:`logs`,mode:`api`,total:this.total,loading:this.loading,sort:`-timestamp`,onParamsChange:e=>{this.load(e)},actions:e=>v`
        <div>
          <app-button
            variant="ghost"
            label="View"
            .icon=${Qa}
            @click=${()=>this.openLogDetailsDialog(e)}
          ></app-button>
        </div>
      `};return v`
      <div class="mb-4 d-flex align-items-end gap-3">
        <div class="w-100 max-w-15rem">
          <label class="form-label">${j(`Date`)}</label>
          <input-date
            key="date"
            .model=${{date:this.selectedDate}}
            .props=${{inline:!0}}
            @field-change=${this.handleDateChange}
          ></input-date>
        </div>
      </div>
      ${this.error?v`<div class="mb-4 p-3 rounded bg-danger">${this.error}</div>`:``}
      <nq-table
        .data=${this.items}
        .columns=${this.columns}
        .options=${e}
      ></nq-table>
    `}};D([C()],Bm.prototype,`loading`,void 0),D([C()],Bm.prototype,`items`,void 0),D([C()],Bm.prototype,`total`,void 0),D([C()],Bm.prototype,`error`,void 0),D([C()],Bm.prototype,`selectedDate`,void 0),Bm=D([x(`logs-history-view`)],Bm);var Z=po()((e,t)=>({folders:[],files:[],selectedFolder:null,selectedFile:null,loading:!1,fetchFolders:async()=>{let n=[...await N.get(`/system-files/folders`)],r=t().selectedFolder||n[0]?.key||null;e({folders:n,selectedFolder:r}),r&&await t().selectFolder(r)},selectFolder:async t=>{e({loading:!0,selectedFolder:t,selectedFile:null}),e({files:(await N.get(`/system-files/list`,{folder:t,dir:``})).files,loading:!1})},openFile:async n=>{let r=t().selectedFolder;if(!r)return null;let i=await N.get(`/system-files/file`,{folder:r,path:n});return e({selectedFile:i}),i},createFile:async(n,r=``,i=!1)=>{let a=t().selectedFolder;if(!a)throw Error(`No folder selected`);let o=await N.post(`/system-files/file`,{folder:a,path:n,content:r,encoding:`utf8`,overwrite:i});return await t().refreshFiles(),e({selectedFile:o}),o},uploadFile:async(e,n,r)=>{let i=t().selectedFolder;if(!i)throw Error(`No folder selected`);let a=await N.post(`/system-files/file`,{folder:i,path:e,content:n,encoding:r,overwrite:!1});return await t().refreshFiles(),a},updateFile:async(n,r)=>{let i=t().selectedFolder;if(!i)throw Error(`No folder selected`);let a=await N.put(`/system-files/file`,{folder:i,path:n,content:r,encoding:`utf8`});return e({selectedFile:a}),await t().refreshFiles(),a},renameFile:async(n,r)=>{let i=t().selectedFolder;if(!i)throw Error(`No folder selected`);let a=await N.put(`/system-files/file/rename`,{folder:i,path:n,newName:r});return t().selectedFile?.path===n&&e({selectedFile:a}),await t().refreshFiles(),a},deleteFile:async n=>{let r=t().selectedFolder;if(!r)throw Error(`No folder selected`);await N.delete(`/system-files/file?folder=${encodeURIComponent(r)}&path=${encodeURIComponent(n)}`),t().selectedFile?.path===n&&e({selectedFile:null}),await t().refreshFiles()},refreshFiles:async()=>{let n=t().selectedFolder;n&&e({files:(await N.get(`/system-files/list`,{folder:n,dir:``})).files})},checkMainAppVersion:()=>N.get(`/system-files/main-app/latest`),installLatestMainApp:()=>N.post(`/system-files/main-app/install-latest`,{}),installMainAppArchive:e=>N.post(`/system-files/main-app/install`,{archive:e}),restartMainApp:()=>N.post(`/system-files/main-app/restart`,{}),getMainAppBackups:()=>N.get(`/system-files/backups`),createMainAppBackup:()=>N.post(`/system-files/backups`,{}),restoreMainAppBackup:e=>N.post(`/system-files/backups/${encodeURIComponent(e)}/restore`,{}),downloadMainAppBackup:async e=>{let t=await N.blobUrl(`/system-files/backups/${encodeURIComponent(e)}/download`),n=document.createElement(`a`);n.href=t,n.download=e,n.click(),setTimeout(()=>URL.revokeObjectURL(t),1e3)},deleteMainAppBackup:async e=>{await N.delete(`/system-files/backups/${encodeURIComponent(e)}`)}}));function Vm(e){let t=e.toLowerCase();return t.endsWith(`.json`)?`input-json`:t.endsWith(`.js`)||t.endsWith(`.ts`)||t.endsWith(`.mjs`)||t.endsWith(`.cjs`)?`input-code`:`input-textarea`}function Hm(e){return e.replace(/^\uFEFF/,``)}async function Um(e){await Z.getState().openFile(e.path);let t=Z.getState().selectedFile;if(!t)return;let n=Vm(e.name),r=typeof window<`u`?window.innerHeight:900,i=Math.max(18,Math.floor((r-240)/21))-2,a={content:t.content};if(n===`input-json`)try{let e=Hm(t.content);a.content=e.trim()?JSON.parse(e):{}}catch{a.content=Hm(t.content)}await G({title:`Edit: ${e.name}`,width:`80rem`,maxWidth:`calc(100vw - 2rem)`,model:a,fields:[{key:`content`,type:`input-code`,hide:()=>n!==`input-code`,props:{rows:i}},{key:`content`,type:`input-json`,hide:()=>n!==`input-json`,props:{rows:i}},{key:`content`,type:`input-textarea`,hide:()=>n!==`input-textarea`,props:{rows:i}}],onBeforeSubmit:async()=>{let t=a.content,n=typeof t==`string`?Hm(t):JSON.stringify(t,null,2);return await Z.getState().updateFile(e.path,n),!0}})}var Wm=class extends w{constructor(...e){super(...e),this.folders=[],this.files=[],this.selectedFolder=null,this.loading=!1,this.isDraggingFiles=!1,this.dragDepth=0}connectedCallback(){super.connectedCallback(),Q.getState().setPageMeta({title:`System Files`,description:`Browse and manage local API files in definitions/integrations/scripts/configs`,action:v`
        <div class="d-flex gap-2">
          <app-button variant='ghost' .icon=${Ka} @click=${()=>this.triggerUpload()} label="Upload"></app-button>
          <app-button variant="primary" background .icon=${O} @click=${()=>this.addFile()} label="Create File"></app-button>
        </div>
      `}),setTimeout(()=>{Z.getState().fetchFolders()})}disconnectedCallback(){Q.getState().setPageMeta(null),super.disconnectedCallback()}async handleFolderChange(e){await Z.getState().selectFolder(e)}async addFile(){let e={fileName:``,content:``};await G({title:`Create file`,model:e,fields:[{key:`fileName`,type:`input-text`,props:{label:`File name`,required:!0}},{key:`content`,type:`input-textarea`,props:{label:`Initial content`,rows:8}}],onBeforeSubmit:async()=>{let t=String(e.fileName||``).trim();if(!t)throw Error(`File name is required`);return await Z.getState().createFile(t,String(e.content||``)),!0}})}async deleteFile(e){await Z.getState().deleteFile(e.path)}async uploadFiles(e){if(e.length!==0)for(let t of e){let e=await t.arrayBuffer(),n=new Uint8Array(e),r=``;for(let e=0;e<n.length;e+=1)r+=String.fromCharCode(n[e]);let i=btoa(r);await Z.getState().uploadFile(t.name,i,`base64`)}}triggerUpload(){let e=document.createElement(`input`);e.type=`file`,e.multiple=!0,e.onchange=async()=>{await this.uploadFiles(Array.from(e.files||[]))},e.click()}handleDragEnter(e){e.dataTransfer?.types.includes(`Files`)&&(e.preventDefault(),this.dragDepth+=1,this.isDraggingFiles=!0)}handleDragOver(e){e.dataTransfer?.types.includes(`Files`)&&(e.preventDefault(),e.dataTransfer.dropEffect=`copy`)}handleDragLeave(e){e.dataTransfer?.types.includes(`Files`)&&(e.preventDefault(),this.dragDepth=Math.max(0,this.dragDepth-1),this.dragDepth===0&&(this.isDraggingFiles=!1))}async handleDrop(e){e.preventDefault(),this.dragDepth=0,this.isDraggingFiles=!1,await this.uploadFiles(Array.from(e.dataTransfer?.files||[]))}formatFileSize(e){return e<1024?`${e} B`:e<1024*1024?`${(e/1024).toFixed(1)} KB`:`${(e/(1024*1024)).toFixed(1)} MB`}formatDate(e){let t=new Date(e);return Number.isNaN(t.getTime())?`-`:t.toLocaleString()}get tabs(){return this.folders.map(e=>({id:e.key,label:e.label}))}get columns(){return[{key:`name`,label:`Name`,sortable:!0,filterable:!0,searchable:!0},{key:`size`,label:`Size`,sortable:!0,renderCell:e=>v`${this.formatFileSize(e)}`},{key:`updatedAt`,label:`Updated`,sortable:!0,renderCell:e=>v`${this.formatDate(e)}`}]}render(){return v`
      <div
        class="space-y-5 system-files-drop-zone ${this.isDraggingFiles?`is-dragging`:``}"
        @dragenter=${e=>this.handleDragEnter(e)}
        @dragover=${e=>this.handleDragOver(e)}
        @dragleave=${e=>this.handleDragLeave(e)}
        @drop=${e=>this.handleDrop(e)}
      >
        ${this.isDraggingFiles?v`
          <div class="system-files-drop-overlay">
            <app-icon .icon=${Ka} size="32"></app-icon>
            <div class="fs-5 fw-semibold">${j(`Drop files to upload`)}</div>
          </div>
        `:``}
        

        <app-tabs
          .items=${this.tabs}
          .activeId=${this.selectedFolder||``}
          ariaLabel="System file folders"
          @tab-change=${e=>this.handleFolderChange(e.detail.id)}
        ></app-tabs>

        <div class="mt-2">
            ${this.loading?v`<div class="text-gray-400 text-sm">${j(`Loading...`)}</div>`:v`
              <nq-table
                .data=${this.files}
                .columns=${this.columns}
                .options=${{id:`system-files`,mode:`ui`,sort:`name`,actions:e=>v`
        <div>
            <app-button
              variant="ghost"
              label="Edit"
              .icon=${A}
              @click=${()=>Um(e)}
            ></app-button>
          <app-button
            variant="ghost"
            className="text-danger"
            label="Remove"
            .icon=${k}
            ${B({title:`Delete file`,message:`Delete ${e.name}?`,variant:`danger`})}
            @click=${()=>this.deleteFile(e)}
          ></app-button>
        </div>
      `}}
              ></nq-table>
            `}
        </div>
      </div>
    `}};D([C(),H(Z,e=>e.folders)],Wm.prototype,`folders`,void 0),D([C(),H(Z,e=>e.files)],Wm.prototype,`files`,void 0),D([C(),H(Z,e=>e.selectedFolder)],Wm.prototype,`selectedFolder`,void 0),D([C(),H(Z,e=>e.loading)],Wm.prototype,`loading`,void 0),D([C()],Wm.prototype,`isDraggingFiles`,void 0),Wm=D([x(`system-files-view`)],Wm);var Gm=class extends w{constructor(...e){super(...e),this.currentPath=``,this.restarting=!1}connectedCallback(){super.connectedCallback(),this.updatePageMeta()}disconnectedCallback(){Q.getState().setPageMeta(null),super.disconnectedCallback()}updatePageMeta(){Q.getState().setPageMeta({title:`Update`,description:`Check for updates or install an NQ2 Local package`,action:v`
        <app-button
          variant="primary"
          background
          label=${this.restarting?`Restarting...`:`Restart APP`}
          .icon=${Yi}
          .disabled=${this.restarting}
          ${B({title:`Restart NQ2 Local`,message:`Restart NQ2 Local now? The application will be unavailable for a moment.`,variant:`danger`})}
          @click=${()=>this.restartApp()}
        ></app-button>
      `})}async restartApp(){if(!this.restarting){this.restarting=!0,this.updatePageMeta();try{await Z.getState().restartMainApp(),M.show({variant:`success`,message:`NQ2 Local is restarting`}),window.setTimeout(()=>window.location.reload(),5e3)}catch(e){this.restarting=!1,this.updatePageMeta(),M.show({variant:`danger`,message:e instanceof Error?e.message:`Cannot restart NQ2 Local.`})}}}render(){return v`
      <app-tabs
        .items=${[{id:`online`,label:`Online Update`,routerLink:`/settings/update/online`},{id:`file`,label:`Install from File`,routerLink:`/settings/update/file`},{id:`backups`,label:`Backups`,routerLink:`/settings/update/backups`}]}
        .activeId=${this.currentPath.includes(`/backups`)?`backups`:this.currentPath.includes(`/file`)?`file`:`online`}
        ariaLabel=${j(`Application update sections`)}
      ></app-tabs>
      <div class="mt-4"><router-outlet></router-outlet></div>
    `}};D([C(),zt()],Gm.prototype,`currentPath`,void 0),D([C()],Gm.prototype,`restarting`,void 0),Gm=D([x(`app-update-view`)],Gm);var Km=class extends w{constructor(...e){super(...e),this.version=null,this.checking=!1,this.installing=!1,this.error=``,this.installedVersion=``}async checkVersion(){if(!this.checking){this.checking=!0,this.error=``;try{this.version=await Z.getState().checkMainAppVersion()}catch(e){this.error=e instanceof Error?e.message:`Cannot check for a new version.`}finally{this.checking=!1}}}async installLatest(){if(!this.installing){this.installing=!0,this.error=``;try{let e=await Z.getState().installLatestMainApp();this.installedVersion=e.version||this.version?.latestVersion||`new version`,M.show({variant:`success`,message:`Update installed. NQ2 Local is restarting`}),window.setTimeout(()=>window.location.reload(),5e3)}catch(e){this.error=e instanceof Error?e.message:`Cannot install the update.`}finally{this.installing=!1}}}render(){return v`
      <div class="d-flex flex-column gap-4">
        ${this.error?v`<div class="alert alert-danger m-0">${this.error}</div>`:``}
        ${this.installedVersion?v`
          <div class="alert alert-success m-0">
            ${j(`Version {{version}} was installed. NQ2 Local is restarting.`,{version:this.installedVersion})}
          </div>
        `:``}
        <section class="bg-surface border rounded p-5">
          <div class="d-flex flex-wrap justify-content-between align-items-center gap-4">
            <div>
              <h2 class="fs-4 mt-0 mb-2">${j(`Online update`)}</h2>
              <p class="text-muted m-0">${j(`Check NQ2 Portal for the latest published NQ2 Local version.`)}</p>
            </div>
            <app-button
              variant="outline"
              label=${this.checking?`Checking...`:`Check new version`}
              .disabled=${this.checking||this.installing}
              @click=${()=>this.checkVersion()}
            ></app-button>
          </div>
          ${this.version?v`
            <div class="border-top mt-4 pt-4 d-flex flex-wrap justify-content-between align-items-center gap-4">
              <div class="d-flex flex-wrap gap-6">
                <div><div class="text-muted small">${j(`Installed version`)}</div><strong>${this.version.currentVersion}</strong></div>
                <div><div class="text-muted small">${j(`Latest version`)}</div><strong>${this.version.latestVersion}</strong></div>
                <div><div class="text-muted small">${j(`Channel`)}</div><strong>${this.version.channel||`-`}</strong></div>
              </div>
              ${this.version.updateAvailable?v`
                <app-button
                  label=${this.installing?`Installing...`:`Download and install`}
                  .disabled=${this.installing}
                  ${B({title:`Install NQ2 Local update`,message:`Download and install NQ2 Local ${this.version.latestVersion}? Only ui, index.js and package.json will be replaced.`})}
                  @click=${()=>this.installLatest()}
                ></app-button>
              `:v`<span class="text-success fw-semibold">${j(`You are using the latest version.`)}</span>`}
            </div>
          `:``}
        </section>
      </div>
    `}};D([C()],Km.prototype,`version`,void 0),D([C()],Km.prototype,`checking`,void 0),D([C()],Km.prototype,`installing`,void 0),D([C()],Km.prototype,`error`,void 0),D([C()],Km.prototype,`installedVersion`,void 0),Km=D([x(`app-update-online-view`)],Km);var qm=class extends w{constructor(...e){super(...e),this.archive=null,this.installing=!1,this.error=``,this.installedVersion=``}selectArchive(){let e=document.createElement(`input`);e.type=`file`,e.accept=`.zip,application/zip`,e.onchange=()=>{this.setArchive(e.files?.[0]||null)},e.click()}setArchive(e){if(e&&!e.name.toLowerCase().endsWith(`.zip`)){this.archive=null,this.error=`Select a ZIP update package.`;return}this.archive=e,this.error=``,this.installedVersion=``}handleDrop(e){e.preventDefault(),this.setArchive(e.dataTransfer?.files?.[0]||null)}formatSize(e){return e<1024*1024?`${Math.max(1,Math.round(e/1024))} KB`:`${(e/1024/1024).toFixed(1)} MB`}async installArchive(){if(!(!this.archive||this.installing)){this.installing=!0,this.error=``;try{let e=this.archive.name,t=new Uint8Array(await this.archive.arrayBuffer()),n=[];for(let e=0;e<t.length;e+=32768)n.push(String.fromCharCode(...t.subarray(e,e+32768)));let r=await Z.getState().installMainAppArchive(btoa(n.join(``)));this.installedVersion=r.version||e,this.archive=null,M.show({variant:`success`,message:`Package installed. NQ2 Local is restarting`}),window.setTimeout(()=>window.location.reload(),5e3)}catch(e){this.error=e instanceof Error?e.message:`Cannot install the selected package.`}finally{this.installing=!1}}}render(){return v`
      <div class="d-flex flex-column gap-4">
        ${this.error?v`<div class="alert alert-danger m-0">${this.error}</div>`:``}
        ${this.installedVersion?v`
          <div class="alert alert-success m-0">
            ${j(`Version {{version}} was installed. NQ2 Local is restarting.`,{version:this.installedVersion})}
          </div>
        `:``}
        <section class="bg-surface border rounded p-5">
          <h2 class="fs-4 mt-0 mb-2">${j(`Install from file`)}</h2>
          <p class="text-muted mb-4">${j(`Upload an NQ2 Local update package from your device.`)}</p>
          <div
            class="empty-state bg-surface w-100 flex-column gap-3 text-center cursor-pointer"
            style="min-height: 11rem;"
            role="button"
            tabindex="0"
            @click=${()=>this.selectArchive()}
            @keydown=${e=>{(e.key===`Enter`||e.key===` `)&&this.selectArchive()}}
            @dragover=${e=>e.preventDefault()}
            @drop=${this.handleDrop}
          >
            <app-icon .icon=${Ka} size="32"></app-icon>
            <div>
              <div class="fs-5 fw-semibold text-body mb-1">${this.archive?this.archive.name:j(`Choose update package`)}</div>
              <div class="text-muted">
                ${this.archive?`${this.formatSize(this.archive.size)} · ${j(`ZIP archive`)}`:j(`Click to select a ZIP file or drag it here`)}
              </div>
            </div>
          </div>
          ${this.archive?v`
            <div class="d-flex justify-content-end mt-4">
              <app-button
                label=${this.installing?`Installing...`:`Install selected version`}
                .disabled=${this.installing}
                ${B({title:`Install selected NQ2 Local version`,message:`Install ${this.archive.name}? Only ui, index.js and package.json will be replaced.`})}
                @click=${()=>this.installArchive()}
              ></app-button>
            </div>
          `:``}
        </section>
      </div>
    `}};D([C()],qm.prototype,`archive`,void 0),D([C()],qm.prototype,`installing`,void 0),D([C()],qm.prototype,`error`,void 0),D([C()],qm.prototype,`installedVersion`,void 0),qm=D([x(`app-update-file-view`)],qm);var Jm=class extends w{constructor(...e){super(...e),this.backups=[],this.loading=!0,this.creating=!1,this.error=``,this.columns=[{key:`name`,label:`Snapshot`,sortable:!0,searchable:!0},{key:`size`,label:`Size`,sortable:!0,renderCell:e=>this.formatSize(Number(e))},{key:`createdAt`,label:`Created`,type:`date`,dateFormat:`standard`,sortable:!0}]}connectedCallback(){super.connectedCallback(),this.load()}async load(){this.loading=!0,this.error=``;try{this.backups=await Z.getState().getMainAppBackups()}catch(e){this.error=e instanceof Error?e.message:`Cannot load snapshots.`}finally{this.loading=!1}}async createBackup(){if(!this.creating){this.creating=!0,this.error=``;try{await Z.getState().createMainAppBackup(),await this.load()}catch(e){this.error=e instanceof Error?e.message:`Cannot create snapshot.`}finally{this.creating=!1}}}async restoreBackup(e){this.error=``;try{await Z.getState().restoreMainAppBackup(e.name),window.setTimeout(()=>window.location.reload(),5e3)}catch(e){this.error=e instanceof Error?e.message:`Cannot restore snapshot.`}}async downloadBackup(e){try{await Z.getState().downloadMainAppBackup(e.name)}catch(e){this.error=e instanceof Error?e.message:`Cannot download snapshot.`}}async deleteBackup(e){this.error=``;try{await Z.getState().deleteMainAppBackup(e.name),await this.load()}catch(e){this.error=e instanceof Error?e.message:`Cannot delete snapshot.`}}formatSize(e){return e<1024*1024?`${Math.max(1,Math.round(e/1024))} KB`:`${(e/1024/1024).toFixed(1)} MB`}render(){let e={id:`main-app-backups`,mode:`ui`,loading:this.loading,sort:`-createdAt`,emptyMessage:`No snapshots created yet`,extra:v`
        <app-button
          label=${this.creating?`Creating...`:`Create snapshot`}
          .icon=${O}
          .disabled=${this.creating}
          @click=${()=>this.createBackup()}
        ></app-button>
      `,actions:e=>v`<div class="d-flex flex-wrap gap-1">
        <app-button
          variant="ghost"
          label="Download"
          .icon=${Tr}
          @click=${()=>this.downloadBackup(e)}
        ></app-button>
        <app-button
          variant="ghost"
          label="Restore"
          .icon=${Yi}
          ${B({title:`Restore snapshot`,message:`Restore ${e.name}? The current application files and database will be replaced. NQ2 Local will restart after the restore.`,variant:`danger`})}
          @click=${()=>this.restoreBackup(e)}
        ></app-button>
        <app-button
          variant="ghost"
          className="text-danger"
          label="Delete"
          .icon=${k}
          ${B({title:`Delete snapshot`,message:`Permanently delete ${e.name}?`,variant:`danger`})}
          @click=${()=>this.deleteBackup(e)}
        ></app-button>
      </div>`};return v`
      <div class="d-flex flex-column gap-4">
        ${this.error?v`<div class="alert alert-danger m-0">${this.error}</div>`:``}
        <div>
          <h2 class="fs-4 mt-0 mb-2">${j(`Snapshots`)}</h2>
          <p class="text-muted mb-4">${j(`Create a complete NQ2 Local snapshot, restore an earlier state or download a backup.`)}</p>
        </div>
        <nq-table .data=${this.backups} .columns=${this.columns} .options=${e}></nq-table>
      </div>
    `}};D([C()],Jm.prototype,`backups`,void 0),D([C()],Jm.prototype,`loading`,void 0),D([C()],Jm.prototype,`creating`,void 0),D([C()],Jm.prototype,`error`,void 0),Jm=D([x(`app-update-backups-view`)],Jm);var Ym={getConfig:()=>N.get(`/ai/config`),updateConfig:e=>N.put(`/ai/config`,e,!1),getConversations:()=>N.get(`/ai/conversations`),createConversation:()=>N.post(`/ai/conversations`,{},{notify:!1}),updateConversation:(e,t)=>N.put(`/ai/conversations/${encodeURIComponent(e)}`,{title:t},!1),deleteConversation:e=>N.delete(`/ai/conversations/${encodeURIComponent(e)}`),ask:(e,t)=>N.post(`/ai/ask`,{prompt:e,conversationId:t},{notify:!1})},Xm=e=>String(e||``).trim().replace(/\/+$/,``).toLowerCase()===`https://api.openai.com/v1`;async function Zm(e){let t={...e,apiKey:``},n=null;return await G({title:`AI Configuration`,size:`lg`,model:t,fields:[{key:`baseUrl`,type:`input-text`,props:{label:`API base URL`,required:!0,debounceMs:0}},{key:`model`,type:`input-text`,props:{label:`Model`,required:!0,debounceMs:0}},{key:`reasoningEffort`,type:`input-select`,hide:()=>!Xm(t.baseUrl),props:{label:`Reasoning effort`,required:!0,options:[{value:`low`,label:`Low`},{value:`medium`,label:`Medium`},{value:`high`,label:`High`},{value:`xhigh`,label:`Extra high`}]}},{key:`reasoningEffort`,type:`input-text`,hide:()=>Xm(t.baseUrl),props:{label:`Reasoning effort`,required:!0,debounceMs:0,placeholder:`For example: high or max`,help:`Enter the value supported by your AI provider.`}},{key:`apiKey`,type:`input-password`,props:{label:e.apiKeyConfigured?`New API key (leave empty to keep current)`:`API key`,required:!e.apiKeyConfigured}},{key:`conversationRetentionDays`,type:`input-number`,props:{label:`Conversation retention (days)`,required:!0,min:1,max:3650,help:`Conversations are automatically removed after this many days without activity.`}},{key:`systemPrompt`,type:`input-textarea`,props:{label:`Built-in system prompt`,rows:8,readonly:!0,help:`Security and NQ2 API rules. This prompt cannot be changed.`}},{key:`dynamicSystemPrompt`,type:`input-textarea`,props:{label:`Dynamic system prompt`,rows:7,help:`Editable preferences learned from explicit corrections in conversations.`}},{template:v`<div class="fw-semibold mt-2">${j(`Context shared with the model`)}</div>`},{key:`includeDevices`,type:`input-toggle`,props:{toggleLabel:`Devices and current states`}},{key:`includeDefinitions`,type:`input-toggle`,props:{toggleLabel:`Definitions`}},{key:`includeZones`,type:`input-toggle`,props:{toggleLabel:`Zones`}},{key:`includeSchedules`,type:`input-toggle`,props:{toggleLabel:`Schedules`}},{key:`includeCards`,type:`input-toggle`,props:{toggleLabel:`Cards`}},{key:`includeScripts`,type:`input-toggle`,props:{toggleLabel:`Scripts`}},{key:`includeIntegrations`,type:`input-toggle`,props:{toggleLabel:`Provider integrations`}}],onBeforeSubmit:async()=>(n=await Ym.updateConfig({baseUrl:String(t.baseUrl||``).trim(),model:String(t.model||``).trim(),reasoningEffort:String(t.reasoningEffort||``).trim(),apiKey:String(t.apiKey||``).trim()||void 0,dynamicSystemPrompt:String(t.dynamicSystemPrompt||``).trim(),includeDevices:!!t.includeDevices,includeDefinitions:!!t.includeDefinitions,includeCards:!!t.includeCards,includeScripts:!!t.includeScripts,includeZones:!!t.includeZones,includeSchedules:!!t.includeSchedules,includeIntegrations:!!t.includeIntegrations,conversationRetentionDays:Math.trunc(Number(t.conversationRetentionDays||30))}),M.show({variant:`success`,message:j(`AI configuration saved`)}),!0)}),n}async function Qm(e,t={}){let n={filename:String(t.targetId||e.filename||``).trim(),source:String(e.source||``)};await G({title:t.edit?`Edit provider integration`:`Create provider integration`,width:`80rem`,maxWidth:`calc(100vw - 2rem)`,model:n,fields:[{key:`filename`,type:`input-text`,props:{label:`File name`,required:!0,debounceMs:0}},{key:`source`,type:`input-code`,props:{label:`JavaScript source`,required:!0,rows:28}}],onBeforeSubmit:async()=>{let e=String(n.filename||``).trim();if(!e.toLowerCase().endsWith(`.js`))throw Error(`Integration file name must end with .js`);return await Z.getState().selectFolder(`integrations`),t.edit?await Z.getState().updateFile(t.targetId||e,String(n.source||``)):await Z.getState().createFile(e,String(n.source||``)),!0}})}async function $m(e){let t={title:e.title},n=null;return await G({title:`Rename conversation`,model:t,fields:[{key:`title`,type:`input-text`,props:{label:`Title`,required:!0,debounceMs:0}}],onBeforeSubmit:async()=>(n=await Ym.updateConversation(e.id,t.title.trim()),!0)}),n}var eh=class extends w{constructor(...e){super(...e),this.config=null,this.conversations=[],this.activeId=``,this.prompt=``,this.loading=!1,this.pendingPrompt=``,this.error=``,this.historyOpen=!1,this.openingArtifact=!1,this.compactLayout=!1,this.updateLayout=()=>{this.compactLayout=window.innerWidth<768}}connectedCallback(){super.connectedCallback(),this.activeId=``,this.historyOpen=!1,this.updateLayout(),window.addEventListener(`resize`,this.updateLayout),Q.getState().setPageMeta({title:`AI Assistant`,description:`Ask about local data and generate NQ2 proposals`,action:v`<app-button label="Configure" .icon=${ia} @click=${()=>this.openConfig()}></app-button>`}),this.load()}disconnectedCallback(){window.removeEventListener(`resize`,this.updateLayout),Q.getState().setPageMeta(null),super.disconnectedCallback()}get active(){return this.conversations.find(e=>e.id===this.activeId)}async load(){try{let[e,t]=await Promise.all([Ym.getConfig(),Ym.getConversations()]);if(this.config=e,this.conversations=t,!t.some(e=>e.id===this.activeId)){let n=t.find(e=>e.messages.length===0);if(n)this.activeId=n.id;else if(e.configured){let e=await Ym.createConversation();this.conversations=[e,...t],this.activeId=e.id}else this.activeId=``}await this.updateComplete,this.scrollToBottom()}catch(e){this.error=e instanceof Error?e.message:j(`Cannot load AI assistant.`)}}async selectChat(e){this.activeId=e,await this.updateComplete,this.scrollToBottom()}scrollToBottom(){let e=this.querySelector(`.ai-messages`);e&&(e.scrollTop=e.scrollHeight)}async newChat(){let e=this.conversations.find(e=>e.messages.length===0);if(e){this.activeId=e.id,this.prompt=``;return}let t=await Ym.createConversation();this.conversations=[t,...this.conversations],this.activeId=t.id,this.prompt=``}async editChat(e){let t=await $m(e);t&&(this.conversations=this.conversations.map(e=>e.id===t.id?t:e))}async removeChat(e){await Ym.deleteConversation(e),this.conversations=this.conversations.filter(t=>t.id!==e),this.activeId===e&&(this.activeId=this.conversations[0]?.id||``)}async openConfig(){this.config||await this.load();let e=this.config;if(!e)return;let t=await Zm(e);t&&(this.config=t)}async ask(e){if(e.preventDefault(),!this.prompt.trim()||this.loading)return;this.activeId||await this.newChat();let t=this.prompt.trim();this.pendingPrompt=t,this.prompt=``,this.loading=!0,this.error=``,await this.updateComplete,this.scrollToBottom();try{await Ym.ask(t,this.activeId),await this.load()}catch(e){this.error=e instanceof Error?e.message:j(`AI request failed.`),this.prompt=t}finally{this.pendingPrompt=``,this.loading=!1}}handlePromptInput(e){let t=e.target;this.prompt=t.value,t.style.height=`auto`,t.style.height=`${Math.min(t.scrollHeight,180)}px`}handlePromptKeydown(e){e.key===`Enter`&&!e.shiftKey&&!e.isComposing&&(e.preventDefault(),this.ask(e))}async useSuggestion(e){this.prompt=e,await this.updateComplete,this.querySelector(`.ai-prompt`)?.focus()}async copy(e){await this.copyText(typeof e.content==`string`?e.content:JSON.stringify(e.content,null,2))}async copyText(e){await navigator.clipboard.writeText(e),M.show({variant:`success`,message:j(`Generated object copied`)})}artifactContent(e){if(![`script`,`card`,`cards`,`definition`,`schedule`,`integration`].includes(e.type))return null;let t=e.content;if(typeof t==`string`)try{t=JSON.parse(t)}catch{return null}return e.type===`cards`?!Array.isArray(t)||!t.length||t.some(e=>!e||typeof e!=`object`||Array.isArray(e))?null:t:!t||typeof t!=`object`||Array.isArray(t)?null:t}artifactOperation(e){if(e.operation)return e.operation;let t=this.artifactContent(e);return e.type===`card`&&!Array.isArray(t)&&t?._id?`update`:`create`}async openArtifact(e){let t=this.artifactContent(e);if(!(!t||this.openingArtifact)){this.openingArtifact=!0;try{if(e.type===`cards`){let e=JSON.parse(JSON.stringify(t));await Promise.all([I.getState().fetchZones(),L.getState().fetchDevices()]);for(let t of e){for(let e of[`_id`,`_createdAt`,`_updatedAt`,`lastSeenAt`,`_fullName`,`_tab`])delete t[e];if(!await cf({data:t,edit:!1,onSubmit:e=>L.getState().addDevice(e)}))break}return}let n=JSON.parse(JSON.stringify(t));for(let e of[`_createdAt`,`_updatedAt`,`lastSeenAt`,`_fullName`])delete n[e];let r=this.artifactOperation(e),i=String(e.targetId||n._id||``).trim();if(e.type===`card`){if(await Promise.all([I.getState().fetchZones(),L.getState().fetchDevices()]),r===`update`){let e=i?L.getState().getDeviceById(i):void 0;if(!e)throw Error(j(`Cannot find the item selected for editing.`));await cf({data:{...e,...n,_id:i},edit:!0,onSubmit:e=>L.getState().updateDevice(i,e)})}else delete n._id,delete n._tab,await cf({data:n,edit:!1,onSubmit:e=>L.getState().addDevice(e)});return}if(e.type===`script`){if(await J.getState().fetchScripts(!0),r===`update`){let e=i?J.getState().getScriptById(i):void 0;if(!e)throw Error(j(`Cannot find the item selected for editing.`));await bm({script:{...e,...n,_id:i},edit:!0})}else await bm({script:n,edit:!1});return}if(e.type===`schedule`){if(await vp.getState().fetchCrons(!0),r===`update`){let e=i?vp.getState().getCronById(i):void 0;if(!e)throw Error(j(`Cannot find the item selected for editing.`));await Dp({cron:{...e,...n,_id:i},edit:!0})}else delete n._id,await Dp({cron:n,edit:!1});return}if(e.type===`integration`){await Qm({filename:String(n.filename||``),source:String(n.source||``)},{edit:r===`update`,targetId:i});return}if(await K.getState().fetchDefinitions(!0),r===`update`){let e=i?K.getState().getDefinitionById(i):void 0;if(!e)throw Error(j(`Cannot find the item selected for editing.`));await lp({definition:{...e,...n,_id:i},edit:!0})}else await lp({definition:n,edit:!1})}catch(e){M.show({variant:`danger`,message:e instanceof Error?e.message:j(`Cannot open the generated object.`)})}finally{this.openingArtifact=!1}}}renderInline(e){return e.replace(/\\([*`_#-])/g,`$1`).split(/(`[^`]+`|\*\*[^*]+\*\*)/g).filter(Boolean).map(e=>e.startsWith("`")&&e.endsWith("`")?v`<code class="d-inline-block border rounded-sm bg-body px-1 font-monospace" style="font-size:.9em;line-height:1.3">${e.slice(1,-1)}</code>`:e.startsWith(`**`)&&e.endsWith(`**`)?v`<strong>${e.slice(2,-2)}</strong>`:e)}renderText(e){return e.split(/```([\s\S]*?)```/g).map((e,t)=>t%2==1?(()=>{let t=e.replace(/^\w+\s*\n/,``);return v`<div class="position-relative min-w-0">
            <button type="button" class="btn btn-sm bg-dark position-absolute top-3 right-3" style="z-index:1" @click=${()=>this.copyText(t)}>${j(`Copy`)}</button>
            <pre class="overflow-auto rounded font-monospace p-4 my-2" style="max-height:30rem;padding-top:3.25rem!important;background:#15171a;color:#f4f4f5;line-height:1.5;white-space:pre"><code>${t}</code></pre>
          </div>`})():e.split(/\n\s*\n/).filter(e=>e.trim()).map(e=>{let t=e.trim().split(`
`);if(t.every(e=>/^\s*[-*]\s+/.test(e)))return v`<ul class="mb-4" style="padding-left:1.4rem">${t.map(e=>v`<li class="my-1">${this.renderInline(e.replace(/^\s*[-*]\s+/,``))}</li>`)}</ul>`;if(t.every(e=>/^\s*\d+[.)]\s+/.test(e)))return v`<ol class="mb-4" style="padding-left:1.4rem">${t.map(e=>v`<li class="my-1">${this.renderInline(e.replace(/^\s*\d+[.)]\s+/,``))}</li>`)}</ol>`;let n=e.match(/^#{1,3}\s+(.+)$/);return n?v`<h3 class="fs-6 mt-1 mb-3">${this.renderInline(n[1])}</h3>`:v`<p class="mt-0 mb-4">${t.map((e,t)=>v`${t?v`<br />`:``}${this.renderInline(e)}`)}</p>`}))}result(e){let t=this.artifactContent(e),n=this.artifactOperation(e);return v`<div class="form-stack min-w-0 gap-2 lh-base">
      ${e.title||e.summary?v`<div>${e.title?v`<strong>${e.title}</strong>`:``}${e.summary?v`<div class="text-muted small mt-1">${e.summary}</div>`:``}</div>`:``}
      ${typeof e.content==`string`&&e.type===`answer`?this.renderText(e.content):v`
        <div class="position-relative min-w-0">
          <div class="position-absolute top-3 right-3 d-flex align-items-center gap-2" style="z-index:1">
            ${t?v`<button type="button" class="btn btn-sm bg-light" ?disabled=${this.openingArtifact} @click=${()=>this.openArtifact(e)}>
              <app-icon .icon=${n===`update`?A:Qi} size="16"></app-icon>
              <span>${j(n===`update`?`Open`:`Save`)}</span>
            </button>`:``}
            <button type="button" class="btn btn-sm bg-dark" @click=${()=>this.copy(e)}>${j(`Copy`)}</button>
          </div>
          <pre class="overflow-auto rounded font-monospace p-4 my-2" style="max-height:30rem;padding-top:3.25rem!important;background:#15171a;color:#f4f4f5;line-height:1.5;white-space:pre"><code>${typeof e.content==`string`?e.content:JSON.stringify(e.content,null,2)}</code></pre>
        </div>`}
    </div>`}render(){let e=this.active?.messages.length||this.pendingPrompt?`width:100%`:`width:min(100%,48.75rem);margin-inline:auto`,t=this.compactLayout?`position:absolute;inset:0 auto 0 0;z-index:3;width:min(18rem,90vw);box-shadow:8px 0 24px rgb(15 23 42 / 12%)`:`width:18rem`;return v`<div class="form-stack gap-3">
      ${this.config?.configured?v`
      <div class="position-relative d-flex min-h-0 overflow-hidden bg-surface" style="height:clamp(30rem,calc(100dvh - 16rem),48rem)">
        ${this.historyOpen?v`<aside class="h-100 min-h-0 flex-shrink-0 overflow-hidden border-right bg-surface" style=${t}><div class="d-flex h-100 min-h-0 flex-column p-4">
          <div class="d-flex flex-shrink-0 align-items-center justify-content-between gap-2 mb-2">
            <div class="small fw-semibold text-muted text-uppercase px-2 py-1" style="letter-spacing:.06em">${j(`Conversations`)}</div>
            <button type="button" class="btn btn-plain btn-sm btn-square" title=${j(`Hide conversations`)} aria-label=${j(`Hide conversations`)} @click=${()=>{this.historyOpen=!1}}><app-icon .icon=${Ri} size="20"></app-icon></button>
          </div>
          <div class="flex-grow-1 min-h-0 overflow-auto">
            <button type="button" class="btn btn-plain w-100 justify-content-start px-2" @click=${()=>this.newChat()}><app-icon .icon=${O} size="18"></app-icon><span>${j(`New conversation`)}</span></button>
            ${this.conversations.length?this.conversations.map(e=>v`<div class="d-flex align-items-center gap-1 rounded mb-1 ${e.id===this.activeId?`bg-surface-subtle`:``}">
            <button class="btn btn-plain min-w-0 flex-grow-1 justify-content-start px-2 text-truncate" title=${e.title} @click=${()=>this.selectChat(e.id)}>${e.messages.length===0&&e.title===`New conversation`?j(`New conversation`):e.title}</button>
            <div class="d-flex flex-shrink-0 align-items-center"><button type="button" class="btn btn-plain btn-sm btn-square" title=${j(`Rename`)} aria-label=${j(`Rename conversation`)} @click=${()=>this.editChat(e)}><app-icon .icon=${A} size="18"></app-icon></button>
            <button type="button" class="btn btn-plain btn-danger btn-sm btn-square" title=${j(`Delete`)} aria-label=${j(`Delete conversation`)}
              ${B({title:j(`Delete conversation`),message:j(`Delete "{{name}}" and all its messages?`,{name:e.title}),variant:`danger`})}
              @click=${()=>this.removeChat(e.id)}><app-icon .icon=${k} size="18"></app-icon></button></div></div>`):v`<div class="text-muted px-2 py-4">${j(`No conversations yet`)}</div>`}
          </div>
        </div></aside>`:``}
        <section class="position-relative h-100 min-h-0 min-w-0 flex-grow-1 overflow-hidden bg-surface"><div class="d-flex h-100 min-h-0 flex-column overflow-hidden">
          ${this.historyOpen?``:v`<div class="position-absolute top-2 left-3" style="z-index:2"><button type="button" class="btn btn-plain btn-sm btn-square" title=${j(`Show conversations`)} aria-label=${j(`Show conversations`)} aria-expanded=${this.historyOpen} @click=${()=>{this.historyOpen=!0}}><app-icon .icon=${zi} size="20"></app-icon></button></div>`}
          <div class="ai-messages flex-grow-1 form-stack gap-3 overflow-auto bg-surface px-3 px-md-6 pt-6 pb-8" style="scroll-behavior:smooth">
            ${!this.active?.messages.length&&!this.pendingPrompt?v`<div class="mx-auto my-auto py-8" style="width:min(100%,48.75rem)">
              <h2 class="fs-4 mt-0 mb-2">${j(`How can I help?`)}</h2>
              <div class="text-muted">${j(`Ask about your NQ2 installation or describe something you want to create.`)}</div>
              <div class="d-grid grid-columns-1 grid-columns-md-2 gap-3 mt-6">
                <button class="btn btn-outline-ghost justify-content-start text-start" @click=${()=>this.useSuggestion(j(`Which devices currently have a low battery?`))}>${j(`Find devices with a low battery`)}</button>
                <button class="btn btn-outline-ghost justify-content-start text-start" @click=${()=>this.useSuggestion(j(`Explain how my current cards are connected to devices.`))}>${j(`Explain cards and device bindings`)}</button>
                <button class="btn btn-outline-ghost justify-content-start text-start" @click=${()=>this.useSuggestion(j(`Create a script based on my NQ2 devices.`))}>${j(`Create an NQ2 script`)}</button>
                <button class="btn btn-outline-ghost justify-content-start text-start" @click=${()=>this.useSuggestion(j(`Review my schedules and point out possible conflicts.`))}>${j(`Review schedules`)}</button>
              </div>
            </div>`:this.active?.messages.map(t=>t.role===`user`?v`<div class="d-flex justify-content-end" style=${e}><div class="border rounded-lg bg-body px-4 py-3 lh-base" style="max-width:min(78%,40.625rem);border-bottom-right-radius:.3rem!important;box-shadow:0 2px 8px rgb(15 23 42 / 5%);white-space:pre-wrap">${t.text}</div></div>`:t.result?v`<div class="d-grid gap-3" style="${e};grid-template-columns:2rem minmax(0,1fr)"><div class="d-grid bg-primary rounded fw-bold" style="width:2rem;height:2rem;place-items:center;font-size:.7rem;letter-spacing:.04em">AI</div><div class="min-w-0"><div class="small fw-bold text-primary text-uppercase mb-3" style="letter-spacing:.05em">NQ2 AI</div>${this.result(t.result)}</div></div>`:``)}
            ${this.pendingPrompt?v`
              <div class="d-flex justify-content-end" style=${e}><div class="border rounded-lg bg-body px-4 py-3 lh-base" style="max-width:min(78%,40.625rem);border-bottom-right-radius:.3rem!important;box-shadow:0 2px 8px rgb(15 23 42 / 5%);white-space:pre-wrap">${this.pendingPrompt}</div></div>
              <div class="d-grid gap-3" style="${e};grid-template-columns:2rem minmax(0,1fr)"><div class="d-grid bg-primary rounded fw-bold" style="width:2rem;height:2rem;place-items:center;font-size:.7rem;letter-spacing:.04em">AI</div><div class="min-w-0"><div class="small fw-bold text-primary text-uppercase mb-3" style="letter-spacing:.05em">NQ2 AI</div><div class="small text-muted py-2" aria-label=${j(`AI is responding`)}>${j(`Generating...`)}</div></div></div>
            `:``}
          </div>
          <div class="flex-shrink-0 bg-surface px-3 px-md-6 pb-3 pb-md-5"><form class="border rounded bg-body p-3 mx-auto" style="${e};box-shadow:0 4px 18px rgb(15 23 42 / 7%)" @submit=${this.ask}>
            <textarea class="ai-prompt w-100 border-0 bg-transparent text-body px-1 lh-base" style="min-height:3rem;max-height:11.25rem;overflow-y:auto;outline:0;resize:none;color:inherit;font:inherit" rows="1" maxlength="4000" .value=${this.prompt} .placeholder=${j(`Message NQ2 AI...`)} @input=${this.handlePromptInput} @keydown=${this.handlePromptKeydown}></textarea>
            <div class="d-flex justify-content-between align-items-center gap-2" style="min-height:var(--nq-control-height)">
              <span class="small text-muted">${j(`Enter to send · Shift+Enter for a new line`)}</span>
              <button class="btn btn-primary" style="min-width:8rem" type="submit" ?disabled=${this.loading||!this.prompt.trim()}>
                <span>${this.loading?j(`Generating...`):j(`Send`)}</span><app-icon .icon=${pn} size="17"></app-icon>
              </button>
            </div>
          </form></div>
        </div></section>
      </div>`:v`<div class="card"><div class="card-body text-center"><app-button label="Configure AI" @click=${()=>this.openConfig()}></app-button></div></div>`}
      ${this.error?v`<div class="alert alert-danger">${this.error}</div>`:``}
    </div>`}};D([C()],eh.prototype,`config`,void 0),D([C()],eh.prototype,`conversations`,void 0),D([C()],eh.prototype,`activeId`,void 0),D([C()],eh.prototype,`prompt`,void 0),D([C()],eh.prototype,`loading`,void 0),D([C()],eh.prototype,`pendingPrompt`,void 0),D([C()],eh.prototype,`error`,void 0),D([C()],eh.prototype,`historyOpen`,void 0),D([C()],eh.prototype,`openingArtifact`,void 0),D([C()],eh.prototype,`compactLayout`,void 0),eh=D([x(`ai-settings-view`)],eh);var Q=po()((e,t)=>({navItems:[{label:`Zones & Subzones`,description:`Manage the physical areas of your home`,path:`zones-and-subzones`,icon:ri,component:Lp},{label:`Providers`,description:`Add and manage providers from various integrations`,path:`providers`,icon:kn,component:Xp,children:[{path:`:providerId`,component:Zp,children:[{path:`devices`,component:om},{path:`console`,component:cm}]}]},{label:`Definitions`,description:`Manage data definitions and schemas`,path:`definitions`,icon:Mn,component:um},{label:`Devices`,description:`View and control all connected devices`,path:`devices`,icon:$t,component:lm},{label:`Cards`,description:`View and control virtual entities grouped from physical devices`,path:`cards`,icon:Qn,component:Bp},{label:`Schedules`,description:`Automate routines using time-based schedules and timers`,path:`schedules`,icon:Rn,component:Dm},{label:`Scripts`,description:`Create and manage scripts for advanced logic`,path:`scripts`,icon:fr,component:Em},{label:`AI Assistant`,description:`Ask about local data and generate configuration proposals`,path:`ai`,icon:en,component:eh},{label:`System Files`,description:`Browse and manage local API files in definitions/integrations/scripts/configs`,path:`system-files`,icon:Ir,component:Wm},{label:`Users`,description:`Manage user accounts and permissions`,path:`users`,icon:Ja,component:Am},{label:`Online`,description:`Enable secure remote access to your local instance`,path:`online-access`,icon:jr,component:Pm},{label:`Update`,description:`Check for updates or install an NQ2 Local package`,path:`update`,icon:Tr,component:Gm,children:[{path:``,redirectTo:`online`},{path:`online`,component:Km},{path:`file`,component:qm},{path:`backups`,component:Jm}]},{label:`Logs`,description:`Browse system and websocket audit logs`,path:`logs`,icon:$n,component:Fm,children:[{path:``,redirectTo:`history`},{path:`history`,component:Bm},{path:`triggers`,component:Rm}]}],pageMeta:null,setPageMeta:t=>e({pageMeta:t}),getNavItems:()=>t().navItems,getNavItemByPath:e=>t().navItems.find(t=>t.path===e)})),th=`settings-sidebar-mode`,nh=768,rh=class extends w{constructor(...e){super(...e),this.currentPath=``,this.pageMeta=null,this.sidebarMode=`full`,this.isMobile=!1}connectedCallback(){super.connectedCallback();let e=localStorage.getItem(th);e&&[`full`,`icons`].includes(e)&&(this.sidebarMode=e),this.isMobile=window.innerWidth<nh}toggleSidebar(){this.sidebarMode=this.sidebarMode===`full`?`icons`:`full`,localStorage.setItem(th,this.sidebarMode)}renderToggleButton(){let e=this.sidebarMode===`full`?un:dn;return v`
      <button
        class="btn px-2"
        @click=${()=>this.toggleSidebar()}
        title=${j(this.sidebarMode===`full`?`Collapse sidebar`:`Expand sidebar`)}
      >
        <app-icon .icon=${e} size="16"></app-icon>
      </button>
    `}renderSidebar(e){return this.isMobile?y:this.sidebarMode===`icons`?v`
        <aside class="flex-shrink-0">
          <div class="bg-surface rounded border py-3  d-flex flex-column">
            <nav class="d-flex flex-column flex-grow-1 gap-1">
              ${e.map(e=>v`
                <app-popover
                  placement="right"
                  .trigger=${v`
                    <button
                      routerLink=${`/settings/${e.path}`}
                      class="btn w-100 justify-content-start px-4 ${Et(`btn-primary`)}"
                    >
                      <app-icon .icon=${e.icon}></app-icon>
                    </button>
                  `}
                  .content=${v`<span class="text-nowrap">${j(e.label)}</span>`}
                ></app-popover>
              `)}
            </nav>
            <div class="d-flex justify-content-end pt-3">
              ${this.renderToggleButton()}
            </div>
          </div>
        </aside>
      `:v`
      <aside class="flex-shrink-0" style="width: 16rem; flex-basis: 16rem;">
        <div class="bg-surface rounded border p-3 d-flex flex-column">
          <nav class="d-flex flex-column flex-grow-1 gap-1">
            ${e.map(e=>v`
              <button
                routerLink=${`/settings/${e.path}`}
                class="btn w-100 justify-content-start px-4 ${Et(`btn-primary`)}"
              >
                <app-icon .icon=${e.icon} class="flex-shrink-0"></app-icon>
                <span>${j(e.label)}</span>
              </button>
            `)}
          </nav>
          <div class="d-flex justify-content-end pt-3">
            ${this.renderToggleButton()}
          </div>
        </div>

      </aside>
    `}render(){let e=this.currentPath?.split(`settings/`)?.[1]?.split(`/`)?.[0]||``,t=Q.getState().getNavItems(),n=t.find(t=>t.path===e),r=this.pageMeta?.title||n?.label||`Settings`,i=this.pageMeta?.description||n?.description||`Configure and manage your smart home system settings.`;return v`
      <div class="d-flex gap-6">
        ${this.renderSidebar(t)}

        <div class="min-w-0 flex-grow-1">
          <div class="bg-surface rounded border p-5">
            <div class="d-flex flex-wrap align-items-center justify-content-between gap-4 mb-5">
              <div class="d-flex align-items-center gap-4 min-w-0">
                <div class="border py-2 px-4 rounded">
                  <app-icon .icon=${n?.icon||ra} size="32"></app-icon>
                </div>
                <div class="min-w-0">
                  <h1 class="fs-2 fw-bold text-body m-0">${j(r)}</h1>
                  <p class="text-muted m-0">${j(i)}</p>
                </div>
              </div>
              ${this.pageMeta?.action?v`<div class="d-flex flex-shrink-0 align-items-center">${this.pageMeta.action}</div>`:y}
            </div>
            <router-outlet .routes=${this.routes}></router-outlet>
          </div>
        </div>
      </div>
    `}};D([S({attribute:!1})],rh.prototype,`routes`,void 0),D([C(),zt()],rh.prototype,`currentPath`,void 0),D([C(),H(Q,e=>e.pageMeta)],rh.prototype,`pageMeta`,void 0),D([C()],rh.prototype,`sidebarMode`,void 0),D([C()],rh.prototype,`isMobile`,void 0),rh=D([x(`settings-view`)],rh);var ih=class extends w{render(){return v`
      <div class="d-grid grid-columns-1 grid-columns-md-2 gap-4">
        ${Q.getState().getNavItems().map(e=>v`
          <button
            routerLink=${`/settings/${e.path}`}
            class="btn btn-card"
          >
            <span class="card-icon">
              <app-icon .icon=${e.icon} size="24"></app-icon>
            </span>
            <div class="flex-grow-1 min-w-0">
              <div class="d-flex align-items-center justify-content-between gap-2">
                <h4 class="card-title">${j(e.label)}</h4>
                ${e.badge?v`<span class="badge">${e.badge}</span>`:``}
              </div>
              <div class="text-muted">${j(e.description)}</div>
            </div>
          </button>
        `)}
      </div>
    `}};ih=D([x(`settings-default-view`)],ih);var ah,oh=0,sh=e=>[...e].sort((e,t)=>new Date(t.date).getTime()-new Date(e.date).getTime()),ch=(e,t)=>e?{...e,...t,message:t.message??e.message}:t,lh=(e,t)=>sh([ch(e.find(e=>e._id===t._id),t),...e.filter(e=>e._id!==t._id)]),uh=po()((e,t)=>({messages:[],loading:!1,unreadCount:0,total:0,page:1,limit:25,query:{page:1,limit:25},fetchMessages:async(n={})=>{let r={page:1,limit:25,...n};e({loading:!0});try{let n=await N.get(`/messages`,r),i=new Map(t().messages.map(e=>[e._id,e]));e({messages:sh(n.items.map(e=>ch(i.get(e._id),e))),total:n.total,page:n.page,limit:n.limit,query:r})}finally{e({loading:!1})}},fetchMessage:async n=>{let r=await N.get(`/messages/${n}`);return e({messages:lh(t().messages,r).slice(0,t().limit)}),r},connect:()=>{oh+=1,!ah&&(t().fetchMessages(),ah=N.sse(`/messages/changes`),ah.onmessage=n=>{let r=n.payload?.unreadCount;if(typeof r==`number`&&e({unreadCount:r}),n.type!==`message`)return;let i=n.payload?.type,a=n.payload?.id,o=n.payload?.message;if(i===`deleted`){a===`*`?t().fetchMessages():typeof a==`string`&&e({messages:t().messages.filter(e=>e._id!==a),total:Math.max(0,t().total-1)});return}if(!o){t().fetchMessages();return}e({messages:lh(t().messages,o).slice(0,t().limit)}),i===`created`&&!o.outgoing&&!rt().startsWith(`messages`)&&M.show({variant:o.priority===`high`?`warning`:`info`,message:`New message: ${o.title}`,actionLabel:`Read more`,action:()=>T(`messages/${o._id}`)})})},disconnect:()=>{oh=Math.max(0,oh-1),oh===0&&(ah?.close(),ah=void 0)},createMessage:async n=>{let r=await N.post(`/messages`,n);return(!r.outgoing||t().query.tab===`sent`)&&e({messages:lh(t().messages,r).slice(0,t().limit),total:t().total+1}),r},removeMessages:async n=>{let r=[...new Set(n.filter(Boolean))];r.length&&(await N.delete(`/messages`,{ids:r}),e({messages:t().messages.filter(e=>!r.includes(e._id)),total:Math.max(0,t().total-r.length)}))}})),dh=class extends b{constructor(...e){super(...e),this.dialogs=[],this.dialogLayouts={},this.minimizedDialogIds=new Set,this.minWidth=320,this.minHeight=180,this.dialogWidthBySize={sm:`350px`,md:`700px`,lg:`var(--nq-container-max-width, 1400px)`,xl:`calc(100vw - 2rem)`},this.dialogHeightBySize={sm:`25vh`,md:`50vh`,lg:`75vh`,xl:`calc(100vh - 2rem)`}}createRenderRoot(){return this}connectedCallback(){super.connectedCallback(),this.unsubscribe=z.subscribe(e=>{this.dialogs=e;let t=new Set(e.map(e=>e.id)),n=Object.fromEntries(Object.entries(this.dialogLayouts).filter(([e])=>t.has(e)));Object.keys(n).length!==Object.keys(this.dialogLayouts).length&&(this.dialogLayouts=n);let r=new Set([...this.minimizedDialogIds].filter(e=>t.has(e)));r.size!==this.minimizedDialogIds.size&&(this.minimizedDialogIds=r)}),this.handleEscape=this.handleEscape.bind(this),this.handlePointerMove=this.handlePointerMove.bind(this),this.handlePointerUp=this.handlePointerUp.bind(this),document.addEventListener(`keydown`,this.handleEscape),document.addEventListener(`pointermove`,this.handlePointerMove),document.addEventListener(`pointerup`,this.handlePointerUp)}disconnectedCallback(){super.disconnectedCallback(),this.unsubscribe?.(),document.removeEventListener(`keydown`,this.handleEscape),document.removeEventListener(`pointermove`,this.handlePointerMove),document.removeEventListener(`pointerup`,this.handlePointerUp)}handleEscape(e){if(e.key===`Escape`&&this.dialogs.length>0){let e=this.getTopVisibleDialog();if(!e)return;e.config.closeOnEscape!==!1&&this.handleCancel(e.id)}}handleBackdropClick(e,t,n){this.isDialogMinimized(t)||e.target===e.currentTarget&&n.closeOnBackdrop!==!1&&this.handleCancel(t)}handleClose(e){this.clearDialogLayout(e),this.clearMinimizedState(e),z.close(void 0,e)}handleCancel(e){let t=this.dialogs.find(t=>t.id===e);t&&this.isFormDialog(t.config)&&t.config.onCancel?.(),this.clearDialogLayout(e),this.clearMinimizedState(e),z.cancel(`cancelled`,e)}isFormDialog(e){return e&&`template`in e}mapVariant(e){return e===`secondary`?`primary`:e||`primary`}clearDialogLayout(e){if(!this.dialogLayouts[e])return;let{[e]:t,...n}=this.dialogLayouts;this.dialogLayouts=n}isDialogMinimized(e){return this.minimizedDialogIds.has(e)}clearMinimizedState(e){this.minimizedDialogIds.has(e)&&(this.minimizedDialogIds=new Set([...this.minimizedDialogIds].filter(t=>t!==e)))}minimizeDialog(e,t){t?.stopPropagation(),this.minimizedDialogIds=new Set([...this.minimizedDialogIds,e]),this.interaction?.dialogId===e&&this.handlePointerUp(),z.moveToBack(e)}restoreDialog(e,t){t?.stopPropagation(),this.clearMinimizedState(e),z.focus(e),setTimeout(()=>this.focusDialogElement(e),0)}focusDialogElement(e){document.querySelector(`[data-dialog-window][data-dialog-id="${e}"]`)?.focus({preventScroll:!0})}handleDialogPointerDown(e,t){z.focus(e),!t.target?.closest(`input, textarea, select, button, app-button, [tabindex]`)&&t.currentTarget.focus({preventScroll:!0})}getDialogElement(e){return e.currentTarget.closest(`[data-dialog-window]`)}getLayoutFromElement(e){let t=e.getBoundingClientRect();return{x:t.left,y:t.top,width:t.width,height:t.height}}clampLayout(e){let t=window.innerWidth,n=window.innerHeight,r=Math.min(Math.max(e.width,this.minWidth),Math.max(this.minWidth,t-16)),i=Math.min(Math.max(e.height,this.minHeight),Math.max(this.minHeight,n-16));return{x:Math.min(Math.max(e.x,8),Math.max(8,t-r-8)),y:Math.min(Math.max(e.y,8),Math.max(8,n-i-8)),width:r,height:i}}setDialogLayout(e,t){this.dialogLayouts={...this.dialogLayouts,[e]:this.clampLayout(t)}}shouldIgnoreDragStart(e){return!!e.target?.closest(`button, app-button, input, textarea, select, [data-no-dialog-drag]`)}startDrag(e,t,n=!0){if(t.button!==0||n&&this.shouldIgnoreDragStart(t))return;t.preventDefault(),t.stopPropagation();let r=this.getDialogElement(t);if(!r)return;let i=this.dialogLayouts[e]||this.getLayoutFromElement(r);this.interaction={dialogId:e,mode:`drag`,startX:t.clientX,startY:t.clientY,startLayout:i},this.setDialogLayout(e,i),document.body.style.userSelect=`none`}startResize(e,t,n){if(n.button!==0)return;n.preventDefault(),n.stopPropagation();let r=this.getDialogElement(n);if(!r)return;let i=this.dialogLayouts[e]||this.getLayoutFromElement(r);this.interaction={dialogId:e,mode:`resize`,edge:t,startX:n.clientX,startY:n.clientY,startLayout:i},this.setDialogLayout(e,i),document.body.style.userSelect=`none`}handlePointerMove(e){if(!this.interaction)return;let t=e.clientX-this.interaction.startX,n=e.clientY-this.interaction.startY,r=this.interaction.startLayout;if(this.interaction.mode===`drag`){this.setDialogLayout(this.interaction.dialogId,{...r,x:r.x+t,y:r.y+n});return}let i=this.interaction.edge||`se`,a={...r};i.includes(`e`)&&(a.width=r.width+t),i.includes(`s`)&&(a.height=r.height+n),i.includes(`w`)&&(a.x=r.x+t,a.width=r.width-t),i.includes(`n`)&&(a.y=r.y+n,a.height=r.height-n),a.width<this.minWidth&&(i.includes(`w`)&&(a.x=r.x+r.width-this.minWidth),a.width=this.minWidth),a.height<this.minHeight&&(i.includes(`n`)&&(a.y=r.y+r.height-this.minHeight),a.height=this.minHeight),this.setDialogLayout(this.interaction.dialogId,a)}handlePointerUp(){this.interaction&&(this.interaction=void 0,document.body.style.userSelect=``)}getDialogStyle(e,t){let n=this.dialogLayouts[e];if(n)return`
        position: fixed;
        left: ${n.x}px;
        top: ${n.y}px;
        width: ${n.width}px;
        height: ${n.height}px;
        max-width: calc(100vw - 1rem);
        max-height: calc(100vh - 1rem);
      `;let r=t?.size||`md`,i=t?.heightSize||`auto`;return`
      position: fixed;
      left: 50%;
      top: 50%;
      transform: translate(-50%, -50%);
      width: ${t?.width||this.dialogWidthBySize[r]||this.dialogWidthBySize.md};
      height: ${t?.height||(i===`auto`?`auto`:this.dialogHeightBySize[i]||`auto`)};
      max-width: ${t?.maxWidth||`calc(100vw - 2rem)`};
      max-height: ${t?.maxHeight||`calc(100vh - 2rem)`};
    `}renderResizeHandles(e){return[{edge:`n`,className:`modal-resize modal-resize-n`},{edge:`s`,className:`modal-resize modal-resize-s`},{edge:`e`,className:`modal-resize modal-resize-e`},{edge:`w`,className:`modal-resize modal-resize-w`},{edge:`ne`,className:`modal-resize modal-resize-ne`},{edge:`nw`,className:`modal-resize modal-resize-nw`},{edge:`se`,className:`modal-resize modal-resize-se`},{edge:`sw`,className:`modal-resize modal-resize-sw`}].map(t=>v`
      <div
        class=${t.className}
        @pointerdown=${n=>this.startResize(e,t.edge,n)}
      ></div>
    `)}renderMinimizedDialogs(){let e=this.dialogs.filter(e=>this.isDialogMinimized(e.id));return e.length===0?``:v`
      <div class="modal-minimized-list">
        ${e.map(e=>v`
          <div
            class="modal-minimized"
            @click=${t=>this.restoreDialog(e.id,t)}
            title=${e.config.title}
          >
            <app-icon .icon=${ln} size="16"></app-icon>
            <span class="modal-minimized-title">${e.config.title}</span>
            <button
              class="btn btn-plain btn-square"
              @click=${t=>{t.stopPropagation(),this.handleCancel(e.id)}}
              title="Close"
            >
              <app-icon .icon=${Gn} size="16"></app-icon>
            </button>
          </div>
        `)}
      </div>
    `}renderContent(e){return e==null?v``:typeof e==`string`?v`<p>${e}</p>`:e}getTopVisibleDialog(){let e=this.dialogs.filter(e=>!this.isDialogMinimized(e.id));if(e.length!==0)return e.find(e=>e.id===z.activeId)||e[e.length-1]}getDialogZIndex(e,t){return e===z.activeId?2500:1001+t*10}render(){return this.dialogs.length===0?v`<div class="d-none"></div>`:v`
      ${this.dialogs.filter(e=>!this.isDialogMinimized(e.id)).length>0?v`
        <div
          class="modal-backdrop"
          style="z-index: 1000"
          @click=${e=>{let t=this.getTopVisibleDialog();t&&this.handleBackdropClick(e,t.id,t.config)}}
        ></div>
      `:``}
      ${Vl(this.dialogs,e=>e.id,(e,t)=>{let n=e.config,r=this.isFormDialog(n),i=this.getDialogZIndex(e.id,t),a=this.isDialogMinimized(e.id),o=e.id===z.activeId,s=r?n.footer:void 0;return v`
            <div
              data-dialog-window
              data-dialog-id=${e.id}
              tabindex="-1"
              style=${`${this.getDialogStyle(e.id,n)} z-index: ${i};`}
              class="modal-dialog ${a?`d-none`:``} ${o?`active`:``}"
              @pointerdown=${t=>this.handleDialogPointerDown(e.id,t)}
              @click=${e=>e.stopPropagation()}
            >
              <div class="modal-header">
                <div class="modal-heading">
                  <h2 class="modal-title">${n.title}</h2>
                </div>
                <div class="modal-actions">
                  ${n.headerActions?v`<div class="modal-header-actions">${n.headerActions}</div>`:``}
                  <button
                    type="button"
                    class="btn btn-plain btn-square modal-drag"
                    @pointerdown=${t=>this.startDrag(e.id,t,!1)}
                    title="Move"
                  >
                    <app-icon .icon=${on} size="20"></app-icon>
                  </button>
                  <button
                    type="button"
                    class="btn btn-plain btn-square modal-minimize-button"
                    @click=${t=>this.minimizeDialog(e.id,t)}
                    title="Minimize"
                  >
                    <app-icon .icon=${Xi} size="20"></app-icon>
                  </button>
                  <button type="button" class="btn btn-plain btn-square modal-close-button" @click=${()=>this.handleCancel(e.id)} title="Close">
                    <app-icon .icon=${Gn} size="20"></app-icon>
                  </button>
                </div>
              </div>

              <div class="modal-body ${r?`modal-body-form`:``}">
                ${r?n.template:this.renderContent(n.content)}
              </div>

              ${s?v`<div class="modal-footer">${s}</div>`:``}

              ${n.buttons&&n.buttons.length>0?v`
                    <div class="modal-footer">
                      ${n.buttons.map(t=>v`
                          <app-button
                            .variant=${this.mapVariant(t.variant)}
                            ?background=${t.variant!==`ghost`}
                            label=${t.label}
                            @click=${async()=>{await t.action(),this.handleClose(e.id)}}
                          >
                          </app-button>
                        `)}
                    </div>
                  `:``}
              ${this.renderResizeHandles(e.id)}
            </div>
            `})}
      ${this.renderMinimizedDialogs()}
    `}};D([C(),E(`design:type`,Array)],dh.prototype,`dialogs`,void 0),D([C(),E(`design:type`,typeof Record>`u`?Object:Record)],dh.prototype,`dialogLayouts`,void 0),D([C(),E(`design:type`,Object)],dh.prototype,`minimizedDialogIds`,void 0),dh=D([x(`app-dialog`)],dh);async function fh(){await Om.getState().fetchUsers();let e=Om.getState().users,t=F.getState().user?.id,n={recipients:[],title:``,message:``,priority:`normal`,tags:[]};return await G({title:`Send message`,model:n,fields:[{key:`recipients`,type:`input-select`,props:{label:`Recipients`,multiple:!0,placeholder:`Everyone`,options:e.filter(e=>e._id&&e._id!==t).map(e=>({value:e._id,label:`${e.name} (${e.email})`}))}},{key:`title`,type:`input-text`,props:{label:`Title`,required:!0}},{key:`priority`,type:`input-radio`,props:{label:`Priority`,options:[{value:`normal`,label:`Normal`},{value:`high`,label:`High`}]}},{key:`message`,type:`input-textarea`,props:{label:`Message`,required:!0,help:`Safe HTML is supported.`}},{key:`tags`,type:`input-array-text`,props:{label:`Tags`}}],submitLabel:`Send`,onAfterSubmit:async()=>{await uh.getState().createMessage({...n,recipients:n.recipients.filter(Boolean)})}})}var $=class extends w{constructor(...e){super(...e),this.routeParams={},this.messages=[],this.loading=!1,this.total=0,this.apiPage=1,this.apiLimit=25,this.users=[],this.selectedId=``,this.selectedIds=[],this.search=``,this.draftSearch=``,this.activeTab=`all`,this.priorityFilter=``,this.draftPriorityFilter=``,this.tagFilter=``,this.draftTagFilter=``,this.dateFilter=``,this.draftDateFilter=``,this.authorFilter=``,this.draftAuthorFilter=``,this.pageSize=25}connectedCallback(){super.connectedCallback(),uh.getState().connect(),Om.getState().fetchUsers(),this.fetchMessages()}disconnectedCallback(){uh.getState().disconnect(),super.disconnectedCallback()}updated(e){e.has(`routeParams`)&&this.openRouteMessage();let t=this.routeParams.messageId||``,n=t?this.messages.find(e=>e._id===t):void 0;t&&n&&!n.message&&this.openRouteMessage(),this.selectedId&&!this.messages.some(e=>e._id===this.selectedId)&&(this.routeParams.messageId||(this.selectedId=``));let r=new Set(this.messages.map(e=>e._id)),i=this.selectedIds.filter(e=>r.has(e));i.length!==this.selectedIds.length&&(this.selectedIds=i)}get selectedMessage(){return this.messages.find(e=>e._id===this.selectedId)}get userId(){return F.getState().user?.id}get totalPages(){return Math.max(1,Math.ceil(this.total/this.apiLimit))}scrollMessagesToTop(){requestAnimationFrame(()=>{this.renderRoot.querySelector(`[data-messages-content]`)?.scrollIntoView({block:`start`,behavior:`smooth`})})}async selectMessage(e){this.routeParams.messageId!==e._id&&T(`messages/${e._id}`),this.selectedId=e._id,e.message||await uh.getState().fetchMessage(e._id),this.scrollMessagesToTop()}async openRouteMessage(){let e=this.routeParams.messageId||``;e&&(this.selectedId=e,!this.messages.find(t=>t._id===e)?.message&&await uh.getState().fetchMessage(e))}canDelete(e){return e.recipient===this.userId||e.author===this.userId}formatDate(e){return new Date(e).toLocaleString()}formatRecipientList(e){let t=this.users.find(t=>t._id===e.recipient);return t?`${t.name||t.email}${t.email?` (${t.email})`:``}`:e.recipient||`-`}async fetchMessages(e={}){let t=e.page??1;await uh.getState().fetchMessages({page:t,limit:this.pageSize,sort:`-date`,where:this.buildWhere()}),this.scrollMessagesToTop()}buildWhere(){return this.mergeWhere(this.getTabWhere(),this.getSearchWhere(),this.getPriorityWhere(),this.getTagWhere(),this.getDateWhere(),this.getAuthorWhere())}getTabWhere(){if(this.activeTab===`sent`)return{author:this.userId};if(this.activeTab===`unread`)return{read:!1};if(this.activeTab===`system`)return{author:{$exists:!1}};if(this.activeTab===`user`)return{author:{$exists:!0}}}getSearchWhere(){let e=this.search.trim();if(e)return{title:{$regex:this.escapeRegex(e),$options:`i`}}}getPriorityWhere(){return this.priorityFilter?{priority:this.priorityFilter}:void 0}getTagWhere(){let e=this.tagFilter.trim().toLowerCase();return e?{tags:{$in:[e]}}:void 0}getDateWhere(){if(!this.dateFilter)return;let e=new Date(`${this.dateFilter}T00:00:00.000`);if(Number.isNaN(e.getTime()))return;let t=new Date(e);return t.setDate(t.getDate()+1),{date:{$gte:e.toISOString(),$lt:t.toISOString()}}}getAuthorWhere(){let e=this.authorFilter.trim().toLowerCase();if(!e)return;let t=this.users.filter(t=>`${t.name||``} ${t.email||``}`.toLowerCase().includes(e)).map(e=>({author:e._id}));return`system`.includes(e)&&t.push({author:{$exists:!1}}),t.length?{$or:t}:{author:`__missing-author__`}}mergeWhere(...e){let t=e.filter(e=>!!(e&&Object.keys(e).length));if(!t.length)return{};let n={},r=[];for(let e of t)Object.keys(e).some(e=>e.startsWith(`$`))?r.push(e):Object.assign(n,e);return r.length&&(n.$and=r),n}escapeRegex(e){return e.replace(/[.*+?^${}()|[\]\\]/g,`\\$&`)}setTab(e){this.activeTab=e,this.fetchMessages({page:1})}setSelected(e,t){this.selectedIds=t?[...new Set([...this.selectedIds,e])]:this.selectedIds.filter(t=>t!==e)}async deleteSelected(){let e=[...this.selectedIds];await uh.getState().removeMessages(e),this.selectedIds=[],await this.fetchMessages({page:Math.min(this.apiPage,this.totalPages)})}selectAllCurrentPage(){let e=this.messages.filter(e=>this.canDelete(e)).map(e=>e._id);this.selectedIds=[...new Set([...this.selectedIds,...e])]}unselectAll(){this.selectedIds=[]}applySearch(){this.search=this.draftSearch,this.fetchMessages({page:1})}applyFilters(){this.priorityFilter=this.draftPriorityFilter,this.tagFilter=this.draftTagFilter,this.dateFilter=this.draftDateFilter,this.authorFilter=this.draftAuthorFilter,this.fetchMessages({page:1})}clearFilters(){this.priorityFilter=``,this.tagFilter=``,this.dateFilter=``,this.authorFilter=``,this.draftPriorityFilter=``,this.draftTagFilter=``,this.draftDateFilter=``,this.draftAuthorFilter=``,this.fetchMessages({page:1})}renderTags(e){return v`
      <div class="d-flex flex-wrap gap-1">
        ${e.map(e=>v`<span class="badge">${e}</span>`)}
      </div>
    `}renderTabs(){return v`
      <div class="tabs mb-3">
        ${[{key:`all`,label:`All`},{key:`sent`,label:`Sent`},{key:`unread`,label:`Unread`},{key:`system`,label:`System`},{key:`user`,label:`User`}].map(e=>v`
          <button
            type="button"
            class="tab-link ${this.activeTab===e.key?`active`:``}"
            @click=${()=>this.setTab(e.key)}
          >
            ${j(e.label)}
          </button>
        `)}
      </div>
    `}renderFilters(){return v`
      <div class="d-flex flex-wrap gap-3 mb-4">
        <input
          class="form-control max-w-20rem"
          type="search"
          placeholder=${j(`Search message`)}
          .value=${this.draftSearch}
          @input=${e=>{this.draftSearch=e.target.value}}
          @keydown=${e=>{e.key===`Enter`&&this.applySearch()}}
          @change=${()=>this.applySearch()}
        />
        <app-dropdown
          .fixedMenu=${!0}
          .showIndicator=${!0}
          .trigger=${{variant:`primary`,outline:!0,icon:Lr,label:`Filter`,badge:this.activeFilterCount?String(this.activeFilterCount):void 0}}
          .menu=${v`
            <div class="p-3 d-flex flex-column gap-3" style="width: min(24rem, calc(100vw - 2rem));">
              <label class="d-flex flex-column gap-1">
                <span class="small fw-semibold text-muted">Priority</span>
                <select
                  class="form-control"
                  .value=${this.draftPriorityFilter}
                  @change=${e=>{this.draftPriorityFilter=e.target.value}}
                >
                  <option value="">All priorities</option>
                  <option value="high">High</option>
                  <option value="normal">Normal</option>
                </select>
              </label>
              <label class="d-flex flex-column gap-1">
                <span class="small fw-semibold text-muted">Tag</span>
                <input
                  class="form-control"
                  type="text"
                  placeholder="Tag"
                  .value=${this.draftTagFilter}
                  @input=${e=>{this.draftTagFilter=e.target.value}}
                />
              </label>
              <label class="d-flex flex-column gap-1">
                <span class="small fw-semibold text-muted">Date</span>
                <input
                  class="form-control"
                  type="date"
                  .value=${this.draftDateFilter}
                  @input=${e=>{this.draftDateFilter=e.target.value}}
                />
              </label>
              <label class="d-flex flex-column gap-1">
                <span class="small fw-semibold text-muted">From</span>
                <input
                  class="form-control"
                  type="text"
                  placeholder="Author"
                  .value=${this.draftAuthorFilter}
                  @input=${e=>{this.draftAuthorFilter=e.target.value}}
                />
              </label>
              <div class="d-flex justify-content-end gap-2" data-dropdown-close>
                <app-button
                  variant="ghost"
                  label="Clear filters"
                  ?disabled=${this.activeFilterCount===0}
                  @click=${()=>this.clearFilters()}
                ></app-button>
                <app-button
                  label="Confirm"
                  @click=${()=>this.applyFilters()}
                ></app-button>
              </div>
            </div>
          `}
        ></app-dropdown>
      </div>
    `}get activeFilterCount(){return[this.priorityFilter,this.tagFilter,this.dateFilter,this.authorFilter].filter(Boolean).length}renderMessageCard(e){let t=this.selectedIds.includes(e._id),n=this.canDelete(e),r=e.priority===`high`?`border-warning`:e._id===this.selectedId?`border-success`:``,i=this.activeTab===`sent`?`To ${this.formatRecipientList(e)}: ${e.title}`:`${e.authorName}: ${e.title}`;return v`
      <article class="card ${r}">
        <div class="card-body d-flex gap-3 align-items-start p-3">
          <label class="form-check flex-shrink-0" @click=${e=>e.stopPropagation()}>
            <input
              type="checkbox"
              class="form-native-control"
              .checked=${t}
              ?disabled=${!n}
              @change=${t=>this.setSelected(e._id,t.target.checked)}
            />
            <span class="form-check-mark ${t?`is-checked`:``}">
              ${t?v`
                <svg class="form-check-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M5 13l4 4L19 7"></path>
                </svg>
              `:``}
            </span>
          </label>
          <button
            type="button"
            class="d-block w-100 border-0 bg-transparent p-0 flex-grow-1 min-w-0 text-left cursor-pointer"
            style="appearance: none; font: inherit; color: inherit;"
            @click=${()=>this.selectMessage(e)}
          >
            <div class="d-flex justify-content-between gap-3 align-items-start">
              <div class="min-w-0">
                <div class="fw-bold text-break">${i}</div>
                <div class="small text-muted text-break mt-2">${e.preview}</div>
                ${e.tags.length?v`<div class="mt-3">${this.renderTags(e.tags)}</div>`:``}
              </div>
              <div class="d-flex align-items-center gap-2 flex-shrink-0">
                <span class="small text-muted text-nowrap">${this.formatDate(e.date)}</span>
                <span class="circle ${e.read?`circle-success`:`circle-danger`}"></span>
              </div>
            </div>
          </button>
        </div>
      </article>
    `}renderMessageList(){return this.loading?v`<div class="p-4 text-muted">${j(`Loading messages...`)}</div>`:this.messages.length?v`
      <div class="d-flex flex-column gap-3">
        ${this.messages.map(e=>this.renderMessageCard(e))}
      </div>
    `:v`<div class="empty-state p-8">${j(`No messages`)}</div>`}renderPagination(){return v`
      <div class="d-flex flex-wrap justify-content-between align-items-center gap-3 p-3 border-top">
        <div class="text-muted">
          ${j(this.total===1?`{{count}} message`:`{{count}} messages`,{count:this.total})}
        </div>
        <div class="d-flex align-items-center gap-2">
          <app-button
            size="sm"
            variant="ghost"
            label=${j(`Previous`)}
            ?disabled=${this.apiPage<=1}
            @click=${()=>this.fetchMessages({page:Math.max(1,this.apiPage-1)})}
          ></app-button>
          <span class="text-muted">${j(`Page {{page}} of {{pages}}`,{page:Math.min(this.apiPage,this.totalPages),pages:this.totalPages})}</span>
          <app-button
            size="sm"
            variant="ghost"
            label=${j(`Next`)}
            ?disabled=${this.apiPage>=this.totalPages}
            @click=${()=>this.fetchMessages({page:Math.min(this.totalPages,this.apiPage+1)})}
          ></app-button>
        </div>
      </div>
    `}renderSelectedMessage(e){if(!e)return v`<div class="empty-state">${j(`Select a message`)}</div>`;let t=e.author===this.userId;return v`
      <div class="card">
        <div class="card-body">
          <div class="d-flex justify-content-between gap-4 align-items-start mb-6">
            <div class="min-w-0">
              <h2 class="m-0 text-break">${e.title}</h2>
              <div class="text-muted mt-1">
                From: ${e.authorName}${e.authorEmail?` (${e.authorEmail})`:``}
              </div>
              <div class="text-muted mt-1">
                To: ${this.formatRecipientList(e)}
              </div>
            </div>
            <div class="d-flex align-items-center gap-2 flex-shrink-0">
              <span class="small text-muted text-nowrap">${this.formatDate(e.date)}</span>
              <span class="circle ${e.read?`circle-success`:`circle-danger`}"></span>
            </div>
          </div>

          ${e.tags.length?v`<div class="mb-6">
            <div class="small text-muted fw-semibold mb-2">Tags</div>
            <div class="d-flex flex-wrap gap-1">
              ${e.tags.map(e=>v`<span class="badge">${e}</span>`)}
            </div>
          </div>`:``}

          <div class="border-bottom mb-6"></div>
          <div class="text-body lh-base text-break">${ys(Fc(e.message||``))}</div>
          <div class="border-bottom my-6"></div>

          <div class="d-flex flex-wrap align-items-center gap-3 text-muted small">
            <span class="circle ${e.read?`circle-success`:`circle-danger`}"></span>
            <span>${e.read?`Read`:`Unread`}</span>
            <span class="border-right h-100"></span>
            <span>Message ID: ${e._id}</span>
          </div>

          <div class="d-flex flex-wrap gap-2 mt-4">
            ${this.canDelete(e)?v`
                <app-button
                  size="sm"
                  variant="danger"
                  label="Delete"
                  .icon=${k}
                  ${V(t?{content:`Deleting a sent message removes it for the recipient too.`,placement:`top`}:null)}
                  ${B({title:`Delete message`,message:t?`Delete "${e.title}" for you and the recipient?`:`Delete "${e.title}"?`,variant:`danger`})}
                  @click=${async()=>{await uh.getState().removeMessages([e._id]),T(`messages`)}}
                ></app-button>
              `:``}
          </div>
        </div>
      </div>
    `}render(){let e=this.selectedMessage,t=this.selectedIds.length,n=this.activeTab===`sent`&&t>0;return v`
      <div class="card overflow-hidden">
        <div class="card-body border-bottom">
          <div class="d-flex justify-content-between align-items-center gap-4">
            <div class="d-flex align-items-center gap-4 min-w-0">
              <span class="card-icon">
                <app-icon .icon=${Si}></app-icon>
              </span>
              <div class="min-w-0">
                <h1 class="m-0">Messages</h1>
                <div class="text-muted mt-1">${j(`Browse system and user messages`)}</div>
              </div>
            </div>
            <div class="d-flex flex-wrap justify-content-end gap-2">
              ${t?v`
                  <app-button
                    variant="ghost"
                    label="Select All"
                    ?disabled=${this.messages.every(e=>!this.canDelete(e))}
                    @click=${()=>this.selectAllCurrentPage()}
                  ></app-button>
                  <app-button
                    variant="ghost"
                    label="Unselect All"
                    @click=${()=>this.unselectAll()}
                  ></app-button>
                  <app-button
                    variant="danger"
                    .outline=${!0}
                    label=${`Delete selected (${t})`}
                    .icon=${k}
                    ${V(n?{content:`Deleting sent messages removes them for recipients too.`,placement:`top`}:null)}
                    ${B({title:`Delete selected messages`,message:n?`Delete ${t} selected sent message${t===1?``:`s`} for recipients too?`:`Delete ${t} selected message${t===1?``:`s`}?`,variant:`danger`})}
                    @click=${()=>this.deleteSelected()}
                  ></app-button>
                `:``}
              <app-button
                .background=${!0}
                label="Create Message"
                .icon=${O}
                @click=${fh}
              ></app-button>
            </div>
          </div>
        </div>

        <div class="d-grid grid-columns-1 grid-columns-lg-2 gap-4 align-items-start p-4" data-messages-content>
          <section class="card min-h-0 overflow-hidden">
            <div class="card-body">
              ${this.renderFilters()}
              ${this.renderTabs()}
              ${this.renderMessageList()}
            </div>
            ${this.renderPagination()}
          </section>

          <section class="min-h-0">
            ${this.renderSelectedMessage(e)}
          </section>
        </div>
      </div>
    `}};D([S({attribute:!1})],$.prototype,`routeParams`,void 0),D([C(),H(uh,e=>e.messages)],$.prototype,`messages`,void 0),D([C(),H(uh,e=>e.loading)],$.prototype,`loading`,void 0),D([C(),H(uh,e=>e.total)],$.prototype,`total`,void 0),D([C(),H(uh,e=>e.page)],$.prototype,`apiPage`,void 0),D([C(),H(uh,e=>e.limit)],$.prototype,`apiLimit`,void 0),D([C(),H(Om,e=>e.users)],$.prototype,`users`,void 0),D([C()],$.prototype,`selectedId`,void 0),D([C()],$.prototype,`selectedIds`,void 0),D([C()],$.prototype,`search`,void 0),D([C()],$.prototype,`draftSearch`,void 0),D([C()],$.prototype,`activeTab`,void 0),D([C()],$.prototype,`priorityFilter`,void 0),D([C()],$.prototype,`draftPriorityFilter`,void 0),D([C()],$.prototype,`tagFilter`,void 0),D([C()],$.prototype,`draftTagFilter`,void 0),D([C()],$.prototype,`dateFilter`,void 0),D([C()],$.prototype,`draftDateFilter`,void 0),D([C()],$.prototype,`authorFilter`,void 0),D([C()],$.prototype,`draftAuthorFilter`,void 0),$=D([x(`messages-view`)],$);var ph=class extends b{constructor(...e){super(...e),this.brandLink=``,this.navItems=[],this.userName=``,this.userEmail=``,this.showUser=!0,this.hideMobileUser=!1}createRenderRoot(){return this}get displayName(){return this.userName||this.userEmail||`User`}handleMobileNavClick(e){if(e.externalUrl){window.location.assign(e.externalUrl);return}T(e.path)}renderUserTrigger(e=!1){return v`
      <div class="d-flex align-items-center gap-3 ${e?`navbar-user-compact`:`pr-1`}">
        <div class="navbar-avatar">
          <app-icon .icon=${Xa} size="18"></app-icon>
        </div>
        <div class="d-flex flex-column align-items-start min-w-0 navbar-user">
          <span class="fw-medium text-truncate w-100">${this.displayName}</span>
          ${e?``:v`<span class="small text-muted text-truncate w-100">${this.userEmail}</span>`}
        </div>
      </div>
    `}renderDesktopNav(){return v`
      <nav class="navbar-nav d-none d-lg-flex">
        ${this.navItems.map(e=>v`
          <button
            routerLink=${e.path}
            class="navbar-link ${Et(`active`,``)}"
          >
            ${e.icon?v`<app-icon .icon=${e.icon} size="18"></app-icon>`:``}
            ${e.label}
          </button>
        `)}
      </nav>
    `}renderMobileMenu(){let e=this.mobileNavItems||this.navItems;return v`
      ${e.map(e=>v`
        ${e.separatorBefore?v`<app-dropdown-item separator></app-dropdown-item>`:``}
        <app-dropdown-item
          label=${e.label}
          .icon=${e.icon}
          @item-click=${()=>this.handleMobileNavClick(e)}
        ></app-dropdown-item>
      `)}
      ${e.length>0&&this.userMenu?v`<app-dropdown-item separator></app-dropdown-item>`:``}
      ${this.userMenu}
    `}render(){return v`
      <header class="navbar">
        <div class="navbar-container">
          <div class="d-flex align-items-center justify-content-between gap-4">
            <div class="d-flex align-items-center gap-6 min-w-0">
              ${this.brandLink?v`<button type="button" class="navbar-brand-button" @click=${()=>T(this.brandLink)}>${this.brand}</button>`:this.brand}
              ${this.renderDesktopNav()}
            </div>

            <div class="d-flex align-items-center gap-2">
              ${this.actions}
              ${this.showUser?v`
                    <div class="d-none d-lg-block">
                      <app-dropdown
                        align="right"
                        .trigger=${this.renderUserTrigger(!1)}
                        .menu=${this.userMenu}
                      ></app-dropdown>
                    </div>
                    <div class="d-lg-none ${this.hideMobileUser?`d-none`:``}">
                      <app-dropdown
                        align="right"
                        .trigger=${this.renderUserTrigger(!0)}
                        .menu=${this.renderMobileMenu()}
                      ></app-dropdown>
                    </div>
                  `:``}
            </div>
          </div>
        </div>
      </header>
    `}};D([S({attribute:!1}),E(`design:type`,Object)],ph.prototype,`brand`,void 0),D([S({type:String}),E(`design:type`,Object)],ph.prototype,`brandLink`,void 0),D([S({attribute:!1}),E(`design:type`,Array)],ph.prototype,`navItems`,void 0),D([S({attribute:!1}),E(`design:type`,Array)],ph.prototype,`mobileNavItems`,void 0),D([S({type:String}),E(`design:type`,Object)],ph.prototype,`userName`,void 0),D([S({type:String}),E(`design:type`,Object)],ph.prototype,`userEmail`,void 0),D([S({attribute:!1}),E(`design:type`,Object)],ph.prototype,`userMenu`,void 0),D([S({attribute:!1}),E(`design:type`,Object)],ph.prototype,`actions`,void 0),D([S({type:Boolean}),E(`design:type`,Object)],ph.prototype,`showUser`,void 0),D([S({type:Boolean}),E(`design:type`,Object)],ph.prototype,`hideMobileUser`,void 0),ph=D([x(`app-navbar`)],ph);var mh=class extends w{constructor(...e){super(...e),this.toasts=[],this.expandedIds=new Set,this.pausedIds=new Set,this.timers=new Map,this.startTimes=new Map,this.remainingTimes=new Map}connectedCallback(){super.connectedCallback(),this.unsubscribe=M.subscribe(()=>{let e=M.getToasts(),t=new Set(e.map(e=>e.id));for(let e of this.timers.keys())t.has(e)||(clearTimeout(this.timers.get(e)),this.timers.delete(e),this.startTimes.delete(e),this.remainingTimes.delete(e),this.expandedIds.delete(e),this.pausedIds.delete(e));for(let t of e)this.timers.has(t.id)||this.startAutoClose(t.id,t.duration);this.toasts=e})}disconnectedCallback(){super.disconnectedCallback(),this.unsubscribe?.();for(let e of this.timers.values())clearTimeout(e);this.timers.clear()}startAutoClose(e,t){this.remainingTimes.set(e,t),this.startTimes.set(e,Date.now());let n=window.setTimeout(()=>{M.remove(e)},t);this.timers.set(e,n)}handleMouseEnter(e){let t=this.timers.get(e);t&&(clearTimeout(t),this.timers.delete(e));let n=this.startTimes.get(e),r=this.remainingTimes.get(e)??1e4;if(n){let t=Date.now()-n;this.remainingTimes.set(e,Math.max(0,r-t))}this.pausedIds=new Set([...this.pausedIds,e]),this.requestUpdate()}handleMouseLeave(e){this.pausedIds=new Set([...this.pausedIds].filter(t=>t!==e));let t=this.remainingTimes.get(e)??1e4;this.startAutoClose(e,t),this.requestUpdate()}handleClose(e){let t=this.timers.get(e);t&&clearTimeout(t),this.timers.delete(e),M.remove(e)}toggleDetails(e){let t=new Set(this.expandedIds);t.has(e)?t.delete(e):t.add(e),this.expandedIds=t}handleAction(e){e.action?.(),this.handleClose(e.id)}formatDetails(e){if(typeof e==`string`)return e;try{return JSON.stringify(e,null,2)}catch{return String(e)}}getVariantClass(e=`error`){return`toast-${e===`error`?`danger`:e}`}renderIcon(e=`error`){return e===`success`?v`<svg fill="currentColor" viewBox="0 0 20 20">
        <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.857-9.809a.75.75 0 00-1.214-.882l-3.483 4.79-1.88-1.88a.75.75 0 10-1.06 1.061l2.5 2.5a.75.75 0 001.137-.089l4-5.5z" clip-rule="evenodd"/>
      </svg>`:v`<svg fill="currentColor" viewBox="0 0 20 20">
      <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.28 7.22a.75.75 0 00-1.06 1.06L8.94 10l-1.72 1.72a.75.75 0 101.06 1.06L10 11.06l1.72 1.72a.75.75 0 101.06-1.06L11.06 10l1.72-1.72a.75.75 0 00-1.06-1.06L10 8.94 8.28 7.22z" clip-rule="evenodd"/>
    </svg>`}renderToast(e){let t=this.pausedIds.has(e.id),n=this.expandedIds.has(e.id);return v`
      <div
        class="toast ${this.getVariantClass(e.variant)}"
        @mouseenter=${()=>this.handleMouseEnter(e.id)}
        @mouseleave=${()=>this.handleMouseLeave(e.id)}
      >
        <div class="toast-header">
          <div class="toast-icon">
            ${this.renderIcon(e.variant)}
          </div>
          <p class="toast-message">${e.message}</p>
          <button
            class="btn btn-plain toast-close"
            @click=${()=>this.handleClose(e.id)}
          >
            <svg fill="currentColor" viewBox="0 0 20 20">
              <path fill-rule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clip-rule="evenodd"/>
            </svg>
          </button>
        </div>

        ${e.action?v`
          <div class="toast-details">
            <button
              class="toast-details-toggle"
              @click=${()=>this.handleAction(e)}
            >
              ${e.actionLabel||`Read more`}
            </button>
          </div>
        `:e.details?v`
          <div class="toast-details">
            <button
              class="toast-details-toggle"
              @click=${()=>this.toggleDetails(e.id)}
            >
              ${n?`Hide details`:`Read more`}
            </button>
            ${n?v`
              <pre class="toast-details-content">${this.formatDetails(e.details)}</pre>
            `:y}
          </div>
        `:y}

        <div class="toast-progress">
          <div
            class="toast-progress-bar"
            style="animation-duration: ${e.duration}ms; animation-play-state: ${t?`paused`:`running`};"
          ></div>
        </div>
      </div>
    `}render(){return this.toasts.length===0?y:v`
      <div class="toast-container">
        ${this.toasts.map(e=>this.renderToast(e))}
      </div>
    `}};D([C(),E(`design:type`,Array)],mh.prototype,`toasts`,void 0),D([C(),E(`design:type`,Object)],mh.prototype,`expandedIds`,void 0),D([C(),E(`design:type`,Object)],mh.prototype,`pausedIds`,void 0),mh=D([x(`toast-container`)],mh);var hh=`nq-theme`,gh=`dark`;function _h(){let e=localStorage.getItem(hh);return e===`light`||e===`dark`?e:gh}function vh(e){document.documentElement.dataset.theme=e}function yh(e){localStorage.setItem(hh,e),vh(e)}function bh(){let e=_h();return vh(e),e}var xh=class extends w{constructor(...e){super(...e),this.unreadCount=0,this.connectedToMessages=!1,this.handleVisibilityChange=()=>this.syncConnection()}syncConnection(){let e=!document.hidden&&this.isConnected;e!==this.connectedToMessages&&(this.connectedToMessages=e,e?uh.getState().connect():uh.getState().disconnect())}connectedCallback(){super.connectedCallback(),document.addEventListener(`visibilitychange`,this.handleVisibilityChange),this.syncConnection()}disconnectedCallback(){super.disconnectedCallback(),document.removeEventListener(`visibilitychange`,this.handleVisibilityChange),this.connectedToMessages&&(this.connectedToMessages=!1,uh.getState().disconnect())}render(){return v`
      <button
        type="button"
        class="btn btn-plain btn-square"
        title="Messages"
        aria-label="${this.unreadCount} unread messages"
        @click=${()=>T(`messages`)}
      >
        <app-icon .icon=${Si} size="20"></app-icon>
        ${this.unreadCount?v`<span class="btn-badge">${this.unreadCount>99?`99+`:this.unreadCount}</span>`:``}
      </button>
    `}};D([C(),H(uh,e=>e.unreadCount)],xh.prototype,`unreadCount`,void 0),xh=D([x(`message-notifications`)],xh);var Sh=`nq-selected-zone-path`,Ch=`nq-cards-home`,wh=[{label:`Cards`,path:`cards`,icon:Qn},{label:`Schedules`,path:`schedules`,icon:Bn},{label:`Devices`,path:`devices`,icon:mr},{label:`Settings`,path:`settings`,icon:ra}],Th=class extends w{constructor(...e){super(...e),this.routeParams={},this.title=``,this.subtitle=``,this.navItems=wh,this.theme=_h()}handleLogout(){F.getState().logout(),T(`login`,{replace:!0})}handleThemeChange(){this.theme=_h()===`dark`?`light`:`dark`,yh(this.theme)}async handleBrandClick(){await I.getState().initializeIfNeeded();let e=[...I.getState().zones].filter(e=>e.parent===null).sort((e,t)=>e.order-t.order)[0],t=e?[e.id]:[];localStorage.setItem(Sh,JSON.stringify({path:t,includeSubzones:!1})),localStorage.removeItem(`nq-cards-selected-zone`),localStorage.removeItem(`nq-cards-selected-subzone`),window.dispatchEvent(new CustomEvent(Ch,{detail:{path:t}})),L.getState().fetchDevices(),T(`cards`)}get isAdmin(){return this.user?.role===`admin`}get isScoped(){return this.user?.role===`scoped`}get visibleNavItems(){if(this.isAdmin)return this.navItems;let e=this.isScoped?[`cards`]:[`cards`,`schedules`];return this.navItems.filter(t=>e.includes(t.path))}async handleChangePassword(){await G({title:j(`Change Password`),fields:[{key:`currentPassword`,type:`input-password`,props:{label:j(`Current Password`),required:!0}},{key:`newPassword`,type:`input-password`,props:{label:j(`New Password`),required:!0,autogenerate:!0}}],model:{currentPassword:``,newPassword:``},submitLabel:j(`Change`),onAfterSubmit:async e=>{await F.getState().changePassword(e.currentPassword,e.newPassword)}})}async handleProfile(){if(!this.user)return;let e={name:this.user.name||``,language:this.user.language||wo()};await G({title:j(`Profile`),model:e,fields:[{key:`name`,type:`input-text`,props:{label:j(`Display name`),required:!0}},{key:`language`,type:`input-select`,props:{label:j(`Language`),required:!0,options:[{value:`en`,label:`English`},{value:`pl`,label:`Polski`}]}}],onBeforeSubmit:async()=>(await Co((await F.getState().updateMe({name:String(e.name||``).trim(),language:e.language})).language||wo()),!0)})&&(M.show({message:j(`Profile saved.`),variant:`success`}),window.setTimeout(()=>window.location.reload(),250))}render(){return!this.routes||this.routes.length===0?y:v`
      <div class="d-flex min-vh-100 flex-column">
        <app-navbar
          .brand=${v`
            <button
              type="button"
              class="navbar-brand-button"
              aria-label="Go to the first cards zone"
              @click=${this.handleBrandClick}
            >
              <span class="navbar-brand-lockup">
                <span class="navbar-brand-logo" aria-label="NQ2" role="img">${xs(qc)}</span>
                <span class="navbar-brand-version">LOCAL ${this.appVersion}</span>
              </span>
            </button>
          `}
          .navItems=${this.visibleNavItems.map(e=>({...e,label:j(e.label)}))}
          userName=${this.user?.name??``}
          userEmail=${this.user?.email??``}
          .actions=${v`<message-notifications></message-notifications>`}
          .userMenu=${v`
            <app-dropdown-item
              label=${j(this.theme===`dark`?`Light mode`:`Dark mode`)}
              .icon=${this.theme===`dark`?Ta:Ai}
              @item-click=${this.handleThemeChange}
            ></app-dropdown-item>
            <app-dropdown-item
              label=${j(`Profile`)}
              .icon=${Xa}
              @item-click=${()=>this.handleProfile()}
            ></app-dropdown-item>
            <app-dropdown-item
              label=${j(`Change Password`)}
              .icon=${Zi}
              @item-click=${()=>this.handleChangePassword()}
            ></app-dropdown-item>
            <app-dropdown-item separator></app-dropdown-item>
            <app-dropdown-item
              label=${j(`Logout`)}
              .icon=${xi}
              @item-click=${()=>this.handleLogout()}
            ></app-dropdown-item>
          `}
        ></app-navbar>

        <main class="flex-grow-1 pt-4 pb-8 bg-body">
          <div class="container">
            <router-outlet .routes=${this.routes}></router-outlet>
          </div>
        </main>

        <app-dialog></app-dialog>
        <toast-container></toast-container>
      </div>
    `}};D([H(Jc,e=>e.version)],Th.prototype,`appVersion`,void 0),D([S({attribute:!1})],Th.prototype,`routes`,void 0),D([S({attribute:!1})],Th.prototype,`routeParams`,void 0),D([S({type:String})],Th.prototype,`title`,void 0),D([S({type:String})],Th.prototype,`subtitle`,void 0),D([S({attribute:!1})],Th.prototype,`navItems`,void 0),D([H(F,e=>e.user)],Th.prototype,`user`,void 0),D([C()],Th.prototype,`theme`,void 0),Th=D([x(`main-layout`)],Th);var Eh=()=>{if(F.getState().isLoggedIn)return!0;let e=rt();return e&&e!==`login`?`login?redirect=${encodeURIComponent(e)}`:`login`},Dh=()=>F.getState().isLoggedIn?`cards`:!0,Oh=()=>F.getState().user?.role===`admin`?!0:`cards`,kh=()=>F.getState().user?.role===`scoped`?`cards`:!0;xo({fallbackLanguage:`en`,supportedLanguages:[`en`,`pl`],storageKey:`local.language`,loaders:{en:()=>Mo(()=>import(`./en-Cl1tp7Un.js`),[]),pl:()=>Mo(()=>import(`./pl-DOIpZKYP.js`),[])}}),bh();var Ah=class extends w{constructor(...e){super(...e),this.i18nInitialized=!1}connectedCallback(){super.connectedCallback(),Jc.getState().initialize(),this.initializeApp()}async initializeApp(){await F.getState().initialize(),await So(F.getState().user?.language),this.i18nInitialized=!0}render(){if(!this.isInitialized||!this.i18nInitialized)return v`
        <div class="d-flex min-vh-100 align-items-center justify-content-center bg-body-secondary">
          <div class="spinner-border text-primary"></div>
        </div>
      `;let e=[{path:``,component:ih},...this.settingsNavItems.filter(e=>e.component).map(e=>{let t={path:e.path,component:e.component};return e.children&&e.children.length>0&&(t.children=e.children),t})];return v`<router-outlet .routes=${[{path:``,redirectTo:`cards`},{path:`login`,component:Yc,canActivate:Dh},{path:``,component:Th,canActivate:Eh,children:[{path:`cards`,component:xf},{path:`devices`,component:hp,canActivate:Oh},{path:`schedules`,component:Op,canActivate:kh},{path:`messages/:messageId`,component:$},{path:`messages`,component:$},{path:`todos`,component:Mp,children:[{path:`:id`,component:Np}]},{path:`settings`,component:rh,canActivate:Oh,children:e}]},{path:`**`,redirectTo:`cards`}]}></router-outlet>`}};D([C()],Ah.prototype,`i18nInitialized`,void 0),D([H(Q,e=>e.getNavItems())],Ah.prototype,`settingsNavItems`,void 0),D([H(F,e=>e.isInitialized)],Ah.prototype,`isInitialized`,void 0),Ah=D([x(`my-app`)],Ah);